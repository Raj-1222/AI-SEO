<?php
/**
 * Verify that all fixes have been applied to the server
 */

echo "<!DOCTYPE html><html><head><title>Verify Fixes Applied</title>";
echo "<style>
body{font-family:Arial,sans-serif;padding:20px;background:#f5f5f5}
.box{background:white;padding:20px;margin:20px 0;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}
.success{color:#28a745;font-weight:bold}
.error{color:#dc3545;font-weight:bold}
.warning{color:#ffc107;font-weight:bold}
h1{color:#333}h2{color:#666;border-bottom:2px solid #667eea;padding-bottom:10px}
pre{background:#f8f9fa;padding:10px;border-radius:4px;overflow-x:auto;font-size:12px}
.check{display:inline-block;width:30px}
</style></head><body>";

echo "<h1>🔍 Verify Fixes Applied</h1>";

$allGood = true;

// Check 1: audit.php has try-catch
echo "<div class='box'>";
echo "<h2>Check 1: api/audit.php - Error Handling</h2>";
$auditContent = file_get_contents(__DIR__ . '/api/audit.php');
if (strpos($auditContent, 'ob_start()') !== false && strpos($auditContent, 'try {') !== false) {
    echo "<p class='success'><span class='check'>✅</span> Output buffering and try-catch blocks found</p>";
} else {
    echo "<p class='error'><span class='check'>❌</span> Missing output buffering or try-catch blocks</p>";
    echo "<p class='warning'>⚠️ The fixed version was not uploaded to the server!</p>";
    $allGood = false;
}
echo "</div>";

// Check 2: pagespeed.php has try-catch
echo "<div class='box'>";
echo "<h2>Check 2: api/pagespeed.php - Error Handling</h2>";
$pagespeedContent = file_get_contents(__DIR__ . '/api/pagespeed.php');
if (strpos($pagespeedContent, 'ob_start()') !== false && strpos($pagespeedContent, 'try {') !== false) {
    echo "<p class='success'><span class='check'>✅</span> Output buffering and try-catch blocks found</p>";
} else {
    echo "<p class='error'><span class='check'>❌</span> Missing output buffering or try-catch blocks</p>";
    echo "<p class='warning'>⚠️ The fixed version was not uploaded to the server!</p>";
    $allGood = false;
}
echo "</div>";

// Check 3: technical-seo.php has try-catch
echo "<div class='box'>";
echo "<h2>Check 3: api/technical-seo.php - Error Handling</h2>";
$technicalContent = file_get_contents(__DIR__ . '/api/technical-seo.php');
if (strpos($technicalContent, 'ob_start()') !== false && strpos($technicalContent, 'try {') !== false) {
    echo "<p class='success'><span class='check'>✅</span> Output buffering and try-catch blocks found</p>";
} else {
    echo "<p class='error'><span class='check'>❌</span> Missing output buffering or try-catch blocks</p>";
    echo "<p class='warning'>⚠️ The fixed version was not uploaded to the server!</p>";
    $allGood = false;
}
echo "</div>";

// Check 4: audit.js has graceful PageSpeed handling
echo "<div class='box'>";
echo "<h2>Check 4: assets/js/audit.js - Graceful PageSpeed Handling</h2>";
$auditJsContent = file_get_contents(__DIR__ . '/assets/js/audit.js');
if (strpos($auditJsContent, 'pageSpeedData = { success: false') !== false) {
    echo "<p class='success'><span class='check'>✅</span> Graceful PageSpeed handling found</p>";
} else {
    echo "<p class='error'><span class='check'>❌</span> Missing graceful PageSpeed handling</p>";
    echo "<p class='warning'>⚠️ The fixed version was not uploaded to the server!</p>";
    $allGood = false;
}
echo "</div>";

// Check 5: Test audit.php directly
echo "<div class='box'>";
echo "<h2>Check 5: Direct API Test - audit.php</h2>";
echo "<p>Testing if audit.php returns clean JSON...</p>";

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 2; // Temporary for testing
}

$ch = curl_init('http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/api/audit.php');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['url' => 'https://example.com']),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Cookie: ' . session_name() . '=' . session_id()
    ]
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<p><strong>HTTP Code:</strong> $httpCode</p>";
echo "<p><strong>Response Preview:</strong></p>";
echo "<pre>" . htmlspecialchars(substr($response, 0, 300)) . "...</pre>";

$data = json_decode($response, true);
if (json_last_error() === JSON_ERROR_NONE) {
    echo "<p class='success'><span class='check'>✅</span> Valid JSON response</p>";
    echo "<p><strong>Success:</strong> " . ($data['success'] ? 'true' : 'false') . "</p>";
    echo "<p><strong>Message:</strong> " . htmlspecialchars($data['message'] ?? 'N/A') . "</p>";
} else {
    echo "<p class='error'><span class='check'>❌</span> Invalid JSON - " . json_last_error_msg() . "</p>";
    
    // Check if it's HTML
    if (stripos($response, '<!DOCTYPE') !== false || stripos($response, '<html') !== false) {
        echo "<p class='error'><strong>⚠️ PROBLEM: API is returning HTML instead of JSON!</strong></p>";
        echo "<p>This means there's a PHP error or the fixed files weren't uploaded.</p>";
    }
    $allGood = false;
}
echo "</div>";

// Summary
echo "<div class='box' style='background:" . ($allGood ? '#d4edda' : '#f8d7da') . "'>";
echo "<h2>📊 Summary</h2>";
if ($allGood) {
    echo "<p class='success' style='font-size:18px'>✅ ALL CHECKS PASSED!</p>";
    echo "<p>All fixes have been applied correctly. The issue might be browser cache.</p>";
    echo "<h3>Next Steps:</h3>";
    echo "<ol>";
    echo "<li><strong>Clear browser cache:</strong> Ctrl+Shift+Delete → Clear all</li>";
    echo "<li><strong>Try incognito mode:</strong> Ctrl+Shift+N</li>";
    echo "<li><strong>Hard refresh:</strong> Ctrl+F5</li>";
    echo "<li><strong>Check console:</strong> F12 → Console tab</li>";
    echo "</ol>";
} else {
    echo "<p class='error' style='font-size:18px'>❌ SOME CHECKS FAILED</p>";
    echo "<p>The fixed files have NOT been uploaded to the server yet.</p>";
    echo "<h3>How to Fix:</h3>";
    echo "<ol>";
    echo "<li>Download the fixed files from your local 'c:\\Users\\rajee\\Downloads\\ai seo\\' folder</li>";
    echo "<li>Upload these files to your server (replacing the old ones):</li>";
    echo "<ul>";
    echo "<li>api/audit.php</li>";
    echo "<li>api/pagespeed.php</li>";
    echo "<li>api/technical-seo.php</li>";
    echo "<li>assets/js/audit.js</li>";
    echo "</ul>";
    echo "<li>Refresh this page to verify</li>";
    echo "</ol>";
}
echo "</div>";

echo "<div class='box'>";
echo "<h3>🔗 Useful Links</h3>";
echo "<ul>";
echo "<li><a href='test-audit-visual.html'>Visual API Test</a></li>";
echo "<li><a href='quick-audit-test.php'>Quick API Test</a></li>";
echo "<li><a href='view-errors.php'>View Error Logs</a></li>";
echo "<li><a href='views/dashboard/website-audit.php'>Website Audit Dashboard</a></li>";
echo "</ul>";
echo "</div>";

echo "</body></html>";
