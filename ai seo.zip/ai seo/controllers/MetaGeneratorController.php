<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/MetaTag.php';

class MetaGeneratorController {
    private $db;
    private $metaTag;
    private $apiKey;
    private $apiUrl;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->metaTag = new MetaTag($this->db);
        // Use OpenAI API
        $this->apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : GEMINI_API_KEY;
        $this->apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : GEMINI_API_URL;
    }
    
    // Generate meta tags using Gemini AI
    public function generateMetaTags($focusKeyword, $websiteUrl = '', $pageType = 'general') {
        if (empty($this->apiKey) || $this->apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            return [
                'success' => false,
                'message' => 'Gemini API key not configured'
            ];
        }
        
        $prompt = $this->buildMetaPrompt($focusKeyword, $websiteUrl, $pageType);
        $response = $this->callGeminiAPI($prompt);
        
        if (!$response['success']) {
            return $response;
        }
        
        $metaData = $this->parseMetaResponse($response['content']);
        
        if ($metaData['success']) {
            $metaData['seo_score'] = $this->calculateSEOScore($metaData);
        }
        
        return $metaData;
    }
    
    // Build meta generation prompt
    private function buildMetaPrompt($focusKeyword, $websiteUrl, $pageType) {
        $urlContext = !empty($websiteUrl) ? "Website URL: $websiteUrl" : "";
        
        $prompt = <<<EOT
You are an expert SEO copywriter. Generate optimized meta tags for:

**FOCUS KEYWORD:** {$focusKeyword}
**PAGE TYPE:** {$pageType}
{$urlContext}

**REQUIRED OUTPUT (STRICT JSON):**

{
  "seo_title": "60 character optimized title with keyword",
  "meta_description": "155 character compelling description with keyword and CTA",
  "og_title": "Facebook-optimized title (60 chars)",
  "og_description": "Facebook-optimized description (155 chars)",
  "og_image_suggestion": "Suggested image type/theme",
  "twitter_title": "Twitter-optimized title (60 chars)",
  "twitter_description": "Twitter-optimized description (155 chars)",
  "twitter_image_suggestion": "Suggested image for Twitter card",
  "focus_keyword_density": "optimal keyword usage note",
  "additional_keywords": ["related", "semantic", "keywords"]
}

**REQUIREMENTS:**
- SEO Title: 50-60 characters (include focus keyword naturally)
- Meta Description: 150-160 characters (compelling, actionable, include keyword)
- Use power words and emotional triggers
- Include clear value proposition
- Natural keyword integration (no stuffing)
- Mobile-friendly and clickable
- OpenGraph optimized for social sharing
- Twitter Card optimized for engagement

**TONE:** Professional, engaging, conversion-focused
EOT;
        
        return $prompt;
    }
    
    // Call OpenAI API (replaces Gemini)
    private function callGeminiAPI($prompt) {
        $url = $this->apiUrl;
        
        $data = [
            'model' => defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are an expert SEO copywriter. Generate compelling meta tags in valid JSON format only.'
                ],
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'temperature' => 0.7,
            'max_tokens' => 1500
            // JSON mode temporarily disabled for compatibility
            // 'response_format' => ['type' => 'json_object']
        ];
        
        try {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $this->apiKey
                ],
                CURLOPT_TIMEOUT => 120,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($error) {
                return ['success' => false, 'message' => 'API request failed: ' . $error];
            }
            
            if ($httpCode !== 200) {
                $errorData = json_decode($response, true);
                $errorMsg = $errorData['error']['message'] ?? 'HTTP ' . $httpCode;
                return ['success' => false, 'message' => 'OpenAI API error: ' . $errorMsg];
            }
            
            $result = json_decode($response, true);
            
            if (!$result || !isset($result['choices'][0]['message']['content'])) {
                return ['success' => false, 'message' => 'Invalid API response'];
            }
            
            return [
                'success' => true,
                'content' => $result['choices'][0]['message']['content']
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Exception: ' . $e->getMessage()];
        }
    }
    
    // Parse meta response
    private function parseMetaResponse($content) {
        $content = preg_replace('/```json\s*/', '', $content);
        $content = preg_replace('/```\s*$/', '', $content);
        $content = trim($content);
        
        $data = json_decode($content, true);
        
        if (!$data) {
            preg_match('/\{[\s\S]*\}/', $content, $matches);
            if ($matches) {
                $data = json_decode($matches[0], true);
            }
        }
        
        if (!$data) {
            return [
                'success' => false,
                'message' => 'Failed to parse meta data'
            ];
        }
        
        return [
            'success' => true,
            'seo_title' => $data['seo_title'] ?? '',
            'meta_description' => $data['meta_description'] ?? '',
            'og_title' => $data['og_title'] ?? $data['seo_title'] ?? '',
            'og_description' => $data['og_description'] ?? $data['meta_description'] ?? '',
            'og_image_suggestion' => $data['og_image_suggestion'] ?? '',
            'twitter_title' => $data['twitter_title'] ?? $data['seo_title'] ?? '',
            'twitter_description' => $data['twitter_description'] ?? $data['meta_description'] ?? '',
            'twitter_image_suggestion' => $data['twitter_image_suggestion'] ?? '',
            'focus_keyword_density' => $data['focus_keyword_density'] ?? '',
            'additional_keywords' => $data['additional_keywords'] ?? []
        ];
    }
    
    // Calculate SEO Score
    private function calculateSEOScore($metaData) {
        $score = 0;
        
        // Title length (50-60 chars = 20 points)
        $titleLen = strlen($metaData['seo_title']);
        if ($titleLen >= 50 && $titleLen <= 60) {
            $score += 20;
        } elseif ($titleLen >= 40 && $titleLen < 70) {
            $score += 15;
        } else {
            $score += 5;
        }
        
        // Description length (150-160 chars = 20 points)
        $descLen = strlen($metaData['meta_description']);
        if ($descLen >= 150 && $descLen <= 160) {
            $score += 20;
        } elseif ($descLen >= 120 && $descLen < 170) {
            $score += 15;
        } else {
            $score += 5;
        }
        
        // Has OpenGraph tags (20 points)
        if (!empty($metaData['og_title']) && !empty($metaData['og_description'])) {
            $score += 20;
        }
        
        // Has Twitter tags (20 points)
        if (!empty($metaData['twitter_title']) && !empty($metaData['twitter_description'])) {
            $score += 20;
        }
        
        // Additional keywords present (20 points)
        if (!empty($metaData['additional_keywords']) && count($metaData['additional_keywords']) > 0) {
            $score += 20;
        }
        
        return min($score, 100);
    }
    
    // Save meta tags
    public function saveMetaTags($focusKeyword, $metaData, $userId) {
        $this->metaTag->user_id = $userId;
        $this->metaTag->focus_keyword = $focusKeyword;
        $this->metaTag->seo_title = $metaData['seo_title'];
        $this->metaTag->meta_description = $metaData['meta_description'];
        $this->metaTag->og_title = $metaData['og_title'];
        $this->metaTag->og_description = $metaData['og_description'];
        $this->metaTag->og_image = $metaData['og_image_suggestion'] ?? '';
        $this->metaTag->twitter_title = $metaData['twitter_title'];
        $this->metaTag->twitter_description = $metaData['twitter_description'];
        $this->metaTag->twitter_image = $metaData['twitter_image_suggestion'] ?? '';
        $this->metaTag->seo_score = $metaData['seo_score'] ?? 0;
        
        if ($this->metaTag->create()) {
            return [
                'success' => true,
                'message' => 'Meta tags saved successfully',
                'meta_id' => $this->metaTag->id
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Failed to save meta tags'
        ];
    }
    
    // Get saved meta tags
    public function getSavedMetaTags($userId, $limit = 20) {
        return $this->metaTag->getByUser($userId, $limit);
    }
}
