<?php
require_once __DIR__ . '/../config/init.php';

class PDFReportController {
    private $db;
    
    public function __construct() {
        $this->db = getDBConnection();
    }
    
    // Generate PDF report
    public function generateReport($websiteId, $userId) {
        // Check if TCPDF is available
        if (!class_exists('TCPDF')) {
            // Try to include TCPDF from lib folder
            $tcpdfPath = __DIR__ . '/../lib/tcpdf/tcpdf.php';
            if (file_exists($tcpdfPath)) {
                require_once $tcpdfPath;
            } else {
                return [
                    'success' => false,
                    'message' => 'TCPDF library not found. Please install TCPDF library.'
                ];
            }
        }
        
        // Fetch website data
        $websiteData = $this->getWebsiteData($websiteId);
        if (!$websiteData) {
            return ['success' => false, 'message' => 'Website not found'];
        }
        
        // Fetch additional data
        $pageSpeedData = $this->getPageSpeedData($websiteId);
        $seoIssues = $this->getSeoIssues($websiteId);
        $aiRecommendations = $this->getAIRecommendations($websiteId);
        
        // Create PDF
        try {
            $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
            
            // Set document information
            $pdf->SetCreator('Aurify AI SEO Automation');
            $pdf->SetAuthor('Aurify Marketing');
            $pdf->SetTitle('SEO Audit Report - ' . $websiteData['url']);
            $pdf->SetSubject('Comprehensive SEO Analysis');
            
            // Set margins
            $pdf->SetMargins(15, 15, 15);
            $pdf->SetHeaderMargin(10);
            $pdf->SetFooterMargin(10);
            
            // Set auto page breaks
            $pdf->SetAutoPageBreak(TRUE, 15);
            
            // Add page
            $pdf->AddPage();
            
            // Build PDF content
            $this->buildPDFContent($pdf, $websiteData, $pageSpeedData, $seoIssues, $aiRecommendations);
            
            // Generate filename
            $filename = 'seo-report-' . preg_replace('/[^a-z0-9]/i', '-', $websiteData['url']) . '-' . time() . '.pdf';
            $filepath = __DIR__ . '/../uploads/reports/' . $filename;
            
            // Create directory if not exists
            if (!is_dir(__DIR__ . '/../uploads/reports/')) {
                mkdir(__DIR__ . '/../uploads/reports/', 0755, true);
            }
            
            // Output PDF to file
            $pdf->Output($filepath, 'F');
            
            // Save to database
            $this->saveReportRecord($userId, $websiteId, $filename, $filepath);
            
            return [
                'success' => true,
                'message' => 'Report generated successfully',
                'filename' => $filename,
                'filepath' => $filepath,
                'download_url' => SITE_URL . '/uploads/reports/' . $filename
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to generate PDF: ' . $e->getMessage()
            ];
        }
    }
    
    // Build PDF content
    private function buildPDFContent($pdf, $websiteData, $pageSpeedData, $seoIssues, $aiRecommendations) {
        // Cover page
        $pdf->SetFont('helvetica', 'B', 28);
        $pdf->SetTextColor(11, 31, 77);
        $pdf->Cell(0, 40, 'SEO AUDIT REPORT', 0, 1, 'C');
        
        $pdf->SetFont('helvetica', '', 14);
        $pdf->SetTextColor(102, 102, 102);
        $pdf->Cell(0, 10, $websiteData['url'], 0, 1, 'C');
        $pdf->Cell(0, 10, date('F j, Y'), 0, 1, 'C');
        
        // SEO Score
        $pdf->Ln(20);
        $pdf->SetFont('helvetica', 'B', 48);
        $pdf->SetTextColor(255, 107, 0);
        $pdf->Cell(0, 20, $websiteData['seo_score'] . '/100', 0, 1, 'C');
        $pdf->SetFont('helvetica', '', 12);
        $pdf->SetTextColor(102, 102, 102);
        $pdf->Cell(0, 10, 'Overall SEO Score', 0, 1, 'C');
        
        // New page for details
        $pdf->AddPage();
        
        // Website Overview
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->SetTextColor(11, 31, 77);
        $pdf->Cell(0, 10, 'Website Overview', 0, 1);
        $pdf->Ln(5);
        
        $pdf->SetFont('helvetica', '', 11);
        $pdf->SetTextColor(51, 51, 51);
        
        $html = '<table cellpadding="5">
            <tr><td width="150"><b>URL:</b></td><td>' . htmlspecialchars($websiteData['url']) . '</td></tr>
            <tr><td><b>Title:</b></td><td>' . htmlspecialchars($websiteData['title']) . '</td></tr>
            <tr><td><b>Description:</b></td><td>' . htmlspecialchars($websiteData['description']) . '</td></tr>
            <tr><td><b>SSL Enabled:</b></td><td>' . ($websiteData['ssl_enabled'] ? 'Yes ✓' : 'No ✗') . '</td></tr>
            <tr><td><b>CMS Detected:</b></td><td>' . htmlspecialchars($websiteData['cms_detected']) . '</td></tr>
            <tr><td><b>Response Time:</b></td><td>' . $websiteData['response_time'] . 'ms</td></tr>
        </table>';
        
        $pdf->writeHTML($html, true, false, true, false, '');
        
        // PageSpeed Scores
        if ($pageSpeedData) {
            $pdf->Ln(10);
            $pdf->SetFont('helvetica', 'B', 16);
            $pdf->SetTextColor(11, 31, 77);
            $pdf->Cell(0, 10, 'Performance Scores', 0, 1);
            $pdf->Ln(5);
            
            $pdf->SetFont('helvetica', '', 11);
            $html = '<table cellpadding="5" border="1">
                <tr bgcolor="#FF6B00" color="#FFFFFF">
                    <th width="150">Metric</th>
                    <th width="150">Desktop</th>
                    <th width="150">Mobile</th>
                </tr>
                <tr>
                    <td>Performance</td>
                    <td>' . ($pageSpeedData['desktop']['performance_score'] ?? 'N/A') . '/100</td>
                    <td>' . ($pageSpeedData['mobile']['performance_score'] ?? 'N/A') . '/100</td>
                </tr>
                <tr>
                    <td>Accessibility</td>
                    <td>' . ($pageSpeedData['desktop']['accessibility_score'] ?? 'N/A') . '/100</td>
                    <td>' . ($pageSpeedData['mobile']['accessibility_score'] ?? 'N/A') . '/100</td>
                </tr>
                <tr>
                    <td>Best Practices</td>
                    <td>' . ($pageSpeedData['desktop']['best_practices_score'] ?? 'N/A') . '/100</td>
                    <td>' . ($pageSpeedData['mobile']['best_practices_score'] ?? 'N/A') . '/100</td>
                </tr>
                <tr>
                    <td>SEO</td>
                    <td>' . ($pageSpeedData['desktop']['seo_score'] ?? 'N/A') . '/100</td>
                    <td>' . ($pageSpeedData['mobile']['seo_score'] ?? 'N/A') . '/100</td>
                </tr>
            </table>';
            
            $pdf->writeHTML($html, true, false, true, false, '');
        }
        
        // SEO Issues
        if (!empty($seoIssues)) {
            $pdf->AddPage();
            $pdf->SetFont('helvetica', 'B', 16);
            $pdf->SetTextColor(11, 31, 77);
            $pdf->Cell(0, 10, 'SEO Issues Found', 0, 1);
            $pdf->Ln(5);
            
            $pdf->SetFont('helvetica', '', 10);
            
            $criticalIssues = array_filter($seoIssues, function($issue) {
                return $issue['severity'] === 'critical' || $issue['severity'] === 'high';
            });
            
            if (!empty($criticalIssues)) {
                $pdf->SetFont('helvetica', 'B', 12);
                $pdf->SetTextColor(220, 53, 69);
                $pdf->Cell(0, 8, 'Critical & High Priority Issues', 0, 1);
                $pdf->Ln(2);
                
                $pdf->SetFont('helvetica', '', 10);
                $pdf->SetTextColor(51, 51, 51);
                
                foreach (array_slice($criticalIssues, 0, 10) as $index => $issue) {
                    $pdf->SetFont('helvetica', 'B', 10);
                    $pdf->Cell(10, 6, ($index + 1) . '.', 0, 0);
                    $pdf->SetFont('helvetica', '', 10);
                    $pdf->MultiCell(0, 6, $issue['category'] . ': ' . $issue['message'], 0, 'L');
                    $pdf->Ln(2);
                }
            }
        }
        
        // AI Recommendations
        if ($aiRecommendations) {
            $pdf->AddPage();
            $pdf->SetFont('helvetica', 'B', 16);
            $pdf->SetTextColor(11, 31, 77);
            $pdf->Cell(0, 10, 'AI-Powered Recommendations', 0, 1);
            $pdf->Ln(5);
            
            $pdf->SetFont('helvetica', 'B', 11);
            $pdf->Cell(0, 8, 'Executive Summary', 0, 1);
            $pdf->SetFont('helvetica', '', 10);
            $pdf->MultiCell(0, 6, $aiRecommendations['summary'], 0, 'L');
            
            $pdf->Ln(5);
            $pdf->SetFont('helvetica', 'B', 11);
            $pdf->Cell(0, 8, 'Priority Actions', 0, 1);
            
            $topProblems = json_decode($aiRecommendations['top_problems'], true);
            if ($topProblems) {
                $pdf->SetFont('helvetica', '', 10);
                foreach (array_slice($topProblems, 0, 5) as $index => $problem) {
                    $pdf->SetFont('helvetica', 'B', 10);
                    $pdf->Cell(10, 6, ($index + 1) . '.', 0, 0);
                    $pdf->SetFont('helvetica', '', 10);
                    $pdf->MultiCell(0, 6, $problem['problem'] . ' - ' . $problem['impact'], 0, 'L');
                    $pdf->Ln(2);
                }
            }
        }
        
        // Footer
        $pdf->SetY(-30);
        $pdf->SetFont('helvetica', 'I', 8);
        $pdf->SetTextColor(153, 153, 153);
        $pdf->Cell(0, 10, 'Generated by Aurify AI SEO Automation - https://aurifymarketing.com', 0, 0, 'C');
    }
    
    // Helper methods
    private function getWebsiteData($websiteId) {
        $query = "SELECT * FROM websites WHERE id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $websiteId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    private function getPageSpeedData($websiteId) {
        $query = "SELECT * FROM pagespeed_reports WHERE website_id = ? ORDER BY created_at DESC LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $websiteId);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        
        if ($data) {
            return [
                'desktop' => json_decode($data['desktop_data'], true),
                'mobile' => json_decode($data['mobile_data'], true)
            ];
        }
        return null;
    }
    
    private function getSeoIssues($websiteId) {
        $query = "SELECT * FROM seo_issues WHERE website_id = ? ORDER BY severity DESC";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $websiteId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    private function getAIRecommendations($websiteId) {
        $query = "SELECT * FROM ai_recommendations WHERE website_id = ? ORDER BY created_at DESC LIMIT 1";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $websiteId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    private function saveReportRecord($userId, $websiteId, $filename, $filepath) {
        $query = "INSERT INTO pdf_reports (user_id, website_id, filename, file_path) VALUES (?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("iiss", $userId, $websiteId, $filename, $filepath);
        return $stmt->execute();
    }
}
