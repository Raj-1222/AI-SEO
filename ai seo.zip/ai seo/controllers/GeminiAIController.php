<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/AIRecommendation.php';

class GeminiAIController {
    private $db;
    private $aiRecommendation;
    private $apiKey;
    private $apiUrl;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->aiRecommendation = new AIRecommendation($this->db);
        // Use OpenAI API
        $this->apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : GEMINI_API_KEY;
        $this->apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : GEMINI_API_URL;
    }
    
    // Generate AI recommendations using Gemini
    public function generateRecommendations($websiteData, $pageSpeedData, $technicalSeoData, $websiteId = null) {
        // Check if API key is configured
        if (empty($this->apiKey) || $this->apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            return [
                'success' => false,
                'message' => 'Gemini API key not configured. Please add your API key in config/database.php'
            ];
        }
        
        // Prepare comprehensive prompt
        $prompt = $this->buildPrompt($websiteData, $pageSpeedData, $technicalSeoData);
        
        // Call Gemini API
        $response = $this->callGeminiAPI($prompt);
        
        if (!$response['success']) {
            return $response;
        }
        
        // Parse AI response
        $recommendations = $this->parseAIResponse($response['content']);
        
        // Save to database if website_id provided
        if ($websiteId && $recommendations['success']) {
            $this->aiRecommendation->website_id = $websiteId;
            $this->aiRecommendation->summary = $recommendations['summary'];
            $this->aiRecommendation->top_problems = json_encode($recommendations['top_problems']);
            $this->aiRecommendation->business_impact = $recommendations['business_impact'];
            $this->aiRecommendation->priority_actions = json_encode($recommendations['priority_actions']);
            $this->aiRecommendation->solutions = json_encode($recommendations['solutions']);
            $this->aiRecommendation->estimated_improvements = json_encode($recommendations['estimated_improvements']);
            $this->aiRecommendation->raw_response = $response['content'];
            $this->aiRecommendation->create();
        }
        
        return $recommendations;
    }
    
    // Build comprehensive prompt for Gemini
    private function buildPrompt($websiteData, $pageSpeedData, $technicalSeoData) {
        $url = $websiteData['url'] ?? 'Unknown';
        $seoScore = $websiteData['seo_score'] ?? 0;
        $title = $websiteData['title'] ?? 'No title';
        $description = $websiteData['description'] ?? 'No description';
        $sslEnabled = $websiteData['ssl_enabled'] ?? false;
        $responseTime = $websiteData['response_time'] ?? 0;
        
        // PageSpeed scores
        $desktopPerf = $pageSpeedData['desktop']['performance_score'] ?? 0;
        $mobilePerf = $pageSpeedData['mobile']['performance_score'] ?? 0;
        $desktopAccessibility = $pageSpeedData['desktop']['accessibility_score'] ?? 0;
        $mobileAccessibility = $pageSpeedData['mobile']['accessibility_score'] ?? 0;
        
        // Core Web Vitals
        $lcpDesktop = $pageSpeedData['desktop']['lcp_value'] ?? 0;
        $lcpMobile = $pageSpeedData['mobile']['lcp_value'] ?? 0;
        $clsDesktop = $pageSpeedData['desktop']['cls_value'] ?? 0;
        $clsMobile = $pageSpeedData['mobile']['cls_value'] ?? 0;
        
        // Technical SEO issues
        $issuesCount = count($technicalSeoData['issues'] ?? []);
        $criticalIssues = array_filter($technicalSeoData['issues'] ?? [], function($issue) {
            return $issue['severity'] === 'critical' || $issue['severity'] === 'high';
        });
        $criticalCount = count($criticalIssues);
        
        // Build issues summary
        $issuesSummary = [];
        foreach (($technicalSeoData['issues'] ?? []) as $issue) {
            if ($issue['status'] !== 'pass') {
                $issuesSummary[] = "- {$issue['category']}: {$issue['message']} (Severity: {$issue['severity']})";
            }
        }
        $issuesText = implode("\n", array_slice($issuesSummary, 0, 15)); // Limit to 15 issues
        
        $prompt = <<<EOT
You are an expert SEO consultant and web performance analyst. Analyze the following website data and provide actionable recommendations.

**WEBSITE INFORMATION:**
- URL: {$url}
- Title: {$title}
- Meta Description: {$description}
- Overall SEO Score: {$seoScore}/100
- SSL Enabled: {$sslEnabled}
- Response Time: {$responseTime}ms

**PERFORMANCE METRICS:**
Desktop Performance: {$desktopPerf}/100
Mobile Performance: {$mobilePerf}/100
Desktop Accessibility: {$desktopAccessibility}/100
Mobile Accessibility: {$mobileAccessibility}/100

**CORE WEB VITALS:**
Desktop LCP: {$lcpDesktop}s (Good: <2.5s)
Mobile LCP: {$lcpMobile}s (Good: <2.5s)
Desktop CLS: {$clsDesktop} (Good: <0.1)
Mobile CLS: {$clsMobile} (Good: <0.1)

**TECHNICAL SEO ISSUES:**
Total Issues Found: {$issuesCount}
Critical/High Priority Issues: {$criticalCount}

Issues Details:
{$issuesText}

**REQUIRED OUTPUT FORMAT (STRICT JSON):**
Please respond with ONLY valid JSON in this exact format:

{
  "summary": "2-3 sentence executive summary of the website's current SEO and performance state",
  "top_problems": [
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "critical", "difficulty": "easy|medium|hard", "estimated_time": "1-2 hours"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "high", "difficulty": "easy|medium|hard", "estimated_time": "2-4 hours"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "high", "difficulty": "easy|medium|hard", "estimated_time": "4-8 hours"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "medium", "difficulty": "easy|medium|hard", "estimated_time": "1-2 days"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "medium", "difficulty": "easy|medium|hard", "estimated_time": "2-3 days"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "medium", "difficulty": "easy|medium|hard", "estimated_time": "3-5 days"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "low", "difficulty": "easy|medium|hard", "estimated_time": "1 week"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "low", "difficulty": "easy|medium|hard", "estimated_time": "1-2 weeks"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "low", "difficulty": "easy|medium|hard", "estimated_time": "2-4 weeks"},
    {"problem": "Clear problem statement", "impact": "Business impact", "severity": "low", "difficulty": "easy|medium|hard", "estimated_time": "1 month"}
  ],
  "business_impact": "Detailed explanation of how these issues affect business goals, revenue, user experience, and search rankings",
  "priority_actions": [
    {"action": "Specific actionable task", "priority": 1, "effort": "low|medium|high", "timeline": "immediate|1-2 weeks|1 month", "expected_improvement": "+10-15% ranking"},
    {"action": "Specific actionable task", "priority": 2, "effort": "low|medium|high", "timeline": "immediate|1-2 weeks|1 month", "expected_improvement": "+5-10% performance"},
    {"action": "Specific actionable task", "priority": 3, "effort": "low|medium|high", "timeline": "immediate|1-2 weeks|1 month", "expected_improvement": "+15-20% speed"},
    {"action": "Specific actionable task", "priority": 4, "effort": "low|medium|high", "timeline": "immediate|1-2 weeks|1 month", "expected_improvement": "+5% conversion"},
    {"action": "Specific actionable task", "priority": 5, "effort": "low|medium|high", "timeline": "immediate|1-2 weeks|1 month", "expected_improvement": "+10% accessibility"}
  ],
  "solutions": [
    {"issue": "Issue name", "solution": "Detailed step-by-step solution", "tools": "Tools or resources needed", "difficulty": "easy|medium|hard"},
    {"issue": "Issue name", "solution": "Detailed step-by-step solution", "tools": "Tools or resources needed", "difficulty": "easy|medium|hard"},
    {"issue": "Issue name", "solution": "Detailed step-by-step solution", "tools": "Tools or resources needed", "difficulty": "easy|medium|hard"},
    {"issue": "Issue name", "solution": "Detailed step-by-step solution", "tools": "Tools or resources needed", "difficulty": "easy|medium|hard"},
    {"issue": "Issue name", "solution": "Detailed step-by-step solution", "tools": "Tools or resources needed", "difficulty": "easy|medium|hard"}
  ],
  "estimated_improvements": {
    "seo_score": "+15-20 points",
    "performance": "+20-30 points",
    "user_experience": "30-40% faster load time",
    "conversion_rate": "+10-15% potential increase",
    "search_ranking": "Expected to rank 3-5 positions higher for target keywords",
    "timeline": "Full implementation: 2-3 months"
  }
}

Provide exactly 10 problems ranked by severity (critical to low). Include detailed timeline estimates, difficulty levels, and expected ranking improvements for each action. Be realistic about timelines and effort.
EOT;
        
        return $prompt;
    }
    
    // Call OpenAI API (replaces Gemini)
    private function callGeminiAPI($prompt) {
        $url = $this->apiUrl;
        
        // Prepare OpenAI format
        $data = [
            'model' => defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are an expert SEO consultant. Provide detailed, actionable recommendations in valid JSON format only.'
                ],
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'temperature' => 0.7,
            'max_tokens' => 4096
            // JSON mode temporarily disabled for compatibility
            // 'response_format' => ['type' => 'json_object']
        ];
        
        try {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $this->apiKey
                ],
                CURLOPT_TIMEOUT => 120,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($error) {
                return [
                    'success' => false,
                    'message' => 'API request failed: ' . $error
                ];
            }
            
            if ($httpCode !== 200) {
                $errorData = json_decode($response, true);
                $errorMsg = $errorData['error']['message'] ?? 'HTTP ' . $httpCode;
                return [
                    'success' => false,
                    'message' => 'OpenAI API error: ' . $errorMsg
                ];
            }
            
            $result = json_decode($response, true);
            
            if (!$result || !isset($result['choices'][0]['message']['content'])) {
                return [
                    'success' => false,
                    'message' => 'Invalid API response format',
                    'response' => $response
                ];
            }
            
            $content = $result['choices'][0]['message']['content'];
            
            return [
                'success' => true,
                'content' => $content
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Exception: ' . $e->getMessage()
            ];
        }
    }
    
    // Parse AI response
    private function parseAIResponse($content) {
        // Clean up the response - remove markdown code blocks if present
        $content = preg_replace('/```json\s*/', '', $content);
        $content = preg_replace('/```\s*$/', '', $content);
        $content = trim($content);
        
        $data = json_decode($content, true);
        
        if (!$data) {
            // Try to extract JSON from text
            preg_match('/\{[\s\S]*\}/', $content, $matches);
            if ($matches) {
                $data = json_decode($matches[0], true);
            }
        }
        
        if (!$data) {
            return [
                'success' => false,
                'message' => 'Failed to parse AI response',
                'raw_content' => $content
            ];
        }
        
        return [
            'success' => true,
            'summary' => $data['summary'] ?? 'No summary available',
            'top_problems' => $data['top_problems'] ?? [],
            'business_impact' => $data['business_impact'] ?? 'No business impact analysis available',
            'priority_actions' => $data['priority_actions'] ?? [],
            'solutions' => $data['solutions'] ?? [],
            'estimated_improvements' => $data['estimated_improvements'] ?? []
        ];
    }
    
    // Get recommendations by website ID
    public function getRecommendationsByWebsite($websiteId) {
        return $this->aiRecommendation->getByWebsite($websiteId);
    }
    
    // Get latest recommendation
    public function getLatestRecommendation($websiteId) {
        $recommendations = $this->aiRecommendation->getByWebsite($websiteId, 1);
        return $recommendations[0] ?? null;
    }
}
