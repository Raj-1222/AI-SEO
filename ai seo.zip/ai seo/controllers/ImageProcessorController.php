<?php
/**
 * Image Processor Controller
 * Handles all image processing operations using Imagick (primary) and GD (fallback)
 */

require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../config/image_optimizer_config.php';
require_once __DIR__ . '/../models/ImageHistory.php';

class ImageProcessorController {
    private $db;
    private $library;
    private $imageHistory;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->library = IMG_LIBRARY;
        $this->imageHistory = new ImageHistory($this->db);
    }
    
    /**
     * Compress image
     */
    public function compressImage($sourcePath, $destinationPath, $quality = 85, $format = null) {
        $startTime = microtime(true);
        
        try {
            if ($this->library === 'imagick') {
                $result = $this->compressImageImagick($sourcePath, $destinationPath, $quality, $format);
            } else {
                $result = $this->compressImageGD($sourcePath, $destinationPath, $quality, $format);
            }
            
            $result['processing_time'] = round(microtime(true) - $startTime, 3);
            return $result;
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Compression failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Compress image using Imagick
     */
    private function compressImageImagick($sourcePath, $destinationPath, $quality, $format) {
        $imagick = new Imagick($sourcePath);
        
        // Get original info
        $originalSize = filesize($sourcePath);
        $originalWidth = $imagick->getImageWidth();
        $originalHeight = $imagick->getImageHeight();
        $originalFormat = strtolower($imagick->getImageFormat());
        
        // Set compression quality
        $imagick->setImageCompressionQuality($quality);
        
        // Convert format if specified
        if ($format) {
            $format = strtolower($format);
            
            // Handle transparency for formats that support it
            if (in_array($format, ['png', 'webp', 'avif'])) {
                $imagick->setImageAlphaChannel(Imagick::ALPHACHANNEL_ACTIVATE);
            } else {
                // Remove transparency for formats that don't support it
                $imagick->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE);
                $imagick->setImageBackgroundColor('white');
                $imagick = $imagick->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
            }
            
            $imagick->setImageFormat($format);
        }
        
        // Strip metadata (EXIF, etc.) to reduce size
        $imagick->stripImage();
        
        // Apply additional compression for specific formats
        switch ($format ?: $originalFormat) {
            case 'jpg':
            case 'jpeg':
                $imagick->setImageCompression(Imagick::COMPRESSION_JPEG);
                break;
            case 'png':
                $imagick->setImageCompression(Imagick::COMPRESSION_ZIP);
                break;
            case 'webp':
                $imagick->setOption('webp:method', '6'); // Best compression
                break;
        }
        
        // Save optimized image
        $imagick->writeImage($destinationPath);
        $optimizedSize = filesize($destinationPath);
        
        $imagick->clear();
        $imagick->destroy();
        
        return [
            'success' => true,
            'original_size' => $originalSize,
            'optimized_size' => $optimizedSize,
            'saved_bytes' => $originalSize - $optimizedSize,
            'compression_ratio' => calculateCompressionRatio($originalSize, $optimizedSize),
            'width' => $originalWidth,
            'height' => $originalHeight,
            'format' => $format ?: $originalFormat
        ];
    }
    
    /**
     * Compress image using GD
     */
    private function compressImageGD($sourcePath, $destinationPath, $quality, $format) {
        // Get original info
        $originalSize = filesize($sourcePath);
        $imageInfo = getimagesize($sourcePath);
        $originalWidth = $imageInfo[0];
        $originalHeight = $imageInfo[1];
        $mimeType = $imageInfo['mime'];
        
        // Create image resource based on type
        switch ($mimeType) {
            case 'image/jpeg':
            case 'image/jpg':
                $image = imagecreatefromjpeg($sourcePath);
                $originalFormat = 'jpg';
                break;
            case 'image/png':
                $image = imagecreatefrompng($sourcePath);
                imagealphablending($image, false);
                imagesavealpha($image, true);
                $originalFormat = 'png';
                break;
            case 'image/gif':
                $image = imagecreatefromgif($sourcePath);
                $originalFormat = 'gif';
                break;
            case 'image/webp':
                $image = imagecreatefromwebp($sourcePath);
                $originalFormat = 'webp';
                break;
            case 'image/bmp':
                $image = imagecreatefrombmp($sourcePath);
                $originalFormat = 'bmp';
                break;
            default:
                throw new Exception('Unsupported image format');
        }
        
        if (!$image) {
            throw new Exception('Failed to create image resource');
        }
        
        // Save with specified format and quality
        $outputFormat = $format ?: $originalFormat;
        
        switch ($outputFormat) {
            case 'jpg':
            case 'jpeg':
                // Remove transparency for JPEG
                $bg = imagecreatetruecolor($originalWidth, $originalHeight);
                $white = imagecolorallocate($bg, 255, 255, 255);
                imagefill($bg, 0, 0, $white);
                imagecopy($bg, $image, 0, 0, 0, 0, $originalWidth, $originalHeight);
                imagejpeg($bg, $destinationPath, $quality);
                imagedestroy($bg);
                break;
            case 'png':
                // PNG quality is 0-9, convert from 0-100
                $pngQuality = 9 - round(($quality / 100) * 9);
                imagepng($image, $destinationPath, $pngQuality);
                break;
            case 'webp':
                imagewebp($image, $destinationPath, $quality);
                break;
            case 'gif':
                imagegif($image, $destinationPath);
                break;
            default:
                imagejpeg($image, $destinationPath, $quality);
        }
        
        imagedestroy($image);
        
        $optimizedSize = filesize($destinationPath);
        
        return [
            'success' => true,
            'original_size' => $originalSize,
            'optimized_size' => $optimizedSize,
            'saved_bytes' => $originalSize - $optimizedSize,
            'compression_ratio' => calculateCompressionRatio($originalSize, $optimizedSize),
            'width' => $originalWidth,
            'height' => $originalHeight,
            'format' => $outputFormat
        ];
    }
    
    /**
     * Resize image
     */
    public function resizeImage($sourcePath, $destinationPath, $width, $height, $maintainAspectRatio = true, $quality = 85) {
        try {
            if ($this->library === 'imagick') {
                return $this->resizeImageImagick($sourcePath, $destinationPath, $width, $height, $maintainAspectRatio, $quality);
            } else {
                return $this->resizeImageGD($sourcePath, $destinationPath, $width, $height, $maintainAspectRatio, $quality);
            }
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Resize failed: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * Resize image using Imagick
     */
    private function resizeImageImagick($sourcePath, $destinationPath, $width, $height, $maintainAspectRatio, $quality) {
        $imagick = new Imagick($sourcePath);
        
        $originalWidth = $imagick->getImageWidth();
        $originalHeight = $imagick->getImageHeight();
        $originalSize = filesize($sourcePath);
        
        if ($maintainAspectRatio) {
            $imagick->resizeImage($width, $height, Imagick::FILTER_LANCZOS, 1, true);
        } else {
            $imagick->resizeImage($width, $height, Imagick::FILTER_LANCZOS, 1, false);
        }
        
        $imagick->setImageCompressionQuality($quality);
        $imagick->stripImage();
        $imagick->writeImage($destinationPath);
        
        $newWidth = $imagick->getImageWidth();
        $newHeight = $imagick->getImageHeight();
        
        $imagick->clear();
        $imagick->destroy();
        
        $optimizedSize = filesize($destinationPath);
        
        return [
            'success' => true,
            'original_width' => $originalWidth,
            'original_height' => $originalHeight,
            'new_width' => $newWidth,
            'new_height' => $newHeight,
            'original_size' => $originalSize,
            'optimized_size' => $optimizedSize,
            'saved_bytes' => $originalSize - $optimizedSize,
            'compression_ratio' => calculateCompressionRatio($originalSize, $optimizedSize)
        ];
    }
    
    /**
     * Resize image using GD
     */
    private function resizeImageGD($sourcePath, $destinationPath, $width, $height, $maintainAspectRatio, $quality) {
        $imageInfo = getimagesize($sourcePath);
        $originalWidth = $imageInfo[0];
        $originalHeight = $imageInfo[1];
        $originalSize = filesize($sourcePath);
        $mimeType = $imageInfo['mime'];
        
        // Calculate new dimensions if maintaining aspect ratio
        if ($maintainAspectRatio) {
            $ratio = min($width / $originalWidth, $height / $originalHeight);
            $newWidth = round($originalWidth * $ratio);
            $newHeight = round($originalHeight * $ratio);
        } else {
            $newWidth = $width;
            $newHeight = $height;
        }
        
        // Create image resource
        $sourceImage = $this->createImageResource($sourcePath, $mimeType);
        
        // Create new image
        $destinationImage = imagecreatetruecolor($newWidth, $newHeight);
        
        // Preserve transparency
        if ($mimeType == 'image/png' || $mimeType == 'image/webp') {
            imagealphablending($destinationImage, false);
            imagesavealpha($destinationImage, true);
            $transparent = imagecolorallocatealpha($destinationImage, 0, 0, 0, 127);
            imagefill($destinationImage, 0, 0, $transparent);
        }
        
        // Resize
        imagecopyresampled($destinationImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);
        
        // Save
        $this->saveImageResource($destinationImage, $destinationPath, $mimeType, $quality);
        
        imagedestroy($sourceImage);
        imagedestroy($destinationImage);
        
        $optimizedSize = filesize($destinationPath);
        
        return [
            'success' => true,
            'original_width' => $originalWidth,
            'original_height' => $originalHeight,
            'new_width' => $newWidth,
            'new_height' => $newHeight,
            'original_size' => $originalSize,
            'optimized_size' => $optimizedSize,
            'saved_bytes' => $originalSize - $optimizedSize,
            'compression_ratio' => calculateCompressionRatio($originalSize, $optimizedSize)
        ];
    }
    
    /**
     * Rotate image
     */
    public function rotateImage($sourcePath, $destinationPath, $angle, $quality = 85) {
        try {
            if ($this->library === 'imagick') {
                $imagick = new Imagick($sourcePath);
                $imagick->rotateImage(new ImagickPixel('none'), $angle);
                $imagick->setImageCompressionQuality($quality);
                $imagick->writeImage($destinationPath);
                $imagick->clear();
                $imagick->destroy();
            } else {
                $imageInfo = getimagesize($sourcePath);
                $sourceImage = $this->createImageResource($sourcePath, $imageInfo['mime']);
                $rotated = imagerotate($sourceImage, -$angle, 0); // GD rotates counter-clockwise
                $this->saveImageResource($rotated, $destinationPath, $imageInfo['mime'], $quality);
                imagedestroy($sourceImage);
                imagedestroy($rotated);
            }
            
            return ['success' => true, 'message' => 'Image rotated successfully'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Rotation failed: ' . $e->getMessage()];
        }
    }
    
    /**
     * Flip image
     */
    public function flipImage($sourcePath, $destinationPath, $direction, $quality = 85) {
        try {
            if ($this->library === 'imagick') {
                $imagick = new Imagick($sourcePath);
                
                if ($direction === 'horizontal') {
                    $imagick->flopImage();
                } else {
                    $imagick->flipImage();
                }
                
                $imagick->setImageCompressionQuality($quality);
                $imagick->writeImage($destinationPath);
                $imagick->clear();
                $imagick->destroy();
            } else {
                $imageInfo = getimagesize($sourcePath);
                $sourceImage = $this->createImageResource($sourcePath, $imageInfo['mime']);
                
                if ($direction === 'horizontal') {
                    imageflip($sourceImage, IMG_FLIP_HORIZONTAL);
                } else {
                    imageflip($sourceImage, IMG_FLIP_VERTICAL);
                }
                
                $this->saveImageResource($sourceImage, $destinationPath, $imageInfo['mime'], $quality);
                imagedestroy($sourceImage);
            }
            
            return ['success' => true, 'message' => 'Image flipped successfully'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Flip failed: ' . $e->getMessage()];
        }
    }
    
    /**
     * Crop image
     */
    public function cropImage($sourcePath, $destinationPath, $x, $y, $width, $height, $quality = 85) {
        try {
            if ($this->library === 'imagick') {
                $imagick = new Imagick($sourcePath);
                $imagick->cropImage($width, $height, $x, $y);
                $imagick->setImagePage(0, 0, 0, 0);
                $imagick->setImageCompressionQuality($quality);
                $imagick->writeImage($destinationPath);
                $imagick->clear();
                $imagick->destroy();
            } else {
                $imageInfo = getimagesize($sourcePath);
                $sourceImage = $this->createImageResource($sourcePath, $imageInfo['mime']);
                
                $croppedImage = imagecrop($sourceImage, ['x' => $x, 'y' => $y, 'width' => $width, 'height' => $height]);
                
                $this->saveImageResource($croppedImage, $destinationPath, $imageInfo['mime'], $quality);
                imagedestroy($sourceImage);
                imagedestroy($croppedImage);
            }
            
            return ['success' => true, 'message' => 'Image cropped successfully'];
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Crop failed: ' . $e->getMessage()];
        }
    }
    
    /**
     * Add watermark
     */
    public function addWatermark($sourcePath, $destinationPath, $watermarkText, $position = 'bottom-right', $opacity = 50, $quality = 85) {
        try {
            if ($this->library === 'imagick') {
                return $this->addWatermarkImagick($sourcePath, $destinationPath, $watermarkText, $position, $opacity, $quality);
            } else {
                return $this->addWatermarkGD($sourcePath, $destinationPath, $watermarkText, $position, $opacity, $quality);
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Watermark failed: ' . $e->getMessage()];
        }
    }
    
    /**
     * Add watermark using Imagick
     */
    private function addWatermarkImagick($sourcePath, $destinationPath, $watermarkText, $position, $opacity, $quality) {
        $imagick = new Imagick($sourcePath);
        $draw = new ImagickDraw();
        
        // Configure text
        $draw->setFillColor(new ImagickPixel('white'));
        $draw->setFillOpacity($opacity / 100);
        $draw->setFont('Arial');
        $draw->setFontSize(36);
        $draw->setGravity($this->getImagickGravity($position));
        
        // Add text
        $imagick->annotateImage($draw, 10, 10, 0, $watermarkText);
        
        $imagick->setImageCompressionQuality($quality);
        $imagick->writeImage($destinationPath);
        $imagick->clear();
        $imagick->destroy();
        
        return ['success' => true, 'message' => 'Watermark added successfully'];
    }
    
    /**
     * Add watermark using GD
     */
    private function addWatermarkGD($sourcePath, $destinationPath, $watermarkText, $position, $opacity, $quality) {
        $imageInfo = getimagesize($sourcePath);
        $sourceImage = $this->createImageResource($sourcePath, $imageInfo['mime']);
        
        $imageWidth = imagesx($sourceImage);
        $imageHeight = imagesy($sourceImage);
        
        // Text properties
        $fontSize = 24;
        $fontFile = __DIR__ . '/../assets/fonts/Arial.ttf'; // You'll need to add a font file
        
        // Calculate text size
        if (file_exists($fontFile)) {
            $textBox = imagettfbbox($fontSize, 0, $fontFile, $watermarkText);
            $textWidth = abs($textBox[4] - $textBox[0]);
            $textHeight = abs($textBox[5] - $textBox[1]);
        } else {
            $textWidth = strlen($watermarkText) * 10;
            $textHeight = 20;
        }
        
        // Calculate position
        list($x, $y) = $this->calculateWatermarkPosition($imageWidth, $imageHeight, $textWidth, $textHeight, $position);
        
        // Create color with opacity
        $alpha = (100 - $opacity) * 1.27; // Convert to 0-127 range
        $color = imagecolorallocatealpha($sourceImage, 255, 255, 255, $alpha);
        
        // Add text
        if (file_exists($fontFile)) {
            imagettftext($sourceImage, $fontSize, 0, $x, $y, $color, $fontFile, $watermarkText);
        } else {
            imagestring($sourceImage, 5, $x, $y, $watermarkText, $color);
        }
        
        $this->saveImageResource($sourceImage, $destinationPath, $imageInfo['mime'], $quality);
        imagedestroy($sourceImage);
        
        return ['success' => true, 'message' => 'Watermark added successfully'];
    }
    
    /**
     * Get metadata from image
     */
    public function getImageMetadata($imagePath) {
        try {
            $metadata = [];
            $imageInfo = getimagesize($imagePath);
            
            $metadata['width'] = $imageInfo[0];
            $metadata['height'] = $imageInfo[1];
            $metadata['mime_type'] = $imageInfo['mime'];
            $metadata['file_size'] = filesize($imagePath);
            $metadata['file_size_formatted'] = formatBytes($metadata['file_size']);
            
            if ($this->library === 'imagick') {
                $imagick = new Imagick($imagePath);
                $metadata['format'] = strtolower($imagick->getImageFormat());
                $metadata['colorspace'] = $imagick->getImageColorspace();
                $metadata['depth'] = $imagick->getImageDepth();
                $metadata['resolution'] = $imagick->getImageResolution();
                $metadata['compression'] = $imagick->getImageCompression();
                $imagick->clear();
                $imagick->destroy();
            } else {
                $metadata['format'] = strtolower(pathinfo($imagePath, PATHINFO_EXTENSION));
            }
            
            // Get EXIF data if available
            if (function_exists('exif_read_data') && in_array($metadata['mime_type'], ['image/jpeg', 'image/tiff'])) {
                $exif = @exif_read_data($imagePath);
                if ($exif !== false) {
                    $metadata['exif'] = [
                        'make' => $exif['Make'] ?? null,
                        'model' => $exif['Model'] ?? null,
                        'datetime' => $exif['DateTime'] ?? null,
                        'exposure' => $exif['ExposureTime'] ?? null,
                        'aperture' => $exif['FNumber'] ?? null,
                        'iso' => $exif['ISOSpeedRatings'] ?? null
                    ];
                }
            }
            
            return $metadata;
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    /**
     * Helper: Create image resource from file
     */
    private function createImageResource($path, $mimeType) {
        switch ($mimeType) {
            case 'image/jpeg':
            case 'image/jpg':
                return imagecreatefromjpeg($path);
            case 'image/png':
                return imagecreatefrompng($path);
            case 'image/gif':
                return imagecreatefromgif($path);
            case 'image/webp':
                return imagecreatefromwebp($path);
            case 'image/bmp':
                return imagecreatefrombmp($path);
            default:
                throw new Exception('Unsupported image format');
        }
    }
    
    /**
     * Helper: Save image resource to file
     */
    private function saveImageResource($image, $path, $mimeType, $quality) {
        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        
        switch ($extension) {
            case 'jpg':
            case 'jpeg':
                imagejpeg($image, $path, $quality);
                break;
            case 'png':
                $pngQuality = 9 - round(($quality / 100) * 9);
                imagepng($image, $path, $pngQuality);
                break;
            case 'webp':
                imagewebp($image, $path, $quality);
                break;
            case 'gif':
                imagegif($image, $path);
                break;
            default:
                imagejpeg($image, $path, $quality);
        }
    }
    
    /**
     * Helper: Get Imagick gravity constant
     */
    private function getImagickGravity($position) {
        $map = [
            'top-left' => Imagick::GRAVITY_NORTHWEST,
            'top-center' => Imagick::GRAVITY_NORTH,
            'top-right' => Imagick::GRAVITY_NORTHEAST,
            'center-left' => Imagick::GRAVITY_WEST,
            'center' => Imagick::GRAVITY_CENTER,
            'center-right' => Imagick::GRAVITY_EAST,
            'bottom-left' => Imagick::GRAVITY_SOUTHWEST,
            'bottom-center' => Imagick::GRAVITY_SOUTH,
            'bottom-right' => Imagick::GRAVITY_SOUTHEAST
        ];
        
        return $map[$position] ?? Imagick::GRAVITY_SOUTHEAST;
    }
    
    /**
     * Helper: Calculate watermark position
     */
    private function calculateWatermarkPosition($imageWidth, $imageHeight, $textWidth, $textHeight, $position) {
        $padding = 20;
        
        switch ($position) {
            case 'top-left':
                return [$padding, $padding + $textHeight];
            case 'top-center':
                return [($imageWidth - $textWidth) / 2, $padding + $textHeight];
            case 'top-right':
                return [$imageWidth - $textWidth - $padding, $padding + $textHeight];
            case 'center-left':
                return [$padding, ($imageHeight + $textHeight) / 2];
            case 'center':
                return [($imageWidth - $textWidth) / 2, ($imageHeight + $textHeight) / 2];
            case 'center-right':
                return [$imageWidth - $textWidth - $padding, ($imageHeight + $textHeight) / 2];
            case 'bottom-left':
                return [$padding, $imageHeight - $padding];
            case 'bottom-center':
                return [($imageWidth - $textWidth) / 2, $imageHeight - $padding];
            case 'bottom-right':
            default:
                return [$imageWidth - $textWidth - $padding, $imageHeight - $padding];
        }
    }
}
