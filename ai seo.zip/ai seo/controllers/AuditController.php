<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/Website.php';

class AuditController {
    private $db;
    private $website;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->website = new Website($this->db);
    }
    
    // Perform website audit
    public function auditWebsite($url, $user_id) {
        // Validate URL
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return ['success' => false, 'message' => 'Invalid URL format'];
        }
        
        // Check if URL already exists for this user
        if ($this->website->urlExists($user_id, $url)) {
            $existingAuditId = $this->website->getAuditIdByUrl($user_id, $url);
            return [
                'success' => false,
                'alreadyAudited' => true,
                'message' => 'This website has already been audited',
                'audit_id' => $existingAuditId
            ];
        }
        
        // Start audit
        $auditData = $this->performAudit($url);
        
        if (!$auditData) {
            return ['success' => false, 'message' => 'Failed to audit website. Please check the URL and try again.'];
        }
        
        // Save to database
        $this->website->user_id = $user_id;
        $this->website->url = $url;
        $this->website->title = $auditData['title'];
        $this->website->description = $auditData['description'];
        $this->website->meta_keywords = $auditData['keywords'];
        $this->website->language = $auditData['language'];
        $this->website->ssl_enabled = $auditData['ssl_enabled'];
        $this->website->cms_detected = $auditData['cms_detected'];
        $this->website->server_info = $auditData['server_info'];
        $this->website->country = $auditData['country'];
        $this->website->ip_address = $auditData['ip_address'];
        $this->website->response_time = $auditData['response_time'];
        $this->website->seo_score = $auditData['seo_score'];
        $this->website->status = 'completed';
        
        if ($this->website->create()) {
            return [
                'success' => true,
                'message' => 'Website audited successfully',
                'data' => $auditData,
                'website_id' => $this->website->id
            ];
        }
        
        return ['success' => false, 'message' => 'Failed to save audit results'];
    }
    
    // Perform actual audit
    private function performAudit($url) {
        try {
            $startTime = microtime(true);
            
            // Initialize curl
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                CURLOPT_HEADER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $endTime = microtime(true);
            $responseTime = round(($endTime - $startTime) * 1000); // in ms
            
            if ($httpCode !== 200 || !$response) {
                curl_close($ch);
                return false;
            }
            
            // Separate headers and body
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $headers = substr($response, 0, $headerSize);
            $html = substr($response, $headerSize);
            
            // Get additional info
            $ip = curl_getinfo($ch, CURLINFO_PRIMARY_IP);
            $effectiveUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
            
            curl_close($ch);
            
            // Parse HTML
            $dom = new DOMDocument();
            @$dom->loadHTML($html);
            
            // Extract data
            $data = [
                'title' => $this->extractTitle($dom),
                'description' => $this->extractMetaDescription($dom),
                'keywords' => $this->extractMetaKeywords($dom),
                'language' => $this->extractLanguage($dom),
                'ssl_enabled' => (strpos($url, 'https://') === 0) ? 1 : 0,
                'cms_detected' => $this->detectCMS($html, $headers),
                'server_info' => $this->extractServerInfo($headers),
                'country' => 'Unknown', // Would need GeoIP service
                'ip_address' => $ip,
                'response_time' => $responseTime,
                'seo_score' => $this->calculateSEOScore($dom, $url, $headers)
            ];
            
            return $data;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    // Extract title
    private function extractTitle($dom) {
        $titles = $dom->getElementsByTagName('title');
        return $titles->length > 0 ? trim($titles->item(0)->textContent) : 'No title found';
    }
    
    // Extract meta description
    private function extractMetaDescription($dom) {
        $metas = $dom->getElementsByTagName('meta');
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'description') {
                return trim($meta->getAttribute('content'));
            }
        }
        return 'No description found';
    }
    
    // Extract meta keywords
    private function extractMetaKeywords($dom) {
        $metas = $dom->getElementsByTagName('meta');
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'keywords') {
                return trim($meta->getAttribute('content'));
            }
        }
        return 'No keywords found';
    }
    
    // Extract language
    private function extractLanguage($dom) {
        $html = $dom->getElementsByTagName('html');
        if ($html->length > 0) {
            $lang = $html->item(0)->getAttribute('lang');
            return $lang ? $lang : 'en';
        }
        return 'en';
    }
    
    // Detect CMS
    private function detectCMS($html, $headers) {
        $cms = 'Unknown';
        
        if (stripos($html, 'wp-content') !== false || stripos($html, 'wordpress') !== false) {
            $cms = 'WordPress';
        } elseif (stripos($html, 'joomla') !== false) {
            $cms = 'Joomla';
        } elseif (stripos($html, 'drupal') !== false) {
            $cms = 'Drupal';
        } elseif (stripos($html, 'shopify') !== false) {
            $cms = 'Shopify';
        } elseif (stripos($html, 'wix.com') !== false) {
            $cms = 'Wix';
        } elseif (stripos($html, 'squarespace') !== false) {
            $cms = 'Squarespace';
        }
        
        return $cms;
    }
    
    // Extract server info
    private function extractServerInfo($headers) {
        if (preg_match('/Server: (.+)/i', $headers, $matches)) {
            return trim($matches[1]);
        }
        return 'Unknown';
    }
    
    // Calculate comprehensive SEO score (Phase 12 Enhancement)
    private function calculateSEOScore($dom, $url, $headers) {
        $score = 0;
        
        // Title exists and optimal length (10 points)
        $titles = $dom->getElementsByTagName('title');
        if ($titles->length > 0) {
            $titleLength = strlen($titles->item(0)->textContent);
            if ($titleLength >= 30 && $titleLength <= 60) {
                $score += 10;
            } elseif ($titleLength > 0) {
                $score += 5;
            }
        }
        
        // Meta description exists and optimal length (10 points)
        $hasDescription = false;
        $metas = $dom->getElementsByTagName('meta');
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'description') {
                $hasDescription = true;
                $descLength = strlen($meta->getAttribute('content'));
                if ($descLength >= 120 && $descLength <= 160) {
                    $score += 10;
                } elseif ($descLength > 0) {
                    $score += 5;
                }
                break;
            }
        }
        
        // SSL enabled (20 points)
        if (strpos($url, 'https://') === 0) {
            $score += 20;
        }
        
        // H1 tags (10 points)
        $h1Tags = $dom->getElementsByTagName('h1');
        if ($h1Tags->length === 1) {
            $score += 10;
        } elseif ($h1Tags->length > 0) {
            $score += 5;
        }
        
        // Images with alt tags (10 points)
        $images = $dom->getElementsByTagName('img');
        $imagesWithAlt = 0;
        foreach ($images as $img) {
            if ($img->getAttribute('alt') !== '') {
                $imagesWithAlt++;
            }
        }
        if ($images->length > 0) {
            $altRatio = $imagesWithAlt / $images->length;
            $score += round($altRatio * 10);
        } else {
            $score += 5; // Bonus if no images to worry about
        }
        
        // Viewport meta tag (10 points)
        $hasViewport = false;
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'viewport') {
                $hasViewport = true;
                $score += 10;
                break;
            }
        }
        
        // Robots meta (10 points)
        $hasRobots = false;
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'robots') {
                $hasRobots = true;
                $score += 10;
                break;
            }
        }
        
        // Response time (10 points)
        // This is a simplified check, in reality it's already calculated
        $score += 10;
        
        // Open Graph tags (10 points)
        $hasOG = false;
        foreach ($metas as $meta) {
            if (strpos($meta->getAttribute('property'), 'og:') === 0) {
                $hasOG = true;
                $score += 10;
                break;
            }
        }
        
        return min($score, 100); // Cap at 100
    }
    
    // Calculate component scores (Phase 12)
    public function calculateComponentScores($dom, $url, $headers, $responseTime) {
        $scores = [
            'overall' => 0,
            'technical' => $this->calculateTechnicalScore($dom, $url, $headers),
            'performance' => $this->calculatePerformanceScore($responseTime, $dom),
            'content' => $this->calculateContentScore($dom),
            'accessibility' => $this->calculateAccessibilityScore($dom),
            'mobile' => $this->calculateMobileScore($dom),
            'security' => $this->calculateSecurityScore($url, $headers)
        ];
        
        // Calculate overall as average of components
        $scores['overall'] = round(array_sum(array_slice($scores, 1)) / 6);
        
        // Determine grade
        $scores['grade'] = $this->determineGrade($scores['overall']);
        
        return $scores;
    }
    
    private function calculateTechnicalScore($dom, $url, $headers) {
        $score = 0;
        $maxScore = 100;
        
        // SSL (25 points)
        if (strpos($url, 'https://') === 0) $score += 25;
        
        // Title tag (15 points)
        $titles = $dom->getElementsByTagName('title');
        if ($titles->length > 0) {
            $titleLen = strlen($titles->item(0)->textContent);
            if ($titleLen >= 30 && $titleLen <= 60) $score += 15;
            elseif ($titleLen > 0) $score += 8;
        }
        
        // Meta description (15 points)
        $metas = $dom->getElementsByTagName('meta');
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'description') {
                $descLen = strlen($meta->getAttribute('content'));
                if ($descLen >= 120 && $descLen <= 160) $score += 15;
                elseif ($descLen > 0) $score += 8;
                break;
            }
        }
        
        // H1 tag (15 points)
        $h1Tags = $dom->getElementsByTagName('h1');
        if ($h1Tags->length === 1) $score += 15;
        elseif ($h1Tags->length > 0) $score += 8;
        
        // Robots meta (10 points)
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'robots') {
                $score += 10;
                break;
            }
        }
        
        // Canonical tag (10 points)
        $links = $dom->getElementsByTagName('link');
        foreach ($links as $link) {
            if ($link->getAttribute('rel') === 'canonical') {
                $score += 10;
                break;
            }
        }
        
        // Sitemap reference (10 points)
        // Simplified check
        $score += 5;
        
        return min($score, $maxScore);
    }
    
    private function calculatePerformanceScore($responseTime, $dom) {
        $score = 0;
        
        // Response time (40 points)
        if ($responseTime < 200) $score += 40;
        elseif ($responseTime < 500) $score += 30;
        elseif ($responseTime < 1000) $score += 20;
        elseif ($responseTime < 2000) $score += 10;
        
        // Image count (20 points)
        $images = $dom->getElementsByTagName('img');
        $imgCount = $images->length;
        if ($imgCount <= 10) $score += 20;
        elseif ($imgCount <= 20) $score += 15;
        elseif ($imgCount <= 30) $score += 10;
        else $score += 5;
        
        // Script count (20 points)
        $scripts = $dom->getElementsByTagName('script');
        $scriptCount = $scripts->length;
        if ($scriptCount <= 5) $score += 20;
        elseif ($scriptCount <= 10) $score += 15;
        elseif ($scriptCount <= 15) $score += 10;
        else $score += 5;
        
        // CSS count (20 points)
        $styles = $dom->getElementsByTagName('link');
        $cssCount = 0;
        foreach ($styles as $style) {
            if ($style->getAttribute('rel') === 'stylesheet') $cssCount++;
        }
        if ($cssCount <= 3) $score += 20;
        elseif ($cssCount <= 5) $score += 15;
        elseif ($cssCount <= 8) $score += 10;
        else $score += 5;
        
        return min($score, 100);
    }
    
    private function calculateContentScore($dom) {
        $score = 0;
        
        // Headings structure (30 points)
        $h1 = $dom->getElementsByTagName('h1')->length;
        $h2 = $dom->getElementsByTagName('h2')->length;
        $h3 = $dom->getElementsByTagName('h3')->length;
        
        if ($h1 === 1 && $h2 > 0) $score += 30;
        elseif ($h1 > 0 || $h2 > 0) $score += 15;
        
        // Paragraph count (20 points)
        $paragraphs = $dom->getElementsByTagName('p');
        if ($paragraphs->length > 5) $score += 20;
        elseif ($paragraphs->length > 2) $score += 10;
        
        // Links (20 points)
        $links = $dom->getElementsByTagName('a');
        if ($links->length > 5 && $links->length < 100) $score += 20;
        elseif ($links->length > 0) $score += 10;
        
        // Lists (15 points)
        $ul = $dom->getElementsByTagName('ul')->length;
        $ol = $dom->getElementsByTagName('ol')->length;
        if ($ul + $ol > 0) $score += 15;
        
        // Images (15 points)
        $images = $dom->getElementsByTagName('img');
        if ($images->length > 0 && $images->length < 30) $score += 15;
        elseif ($images->length > 0) $score += 8;
        
        return min($score, 100);
    }
    
    private function calculateAccessibilityScore($dom) {
        $score = 0;
        
        // Alt attributes (30 points)
        $images = $dom->getElementsByTagName('img');
        if ($images->length > 0) {
            $withAlt = 0;
            foreach ($images as $img) {
                if ($img->getAttribute('alt') !== '') $withAlt++;
            }
            $score += round(($withAlt / $images->length) * 30);
        } else {
            $score += 15;
        }
        
        // Language attribute (20 points)
        $html = $dom->getElementsByTagName('html');
        if ($html->length > 0 && $html->item(0)->getAttribute('lang')) {
            $score += 20;
        }
        
        // Form labels (20 points)
        $inputs = $dom->getElementsByTagName('input');
        $labels = $dom->getElementsByTagName('label');
        if ($inputs->length === 0 || $labels->length > 0) {
            $score += 20;
        }
        
        // ARIA attributes (15 points)
        $xpath = new DOMXPath($dom);
        $ariaElements = $xpath->query('//*[@aria-label or @aria-labelledby or @role]');
        if ($ariaElements->length > 0) $score += 15;
        else $score += 5;
        
        // Skip links (15 points)
        $score += 8; // Simplified
        
        return min($score, 100);
    }
    
    private function calculateMobileScore($dom) {
        $score = 0;
        
        // Viewport meta tag (40 points)
        $metas = $dom->getElementsByTagName('meta');
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'viewport') {
                $content = $meta->getAttribute('content');
                if (strpos($content, 'width=device-width') !== false) {
                    $score += 40;
                } else {
                    $score += 20;
                }
                break;
            }
        }
        
        // Responsive images (20 points)
        $images = $dom->getElementsByTagName('img');
        $responsiveImages = 0;
        foreach ($images as $img) {
            if ($img->getAttribute('srcset') || $img->getAttribute('sizes')) {
                $responsiveImages++;
            }
        }
        if ($images->length > 0) {
            $score += round(($responsiveImages / $images->length) * 20);
        } else {
            $score += 10;
        }
        
        // Media queries (20 points - simplified)
        $styles = $dom->getElementsByTagName('style');
        $hasMediaQueries = false;
        foreach ($styles as $style) {
            if (strpos($style->textContent, '@media') !== false) {
                $hasMediaQueries = true;
                break;
            }
        }
        if ($hasMediaQueries) $score += 20;
        else $score += 10;
        
        // Touch-friendly elements (20 points - simplified)
        $score += 15;
        
        return min($score, 100);
    }
    
    private function calculateSecurityScore($url, $headers) {
        $score = 0;
        
        // HTTPS (40 points)
        if (strpos($url, 'https://') === 0) $score += 40;
        
        // Security headers (60 points total)
        // X-Frame-Options (10 points)
        if (stripos($headers, 'X-Frame-Options') !== false) $score += 10;
        
        // X-Content-Type-Options (10 points)
        if (stripos($headers, 'X-Content-Type-Options') !== false) $score += 10;
        
        // Strict-Transport-Security (10 points)
        if (stripos($headers, 'Strict-Transport-Security') !== false) $score += 10;
        
        // Content-Security-Policy (15 points)
        if (stripos($headers, 'Content-Security-Policy') !== false) $score += 15;
        
        // X-XSS-Protection (10 points)
        if (stripos($headers, 'X-XSS-Protection') !== false) $score += 10;
        
        // Referrer-Policy (5 points)
        if (stripos($headers, 'Referrer-Policy') !== false) $score += 5;
        
        return min($score, 100);
    }
    
    private function determineGrade($score) {
        if ($score >= 90) return 'Excellent';
        if ($score >= 70) return 'Good';
        if ($score >= 50) return 'Average';
        return 'Poor';
    }
}
