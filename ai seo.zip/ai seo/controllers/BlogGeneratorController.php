<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/BlogPost.php';

class BlogGeneratorController {
    private $db;
    private $blogPost;
    private $apiKey;
    private $apiUrl;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->blogPost = new BlogPost($this->db);
        // Use OpenAI API
        $this->apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : GEMINI_API_KEY;
        $this->apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : GEMINI_API_URL;
    }
    
    // Generate blog post using Gemini AI
    public function generateBlogPost($keyword, $wordCount, $language, $tone) {
        if (empty($this->apiKey) || $this->apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            return [
                'success' => false,
                'message' => 'Gemini API key not configured'
            ];
        }
        
        $prompt = $this->buildBlogPrompt($keyword, $wordCount, $language, $tone);
        $response = $this->callGeminiAPI($prompt);
        
        if (!$response['success']) {
            return $response;
        }
        
        $blogData = $this->parseBlogResponse($response['content']);
        
        if ($blogData['success']) {
            $blogData['seo_score'] = $this->calculateSEOScore($blogData, $keyword, $wordCount);
        }
        
        return $blogData;
    }
    
    // Build blog generation prompt
    private function buildBlogPrompt($keyword, $wordCount, $language, $tone) {
        $prompt = <<<EOT
You are an expert content writer and SEO specialist. Write a comprehensive blog post in {$language} with a {$tone} tone.

**TOPIC KEYWORD:** {$keyword}
**TARGET WORD COUNT:** {$wordCount} words
**LANGUAGE:** {$language}
**TONE:** {$tone}

**REQUIRED OUTPUT (STRICT JSON):**

{
  "title": "SEO-optimized blog title (60 characters max, include keyword)",
  "outline": [
    "Introduction overview",
    "Main point 1",
    "Main point 2",
    "Main point 3",
    "Main point 4",
    "Main point 5",
    "Conclusion overview"
  ],
  "introduction": "Engaging 150-200 word introduction that hooks readers and includes the keyword naturally. Explain what the article covers and why it matters.",
  "sections": [
    {
      "heading": "H2 Heading Here",
      "content": "300-400 word section content with H3 subheadings if needed. Include keyword variations and semantic keywords."
    },
    {
      "heading": "H2 Heading Here",
      "content": "300-400 word section content"
    },
    {
      "heading": "H2 Heading Here",
      "content": "300-400 word section content"
    },
    {
      "heading": "H2 Heading Here",
      "content": "300-400 word section content"
    }
  ],
  "faq": [
    {
      "question": "Common question about the topic?",
      "answer": "Clear, concise answer (50-80 words)"
    },
    {
      "question": "Another common question?",
      "answer": "Clear answer"
    },
    {
      "question": "Third question?",
      "answer": "Clear answer"
    },
    {
      "question": "Fourth question?",
      "answer": "Clear answer"
    },
    {
      "question": "Fifth question?",
      "answer": "Clear answer"
    }
  ],
  "conclusion": "Strong 100-150 word conclusion that summarizes key points and includes keyword",
  "call_to_action": "Compelling CTA (30-50 words) that encourages reader action"
}

**REQUIREMENTS:**
- Write approximately {$wordCount} words total
- Use keyword naturally (1-2% density)
- Include H2 and H3 headings
- Write in active voice
- Use short paragraphs (3-4 sentences max)
- Include transition words
- Add specific examples and data
- Make it engaging and valuable
- Optimize for featured snippets
- Use semantic keywords
- {$tone} tone throughout
- Write in {$language}

**STRUCTURE:**
1. Title (keyword-optimized)
2. Introduction (hook + overview)
3. 4-6 main sections with H2 headings
4. FAQ section (5 questions)
5. Conclusion (summary)
6. Call-to-action (next steps)
EOT;
        
        return $prompt;
    }
    
    // Call OpenAI API (replaces Gemini)
    private function callGeminiAPI($prompt) {
        $url = $this->apiUrl;
        
        $data = [
            'model' => defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are an expert content writer and SEO specialist. Create comprehensive, engaging blog posts in valid JSON format only.'
                ],
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'temperature' => 0.8,
            'max_tokens' => 4096
            // JSON mode temporarily disabled for compatibility
            // 'response_format' => ['type' => 'json_object']
        ];
        
        try {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $this->apiKey
                ],
                CURLOPT_TIMEOUT => 120,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($error) {
                return ['success' => false, 'message' => 'API request failed: ' . $error];
            }
            
            if ($httpCode !== 200) {
                $errorData = json_decode($response, true);
                $errorMsg = $errorData['error']['message'] ?? 'HTTP ' . $httpCode;
                return ['success' => false, 'message' => 'OpenAI API error: ' . $errorMsg];
            }
            
            $result = json_decode($response, true);
            
            if (!$result || !isset($result['choices'][0]['message']['content'])) {
                return ['success' => false, 'message' => 'Invalid API response'];
            }
            
            return [
                'success' => true,
                'content' => $result['choices'][0]['message']['content']
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Exception: ' . $e->getMessage()];
        }
    }
    
    // Parse blog response
    private function parseBlogResponse($content) {
        $content = preg_replace('/```json\s*/', '', $content);
        $content = preg_replace('/```\s*$/', '', $content);
        $content = trim($content);
        
        $data = json_decode($content, true);
        
        if (!$data) {
            preg_match('/\{[\s\S]*\}/', $content, $matches);
            if ($matches) {
                $data = json_decode($matches[0], true);
            }
        }
        
        if (!$data) {
            return [
                'success' => false,
                'message' => 'Failed to parse blog data'
            ];
        }
        
        return [
            'success' => true,
            'title' => $data['title'] ?? 'Untitled Blog Post',
            'outline' => $data['outline'] ?? [],
            'introduction' => $data['introduction'] ?? '',
            'sections' => $data['sections'] ?? [],
            'faq' => $data['faq'] ?? [],
            'conclusion' => $data['conclusion'] ?? '',
            'call_to_action' => $data['call_to_action'] ?? ''
        ];
    }
    
    // Calculate SEO Score
    private function calculateSEOScore($blogData, $keyword, $targetWordCount) {
        $score = 0;
        
        // Word count check (20 points)
        $fullContent = $blogData['introduction'] . ' ';
        foreach ($blogData['sections'] as $section) {
            $fullContent .= $section['content'] . ' ';
        }
        $fullContent .= $blogData['conclusion'];
        
        $actualWordCount = str_word_count($fullContent);
        $wordCountRatio = $actualWordCount / $targetWordCount;
        
        if ($wordCountRatio >= 0.9 && $wordCountRatio <= 1.1) {
            $score += 20;
        } elseif ($wordCountRatio >= 0.7) {
            $score += 15;
        } else {
            $score += 5;
        }
        
        // Keyword in title (15 points)
        if (stripos($blogData['title'], $keyword) !== false) {
            $score += 15;
        }
        
        // Has outline (10 points)
        if (count($blogData['outline']) >= 5) {
            $score += 10;
        }
        
        // Has sections (20 points)
        if (count($blogData['sections']) >= 4) {
            $score += 20;
        } elseif (count($blogData['sections']) >= 3) {
            $score += 15;
        }
        
        // Has FAQ (15 points)
        if (count($blogData['faq']) >= 5) {
            $score += 15;
        } elseif (count($blogData['faq']) >= 3) {
            $score += 10;
        }
        
        // Has CTA (10 points)
        if (!empty($blogData['call_to_action'])) {
            $score += 10;
        }
        
        // Has conclusion (10 points)
        if (!empty($blogData['conclusion'])) {
            $score += 10;
        }
        
        return min($score, 100);
    }
    
    // Save blog post
    public function saveBlogPost($keyword, $wordCount, $language, $tone, $blogData, $userId) {
        $this->blogPost->user_id = $userId;
        $this->blogPost->keyword = $keyword;
        $this->blogPost->word_count = $wordCount;
        $this->blogPost->language = $language;
        $this->blogPost->tone = $tone;
        $this->blogPost->title = $blogData['title'];
        $this->blogPost->outline = json_encode($blogData['outline']);
        $this->blogPost->introduction = $blogData['introduction'];
        $this->blogPost->content = json_encode($blogData['sections']);
        $this->blogPost->faq = json_encode($blogData['faq']);
        $this->blogPost->call_to_action = $blogData['call_to_action'];
        $this->blogPost->seo_score = $blogData['seo_score'] ?? 0;
        
        if ($this->blogPost->create()) {
            return [
                'success' => true,
                'message' => 'Blog post saved successfully',
                'blog_id' => $this->blogPost->id
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Failed to save blog post'
        ];
    }
    
    // Get saved blog posts
    public function getSavedBlogPosts($userId, $limit = 20) {
        return $this->blogPost->getByUser($userId, $limit);
    }
}
