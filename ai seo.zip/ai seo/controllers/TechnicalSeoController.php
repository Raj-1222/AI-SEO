<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/SeoIssue.php';

class TechnicalSeoController {
    private $db;
    private $seoIssue;
    private $issues = [];
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->seoIssue = new SeoIssue($this->db);
    }
    
    // Perform technical SEO scan
    public function scanWebsite($url, $website_id) {
        $this->issues = [];
        
        // Fetch website content
        $data = $this->fetchWebsiteData($url);
        if (!$data) {
            return ['success' => false, 'message' => 'Failed to fetch website data'];
        }
        
        $html = $data['html'];
        $headers = $data['headers'];
        $dom = $data['dom'];
        
        // Run all checks
        $this->checkTitle($dom);
        $this->checkMetaDescription($dom);
        $this->checkHeadings($dom);
        $this->checkCanonical($dom, $url);
        $this->checkRobotsTxt($url);
        $this->checkSitemap($url);
        $this->checkSSL($url);
        $this->checkOpenGraph($dom);
        $this->checkTwitterCards($dom);
        $this->checkSchema($html);
        $this->checkImages($dom);
        $this->checkLinks($dom, $url);
        $this->checkURLStructure($url);
        $this->checkMobileFriendly($dom);
        
        // Save issues to database
        $saved = 0;
        foreach ($this->issues as $issue) {
            $issue['website_id'] = $website_id;
            $this->seoIssue->website_id = $issue['website_id'];
            $this->seoIssue->category = $issue['category'];
            $this->seoIssue->issue_type = $issue['issue_type'];
            $this->seoIssue->status = $issue['status'];
            $this->seoIssue->severity = $issue['severity'];
            $this->seoIssue->message = $issue['message'];
            $this->seoIssue->recommendation = $issue['recommendation'];
            $this->seoIssue->priority = $issue['priority'];
            $this->seoIssue->details = isset($issue['details']) ? json_encode($issue['details']) : null;
            
            if ($this->seoIssue->create()) {
                $saved++;
            }
        }
        
        return [
            'success' => true,
            'message' => 'Technical SEO scan completed',
            'issues_found' => count($this->issues),
            'issues_saved' => $saved,
            'issues' => $this->issues
        ];
    }
    
    // Fetch website data
    private function fetchWebsiteData($url) {
        try {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; AurifySEO/1.0)',
                CURLOPT_HEADER => true
            ]);
            
            $response = curl_exec($ch);
            if (!$response) {
                curl_close($ch);
                return false;
            }
            
            $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $headers = substr($response, 0, $headerSize);
            $html = substr($response, $headerSize);
            curl_close($ch);
            
            $dom = new DOMDocument();
            @$dom->loadHTML($html);
            
            return [
                'html' => $html,
                'headers' => $headers,
                'dom' => $dom
            ];
        } catch (Exception $e) {
            return false;
        }
    }
    
    // Check Title Tag
    private function checkTitle($dom) {
        $titles = $dom->getElementsByTagName('title');
        
        if ($titles->length === 0) {
            $this->addIssue('Meta Tags', 'title', 'error', 'critical', 
                'Missing Title Tag', 
                'Add a unique, descriptive title tag (50-60 characters)', 
                100);
        } else {
            $title = trim($titles->item(0)->textContent);
            $length = strlen($title);
            
            if ($length === 0) {
                $this->addIssue('Meta Tags', 'title', 'error', 'critical', 
                    'Empty Title Tag', 
                    'Add descriptive content to your title tag', 
                    95);
            } elseif ($length < 30) {
                $this->addIssue('Meta Tags', 'title', 'warning', 'medium', 
                    'Title Too Short (' . $length . ' characters)', 
                    'Expand title to 50-60 characters for better SEO', 
                    60);
            } elseif ($length > 60) {
                $this->addIssue('Meta Tags', 'title', 'warning', 'medium', 
                    'Title Too Long (' . $length . ' characters)', 
                    'Shorten title to 50-60 characters to avoid truncation', 
                    60);
            } else {
                $this->addIssue('Meta Tags', 'title', 'pass', 'low', 
                    'Title Tag Optimized (' . $length . ' characters)', 
                    'Great! Your title length is within the recommended range', 
                    10, ['title' => $title, 'length' => $length]);
            }
        }
    }
    
    // Check Meta Description
    private function checkMetaDescription($dom) {
        $found = false;
        $metas = $dom->getElementsByTagName('meta');
        
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'description') {
                $found = true;
                $description = trim($meta->getAttribute('content'));
                $length = strlen($description);
                
                if ($length === 0) {
                    $this->addIssue('Meta Tags', 'meta-description', 'error', 'high', 
                        'Empty Meta Description', 
                        'Add descriptive content to your meta description', 
                        90);
                } elseif ($length < 120) {
                    $this->addIssue('Meta Tags', 'meta-description', 'warning', 'medium', 
                        'Meta Description Too Short (' . $length . ' characters)', 
                        'Expand to 120-160 characters for better CTR', 
                        55);
                } elseif ($length > 160) {
                    $this->addIssue('Meta Tags', 'meta-description', 'warning', 'medium', 
                        'Meta Description Too Long (' . $length . ' characters)', 
                        'Shorten to 120-160 characters to avoid truncation', 
                        55);
                } else {
                    $this->addIssue('Meta Tags', 'meta-description', 'pass', 'low', 
                        'Meta Description Optimized (' . $length . ' characters)', 
                        'Perfect length for search engine results', 
                        10);
                }
                break;
            }
        }
        
        if (!$found) {
            $this->addIssue('Meta Tags', 'meta-description', 'error', 'high', 
                'Missing Meta Description', 
                'Add a unique meta description (120-160 characters)', 
                90);
        }
    }
    
    // Check Headings (H1, H2)
    private function checkHeadings($dom) {
        // Check H1
        $h1Tags = $dom->getElementsByTagName('h1');
        $h1Count = $h1Tags->length;
        
        if ($h1Count === 0) {
            $this->addIssue('Content', 'h1', 'error', 'high', 
                'Missing H1 Tag', 
                'Add exactly one H1 tag containing your main keyword', 
                85);
        } elseif ($h1Count === 1) {
            $this->addIssue('Content', 'h1', 'pass', 'low', 
                'H1 Tag Present (1 found)', 
                'Good! Single H1 tag improves content structure', 
                10);
        } else {
            $this->addIssue('Content', 'h1', 'warning', 'medium', 
                'Multiple H1 Tags (' . $h1Count . ' found)', 
                'Use only one H1 tag per page for better SEO', 
                65);
        }
        
        // Check H2
        $h2Tags = $dom->getElementsByTagName('h2');
        $h2Count = $h2Tags->length;
        
        if ($h2Count === 0) {
            $this->addIssue('Content', 'h2', 'warning', 'low', 
                'No H2 Tags Found', 
                'Add H2 tags to break up content and improve structure', 
                40);
        } else {
            $this->addIssue('Content', 'h2', 'pass', 'low', 
                'H2 Tags Present (' . $h2Count . ' found)', 
                'Good content structure with heading hierarchy', 
                10);
        }
    }
    
    // Check Canonical Tag
    private function checkCanonical($dom, $url) {
        $found = false;
        $links = $dom->getElementsByTagName('link');
        
        foreach ($links as $link) {
            if (strtolower($link->getAttribute('rel')) === 'canonical') {
                $found = true;
                $canonical = $link->getAttribute('href');
                
                if (empty($canonical)) {
                    $this->addIssue('Technical', 'canonical', 'error', 'medium', 
                        'Empty Canonical Tag', 
                        'Set a valid canonical URL to avoid duplicate content issues', 
                        70);
                } else {
                    $this->addIssue('Technical', 'canonical', 'pass', 'low', 
                        'Canonical Tag Present', 
                        'Helps prevent duplicate content issues', 
                        10, ['canonical' => $canonical]);
                }
                break;
            }
        }
        
        if (!$found) {
            $this->addIssue('Technical', 'canonical', 'warning', 'medium', 
                'Missing Canonical Tag', 
                'Add canonical tag to specify preferred URL version', 
                60);
        }
    }
    
    // Check Robots.txt
    private function checkRobotsTxt($url) {
        $parsed = parse_url($url);
        $robotsUrl = $parsed['scheme'] . '://' . $parsed['host'] . '/robots.txt';
        
        $ch = curl_init($robotsUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => 10
        ]);
        
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $this->addIssue('Technical', 'robots-txt', 'pass', 'low', 
                'Robots.txt Found', 
                'Good! Helps search engines crawl your site effectively', 
                10, ['url' => $robotsUrl]);
        } else {
            $this->addIssue('Technical', 'robots-txt', 'warning', 'low', 
                'Robots.txt Not Found', 
                'Create robots.txt to guide search engine crawlers', 
                45);
        }
    }
    
    // Check Sitemap.xml
    private function checkSitemap($url) {
        $parsed = parse_url($url);
        $sitemapUrl = $parsed['scheme'] . '://' . $parsed['host'] . '/sitemap.xml';
        
        $ch = curl_init($sitemapUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY => true,
            CURLOPT_TIMEOUT => 10
        ]);
        
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $this->addIssue('Technical', 'sitemap', 'pass', 'low', 
                'Sitemap.xml Found', 
                'Excellent! Helps search engines discover your content', 
                10, ['url' => $sitemapUrl]);
        } else {
            $this->addIssue('Technical', 'sitemap', 'warning', 'medium', 
                'Sitemap.xml Not Found', 
                'Create XML sitemap to improve search engine indexing', 
                65);
        }
    }

    
    // Check SSL/HTTPS
    private function checkSSL($url) {
        if (strpos($url, 'https://') === 0) {
            $this->addIssue('Security', 'ssl', 'pass', 'low', 
                'HTTPS Enabled', 
                'Great! Your site uses secure SSL encryption', 
                10);
        } else {
            $this->addIssue('Security', 'ssl', 'error', 'critical', 
                'HTTPS Not Enabled', 
                'Enable HTTPS immediately for security and SEO benefits', 
                100);
        }
    }
    
    // Check Open Graph Tags
    private function checkOpenGraph($dom) {
        $ogTags = [];
        $metas = $dom->getElementsByTagName('meta');
        
        foreach ($metas as $meta) {
            $property = $meta->getAttribute('property');
            if (strpos($property, 'og:') === 0) {
                $ogTags[] = $property;
            }
        }
        
        $requiredOG = ['og:title', 'og:description', 'og:image', 'og:url'];
        $missing = array_diff($requiredOG, $ogTags);
        
        if (empty($ogTags)) {
            $this->addIssue('Social', 'open-graph', 'warning', 'medium', 
                'Missing Open Graph Tags', 
                'Add Open Graph tags to improve social media sharing', 
                50);
        } elseif (count($missing) > 0) {
            $this->addIssue('Social', 'open-graph', 'warning', 'low', 
                'Incomplete Open Graph Tags (' . count($ogTags) . '/4 found)', 
                'Add missing OG tags: ' . implode(', ', $missing), 
                35, ['found' => $ogTags, 'missing' => $missing]);
        } else {
            $this->addIssue('Social', 'open-graph', 'pass', 'low', 
                'Open Graph Tags Complete', 
                'Excellent social media optimization', 
                10, ['tags' => $ogTags]);
        }
    }
    
    // Check Twitter Cards
    private function checkTwitterCards($dom) {
        $twitterTags = [];
        $metas = $dom->getElementsByTagName('meta');
        
        foreach ($metas as $meta) {
            $name = $meta->getAttribute('name');
            if (strpos($name, 'twitter:') === 0) {
                $twitterTags[] = $name;
            }
        }
        
        if (empty($twitterTags)) {
            $this->addIssue('Social', 'twitter-cards', 'warning', 'low', 
                'Missing Twitter Card Tags', 
                'Add Twitter Card tags to optimize Twitter sharing', 
                40);
        } else {
            $this->addIssue('Social', 'twitter-cards', 'pass', 'low', 
                'Twitter Card Tags Present (' . count($twitterTags) . ' found)', 
                'Good Twitter optimization', 
                10, ['tags' => $twitterTags]);
        }
    }
    
    // Check Schema/Structured Data
    private function checkSchema($html) {
        $hasJsonLd = (strpos($html, 'application/ld+json') !== false);
        $hasMicrodata = (strpos($html, 'itemscope') !== false || strpos($html, 'itemprop') !== false);
        $hasRDFa = (strpos($html, 'vocab=') !== false || strpos($html, 'typeof=') !== false);
        
        if ($hasJsonLd || $hasMicrodata || $hasRDFa) {
            $types = [];
            if ($hasJsonLd) $types[] = 'JSON-LD';
            if ($hasMicrodata) $types[] = 'Microdata';
            if ($hasRDFa) $types[] = 'RDFa';
            
            $this->addIssue('Technical', 'schema', 'pass', 'low', 
                'Structured Data Found (' . implode(', ', $types) . ')', 
                'Great! Helps search engines understand your content', 
                10, ['types' => $types]);
        } else {
            $this->addIssue('Technical', 'schema', 'warning', 'medium', 
                'No Structured Data Found', 
                'Add Schema.org markup to enhance search results', 
                55);
        }
    }
    
    // Check Images
    private function checkImages($dom) {
        $images = $dom->getElementsByTagName('img');
        $totalImages = $images->length;
        $imagesWithAlt = 0;
        $imagesWithoutAlt = [];
        $largeImages = [];
        
        foreach ($images as $img) {
            $alt = $img->getAttribute('alt');
            $src = $img->getAttribute('src');
            
            if (!empty($alt)) {
                $imagesWithAlt++;
            } else {
                $imagesWithoutAlt[] = $src;
            }
            
            // Check image size (basic check)
            $width = $img->getAttribute('width');
            $height = $img->getAttribute('height');
            if (($width > 2000) || ($height > 2000)) {
                $largeImages[] = $src;
            }
        }
        
        if ($totalImages === 0) {
            $this->addIssue('Content', 'images', 'info', 'low', 
                'No Images Found', 
                'Consider adding relevant images to enhance content', 
                20);
        } else {
            // Alt text check
            $altPercentage = round(($imagesWithAlt / $totalImages) * 100);
            
            if ($altPercentage === 100) {
                $this->addIssue('Content', 'image-alt', 'pass', 'low', 
                    'All Images Have Alt Text (' . $totalImages . ' images)', 
                    'Perfect accessibility and SEO optimization', 
                    10);
            } elseif ($altPercentage >= 80) {
                $this->addIssue('Content', 'image-alt', 'warning', 'low', 
                    'Most Images Have Alt Text (' . $altPercentage . '%)', 
                    'Add alt text to remaining ' . count($imagesWithoutAlt) . ' images', 
                    30);
            } else {
                $this->addIssue('Content', 'image-alt', 'warning', 'medium', 
                    'Many Images Missing Alt Text (' . $altPercentage . '%)', 
                    'Add descriptive alt text to improve accessibility and SEO', 
                    60, ['missing_count' => count($imagesWithoutAlt)]);
            }
            
            // Large images check
            if (count($largeImages) > 0) {
                $this->addIssue('Performance', 'image-size', 'warning', 'medium', 
                    'Large Images Detected (' . count($largeImages) . ' images)', 
                    'Optimize large images to improve page load speed', 
                    65, ['count' => count($largeImages)]);
            }
        }
    }
    
    // Check Links
    private function checkLinks($dom, $url) {
        $links = $dom->getElementsByTagName('a');
        $totalLinks = $links->length;
        $internalLinks = 0;
        $externalLinks = 0;
        $brokenLinks = [];
        
        $parsedUrl = parse_url($url);
        $host = $parsedUrl['host'];
        
        foreach ($links as $link) {
            $href = $link->getAttribute('href');
            
            if (empty($href) || $href === '#') {
                continue;
            }
            
            // Check if internal or external
            if (strpos($href, $host) !== false || strpos($href, '/') === 0) {
                $internalLinks++;
            } elseif (strpos($href, 'http') === 0) {
                $externalLinks++;
            }
        }
        
        if ($totalLinks === 0) {
            $this->addIssue('Content', 'links', 'warning', 'low', 
                'No Links Found', 
                'Add internal and external links to improve navigation and SEO', 
                45);
        } else {
            $this->addIssue('Content', 'internal-links', 'pass', 'low', 
                'Internal Links Found (' . $internalLinks . ' links)', 
                'Good internal linking structure', 
                10, ['count' => $internalLinks]);
            
            $this->addIssue('Content', 'external-links', 'pass', 'low', 
                'External Links Found (' . $externalLinks . ' links)', 
                'Provides additional value to users', 
                10, ['count' => $externalLinks]);
        }
    }
    
    // Check URL Structure
    private function checkURLStructure($url) {
        $parsed = parse_url($url);
        $path = isset($parsed['path']) ? $parsed['path'] : '/';
        
        $issues = [];
        
        // Check for parameters
        if (isset($parsed['query'])) {
            $issues[] = 'Contains query parameters';
        }
        
        // Check for underscores
        if (strpos($path, '_') !== false) {
            $issues[] = 'Uses underscores (hyphens preferred)';
        }
        
        // Check for uppercase
        if (preg_match('/[A-Z]/', $path)) {
            $issues[] = 'Contains uppercase letters';
        }
        
        // Check length
        if (strlen($url) > 100) {
            $issues[] = 'URL too long (' . strlen($url) . ' characters)';
        }
        
        if (empty($issues)) {
            $this->addIssue('Technical', 'url-structure', 'pass', 'low', 
                'URL Structure Optimized', 
                'Clean, SEO-friendly URL structure', 
                10);
        } else {
            $this->addIssue('Technical', 'url-structure', 'warning', 'low', 
                'URL Structure Issues', 
                'Optimize URL: ' . implode(', ', $issues), 
                35, ['issues' => $issues]);
        }
    }
    
    // Check Mobile Friendly
    private function checkMobileFriendly($dom) {
        $hasViewport = false;
        $metas = $dom->getElementsByTagName('meta');
        
        foreach ($metas as $meta) {
            if (strtolower($meta->getAttribute('name')) === 'viewport') {
                $hasViewport = true;
                $content = $meta->getAttribute('content');
                
                if (strpos($content, 'width=device-width') !== false) {
                    $this->addIssue('Mobile', 'mobile-friendly', 'pass', 'low', 
                        'Mobile Viewport Configured', 
                        'Site is optimized for mobile devices', 
                        10, ['viewport' => $content]);
                } else {
                    $this->addIssue('Mobile', 'mobile-friendly', 'warning', 'medium', 
                        'Viewport Meta Tag Incomplete', 
                        'Set viewport to "width=device-width, initial-scale=1.0"', 
                        55);
                }
                break;
            }
        }
        
        if (!$hasViewport) {
            $this->addIssue('Mobile', 'mobile-friendly', 'error', 'high', 
                'Missing Viewport Meta Tag', 
                'Add viewport meta tag for mobile optimization', 
                80);
        }
    }
    
    // Add issue to array
    private function addIssue($category, $type, $status, $severity, $message, $recommendation, $priority, $details = null) {
        $this->issues[] = [
            'category' => $category,
            'issue_type' => $type,
            'status' => $status,
            'severity' => $severity,
            'message' => $message,
            'recommendation' => $recommendation,
            'priority' => $priority,
            'details' => $details
        ];
    }
    
    // Get issues for display
    public function getIssues($website_id) {
        return $this->seoIssue->getByWebsite($website_id);
    }
    
    // Get issue statistics
    public function getIssueStats($website_id) {
        return $this->seoIssue->getStats($website_id);
    }
}
