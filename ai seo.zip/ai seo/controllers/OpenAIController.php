<?php
require_once __DIR__ . '/../config/init.php';

class OpenAIController {
    private $apiKey;
    private $apiUrl;
    private $model;
    
    public function __construct() {
        $this->apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : GEMINI_API_KEY;
        $this->apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : 'https://api.openai.com/v1/chat/completions';
        $this->model = defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini';
    }
    
    // Universal method to call OpenAI API
    public function generateContent($prompt, $temperature = 0.7, $maxTokens = 4096, $jsonMode = true) {
        // Check if API key is configured
        if (empty($this->apiKey) || strpos($this->apiKey, 'YOUR_') !== false) {
            return [
                'success' => false,
                'message' => 'OpenAI API key not configured. Please add your API key in config/database.php'
            ];
        }
        
        $data = [
            'model' => $this->model,
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are an expert SEO consultant and content writer. Always provide accurate, actionable advice.'
                ],
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'temperature' => $temperature,
            'max_tokens' => $maxTokens
        ];
        
        // Add JSON mode if requested
        if ($jsonMode) {
            $data['response_format'] = ['type' => 'json_object'];
        }
        
        try {
            $ch = curl_init($this->apiUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $this->apiKey
                ],
                CURLOPT_TIMEOUT => 120,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($error) {
                return [
                    'success' => false,
                    'message' => 'API request failed: ' . $error
                ];
            }
            
            if ($httpCode !== 200) {
                $errorData = json_decode($response, true);
                $errorMsg = $errorData['error']['message'] ?? 'HTTP ' . $httpCode;
                return [
                    'success' => false,
                    'message' => 'OpenAI API error: ' . $errorMsg,
                    'response' => $response
                ];
            }
            
            $result = json_decode($response, true);
            
            if (!$result || !isset($result['choices'][0]['message']['content'])) {
                return [
                    'success' => false,
                    'message' => 'Invalid API response format',
                    'response' => $response
                ];
            }
            
            $content = $result['choices'][0]['message']['content'];
            
            return [
                'success' => true,
                'content' => $content,
                'usage' => $result['usage'] ?? null
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Exception: ' . $e->getMessage()
            ];
        }
    }
    
    // Parse JSON response
    public function parseJsonResponse($content) {
        // Clean up the response
        $content = trim($content);
        
        // Remove markdown code blocks if present
        $content = preg_replace('/```json\s*/', '', $content);
        $content = preg_replace('/```\s*$/', '', $content);
        $content = trim($content);
        
        $data = json_decode($content, true);
        
        if (!$data) {
            // Try to extract JSON from text
            preg_match('/\{[\s\S]*\}/', $content, $matches);
            if ($matches) {
                $data = json_decode($matches[0], true);
            }
        }
        
        return $data;
    }
    
    // Check if API is configured and working
    public function testConnection() {
        $response = $this->generateContent('Respond with: {"status": "ok", "message": "API is working"}', 0.5, 100, true);
        return $response;
    }
}
