<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/User.php';

class AuthController {
    private $db;
    private $user;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->user = new User($this->db);
    }
    
    // Handle login
    public function handleLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $remember = isset($_POST['remember']) ? true : false;
            
            if (empty($email) || empty($password)) {
                return ['success' => false, 'message' => 'Please fill in all fields'];
            }
            
            if ($this->user->login($email, $password, $remember)) {
                return ['success' => true, 'message' => 'Login successful'];
            } else {
                return ['success' => false, 'message' => 'Invalid email or password'];
            }
        }
    }
    
    // Handle registration
    public function handleRegister() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
            
            // Validation
            if (empty($name) || empty($email) || empty($password)) {
                return ['success' => false, 'message' => 'Please fill in all fields'];
            }
            
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return ['success' => false, 'message' => 'Invalid email format'];
            }
            
            if (strlen($password) < 6) {
                return ['success' => false, 'message' => 'Password must be at least 6 characters'];
            }
            
            if ($password !== $confirm_password) {
                return ['success' => false, 'message' => 'Passwords do not match'];
            }
            
            if ($this->user->emailExists($email)) {
                return ['success' => false, 'message' => 'Email already exists'];
            }
            
            // Register user
            $this->user->name = $name;
            $this->user->email = $email;
            $this->user->password = $password;
            $this->user->role = 'user';
            
            if ($this->user->register()) {
                return ['success' => true, 'message' => 'Registration successful'];
            } else {
                return ['success' => false, 'message' => 'Registration failed'];
            }
        }
    }
    
    // Handle forgot password
    public function handleForgotPassword() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            
            if (empty($email)) {
                return ['success' => false, 'message' => 'Please enter your email'];
            }
            
            if (!$this->user->emailExists($email)) {
                return ['success' => false, 'message' => 'Email not found'];
            }
            
            $token = $this->user->createPasswordResetToken($email);
            
            if ($token) {
                // In production, send email with reset link
                // For now, we'll just return the token
                $reset_link = SITE_URL . "/views/auth/reset_password.php?token=" . $token . "&email=" . urlencode($email);
                return ['success' => true, 'message' => 'Password reset link generated', 'reset_link' => $reset_link];
            } else {
                return ['success' => false, 'message' => 'Failed to create reset token'];
            }
        }
    }
    
    // Handle password reset
    public function handleResetPassword() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $token = trim($_POST['token']);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
            
            if (empty($email) || empty($token) || empty($password)) {
                return ['success' => false, 'message' => 'Please fill in all fields'];
            }
            
            if (strlen($password) < 6) {
                return ['success' => false, 'message' => 'Password must be at least 6 characters'];
            }
            
            if ($password !== $confirm_password) {
                return ['success' => false, 'message' => 'Passwords do not match'];
            }
            
            if ($this->user->resetPassword($email, $token, $password)) {
                return ['success' => true, 'message' => 'Password reset successful'];
            } else {
                return ['success' => false, 'message' => 'Invalid or expired reset token'];
            }
        }
    }
    
    // Handle logout
    public function handleLogout() {
        $this->user->logout();
        header('Location: ' . SITE_URL . '/views/auth/login.php');
        exit();
    }
    
    // Check remember me cookie
    public function checkRememberMe() {
        if (isset($_COOKIE['remember_token']) && isset($_COOKIE['user_id'])) {
            if (!isset($_SESSION['user_id'])) {
                $this->user->checkRememberToken($_COOKIE['user_id'], $_COOKIE['remember_token']);
            }
        }
    }
}
