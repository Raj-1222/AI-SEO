<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/Setting.php';
require_once __DIR__ . '/../models/N8nWebhookLog.php';

class N8nWebhookController {
    private $db;
    private $setting;
    private $webhookLog;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->setting = new Setting($this->db);
        $this->webhookLog = new N8nWebhookLog($this->db);
    }
    
    // Send website data to n8n webhook
    public function sendToWebhook($websiteData, $website_id = null) {
        // Check if webhook is enabled
        $enabled = $this->setting->get('n8n_webhook_enabled');
        if (!$enabled) {
            return [
                'success' => false,
                'message' => 'n8n webhook integration is disabled'
            ];
        }
        
        // Get webhook URL
        $webhookUrl = $this->setting->get('n8n_webhook_url');
        if (empty($webhookUrl)) {
            return [
                'success' => false,
                'message' => 'n8n webhook URL not configured'
            ];
        }
        
        // Prepare request data
        $requestData = [
            'url' => $websiteData['url'] ?? '',
            'timestamp' => date('Y-m-d H:i:s'),
            'data' => $websiteData
        ];
        
        // Create log entry
        $this->webhookLog->website_id = $website_id;
        $this->webhookLog->webhook_url = $webhookUrl;
        $this->webhookLog->request_data = json_encode($requestData);
        $this->webhookLog->status = 'pending';
        $this->webhookLog->retry_count = 0;
        $this->webhookLog->create();
        
        $logId = $this->webhookLog->id;
        
        // Send request
        $result = $this->executeWebhookRequest($webhookUrl, $requestData, $logId);
        
        return $result;
    }
    
    // Execute webhook request
    private function executeWebhookRequest($url, $data, $logId) {
        $timeout = $this->setting->get('n8n_timeout') ?: 30;
        
        try {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'User-Agent: AurifySEO/1.0'
                ],
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_SSL_VERIFYPEER => false
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            // Update log
            $log = $this->webhookLog->getById($logId);
            if ($log) {
                $this->webhookLog->id = $logId;
                $this->webhookLog->response_data = $response;
                $this->webhookLog->status_code = $httpCode;
                
                if ($httpCode >= 200 && $httpCode < 300) {
                    $this->webhookLog->status = 'success';
                    $this->webhookLog->error_message = null;
                    $this->webhookLog->update();
                    
                    return [
                        'success' => true,
                        'message' => 'Webhook sent successfully',
                        'response' => json_decode($response, true),
                        'status_code' => $httpCode,
                        'log_id' => $logId
                    ];
                } else {
                    $this->webhookLog->status = 'failed';
                    $this->webhookLog->error_message = $error ?: 'HTTP ' . $httpCode;
                    $this->webhookLog->update();
                    
                    // Check if retry is enabled
                    $retryEnabled = $this->setting->get('n8n_retry_enabled');
                    $maxRetries = $this->setting->get('n8n_max_retries') ?: 3;
                    
                    if ($retryEnabled && $log['retry_count'] < $maxRetries) {
                        $this->scheduleRetry($logId);
                    }
                    
                    return [
                        'success' => false,
                        'message' => 'Webhook failed',
                        'error' => $error ?: 'HTTP ' . $httpCode,
                        'status_code' => $httpCode,
                        'log_id' => $logId
                    ];
                }
            }
            
        } catch (Exception $e) {
            // Update log with exception
            if ($logId) {
                $this->webhookLog->id = $logId;
                $this->webhookLog->status = 'failed';
                $this->webhookLog->error_message = $e->getMessage();
                $this->webhookLog->update();
            }
            
            return [
                'success' => false,
                'message' => 'Webhook request failed',
                'error' => $e->getMessage(),
                'log_id' => $logId
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Unknown error occurred'
        ];
    }
    
    // Retry failed webhook
    public function retryWebhook($logId) {
        $log = $this->webhookLog->getById($logId);
        
        if (!$log) {
            return ['success' => false, 'message' => 'Log not found'];
        }
        
        $maxRetries = $this->setting->get('n8n_max_retries') ?: 3;
        
        if ($log['retry_count'] >= $maxRetries) {
            return ['success' => false, 'message' => 'Maximum retries reached'];
        }
        
        // Increment retry count
        $this->webhookLog->id = $logId;
        $this->webhookLog->retry_count = $log['retry_count'] + 1;
        $this->webhookLog->status = 'retry';
        $this->webhookLog->update();
        
        // Retry request
        $requestData = json_decode($log['request_data'], true);
        return $this->executeWebhookRequest($log['webhook_url'], $requestData, $logId);
    }
    
    // Schedule retry (placeholder for cron job)
    private function scheduleRetry($logId) {
        // In production, this would add to a queue or schedule a cron job
        // For now, just mark as retry status
        $this->webhookLog->id = $logId;
        $this->webhookLog->status = 'retry';
        $this->webhookLog->update();
    }
    
    // Process retry queue
    public function processRetryQueue() {
        $maxRetries = $this->setting->get('n8n_max_retries') ?: 3;
        $failedLogs = $this->webhookLog->getFailedForRetry($maxRetries);
        
        $results = [];
        foreach ($failedLogs as $log) {
            $result = $this->retryWebhook($log['id']);
            $results[] = [
                'log_id' => $log['id'],
                'result' => $result
            ];
        }
        
        return [
            'success' => true,
            'processed' => count($results),
            'results' => $results
        ];
    }
    
    // Get webhook statistics
    public function getStats() {
        return $this->webhookLog->getStats();
    }
    
    // Get recent logs
    public function getRecentLogs($website_id = null, $limit = 10) {
        if ($website_id) {
            return $this->webhookLog->getByWebsite($website_id, $limit);
        }
        
        $query = "SELECT * FROM n8n_webhook_logs ORDER BY created_at DESC LIMIT ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
