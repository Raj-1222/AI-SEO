<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/CompetitorSeo.php';
require_once __DIR__ . '/../services/CompetitorAIService.php';

class CompetitorSeoController {
    private $db;
    private $model;
    private $aiService;
    private $apiKey;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->model = new CompetitorSeo($this->db);
        $this->aiService = new CompetitorAIService();
        $this->apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';
    }
    
    /**
     * 1. COMPETITOR DISCOVERY
     * Discover competitors based on domain, keywords, and industry
     */
    public function discoverCompetitors($primaryDomain, $keywords = [], $industry = null) {
        try {
            // Use AI to discover competitors
            $competitors = $this->aiService->discoverCompetitors($primaryDomain, $industry ?? 'General', $keywords);
            
            // Save to database
            $userId = $_SESSION['user_id'] ?? 1;
            foreach ($competitors as $competitor) {
                $this->model->getOrCreateCompetitor($userId, $competitor['domain'], $primaryDomain);
            }
            
            return [
                'success' => true,
                'competitors' => $competitors,
                'count' => count($competitors),
                'powered_by' => 'ChatGPT AI'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error discovering competitors: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 2. COMPETITOR KEYWORD ANALYSIS
     * Analyze keywords that competitors are ranking for
     */
    public function analyzeCompetitorKeywords($competitorDomain, $limit = 100) {
        try {
            // Get or create competitor record
            $competitorId = $this->model->getOrCreateCompetitor($_SESSION['user_id'] ?? 1, $competitorDomain);
            
            // Use AI to analyze keywords
            $keywords = $this->aiService->analyzeCompetitorKeywords($competitorDomain, $limit);
            
            // Store keywords in database
            foreach ($keywords as $keyword) {
                $this->model->saveCompetitorKeyword($competitorId, $keyword);
            }
            
            return [
                'success' => true,
                'keywords' => $keywords,
                'total' => count($keywords),
                'competitor_domain' => $competitorDomain,
                'powered_by' => 'ChatGPT AI'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error analyzing competitor keywords: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 3. KEYWORD GAP ANALYSIS
     * Find keywords competitors rank for but you don't
     */
    public function analyzeKeywordGap($primaryDomain, $competitorDomains) {
        try {
            // Use AI to identify keyword gaps
            $industry = 'General'; // Could be passed as parameter
            $gaps = $this->aiService->identifyKeywordGaps($primaryDomain, $competitorDomains, $industry);
            
            // Sort by opportunity score
            usort($gaps, function($a, $b) {
                return $b['opportunity_score'] - $a['opportunity_score'];
            });
            
            // Save to database
            $userId = $_SESSION['user_id'] ?? 1;
            foreach (array_slice($gaps, 0, 100) as $gap) {
                $this->model->saveKeywordGap($userId, $primaryDomain, $gap);
            }
            
            return [
                'success' => true,
                'gaps' => $gaps,
                'total_opportunities' => count($gaps),
                'high_priority' => count(array_filter($gaps, function($g) { 
                    return isset($g['priority']) && ($g['priority'] === 'high' || $g['priority'] === 'critical'); 
                })),
                'powered_by' => 'ChatGPT AI'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error analyzing keyword gap: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 4. CONTENT GAP ANALYSIS
     * Identify topics competitors cover but you don't
     */
    public function analyzeContentGap($primaryDomain, $competitorDomains) {
        try {
            // Use AI to identify content gaps
            $industry = 'General';
            $contentGaps = $this->aiService->analyzeContentGaps($primaryDomain, $competitorDomains, $industry);
            
            // Save to database
            $userId = $_SESSION['user_id'] ?? 1;
            foreach ($contentGaps as $gap) {
                $this->model->saveContentGap($userId, $primaryDomain, $gap);
            }
            
            return [
                'success' => true,
                'content_gaps' => $contentGaps,
                'total' => count($contentGaps),
                'powered_by' => 'ChatGPT AI'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error analyzing content gap: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 5. COMPETITOR BACKLINKS ANALYSIS
     * Analyze competitor backlink profiles
     */
    public function analyzeCompetitorBacklinks($competitorDomain, $limit = 100) {
        try {
            $competitorId = $this->model->getOrCreateCompetitor($_SESSION['user_id'] ?? 1, $competitorDomain);
            
            // Simulate backlink analysis
            $backlinks = $this->simulateBacklinkAnalysis($competitorDomain, $limit);
            
            // Store in database
            foreach ($backlinks as $backlink) {
                $this->model->saveCompetitorBacklink($competitorId, $backlink);
            }
            
            // Calculate metrics
            $metrics = [
                'total_backlinks' => count($backlinks),
                'dofollow' => count(array_filter($backlinks, fn($b) => $b['link_type'] === 'dofollow')),
                'avg_domain_authority' => round(array_sum(array_column($backlinks, 'domain_authority')) / count($backlinks)),
                'unique_domains' => count(array_unique(array_column($backlinks, 'source_domain')))
            ];
            
            return [
                'success' => true,
                'backlinks' => $backlinks,
                'metrics' => $metrics,
                'competitor_domain' => $competitorDomain
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error analyzing backlinks: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 6. COMPETITOR TOP PAGES
     * Identify competitor's top performing pages
     */
    public function getCompetitorTopPages($competitorDomain, $limit = 20) {
        try {
            $competitorId = $this->model->getOrCreateCompetitor($_SESSION['user_id'] ?? 1, $competitorDomain);
            
            // Simulate top pages analysis
            $topPages = $this->simulateTopPagesAnalysis($competitorDomain, $limit);
            
            // Store in database
            foreach ($topPages as $page) {
                $this->model->saveCompetitorTopPage($competitorId, $page);
            }
            
            return [
                'success' => true,
                'top_pages' => $topPages,
                'total' => count($topPages)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error getting top pages: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 7. COMPETITOR TRAFFIC ESTIMATES
     * Estimate competitor traffic and trends
     */
    public function estimateCompetitorTraffic($competitorDomain, $months = 6) {
        try {
            $competitorId = $this->model->getOrCreateCompetitor($_SESSION['user_id'] ?? 1, $competitorDomain);
            
            // Use AI to estimate traffic
            $industry = 'General';
            $result = $this->aiService->estimateTrafficTrends($competitorDomain, $industry);
            
            // Get only the requested months
            $trafficData = array_slice($result['traffic_data'], -$months);
            
            // Store in database
            foreach ($trafficData as $data) {
                $this->model->saveTrafficEstimate($competitorId, $data);
            }
            
            return [
                'success' => true,
                'traffic_data' => $trafficData,
                'trend' => $result['trend'],
                'insights' => $result['insights'],
                'competitor_domain' => $competitorDomain,
                'powered_by' => 'ChatGPT AI'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error estimating traffic: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 8. SERP COMPARISON
     * Compare SERP positions for specific keywords
     */
    public function compareSERP($keywords, $primaryDomain, $competitorDomains) {
        try {
            $comparison = [];
            
            foreach ($keywords as $keyword) {
                $serpData = $this->simulateSERPAnalysis($keyword, array_merge([$primaryDomain], $competitorDomains));
                $comparison[] = $serpData;
                
                // Save to database
                $userId = $_SESSION['user_id'] ?? 1;
                $this->model->saveSERPComparison($userId, $keyword, $primaryDomain, $serpData);
            }
            
            return [
                'success' => true,
                'serp_comparison' => $comparison,
                'keywords_analyzed' => count($keywords)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error comparing SERP: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 9. COMPETITOR META ANALYSIS
     * Analyze competitor meta tags and on-page SEO
     */
    public function analyzeCompetitorMeta($competitorDomain, $sampleUrls = []) {
        try {
            $competitorId = $this->model->getOrCreateCompetitor($_SESSION['user_id'] ?? 1, $competitorDomain);
            
            if (empty($sampleUrls)) {
                $sampleUrls = [$competitorDomain];
            }
            
            $metaAnalysis = [];
            foreach ($sampleUrls as $url) {
                $meta = $this->simulateMetaAnalysis($url);
                $metaAnalysis[] = $meta;
                
                // Save to database
                $this->model->saveCompetitorMeta($competitorId, $meta);
            }
            
            return [
                'success' => true,
                'meta_analysis' => $metaAnalysis,
                'pages_analyzed' => count($metaAnalysis)
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error analyzing meta tags: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 10. COMPETITOR CONTENT ANALYSIS
     * Deep dive into competitor content strategy
     */
    public function analyzeCompetitorContent($competitorDomain, $limit = 20) {
        try {
            $competitorId = $this->model->getOrCreateCompetitor($_SESSION['user_id'] ?? 1, $competitorDomain);
            
            // Simulate content analysis
            $contentAnalysis = $this->simulateDetailedContentAnalysis($competitorDomain, $limit);
            
            // Store in database
            foreach ($contentAnalysis as $content) {
                $this->model->saveCompetitorContent($competitorId, $content);
            }
            
            // Calculate content metrics
            $metrics = [
                'avg_word_count' => round(array_sum(array_column($contentAnalysis, 'word_count')) / count($contentAnalysis)),
                'avg_seo_score' => round(array_sum(array_column($contentAnalysis, 'seo_score')) / count($contentAnalysis)),
                'total_estimated_traffic' => array_sum(array_column($contentAnalysis, 'estimated_traffic'))
            ];
            
            return [
                'success' => true,
                'content_analysis' => $contentAnalysis,
                'metrics' => $metrics
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error analyzing content: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * 11. COMPETITOR CHANGE MONITORING
     * Monitor and track competitor changes over time
     */
    public function monitorCompetitorChanges($competitorDomain) {
        try {
            $competitorId = $this->model->getOrCreateCompetitor($_SESSION['user_id'] ?? 1, $competitorDomain);
            
            // Get current data
            $currentData = $this->getCurrentCompetitorData($competitorId);
            
            // Compare with historical data
            $changes = $this->detectChanges($competitorId, $currentData);
            
            // Save changes to database
            foreach ($changes as $change) {
                $this->model->saveCompetitorChange($competitorId, $change);
            }
            
            return [
                'success' => true,
                'changes' => $changes,
                'change_count' => count($changes),
                'competitor_domain' => $competitorDomain
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error monitoring changes: ' . $e->getMessage()
            ];
        }
    }
    
    /**
     * COMPREHENSIVE COMPETITOR REPORT
     * Generate a complete competitor analysis report
     */
    public function generateComprehensiveReport($primaryDomain, $competitorDomains) {
        try {
            // Use AI to generate comprehensive report
            $industry = 'General';
            $aiReport = $this->aiService->generateCompetitorReport($primaryDomain, $competitorDomains, $industry);
            
            if (!$aiReport['success']) {
                throw new Exception('AI report generation failed');
            }
            
            $report = [
                'primary_domain' => $primaryDomain,
                'competitors' => $competitorDomains,
                'ai_analysis' => $aiReport['report'],
                'raw_insights' => $aiReport['raw_analysis'],
                'generated_at' => date('Y-m-d H:i:s'),
                'powered_by' => 'ChatGPT AI'
            ];
            
            // Gather quick data for each competitor
            foreach ($competitorDomains as $competitorDomain) {
                $report['competitor_data'][$competitorDomain] = [
                    'domain' => $competitorDomain,
                    'analyzed' => true
                ];
            }
            
            // Save report
            $userId = $_SESSION['user_id'] ?? 1;
            $this->model->saveCompetitorReport($userId, $primaryDomain, $report);
            
            return [
                'success' => true,
                'report' => $report,
                'powered_by' => 'ChatGPT AI'
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Error generating report: ' . $e->getMessage()
            ];
        }
    }
    
    // ==================== SIMULATION METHODS ====================
    // In production, these would call real APIs (SEMrush, Ahrefs, Moz, etc.)
    
    private function simulateCompetitorDiscovery($domain, $keywords, $industry) {
        $competitors = [
            ['domain' => 'competitor1.com', 'similarity_score' => 85, 'common_keywords' => 150],
            ['domain' => 'competitor2.com', 'similarity_score' => 78, 'common_keywords' => 120],
            ['domain' => 'competitor3.com', 'similarity_score' => 72, 'common_keywords' => 95],
            ['domain' => 'competitor4.com', 'similarity_score' => 68, 'common_keywords' => 85],
            ['domain' => 'competitor5.com', 'similarity_score' => 65, 'common_keywords' => 75]
        ];
        
        return $competitors;
    }
    
    private function simulateKeywordAnalysis($domain, $limit) {
        $keywords = [];
        $keywordBases = ['seo', 'marketing', 'digital', 'website', 'optimization', 'analytics', 'traffic', 'conversion'];
        
        for ($i = 0; $i < $limit; $i++) {
            $base = $keywordBases[array_rand($keywordBases)];
            $keywords[] = [
                'keyword' => $base . ' ' . ['tools', 'services', 'agency', 'software', 'tips', 'guide'][array_rand(['tools', 'services', 'agency', 'software', 'tips', 'guide'])],
                'search_volume' => rand(100, 10000),
                'keyword_difficulty' => rand(20, 90),
                'cpc_value' => round(rand(50, 500) / 100, 2),
                'position' => rand(1, 50),
                'traffic_estimate' => rand(10, 1000),
                'competition' => ['low', 'medium', 'high'][array_rand(['low', 'medium', 'high'])],
                'trend' => ['up', 'stable', 'down'][array_rand(['up', 'stable', 'down'])]
            ];
        }
        
        return $keywords;
    }
    
    private function simulateContentAnalysis($domain) {
        $content = [];
        $topics = ['SEO Guide', 'Marketing Tips', 'Analytics Tutorial', 'Conversion Optimization', 'Link Building'];
        
        foreach ($topics as $topic) {
            $content[] = [
                'topic' => $topic,
                'url' => 'https://' . $domain . '/' . strtolower(str_replace(' ', '-', $topic)),
                'keywords' => ['keyword1', 'keyword2', 'keyword3'],
                'traffic' => rand(100, 5000)
            ];
        }
        
        return $content;
    }
    
    private function simulateBacklinkAnalysis($domain, $limit) {
        $backlinks = [];
        
        for ($i = 0; $i < $limit; $i++) {
            $backlinks[] = [
                'source_url' => 'https://source' . $i . '.com/article',
                'source_domain' => 'source' . $i . '.com',
                'target_url' => 'https://' . $domain . '/page',
                'anchor_text' => 'anchor text ' . $i,
                'domain_authority' => rand(20, 90),
                'page_authority' => rand(15, 85),
                'link_type' => rand(0, 1) ? 'dofollow' : 'nofollow',
                'first_seen' => date('Y-m-d', strtotime('-' . rand(1, 365) . ' days')),
                'status' => 'active',
                'spam_score' => rand(0, 30)
            ];
        }
        
        return $backlinks;
    }
    
    private function simulateTopPagesAnalysis($domain, $limit) {
        $pages = [];
        
        for ($i = 0; $i < $limit; $i++) {
            $pages[] = [
                'url' => 'https://' . $domain . '/page-' . $i,
                'title' => 'Top Page ' . $i . ' - ' . ucfirst($domain),
                'estimated_traffic' => rand(500, 10000),
                'ranking_keywords' => rand(10, 100),
                'backlinks_count' => rand(5, 200),
                'social_shares' => rand(50, 5000),
                'page_authority' => rand(30, 90),
                'content_type' => ['blog', 'landing', 'product', 'guide'][array_rand(['blog', 'landing', 'product', 'guide'])],
                'last_updated' => date('Y-m-d', strtotime('-' . rand(1, 180) . ' days'))
            ];
        }
        
        // Sort by traffic
        usort($pages, function($a, $b) {
            return $b['estimated_traffic'] - $a['estimated_traffic'];
        });
        
        return $pages;
    }
    
    private function simulateTrafficEstimation($domain, $months) {
        $trafficData = [];
        $baseTraffic = rand(10000, 100000);
        
        for ($i = $months - 1; $i >= 0; $i--) {
            $date = date('Y-m-01', strtotime("-$i months"));
            $variation = rand(-20, 30);
            $totalTraffic = $baseTraffic + ($baseTraffic * $variation / 100);
            
            $trafficData[] = [
                'month_year' => $date,
                'organic_traffic' => round($totalTraffic * 0.6),
                'paid_traffic' => round($totalTraffic * 0.15),
                'direct_traffic' => round($totalTraffic * 0.15),
                'referral_traffic' => round($totalTraffic * 0.07),
                'social_traffic' => round($totalTraffic * 0.03),
                'total_traffic' => round($totalTraffic),
                'bounce_rate' => rand(35, 65),
                'avg_session_duration' => rand(60, 300),
                'pages_per_session' => round(rand(15, 45) / 10, 2)
            ];
            
            $baseTraffic = $totalTraffic; // Update base for next month
        }
        
        return $trafficData;
    }
    
    private function simulateSERPAnalysis($keyword, $domains) {
        $serpData = [
            'keyword' => $keyword,
            'search_volume' => rand(100, 50000),
            'positions' => []
        ];
        
        foreach ($domains as $domain) {
            $position = rand(1, 100);
            $serpData['positions'][$domain] = [
                'position' => $position,
                'url' => 'https://' . $domain . '/page',
                'title' => ucfirst($keyword) . ' - ' . $domain,
                'snippet' => 'Meta description for ' . $keyword
            ];
        }
        
        return $serpData;
    }
    
    private function simulateMetaAnalysis($url) {
        return [
            'url' => $url,
            'title' => 'Example Page Title - ' . parse_url($url, PHP_URL_HOST),
            'title_length' => rand(30, 65),
            'meta_description' => 'This is an example meta description for the page.',
            'description_length' => rand(120, 160),
            'h1_tag' => 'Main Heading',
            'canonical_url' => $url,
            'robots_meta' => 'index, follow',
            'og_tags' => json_encode(['og:title' => 'Title', 'og:description' => 'Description']),
            'twitter_tags' => json_encode(['twitter:card' => 'summary']),
            'schema_markup' => json_encode(['@type' => 'WebPage']),
            'has_favicon' => true,
            'meta_quality_score' => rand(60, 95)
        ];
    }
    
    private function simulateDetailedContentAnalysis($domain, $limit) {
        $content = [];
        
        for ($i = 0; $i < $limit; $i++) {
            $content[] = [
                'url' => 'https://' . $domain . '/article-' . $i,
                'title' => 'Article Title ' . $i,
                'word_count' => rand(800, 3000),
                'content_type' => ['blog', 'guide', 'tutorial', 'case-study'][array_rand(['blog', 'guide', 'tutorial', 'case-study'])],
                'publish_date' => date('Y-m-d', strtotime('-' . rand(1, 365) . ' days')),
                'keywords_targeted' => json_encode(['keyword1', 'keyword2', 'keyword3']),
                'headings_count' => rand(5, 20),
                'images_count' => rand(3, 15),
                'internal_links' => rand(5, 30),
                'external_links' => rand(2, 10),
                'readability_score' => rand(60, 95),
                'seo_score' => rand(65, 98),
                'social_shares' => rand(10, 5000),
                'estimated_traffic' => rand(50, 5000)
            ];
        }
        
        return $content;
    }
    
    private function getCurrentCompetitorData($competitorId) {
        // This would fetch current competitor data
        return [
            'keyword_count' => rand(100, 500),
            'backlink_count' => rand(500, 5000),
            'traffic' => rand(10000, 100000)
        ];
    }
    
    private function detectChanges($competitorId, $currentData) {
        // Simulate change detection
        $changes = [];
        
        if (rand(0, 1)) {
            $changes[] = [
                'change_type' => 'ranking',
                'change_description' => 'Competitor improved ranking for 15 keywords',
                'impact_level' => 'medium',
                'old_value' => '150',
                'new_value' => '165'
            ];
        }
        
        if (rand(0, 1)) {
            $changes[] = [
                'change_type' => 'backlink',
                'change_description' => 'Competitor gained 50 new backlinks',
                'impact_level' => 'high',
                'old_value' => '1200',
                'new_value' => '1250'
            ];
        }
        
        return $changes;
    }
    
    private function calculateOpportunityScore($competitorKeyword, $ourKeyword) {
        $positionDiff = $ourKeyword['position'] - $competitorKeyword['position'];
        $volume = $competitorKeyword['search_volume'];
        return round(($volume * $positionDiff) / 10);
    }
    
    private function topicsSimilar($topic1, $topic2) {
        similar_text(strtolower($topic1), strtolower($topic2), $percent);
        return $percent > 60;
    }
    
    private function calculateContentPriority($content) {
        if ($content['traffic'] > 1000) return 'high';
        if ($content['traffic'] > 500) return 'medium';
        return 'low';
    }
    
    private function calculateTrafficTrend($trafficData) {
        if (count($trafficData) < 2) return 'stable';
        
        $first = $trafficData[0]['total_traffic'];
        $last = $trafficData[count($trafficData) - 1]['total_traffic'];
        
        $change = (($last - $first) / $first) * 100;
        
        if ($change > 10) return 'growing';
        if ($change < -10) return 'declining';
        return 'stable';
    }
    
    private function generateAIInsights($report) {
        // Use AI to generate strategic insights
        if (empty($this->apiKey)) {
            return ['message' => 'AI insights require API key configuration'];
        }
        
        $prompt = "Analyze this competitor data and provide strategic insights:\n\n";
        $prompt .= json_encode($report, JSON_PRETTY_PRINT);
        
        // Call AI API (simplified)
        return [
            'summary' => 'Competitive analysis summary generated by AI',
            'strengths' => ['Strong backlink profile', 'High-traffic content'],
            'weaknesses' => ['Limited keyword coverage', 'Lower social engagement'],
            'opportunities' => ['Target competitor keyword gaps', 'Replicate top content'],
            'threats' => ['Competitor increasing content output', 'Strong domain authority']
        ];
    }
}
