<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/EmailLog.php';

class EmailController {
    private $db;
    private $emailLog;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->emailLog = new EmailLog($this->db);
    }
    
    // Send email with PDF report
    public function sendReportEmail($recipientEmail, $reportPath, $websiteUrl, $userId) {
        // Check if PHPMailer is available
        if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            // Try to include PHPMailer
            $phpmailerPath = __DIR__ . '/../lib/phpmailer/PHPMailer.php';
            if (file_exists($phpmailerPath)) {
                require_once __DIR__ . '/../lib/phpmailer/PHPMailer.php';
                require_once __DIR__ . '/../lib/phpmailer/SMTP.php';
                require_once __DIR__ . '/../lib/phpmailer/Exception.php';
            } else {
                return [
                    'success' => false,
                    'message' => 'PHPMailer library not found. Please install PHPMailer.'
                ];
            }
        }
        
        // Validate email
        if (!filter_var($recipientEmail, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Invalid email address'];
        }
        
        // Check if report file exists
        if (!file_exists($reportPath)) {
            return ['success' => false, 'message' => 'Report file not found'];
        }
        
        // Create email log entry
        $this->emailLog->user_id = $userId;
        $this->emailLog->recipient_email = $recipientEmail;
        $this->emailLog->report_id = null;
        $this->emailLog->status = 'pending';
        $this->emailLog->error_message = null;
        $this->emailLog->create();
        $logId = $this->emailLog->id;
        
        try {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            
            // Server settings
            $mail->isSMTP();
            $mail->Host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = defined('SMTP_USER') ? SMTP_USER : '';
            $mail->Password = defined('SMTP_PASS') ? SMTP_PASS : '';
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = defined('SMTP_PORT') ? SMTP_PORT : 587;
            
            // Check if SMTP credentials are configured
            if (empty($mail->Username) || empty($mail->Password)) {
                $this->emailLog->updateStatus($logId, 'failed', 'SMTP credentials not configured');
                return [
                    'success' => false,
                    'message' => 'SMTP credentials not configured. Please configure in config/database.php'
                ];
            }
            
            // Recipients
            $mail->setFrom(
                defined('SMTP_FROM') ? SMTP_FROM : 'noreply@aurify.com',
                defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Aurify AI SEO'
            );
            $mail->addAddress($recipientEmail);
            
            // Attachments
            $mail->addAttachment($reportPath);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your SEO Audit Report for ' . $websiteUrl;
            $mail->Body = $this->buildEmailTemplate($websiteUrl);
            $mail->AltBody = strip_tags($mail->Body);
            
            // Send email
            $mail->send();
            
            // Update log status
            $this->emailLog->updateStatus($logId, 'sent');
            
            return [
                'success' => true,
                'message' => 'Email sent successfully',
                'log_id' => $logId
            ];
            
        } catch (Exception $e) {
            // Update log with error
            $this->emailLog->updateStatus($logId, 'failed', $e->getMessage());
            
            return [
                'success' => false,
                'message' => 'Failed to send email: ' . $e->getMessage()
            ];
        }
    }
    
    // Build email HTML template
    private function buildEmailTemplate($websiteUrl) {
        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 30px auto;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #0B1F4D 0%, #1a3a6e 100%);
            color: white;
            padding: 30px 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 30px 20px;
        }
        .content h2 {
            color: #0B1F4D;
            font-size: 20px;
            margin-top: 0;
        }
        .content p {
            margin: 15px 0;
        }
        .website-url {
            background: #f8f9fa;
            padding: 15px;
            border-left: 4px solid #FF6B00;
            border-radius: 4px;
            margin: 20px 0;
        }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, #FF6B00 0%, #FF8533 100%);
            color: white !important;
            padding: 14px 30px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            margin: 20px 0;
        }
        .features {
            margin: 25px 0;
        }
        .feature-item {
            padding: 10px 0;
            border-bottom: 1px solid #e0e0e0;
        }
        .feature-item:last-child {
            border-bottom: none;
        }
        .feature-icon {
            color: #FF6B00;
            margin-right: 10px;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        .footer a {
            color: #FF6B00;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 Your SEO Audit Report is Ready!</h1>
        </div>
        
        <div class="content">
            <h2>Comprehensive SEO Analysis</h2>
            <p>We've completed a thorough SEO audit of your website and compiled a detailed report with actionable insights.</p>
            
            <div class="website-url">
                <strong>Website:</strong> {$websiteUrl}
            </div>
            
            <h3 style="color: #0B1F4D;">What's Included in Your Report:</h3>
            <div class="features">
                <div class="feature-item">
                    <span class="feature-icon">✓</span> Overall SEO Score & Performance Analysis
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span> Technical SEO Issues & Recommendations
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span> PageSpeed Insights (Desktop & Mobile)
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span> Core Web Vitals Assessment
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span> AI-Powered Improvement Suggestions
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span> Priority Action Plan with Timeline
                </div>
            </div>
            
            <p style="margin-top: 25px;">
                Your complete SEO audit report is attached to this email as a PDF. 
                Review the findings and start implementing the recommendations to improve your search engine rankings and user experience.
            </p>
            
            <center>
                <a href="' . SITE_URL . '" class="cta-button">
                    Visit Dashboard
                </a>
            </center>
            
            <p style="font-size: 14px; color: #666; margin-top: 25px;">
                <strong>Need help implementing these recommendations?</strong><br>
                Our team at Aurify Marketing specializes in SEO optimization and can help you achieve better rankings.
            </p>
        </div>
        
        <div class="footer">
            <p>
                <strong>Aurify AI SEO Automation</strong><br>
                Powered by Google Gemini AI & Advanced Analytics
            </p>
            <p>
                <a href="https://aurifymarketing.com">Visit Our Website</a> | 
                <a href="mailto:support@aurifymarketing.com">Contact Support</a>
            </p>
            <p style="margin-top: 15px; font-size: 11px; color: #999;">
                This is an automated email. Please do not reply to this message.
            </p>
        </div>
    </div>
</body>
</html>
HTML;
    }
    
    // Get email logs for user
    public function getEmailLogs($userId, $limit = 50) {
        return $this->emailLog->getByUser($userId, $limit);
    }
    
    // Get email statistics
    public function getStatistics($userId) {
        return $this->emailLog->getStatistics($userId);
    }
}
