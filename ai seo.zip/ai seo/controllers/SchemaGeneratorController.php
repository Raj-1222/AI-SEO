<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/Schema.php';

class SchemaGeneratorController {
    
    // Generate schema based on type
    public function generateSchema($type, $data) {
        $schema = null;
        
        switch ($type) {
            case 'organization':
                $schema = Schema::generateOrganization($data);
                break;
            case 'local_business':
                $schema = Schema::generateLocalBusiness($data);
                break;
            case 'product':
                $schema = Schema::generateProduct($data);
                break;
            case 'article':
                $schema = Schema::generateArticle($data);
                break;
            case 'faq':
                $schema = Schema::generateFAQ($data);
                break;
            case 'breadcrumb':
                $schema = Schema::generateBreadcrumb($data);
                break;
            case 'service':
                $schema = Schema::generateService($data);
                break;
            default:
                return [
                    'success' => false,
                    'message' => 'Invalid schema type'
                ];
        }
        
        // Validate schema
        $validation = Schema::validate($schema);
        
        if (!$validation['valid']) {
            return [
                'success' => false,
                'message' => 'Schema validation failed: ' . $validation['error']
            ];
        }
        
        return [
            'success' => true,
            'schema' => $schema,
            'json' => $validation['json'],
            'html' => Schema::toHTMLScript($schema)
        ];
    }
    
    // Get schema templates/examples
    public function getSchemaTemplates() {
        return [
            'organization' => [
                'name' => 'Organization',
                'description' => 'Markup for organizations, companies, and businesses',
                'fields' => [
                    'name' => ['type' => 'text', 'required' => true, 'label' => 'Organization Name'],
                    'url' => ['type' => 'url', 'required' => true, 'label' => 'Website URL'],
                    'logo' => ['type' => 'url', 'required' => false, 'label' => 'Logo URL'],
                    'description' => ['type' => 'textarea', 'required' => false, 'label' => 'Description'],
                    'telephone' => ['type' => 'tel', 'required' => false, 'label' => 'Phone Number'],
                    'email' => ['type' => 'email', 'required' => false, 'label' => 'Email']
                ]
            ],
            'local_business' => [
                'name' => 'Local Business',
                'description' => 'Markup for local businesses with physical locations',
                'fields' => [
                    'name' => ['type' => 'text', 'required' => true, 'label' => 'Business Name'],
                    'url' => ['type' => 'url', 'required' => true, 'label' => 'Website URL'],
                    'telephone' => ['type' => 'tel', 'required' => true, 'label' => 'Phone Number'],
                    'priceRange' => ['type' => 'text', 'required' => false, 'label' => 'Price Range (e.g., $$)']
                ]
            ],
            'product' => [
                'name' => 'Product',
                'description' => 'Markup for products and items for sale',
                'fields' => [
                    'name' => ['type' => 'text', 'required' => true, 'label' => 'Product Name'],
                    'description' => ['type' => 'textarea', 'required' => true, 'label' => 'Description'],
                    'brand' => ['type' => 'text', 'required' => false, 'label' => 'Brand'],
                    'price' => ['type' => 'number', 'required' => true, 'label' => 'Price'],
                    'currency' => ['type' => 'text', 'required' => true, 'label' => 'Currency (e.g., USD)']
                ]
            ],
            'article' => [
                'name' => 'Article',
                'description' => 'Markup for blog posts and articles',
                'fields' => [
                    'headline' => ['type' => 'text', 'required' => true, 'label' => 'Article Headline'],
                    'author' => ['type' => 'text', 'required' => true, 'label' => 'Author Name'],
                    'publisher' => ['type' => 'text', 'required' => true, 'label' => 'Publisher Name'],
                    'datePublished' => ['type' => 'date', 'required' => true, 'label' => 'Published Date']
                ]
            ],
            'faq' => [
                'name' => 'FAQ',
                'description' => 'Markup for Frequently Asked Questions',
                'fields' => [
                    'questions' => ['type' => 'array', 'required' => true, 'label' => 'Q&A Pairs']
                ]
            ],
            'breadcrumb' => [
                'name' => 'Breadcrumb',
                'description' => 'Markup for breadcrumb navigation',
                'fields' => [
                    'items' => ['type' => 'array', 'required' => true, 'label' => 'Breadcrumb Items']
                ]
            ],
            'service' => [
                'name' => 'Service',
                'description' => 'Markup for services offered',
                'fields' => [
                    'name' => ['type' => 'text', 'required' => true, 'label' => 'Service Name'],
                    'description' => ['type' => 'textarea', 'required' => true, 'label' => 'Description'],
                    'provider' => ['type' => 'text', 'required' => true, 'label' => 'Service Provider']
                ]
            ]
        ];
    }
}
