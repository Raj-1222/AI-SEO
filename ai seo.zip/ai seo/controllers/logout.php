<?php
require_once '../config/init.php';
require_once '../controllers/AuthController.php';

$auth = new AuthController();
$auth->handleLogout();
