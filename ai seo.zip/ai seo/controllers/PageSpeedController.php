<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/PageSpeedReport.php';

class PageSpeedController {
    private $db;
    private $report;
    private $apiKey;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->report = new PageSpeedReport($this->db);
        $this->apiKey = defined('PAGESPEED_API_KEY') ? PAGESPEED_API_KEY : '';
        
        // Increase MySQL timeout for long PageSpeed API calls
        try {
            $this->db->setAttribute(PDO::ATTR_TIMEOUT, 120);
            $this->db->exec("SET SESSION wait_timeout=120");
            $this->db->exec("SET SESSION interactive_timeout=120");
        } catch (Exception $e) {
            // Ignore if setting timeout fails
        }
    }
    
    // Fetch PageSpeed Insights data
    public function analyzePageSpeed($url, $website_id) {
        if (empty($this->apiKey) || $this->apiKey === 'YOUR_API_KEY_HERE') {
            return [
                'success' => false,
                'message' => 'PageSpeed API key not configured. Please add your API key in config/database.php'
            ];
        }
        
        $results = [];
        
        // Fetch both desktop and mobile data
        foreach (['desktop', 'mobile'] as $strategy) {
            $data = $this->fetchPageSpeedData($url, $strategy);
            
            if ($data) {
                // Save to database
                $this->report->website_id = $website_id;
                $this->report->device_type = $strategy;
                $this->report->performance_score = $data['performance_score'];
                $this->report->accessibility_score = $data['accessibility_score'];
                $this->report->best_practices_score = $data['best_practices_score'];
                $this->report->seo_score = $data['seo_score'];
                $this->report->lcp_value = $data['lcp_value'];
                $this->report->lcp_score = $data['lcp_score'];
                $this->report->cls_value = $data['cls_value'];
                $this->report->cls_score = $data['cls_score'];
                $this->report->fid_value = $data['fid_value'];
                $this->report->fid_score = $data['fid_score'];
                $this->report->ttfb_value = $data['ttfb_value'];
                $this->report->ttfb_score = $data['ttfb_score'];
                $this->report->speed_index_value = $data['speed_index_value'];
                $this->report->speed_index_score = $data['speed_index_score'];
                $this->report->fcp_value = $data['fcp_value'];
                $this->report->fcp_score = $data['fcp_score'];
                
                $this->report->create();
                
                $results[$strategy] = $data;
            }
        }
        
        if (empty($results)) {
            return [
                'success' => false,
                'message' => 'Failed to fetch PageSpeed data. Please check the URL and try again.'
            ];
        }
        
        return [
            'success' => true,
            'data' => $results
        ];
    }
    
    // Fetch data from PageSpeed Insights API
    private function fetchPageSpeedData($url, $strategy = 'desktop') {
        $apiUrl = sprintf(
            'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=%s&strategy=%s&key=%s',
            urlencode($url),
            $strategy,
            $this->apiKey
        );
        
        // Add categories
        $apiUrl .= '&category=PERFORMANCE&category=ACCESSIBILITY&category=BEST_PRACTICES&category=SEO';
        
        try {
            $ch = curl_init($apiUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 60,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode !== 200 || !$response) {
                return false;
            }
            
            $data = json_decode($response, true);
            
            if (!isset($data['lighthouseResult'])) {
                return false;
            }
            
            $lighthouse = $data['lighthouseResult'];
            $categories = $lighthouse['categories'];
            $audits = $lighthouse['audits'];
            
            // Extract scores
            $result = [
                'performance_score' => $this->getScore($categories, 'performance'),
                'accessibility_score' => $this->getScore($categories, 'accessibility'),
                'best_practices_score' => $this->getScore($categories, 'best-practices'),
                'seo_score' => $this->getScore($categories, 'seo'),
            ];
            
            // Extract Core Web Vitals
            $result['lcp_value'] = $this->getMetricValue($audits, 'largest-contentful-paint');
            $result['lcp_score'] = $this->getMetricScore($audits, 'largest-contentful-paint');
            
            $result['cls_value'] = $this->getMetricValue($audits, 'cumulative-layout-shift');
            $result['cls_score'] = $this->getMetricScore($audits, 'cumulative-layout-shift');
            
            $result['fid_value'] = $this->getMetricValue($audits, 'max-potential-fid');
            $result['fid_score'] = $this->getMetricScore($audits, 'max-potential-fid');
            
            $result['ttfb_value'] = $this->getMetricValue($audits, 'server-response-time');
            $result['ttfb_score'] = $this->getMetricScore($audits, 'server-response-time');
            
            $result['speed_index_value'] = $this->getMetricValue($audits, 'speed-index');
            $result['speed_index_score'] = $this->getMetricScore($audits, 'speed-index');
            
            $result['fcp_value'] = $this->getMetricValue($audits, 'first-contentful-paint');
            $result['fcp_score'] = $this->getMetricScore($audits, 'first-contentful-paint');
            
            return $result;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    // Get category score
    private function getScore($categories, $category) {
        if (isset($categories[$category]['score'])) {
            return round($categories[$category]['score'] * 100);
        }
        return 0;
    }
    
    // Get metric value
    private function getMetricValue($audits, $metric) {
        if (isset($audits[$metric]['numericValue'])) {
            $value = $audits[$metric]['numericValue'];
            // Convert to seconds if needed
            if ($metric !== 'cumulative-layout-shift') {
                return round($value / 1000, 2);
            }
            return round($value, 4);
        }
        return 0;
    }
    
    // Get metric score
    private function getMetricScore($audits, $metric) {
        if (isset($audits[$metric]['score'])) {
            return round($audits[$metric]['score'] * 100);
        }
        return 0;
    }
    
    // Get saved reports
    public function getReports($website_id) {
        return $this->report->getByWebsite($website_id);
    }
}
