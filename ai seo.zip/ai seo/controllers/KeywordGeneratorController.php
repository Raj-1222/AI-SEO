<?php
require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../models/Keyword.php';

class KeywordGeneratorController {
    private $db;
    private $keyword;
    private $apiKey;
    private $apiUrl;
    
    public function __construct() {
        $this->db = getDBConnection();
        $this->keyword = new Keyword($this->db);
        // Use OpenAI API
        $this->apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : GEMINI_API_KEY;
        $this->apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : GEMINI_API_URL;
    }
    
    // Generate keywords using Gemini AI
    public function generateKeywords($websiteUrl, $industry, $location = '') {
        // Check if API key is configured
        if (empty($this->apiKey) || $this->apiKey === 'YOUR_GEMINI_API_KEY_HERE' || $this->apiKey === 'YOUR_OPENAI_API_KEY_HERE') {
            return [
                'success' => false,
                'message' => 'OpenAI API key not configured. Please configure your API key in config/database.php'
            ];
        }
        
        // Validate URL
        if (!filter_var($websiteUrl, FILTER_VALIDATE_URL)) {
            return [
                'success' => false,
                'message' => 'Invalid website URL format'
            ];
        }
        
        // Build prompt
        $prompt = $this->buildKeywordPrompt($websiteUrl, $industry, $location);
        
        // Call OpenAI API
        $response = $this->callGeminiAPI($prompt);
        
        if (!$response['success']) {
            // Return detailed error
            return [
                'success' => false,
                'message' => $response['message'],
                'error_type' => 'api_error'
            ];
        }
        
        // Parse response
        $keywords = $this->parseKeywordResponse($response['content']);
        
        return $keywords;
    }
    
    // Build keyword generation prompt
    private function buildKeywordPrompt($websiteUrl, $industry, $location) {
        $locationText = !empty($location) ? "Location: $location" : "Location: Global";
        
        $prompt = <<<EOT
You are an expert SEO keyword researcher. Generate comprehensive keyword recommendations for:

**WEBSITE INFORMATION:**
- URL: {$websiteUrl}
- Industry: {$industry}
- {$locationText}

**REQUIRED OUTPUT (STRICT JSON FORMAT):**

{
  "primary_keywords": [
    {
      "keyword": "main keyword phrase",
      "search_volume": "high|medium|low",
      "difficulty": "easy|medium|hard",
      "search_intent": "informational|navigational|transactional|commercial",
      "priority": "high|medium|low",
      "monthly_searches": "estimated number"
    }
  ],
  "secondary_keywords": [
    {
      "keyword": "supporting keyword",
      "search_volume": "high|medium|low",
      "difficulty": "easy|medium|hard",
      "search_intent": "informational|navigational|transactional|commercial",
      "priority": "high|medium|low",
      "monthly_searches": "estimated number"
    }
  ],
  "long_tail_keywords": [
    {
      "keyword": "specific long-tail phrase",
      "search_volume": "high|medium|low",
      "difficulty": "easy|medium|hard",
      "search_intent": "informational|navigational|transactional|commercial",
      "priority": "high|medium|low",
      "monthly_searches": "estimated number"
    }
  ]
}

Generate:
- 5-8 primary keywords (high commercial value, broad reach)
- 8-12 secondary keywords (supporting topics, moderate reach)
- 10-15 long-tail keywords (specific, low competition, high conversion)

Focus on:
- Relevance to industry
- Local intent if location specified
- Realistic search volumes
- Actionable keyword opportunities
- Mix of informational and transactional intent
EOT;
        
        return $prompt;
    }
    
    // Call OpenAI API (replaces Gemini)
    private function callGeminiAPI($prompt) {
        $url = $this->apiUrl;
        
        $data = [
            'model' => defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are an expert SEO keyword researcher. Provide keyword data in valid JSON format only.'
                ],
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'temperature' => 0.8,
            'max_tokens' => 3000
            // JSON mode temporarily disabled for compatibility
            // 'response_format' => ['type' => 'json_object']
        ];
        
        try {
            // Log API request (without full key)
            error_log("OpenAI API Request - Model: " . $data['model'] . ", URL: " . $url);
            
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $this->apiKey
                ],
                CURLOPT_TIMEOUT => 120,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            // Log response details
            error_log("OpenAI API Response - HTTP Code: " . $httpCode);
            
            if ($error) {
                error_log("OpenAI cURL Error: " . $error);
                return ['success' => false, 'message' => 'Connection error: ' . $error];
            }
            
            if ($httpCode !== 200) {
                $errorData = json_decode($response, true);
                $errorMsg = 'HTTP ' . $httpCode;
                
                if ($errorData && isset($errorData['error']['message'])) {
                    $errorMsg = $errorData['error']['message'];
                    error_log("OpenAI API Error: " . $errorMsg);
                    
                    // Provide helpful messages
                    if (strpos($errorMsg, 'API key') !== false || strpos($errorMsg, 'authentication') !== false) {
                        return ['success' => false, 'message' => 'Invalid API key. Please check your OpenAI API key in config/database.php'];
                    } elseif (strpos($errorMsg, 'quota') !== false || strpos($errorMsg, 'billing') !== false) {
                        return ['success' => false, 'message' => 'OpenAI billing issue. Please add a payment method at https://platform.openai.com/account/billing'];
                    } elseif (strpos($errorMsg, 'model') !== false) {
                        return ['success' => false, 'message' => 'Model not available. The model may not be accessible with your API key.'];
                    }
                }
                
                error_log("OpenAI API Raw Error Response: " . $response);
                return ['success' => false, 'message' => 'OpenAI API error: ' . $errorMsg];
            }
            
            $result = json_decode($response, true);
            
            if (!$result || !isset($result['choices'][0]['message']['content'])) {
                error_log("OpenAI Invalid Response Structure: " . substr($response, 0, 500));
                return ['success' => false, 'message' => 'Invalid API response format'];
            }
            
            error_log("OpenAI API Success - Generated content");
            
            return [
                'success' => true,
                'content' => $result['choices'][0]['message']['content']
            ];
            
        } catch (Exception $e) {
            error_log("OpenAI Exception: " . $e->getMessage());
            return ['success' => false, 'message' => 'Exception: ' . $e->getMessage()];
        }
    }
    
    // Parse keyword response
    private function parseKeywordResponse($content) {
        // Clean response
        $content = preg_replace('/```json\s*/', '', $content);
        $content = preg_replace('/```\s*$/', '', $content);
        $content = trim($content);
        
        $data = json_decode($content, true);
        
        if (!$data) {
            preg_match('/\{[\s\S]*\}/', $content, $matches);
            if ($matches) {
                $data = json_decode($matches[0], true);
            }
        }
        
        if (!$data) {
            return [
                'success' => false,
                'message' => 'Failed to parse keyword data'
            ];
        }
        
        return [
            'success' => true,
            'primary_keywords' => $data['primary_keywords'] ?? [],
            'secondary_keywords' => $data['secondary_keywords'] ?? [],
            'long_tail_keywords' => $data['long_tail_keywords'] ?? []
        ];
    }
    
    // Save keywords to database
    public function saveKeywords($websiteUrl, $industry, $location, $keywordsData, $userId) {
        $this->keyword->user_id = $userId;
        $this->keyword->website_url = $websiteUrl;
        $this->keyword->industry = $industry;
        $this->keyword->location = $location;
        $this->keyword->primary_keywords = json_encode($keywordsData['primary_keywords']);
        $this->keyword->secondary_keywords = json_encode($keywordsData['secondary_keywords']);
        $this->keyword->long_tail_keywords = json_encode($keywordsData['long_tail_keywords']);
        
        if ($this->keyword->create()) {
            return [
                'success' => true,
                'message' => 'Keywords saved successfully',
                'keyword_id' => $this->keyword->id
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Failed to save keywords'
        ];
    }
    
    // Get saved keywords
    public function getSavedKeywords($userId, $limit = 20) {
        return $this->keyword->getByUser($userId, $limit);
    }
}
