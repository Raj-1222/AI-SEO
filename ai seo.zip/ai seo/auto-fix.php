<?php
/**
 * AUTO-FIX SCRIPT
 * This will directly apply the fixes to your server files
 * Upload this file to your server root and run it
 */

echo "<!DOCTYPE html><html><head><title>Auto-Fix Script</title>";
echo "<style>body{font-family:Arial;padding:20px;background:#f5f5f5}";
echo ".success{color:#28a745}.error{color:#dc3545}.box{background:white;padding:20px;margin:20px 0;border-radius:8px}";
echo "h1{color:#333}</style></head><body>";

echo "<h1>🔧 Auto-Fix Script</h1>";
echo "<p>This script will apply fixes directly to your server files.</p>";

$fixed = 0;
$errors = [];

// FIX 1: audit.php
echo "<div class='box'><h3>Fixing api/audit.php...</h3>";
$auditPhp = <<<'PHP'
<?php
// Suppress all error output to prevent HTML from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set JSON header FIRST before any output
header('Content-Type: application/json');

// Start output buffering to catch any accidental output
ob_start();

try {
    require_once __DIR__ . '/../config/init.php';
    require_once __DIR__ . '/../controllers/AuditController.php';

    // Clean any buffered output before this point
    ob_clean();

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit();
    }
} catch (Exception $e) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit();
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$url = isset($input['url']) ? trim($input['url']) : '';

if (empty($url)) {
    echo json_encode(['success' => false, 'message' => 'URL is required']);
    exit();
}

// Validate URL format
if (!filter_var($url, FILTER_VALIDATE_URL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid URL format. Please include http:// or https://']);
    exit();
}

// Perform audit
try {
    $controller = new AuditController();
    $result = $controller->auditWebsite($url, $_SESSION['user_id']);
    
    // Clean any buffered output before sending JSON
    ob_clean();
    echo json_encode($result);
} catch (Exception $e) {
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Audit failed: ' . $e->getMessage()
    ]);
}
PHP;

if (file_put_contents(__DIR__ . '/api/audit.php', $auditPhp)) {
    echo "<p class='success'>✅ Fixed api/audit.php</p>";
    $fixed++;
} else {
    echo "<p class='error'>❌ Could not write api/audit.php</p>";
    $errors[] = 'audit.php';
}
echo "</div>";

// FIX 2: pagespeed.php  
echo "<div class='box'><h3>Fixing api/pagespeed.php...</h3>";
$pagespeedPhp = <<<'PHP'
<?php
// Suppress all error output to prevent HTML from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set JSON header FIRST before any output
header('Content-Type: application/json');

// Start output buffering to catch any accidental output
ob_start();

try {
    require_once __DIR__ . '/../config/init.php';
    require_once __DIR__ . '/../controllers/PageSpeedController.php';

    // Clean any buffered output before this point
    ob_clean();

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit();
    }
} catch (Exception $e) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit();
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$url = isset($input['url']) ? trim($input['url']) : '';
$website_id = isset($input['website_id']) ? (int)$input['website_id'] : 0;

if (empty($url) || $website_id === 0) {
    echo json_encode(['success' => false, 'message' => 'URL and website ID are required']);
    exit();
}

// Analyze PageSpeed
try {
    $controller = new PageSpeedController();
    $result = $controller->analyzePageSpeed($url, $website_id);
    
    // Clean any buffered output before sending JSON
    ob_clean();
    echo json_encode($result);
} catch (Exception $e) {
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'PageSpeed analysis failed: ' . $e->getMessage()
    ]);
}
PHP;

if (file_put_contents(__DIR__ . '/api/pagespeed.php', $pagespeedPhp)) {
    echo "<p class='success'>✅ Fixed api/pagespeed.php</p>";
    $fixed++;
} else {
    echo "<p class='error'>❌ Could not write api/pagespeed.php</p>";
    $errors[] = 'pagespeed.php';
}
echo "</div>";

// FIX 3: technical-seo.php
echo "<div class='box'><h3>Fixing api/technical-seo.php...</h3>";
$technicalPhp = <<<'PHP'
<?php
// Suppress all error output to prevent HTML from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set JSON header FIRST before any output
header('Content-Type: application/json');

// Start output buffering to catch any accidental output
ob_start();

try {
    require_once __DIR__ . '/../config/init.php';
    require_once __DIR__ . '/../controllers/TechnicalSeoController.php';

    // Clean any buffered output before this point
    ob_clean();

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit();
    }
} catch (Exception $e) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit();
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$url = isset($input['url']) ? trim($input['url']) : '';
$website_id = isset($input['website_id']) ? (int)$input['website_id'] : 0;

if (empty($url) || $website_id === 0) {
    echo json_encode(['success' => false, 'message' => 'URL and website ID are required']);
    exit();
}

// Perform technical SEO scan
try {
    $controller = new TechnicalSeoController();
    $result = $controller->scanWebsite($url, $website_id);
    
    // Clean any buffered output before sending JSON
    ob_clean();
    echo json_encode($result);
} catch (Exception $e) {
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Technical SEO scan failed: ' . $e->getMessage()
    ]);
}
PHP;

if (file_put_contents(__DIR__ . '/api/technical-seo.php', $technicalPhp)) {
    echo "<p class='success'>✅ Fixed api/technical-seo.php</p>";
    $fixed++;
} else {
    echo "<p class='error'>❌ Could not write api/technical-seo.php</p>";
    $errors[] = 'technical-seo.php';
}
echo "</div>";

// Summary
echo "<div class='box' style='background:" . (empty($errors) ? '#d4edda' : '#f8d7da') . "'>";
echo "<h2>📊 Summary</h2>";
echo "<p><strong>Fixed:</strong> $fixed / 3 files</p>";

if (empty($errors)) {
    echo "<p class='success' style='font-size:18px'>✅ ALL FILES FIXED!</p>";
    echo "<h3>Next Steps:</h3>";
    echo "<ol>";
    echo "<li>Delete this auto-fix.php file from your server (for security)</li>";
    echo "<li>Clear browser cache: Ctrl+Shift+Delete</li>";
    echo "<li>Test Website Audit: <a href='views/dashboard/website-audit.php'>Go to Dashboard</a></li>";
    echo "</ol>";
} else {
    echo "<p class='error' style='font-size:18px'>❌ SOME FILES COULD NOT BE FIXED</p>";
    echo "<p>Failed files: " . implode(', ', $errors) . "</p>";
    echo "<p>This means the server doesn't have write permissions for those files.</p>";
    echo "<p>You'll need to upload them manually via File Manager.</p>";
}
echo "</div>";

echo "<div class='box'>";
echo "<h3>🔗 Quick Links</h3>";
echo "<ul>";
echo "<li><a href='verify-fixes.php'>Verify Fixes</a></li>";
echo "<li><a href='views/dashboard/website-audit.php'>Website Audit Dashboard</a></li>";
echo "<li><a href='test-simple-audit.php'>Simple Test (Already Working)</a></li>";
echo "</ul>";
echo "</div>";

echo "</body></html>";
