<?php
require_once '../../config/init.php';
require_once '../../models/User.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$db = getDBConnection();
$user = new User($db);
$user_data = $user->getUserById($_SESSION['user_id']);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        
        if (empty($name) || empty($email)) {
            $error = 'Please fill in all fields';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format';
        } elseif ($email !== $user_data['email'] && $user->emailExists($email)) {
            $error = 'Email already exists';
        } else {
            if ($user->updateProfile($_SESSION['user_id'], $name, $email)) {
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                $success = 'Profile updated successfully';
                $user_data = $user->getUserById($_SESSION['user_id']);
            } else {
                $error = 'Failed to update profile';
            }
        }
    }
    
    if (isset($_POST['update_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password)) {
            $error = 'Please fill in all password fields';
        } elseif (strlen($new_password) < 6) {
            $error = 'New password must be at least 6 characters';
        } elseif ($new_password !== $confirm_password) {
            $error = 'New passwords do not match';
        } else {
            // Verify current password
            if ($user->login($_SESSION['user_email'], $current_password)) {
                if ($user->updatePassword($_SESSION['user_id'], $new_password)) {
                    $success = 'Password updated successfully';
                } else {
                    $error = 'Failed to update password';
                }
            } else {
                $error = 'Current password is incorrect';
            }
        }
    }
}

$page_title = 'Profile';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">Profile</h1>
                <p class="page-subtitle">Manage your account settings</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="card profile-card glass-card">
                        <div class="text-center">
                            <div class="profile-avatar">
                                <?php echo strtoupper(substr($user_data['name'], 0, 1)); ?>
                            </div>
                            <h4 class="mb-1"><?php echo htmlspecialchars($user_data['name']); ?></h4>
                            <p class="text-muted mb-3"><?php echo htmlspecialchars($user_data['email']); ?></p>
                            <span class="badge bg-primary"><?php echo ucfirst($user_data['role']); ?></span>
                            <hr class="my-4">
                            <div class="text-start">
                                <p class="mb-2"><i class="bi bi-calendar-event text-primary me-2"></i> 
                                    Joined <?php echo date('M d, Y', strtotime($user_data['created_at'])); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-8">
                    <div class="card profile-card glass-card mb-4">
                        <h5 class="mb-4"><i class="bi bi-person-fill text-primary me-2"></i>Profile Information</h5>
                        <form method="POST" action="">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="name" class="form-label">Full Name</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required>
                                </div>
                                
                                <div class="col-md-6">
                                    <label for="email" class="form-label">Email Address</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                                </div>
                            </div>
                            
                            <button type="submit" name="update_profile" class="btn btn-primary mt-3">
                                <i class="bi bi-check-circle me-2"></i>Update Profile
                            </button>
                        </form>
                    </div>

                    <div class="card profile-card glass-card">
                        <h5 class="mb-4"><i class="bi bi-shield-lock-fill text-primary me-2"></i>Change Password</h5>
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="new_password" class="form-label">New Password</label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                                </div>
                                
                                <div class="col-md-6">
                                    <label for="confirm_password" class="form-label">Confirm New Password</label>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                </div>
                            </div>
                            
                            <button type="submit" name="update_password" class="btn btn-secondary mt-3">
                                <i class="bi bi-key-fill me-2"></i>Update Password
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
