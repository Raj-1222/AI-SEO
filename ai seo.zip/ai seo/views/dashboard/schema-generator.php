<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Schema Generator';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="bi bi-code-square text-primary me-2"></i>JSON-LD Schema Generator
                </h1>
                <p class="page-subtitle">Generate structured data markup for better search visibility</p>
            </div>
            
            <div class="row g-4">
                <!-- Schema Type Selection -->
                <div class="col-lg-4">
                    <div class="card glass-card sticky-top" style="top: 20px;">
                        <h5 class="mb-4">
                            <i class="bi bi-layers text-primary me-2"></i>Select Schema Type
                        </h5>
                        
                        <div class="schema-types">
                            <button class="schema-type-btn active" data-type="organization">
                                <i class="bi bi-building"></i>
                                <div>
                                    <strong>Organization</strong>
                                    <small>Company/Business</small>
                                </div>
                            </button>
                            
                            <button class="schema-type-btn" data-type="local_business">
                                <i class="bi bi-shop"></i>
                                <div>
                                    <strong>Local Business</strong>
                                    <small>Physical Location</small>
                                </div>
                            </button>
                            
                            <button class="schema-type-btn" data-type="product">
                                <i class="bi bi-box-seam"></i>
                                <div>
                                    <strong>Product</strong>
                                    <small>Items for Sale</small>
                                </div>
                            </button>
                            
                            <button class="schema-type-btn" data-type="service">
                                <i class="bi bi-gear"></i>
                                <div>
                                    <strong>Service</strong>
                                    <small>Services Offered</small>
                                </div>
                            </button>
                            
                            <button class="schema-type-btn" data-type="article">
                                <i class="bi bi-file-text"></i>
                                <div>
                                    <strong>Article</strong>
                                    <small>Blog Posts</small>
                                </div>
                            </button>
                            
                            <button class="schema-type-btn" data-type="faq">
                                <i class="bi bi-question-circle"></i>
                                <div>
                                    <strong>FAQ</strong>
                                    <small>Q&A Pairs</small>
                                </div>
                            </button>
                            
                            <button class="schema-type-btn" data-type="breadcrumb">
                                <i class="bi bi-arrow-right-circle"></i>
                                <div>
                                    <strong>Breadcrumb</strong>
                                    <small>Navigation Path</small>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Schema Form & Preview -->
                <div class="col-lg-8">
                    <!-- Form Section -->
                    <div class="card glass-card mb-4">
                        <h5 class="mb-3">
                            <i class="bi bi-pencil text-success me-2"></i><span id="formTitle">Organization Schema</span>
                        </h5>
                        
                        <form id="schemaForm">
                            <div id="formFields"></div>
                            
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-stars me-2"></i>Generate Schema
                            </button>
                        </form>
                    </div>
                    
                    <!-- Results Section -->
                    <div id="resultsSection" style="display: none;">
                        <!-- Validation Status -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex align-items-center">
                                <div class="validation-icon me-3">
                                    <i class="bi bi-check-circle-fill text-success" style="font-size: 2rem;"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <h5 class="mb-0">Schema Valid ✓</h5>
                                    <small class="text-muted">Ready for implementation</small>
                                </div>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-outline-primary" id="copyBtn">
                                        <i class="bi bi-clipboard"></i> Copy
                                    </button>
                                    <button class="btn btn-sm btn-outline-success" id="downloadBtn">
                                        <i class="bi bi-download"></i> Download
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- JSON Preview -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0">
                                    <i class="bi bi-code-slash text-info me-2"></i>JSON-LD Code
                                </h5>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-secondary active" id="viewJsonBtn">JSON</button>
                                    <button class="btn btn-outline-secondary" id="viewHtmlBtn">HTML</button>
                                </div>
                            </div>
                            
                            <div id="jsonView">
                                <pre class="schema-preview"><code id="schemaJson"></code></pre>
                            </div>
                            
                            <div id="htmlView" style="display: none;">
                                <pre class="schema-preview"><code id="schemaHtml"></code></pre>
                            </div>
                        </div>
                        
                        <!-- Implementation Guide -->
                        <div class="card glass-card">
                            <h5 class="mb-3">
                                <i class="bi bi-info-circle text-warning me-2"></i>Implementation Guide
                            </h5>
                            <div class="implementation-steps">
                                <div class="step">
                                    <div class="step-number">1</div>
                                    <div class="step-content">
                                        <strong>Copy the Code</strong>
                                        <p class="text-muted mb-0">Click the "Copy" button above to copy the JSON-LD code</p>
                                    </div>
                                </div>
                                <div class="step">
                                    <div class="step-number">2</div>
                                    <div class="step-content">
                                        <strong>Add to Your Website</strong>
                                        <p class="text-muted mb-0">Paste the code in the <code>&lt;head&gt;</code> section of your HTML</p>
                                    </div>
                                </div>
                                <div class="step">
                                    <div class="step-number">3</div>
                                    <div class="step-content">
                                        <strong>Validate</strong>
                                        <p class="text-muted mb-0">Test using <a href="https://search.google.com/test/rich-results" target="_blank">Google Rich Results Test</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</div>

<script src="../../assets/js/schema-generator.js"></script>
<?php include '../includes/footer.php'; ?>
