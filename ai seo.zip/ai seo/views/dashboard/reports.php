<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Reports';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <div class="d-flex justify-content-between align-items-center flex-wrap">
                    <div>
                        <h1 class="page-title">Reports</h1>
                        <p class="page-subtitle">View and manage your SEO reports</p>
                    </div>
                    <button class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>Generate New Report
                    </button>
                </div>
            </div>
            
            <div class="card profile-card glass-card">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Website</th>
                                <th>Report Type</th>
                                <th>Score</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <strong>example.com</strong>
                                    <br><small class="text-muted">Full SEO Audit</small>
                                </td>
                                <td>Comprehensive</td>
                                <td>
                                    <div class="score-badge excellent">
                                        <i class="bi bi-star-fill"></i> 92
                                    </div>
                                </td>
                                <td>Today, 10:30 AM</td>
                                <td><span class="badge bg-success">Completed</span></td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-outline-primary me-1">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <strong>mystore.com</strong>
                                    <br><small class="text-muted">Quick Scan</small>
                                </td>
                                <td>Basic</td>
                                <td>
                                    <div class="score-badge good">
                                        <i class="bi bi-star-fill"></i> 78
                                    </div>
                                </td>
                                <td>Yesterday, 3:15 PM</td>
                                <td><span class="badge bg-success">Completed</span></td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-outline-primary me-1">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="#" class="btn btn-sm btn-outline-secondary">
                                        <i class="bi bi-download"></i>
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
