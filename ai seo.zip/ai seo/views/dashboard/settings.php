<?php
require_once '../../config/init.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Settings';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">Settings</h1>
                <p class="page-subtitle">Manage your application settings</p>
            </div>
            
            <div class="row g-4">
                <!-- n8n Webhook Configuration -->
                <div class="col-lg-8">
                    <div class="card profile-card glass-card">
                        <h5 class="mb-4"><i class="bi bi-webhook text-primary me-2"></i>n8n Webhook Configuration</h5>
                        
                        <form id="webhookSettingsForm">
                            <!-- Enable/Disable Webhook -->
                            <div class="mb-4">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="webhook_enabled" name="webhook_enabled">
                                    <label class="form-check-label" for="webhook_enabled">
                                        <strong>Enable Webhook Integration</strong>
                                        <small class="d-block text-muted">Send audit data to n8n automatically</small>
                                    </label>
                                </div>
                            </div>
                            
                            <!-- Webhook URL -->
                            <div class="mb-4">
                                <label for="webhook_url" class="form-label">
                                    <i class="bi bi-link-45deg me-1"></i>Webhook URL
                                </label>
                                <input type="url" class="form-control" id="webhook_url" name="webhook_url" 
                                       placeholder="https://your-n8n-instance.com/webhook/aurify-seo">
                                <small class="form-text text-muted">Your n8n webhook endpoint URL</small>
                            </div>
                            
                            <!-- Retry Settings -->
                            <div class="mb-4">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="retry_enabled" name="retry_enabled">
                                    <label class="form-check-label" for="retry_enabled">
                                        <strong>Enable Auto Retry</strong>
                                        <small class="d-block text-muted">Automatically retry failed webhook requests</small>
                                    </label>
                                </div>
                                
                                <div id="retrySettings" style="display: none;">
                                    <label for="max_retries" class="form-label">Maximum Retries</label>
                                    <input type="number" class="form-control" id="max_retries" name="max_retries" 
                                           min="1" max="10" value="3">
                                    <small class="form-text text-muted">Number of retry attempts (1-10)</small>
                                </div>
                            </div>
                            
                            <!-- Timeout -->
                            <div class="mb-4">
                                <label for="timeout" class="form-label">
                                    <i class="bi bi-clock me-1"></i>Request Timeout (seconds)
                                </label>
                                <input type="number" class="form-control" id="timeout" name="timeout" 
                                       min="5" max="120" value="30">
                                <small class="form-text text-muted">Timeout for webhook requests (5-120 seconds)</small>
                            </div>
                            
                            <!-- Test Webhook -->
                            <div class="mb-4">
                                <button type="button" class="btn btn-outline-primary" id="testWebhookBtn">
                                    <i class="bi bi-send me-2"></i>Test Webhook Connection
                                </button>
                                <div id="testWebhookResult" class="mt-2"></div>
                            </div>
                            
                            <!-- Save Button -->
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save me-2"></i>Save Settings
                                </button>
                                <button type="button" class="btn btn-secondary" id="resetSettingsBtn">
                                    <i class="bi bi-arrow-counterclockwise me-2"></i>Reset
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Webhook Statistics -->
                <div class="col-lg-4">
                    <div class="card profile-card glass-card">
                        <h5 class="mb-4"><i class="bi bi-bar-chart text-primary me-2"></i>Webhook Statistics</h5>
                        
                        <div id="webhookStats">
                            <div class="stat-item mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Total Requests</span>
                                    <span class="badge bg-primary" id="stat_total">0</span>
                                </div>
                            </div>
                            
                            <div class="stat-item mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Successful</span>
                                    <span class="badge bg-success" id="stat_success">0</span>
                                </div>
                            </div>
                            
                            <div class="stat-item mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Failed</span>
                                    <span class="badge bg-danger" id="stat_failed">0</span>
                                </div>
                            </div>
                            
                            <div class="stat-item mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Pending</span>
                                    <span class="badge bg-warning" id="stat_pending">0</span>
                                </div>
                            </div>
                            
                            <div class="stat-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted">Avg Retries</span>
                                    <span class="badge bg-info" id="stat_avg_retries">0</span>
                                </div>
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        
                        <button type="button" class="btn btn-sm btn-outline-primary w-100" id="viewWebhookLogsBtn">
                            <i class="bi bi-list-ul me-2"></i>View Webhook Logs
                        </button>
                    </div>
                </div>
                
                <!-- Recent Webhook Logs -->
                <div class="col-12">
                    <div class="card profile-card glass-card">
                        <h5 class="mb-4"><i class="bi bi-journal-text text-primary me-2"></i>Recent Webhook Logs</h5>
                        
                        <div class="table-responsive">
                            <table class="table table-hover" id="webhookLogsTable">
                                <thead>
                                    <tr>
                                        <th>Timestamp</th>
                                        <th>URL</th>
                                        <th>Status</th>
                                        <th>Status Code</th>
                                        <th>Retries</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="webhookLogsBody">
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-4">
                                            <i class="bi bi-inbox display-6 d-block mb-2"></i>
                                            No webhook logs yet
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Settings Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Load current settings
    loadSettings();
    
    // Load webhook statistics
    loadWebhookStats();
    
    // Load recent logs
    loadRecentLogs();
    
    // Toggle retry settings visibility
    const retryEnabledCheckbox = document.getElementById('retry_enabled');
    const retrySettings = document.getElementById('retrySettings');
    
    retryEnabledCheckbox.addEventListener('change', function() {
        retrySettings.style.display = this.checked ? 'block' : 'none';
    });
    
    // Save settings form
    document.getElementById('webhookSettingsForm').addEventListener('submit', function(e) {
        e.preventDefault();
        saveSettings();
    });
    
    // Test webhook button
    document.getElementById('testWebhookBtn').addEventListener('click', function() {
        testWebhook();
    });
    
    // Reset settings button
    document.getElementById('resetSettingsBtn').addEventListener('click', function() {
        if (confirm('Are you sure you want to reset all settings?')) {
            loadSettings();
        }
    });
    
    // View logs button
    document.getElementById('viewWebhookLogsBtn').addEventListener('click', function() {
        document.querySelector('#webhookLogsTable').scrollIntoView({ behavior: 'smooth' });
    });
    
    // Auto-refresh stats every 30 seconds
    setInterval(() => {
        loadWebhookStats();
        loadRecentLogs();
    }, 30000);
});

// Load current settings
function loadSettings() {
    fetch('/ai seo/api/settings.php?action=get')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const settings = data.settings;
                
                document.getElementById('webhook_enabled').checked = settings.n8n_webhook_enabled || false;
                document.getElementById('webhook_url').value = settings.n8n_webhook_url || '';
                document.getElementById('retry_enabled').checked = settings.n8n_retry_enabled || false;
                document.getElementById('max_retries').value = settings.n8n_max_retries || 3;
                document.getElementById('timeout').value = settings.n8n_timeout || 30;
                
                // Show/hide retry settings
                document.getElementById('retrySettings').style.display = 
                    settings.n8n_retry_enabled ? 'block' : 'none';
            }
        })
        .catch(error => {
            console.error('Error loading settings:', error);
        });
}

// Save settings
function saveSettings() {
    const formData = {
        n8n_webhook_enabled: document.getElementById('webhook_enabled').checked,
        n8n_webhook_url: document.getElementById('webhook_url').value,
        n8n_retry_enabled: document.getElementById('retry_enabled').checked,
        n8n_max_retries: document.getElementById('max_retries').value,
        n8n_timeout: document.getElementById('timeout').value
    };
    
    fetch('/ai seo/api/settings.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'save', settings: formData })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Settings saved successfully!', 'success');
        } else {
            showToast('Failed to save settings: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error saving settings:', error);
        showToast('Error saving settings', 'error');
    });
}

// Test webhook
function testWebhook() {
    const webhookUrl = document.getElementById('webhook_url').value;
    const resultDiv = document.getElementById('testWebhookResult');
    
    if (!webhookUrl) {
        resultDiv.innerHTML = '<div class="alert alert-warning">Please enter a webhook URL first</div>';
        return;
    }
    
    resultDiv.innerHTML = '<div class="alert alert-info"><i class="bi bi-hourglass-split me-2"></i>Testing connection...</div>';
    
    fetch('/ai seo/api/settings.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'test', webhook_url: webhookUrl })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            resultDiv.innerHTML = `
                <div class="alert alert-success">
                    <i class="bi bi-check-circle me-2"></i>
                    <strong>Success!</strong> Webhook is working correctly.
                    <br><small>Status Code: ${data.status_code}</small>
                </div>
            `;
        } else {
            resultDiv.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-x-circle me-2"></i>
                    <strong>Failed!</strong> ${data.message}
                    ${data.error ? `<br><small>Error: ${data.error}</small>` : ''}
                </div>
            `;
        }
    })
    .catch(error => {
        console.error('Error testing webhook:', error);
        resultDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="bi bi-x-circle me-2"></i>
                Error testing webhook: ${error.message}
            </div>
        `;
    });
}

// Load webhook statistics
function loadWebhookStats() {
    fetch('/ai seo/api/settings.php?action=stats')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.stats) {
                document.getElementById('stat_total').textContent = data.stats.total || 0;
                document.getElementById('stat_success').textContent = data.stats.success || 0;
                document.getElementById('stat_failed').textContent = data.stats.failed || 0;
                document.getElementById('stat_pending').textContent = data.stats.pending || 0;
                document.getElementById('stat_avg_retries').textContent = 
                    parseFloat(data.stats.avg_retries || 0).toFixed(2);
            }
        })
        .catch(error => {
            console.error('Error loading webhook stats:', error);
        });
}

// Load recent webhook logs
function loadRecentLogs() {
    fetch('/ai seo/api/settings.php?action=logs&limit=10')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.logs) {
                displayWebhookLogs(data.logs);
            }
        })
        .catch(error => {
            console.error('Error loading webhook logs:', error);
        });
}

// Display webhook logs
function displayWebhookLogs(logs) {
    const tbody = document.getElementById('webhookLogsBody');
    
    if (logs.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted py-4">
                    <i class="bi bi-inbox display-6 d-block mb-2"></i>
                    No webhook logs yet
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = logs.map(log => {
        const statusBadge = getStatusBadge(log.status);
        const statusCodeBadge = getStatusCodeBadge(log.status_code);
        
        return `
            <tr>
                <td>${formatDate(log.created_at)}</td>
                <td><small class="text-muted">${truncateUrl(log.webhook_url)}</small></td>
                <td>${statusBadge}</td>
                <td>${statusCodeBadge}</td>
                <td><span class="badge bg-secondary">${log.retry_count}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="viewLogDetails(${log.id})">
                        <i class="bi bi-eye"></i>
                    </button>
                    ${log.status === 'failed' ? `
                        <button class="btn btn-sm btn-outline-warning" onclick="retryWebhook(${log.id})">
                            <i class="bi bi-arrow-clockwise"></i>
                        </button>
                    ` : ''}
                </td>
            </tr>
        `;
    }).join('');
}

// Get status badge
function getStatusBadge(status) {
    const badges = {
        'success': '<span class="badge bg-success">Success</span>',
        'failed': '<span class="badge bg-danger">Failed</span>',
        'pending': '<span class="badge bg-warning">Pending</span>',
        'retry': '<span class="badge bg-info">Retry</span>'
    };
    return badges[status] || '<span class="badge bg-secondary">Unknown</span>';
}

// Get status code badge
function getStatusCodeBadge(statusCode) {
    if (!statusCode) return '-';
    
    let className = 'secondary';
    if (statusCode >= 200 && statusCode < 300) className = 'success';
    else if (statusCode >= 400) className = 'danger';
    else if (statusCode >= 300) className = 'warning';
    
    return `<span class="badge bg-${className}">${statusCode}</span>`;
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
}

// Truncate URL
function truncateUrl(url) {
    return url.length > 40 ? url.substring(0, 40) + '...' : url;
}

// View log details (modal or redirect)
function viewLogDetails(logId) {
    // For now, show alert
    alert('Log details view coming soon! Log ID: ' + logId);
}

// Retry webhook
function retryWebhook(logId) {
    if (!confirm('Retry this webhook request?')) return;
    
    fetch('/ai seo/api/settings.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'retry', log_id: logId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Webhook retry successful!', 'success');
            loadRecentLogs();
            loadWebhookStats();
        } else {
            showToast('Retry failed: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error retrying webhook:', error);
        showToast('Error retrying webhook', 'error');
    });
}

// Show toast notification
function showToast(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : (type === 'success' ? 'alert-success' : 'alert-info');
    const icon = type === 'error' ? 'exclamation-circle' : (type === 'success' ? 'check-circle' : 'info-circle');
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}
</script>
