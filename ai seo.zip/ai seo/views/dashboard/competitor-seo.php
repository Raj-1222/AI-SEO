<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Competitor SEO Analysis';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="bi bi-trophy text-warning me-2"></i>Competitor SEO Analysis
                </h1>
                <p class="page-subtitle">Discover, analyze, and outrank your competitors with comprehensive SEO intelligence</p>
            </div>
            
            <!-- Analysis Tabs -->
            <ul class="nav nav-pills nav-fill mb-4 glass-card p-2" id="competitorTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="discovery-tab" data-bs-toggle="pill" data-bs-target="#discovery" type="button">
                        <i class="bi bi-search me-2"></i>Discovery
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="keywords-tab" data-bs-toggle="pill" data-bs-target="#keywords" type="button">
                        <i class="bi bi-key me-2"></i>Keywords
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="content-tab" data-bs-toggle="pill" data-bs-target="#content" type="button">
                        <i class="bi bi-file-text me-2"></i>Content
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="backlinks-tab" data-bs-toggle="pill" data-bs-target="#backlinks" type="button">
                        <i class="bi bi-link-45deg me-2"></i>Backlinks
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="traffic-tab" data-bs-toggle="pill" data-bs-target="#traffic" type="button">
                        <i class="bi bi-graph-up me-2"></i>Traffic
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="serp-tab" data-bs-toggle="pill" data-bs-target="#serp" type="button">
                        <i class="bi bi-list-ol me-2"></i>SERP
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="monitoring-tab" data-bs-toggle="pill" data-bs-target="#monitoring" type="button">
                        <i class="bi bi-eye me-2"></i>Monitor
                    </button>
                </li>
            </ul>
            
            <!-- Tab Content -->
            <div class="tab-content" id="competitorTabContent">
                
                <!-- 1. COMPETITOR DISCOVERY TAB -->
                <div class="tab-pane fade show active" id="discovery" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-lg-4">
                            <div class="card glass-card sticky-top" style="top: 20px;">
                                <h5 class="mb-4">
                                    <i class="bi bi-search text-primary me-2"></i>Discover Competitors
                                </h5>
                                
                                <form id="discoveryForm">
                                    <div class="mb-3">
                                        <label for="primary_domain" class="form-label">Your Website *</label>
                                        <input type="text" class="form-control" id="primary_domain" placeholder="example.com" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="industry" class="form-label">Industry</label>
                                        <input type="text" class="form-control" id="industry" placeholder="Digital Marketing">
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="keywords" class="form-label">Target Keywords (Optional)</label>
                                        <textarea class="form-control" id="keywords" rows="3" placeholder="Enter keywords, one per line"></textarea>
                                        <small class="text-muted">Add relevant keywords to find more specific competitors</small>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Discover Competitors
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div id="discoveryLoading" style="display: none;">
                                <div class="card glass-card text-center py-5">
                                    <div class="spinner-border text-primary mb-3"></div>
                                    <h5>Discovering Competitors...</h5>
                                </div>
                            </div>
                            
                            <div id="discoveryWelcome" style="display: block;">
                                <div class="card glass-card text-center py-5">
                                    <i class="bi bi-trophy display-1 text-warning mb-3"></i>
                                    <h4>Competitor Discovery</h4>
                                    <p class="text-muted mb-4">Find your top competitors based on domain similarity, keywords, and industry</p>
                                    
                                    <div class="row mt-4">
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-globe text-primary mb-2" style="font-size: 2rem;"></i>
                                                <h6>Domain Analysis</h6>
                                                <small class="text-muted">Find competitors by domain similarity</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-key text-info mb-2" style="font-size: 2rem;"></i>
                                                <h6>Keyword Matching</h6>
                                                <small class="text-muted">Discover competitors by keywords</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-building text-success mb-2" style="font-size: 2rem;"></i>
                                                <h6>Industry Analysis</h6>
                                                <small class="text-muted">Find competitors in your industry</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="discoveryResults" style="display: none;">
                                <div class="card glass-card">
                                    <h5 class="mb-4">
                                        <i class="bi bi-people text-success me-2"></i>Discovered Competitors
                                    </h5>
                                    <div id="competitorsTable"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 2. KEYWORD ANALYSIS TAB -->
                <div class="tab-pane fade" id="keywords" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-lg-4">
                            <div class="card glass-card">
                                <h5 class="mb-4">
                                    <i class="bi bi-key text-primary me-2"></i>Keyword Analysis
                                </h5>
                                
                                <form id="keywordAnalysisForm">
                                    <div class="mb-3">
                                        <label class="form-label">Analysis Type *</label>
                                        <select class="form-select" id="keyword_analysis_type" required>
                                            <option value="">Select Type</option>
                                            <option value="competitor_keywords">Competitor Keywords</option>
                                            <option value="keyword_gap">Keyword Gap Analysis</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="kw_primary_domain" class="form-label">Your Website *</label>
                                        <input type="text" class="form-control" id="kw_primary_domain" placeholder="example.com" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="competitor_domains" class="form-label">Competitor Domains *</label>
                                        <textarea class="form-control" id="competitor_domains" rows="3" placeholder="competitor1.com&#10;competitor2.com&#10;competitor3.com" required></textarea>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Analyze Keywords
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div id="keywordLoading" style="display: none;">
                                <div class="card glass-card text-center py-5">
                                    <div class="spinner-border text-primary mb-3"></div>
                                    <h5>Analyzing Keywords...</h5>
                                </div>
                            </div>
                            
                            <div id="keywordWelcome" style="display: block;">
                                <div class="card glass-card text-center py-5">
                                    <i class="bi bi-key display-1 text-primary mb-3"></i>
                                    <h4>Keyword Intelligence</h4>
                                    <p class="text-muted mb-4">Discover competitor keywords and identify gaps in your keyword strategy</p>
                                    
                                    <div class="row mt-4">
                                        <div class="col-md-6 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-search text-primary mb-2" style="font-size: 2rem;"></i>
                                                <h6>Competitor Keywords</h6>
                                                <small class="text-muted">Analyze what keywords your competitors rank for</small>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-graph-up text-success mb-2" style="font-size: 2rem;"></i>
                                                <h6>Keyword Gap Analysis</h6>
                                                <small class="text-muted">Find keyword opportunities you're missing</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="alert alert-info mt-4">
                                        <i class="bi bi-info-circle me-2"></i>
                                        <strong>Get Started:</strong> Select an analysis type and enter competitor domains to begin
                                    </div>
                                </div>
                            </div>
                            
                            <div id="keywordResults" style="display: none;">
                                <div class="card glass-card mb-4">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <h5 class="mb-0">
                                            <i class="bi bi-bar-chart text-success me-2"></i>Keyword Insights
                                        </h5>
                                        <button class="btn btn-sm btn-outline-primary" id="exportKeywordsBtn">
                                            <i class="bi bi-download me-1"></i>Export
                                        </button>
                                    </div>
                                    <div id="keywordStats" class="row g-3 mb-3"></div>
                                </div>
                                
                                <div class="card glass-card">
                                    <h5 class="mb-3">Keyword Opportunities</h5>
                                    <div id="keywordTable"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 3. CONTENT ANALYSIS TAB -->
                <div class="tab-pane fade" id="content" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-lg-4">
                            <div class="card glass-card">
                                <h5 class="mb-4">
                                    <i class="bi bi-file-text text-primary me-2"></i>Content Analysis
                                </h5>
                                
                                <form id="contentAnalysisForm">
                                    <div class="mb-3">
                                        <label class="form-label">Analysis Type *</label>
                                        <select class="form-select" id="content_analysis_type" required>
                                            <option value="">Select Type</option>
                                            <option value="content_gap">Content Gap Analysis</option>
                                            <option value="content_quality">Content Quality Analysis</option>
                                            <option value="top_pages">Top Pages</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="content_primary_domain" class="form-label">Your Website *</label>
                                        <input type="text" class="form-control" id="content_primary_domain" placeholder="example.com" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="content_competitor_domains" class="form-label">Competitor Domains *</label>
                                        <textarea class="form-control" id="content_competitor_domains" rows="3" placeholder="competitor1.com&#10;competitor2.com" required></textarea>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Analyze Content
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div id="contentLoading" style="display: none;">
                                <div class="card glass-card text-center py-5">
                                    <div class="spinner-border text-primary mb-3"></div>
                                    <h5>Analyzing Content...</h5>
                                </div>
                            </div>
                            
                            <div id="contentWelcome" style="display: block;">
                                <div class="card glass-card text-center py-5">
                                    <i class="bi bi-file-text display-1 text-info mb-3"></i>
                                    <h4>Content Intelligence</h4>
                                    <p class="text-muted mb-4">Discover content gaps and analyze competitor content strategies</p>
                                    
                                    <div class="row mt-4">
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-clipboard-check text-primary mb-2" style="font-size: 2rem;"></i>
                                                <h6>Content Gap</h6>
                                                <small class="text-muted">Find topics competitors cover</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-star text-warning mb-2" style="font-size: 2rem;"></i>
                                                <h6>Content Quality</h6>
                                                <small class="text-muted">Analyze content performance</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-trophy text-success mb-2" style="font-size: 2rem;"></i>
                                                <h6>Top Pages</h6>
                                                <small class="text-muted">Identify best-performing pages</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="contentResults" style="display: none;">
                                <div class="card glass-card mb-4">
                                    <h5 class="mb-3">Content Metrics</h5>
                                    <div id="contentMetrics" class="row g-3"></div>
                                </div>
                                
                                <div class="card glass-card">
                                    <h5 class="mb-3">Content Analysis</h5>
                                    <div id="contentTable"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 4. BACKLINKS ANALYSIS TAB -->
                <div class="tab-pane fade" id="backlinks" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-lg-4">
                            <div class="card glass-card">
                                <h5 class="mb-4">
                                    <i class="bi bi-link-45deg text-primary me-2"></i>Backlink Analysis
                                </h5>
                                
                                <form id="backlinkAnalysisForm">
                                    <div class="mb-3">
                                        <label for="backlink_competitor_domain" class="form-label">Competitor Domain *</label>
                                        <input type="text" class="form-control" id="backlink_competitor_domain" placeholder="competitor.com" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="backlink_limit" class="form-label">Number of Backlinks</label>
                                        <select class="form-select" id="backlink_limit">
                                            <option value="50">50 backlinks</option>
                                            <option value="100" selected>100 backlinks</option>
                                            <option value="200">200 backlinks</option>
                                        </select>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Analyze Backlinks
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div id="backlinkLoading" style="display: none;">
                                <div class="card glass-card text-center py-5">
                                    <div class="spinner-border text-primary mb-3"></div>
                                    <h5>Analyzing Backlinks...</h5>
                                </div>
                            </div>
                            
                            <div id="backlinkWelcome" style="display: block;">
                                <div class="card glass-card text-center py-5">
                                    <i class="bi bi-link-45deg display-1 text-success mb-3"></i>
                                    <h4>Backlink Intelligence</h4>
                                    <p class="text-muted mb-4">Analyze competitor backlink profiles and find link building opportunities</p>
                                    
                                    <div class="row mt-4 justify-content-center">
                                        <div class="col-md-3 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-link text-primary mb-2" style="font-size: 2rem;"></i>
                                                <h6>Total Backlinks</h6>
                                                <small class="text-muted">All incoming links</small>
                                            </div>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-check-circle text-success mb-2" style="font-size: 2rem;"></i>
                                                <h6>Dofollow Links</h6>
                                                <small class="text-muted">SEO value links</small>
                                            </div>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-globe text-info mb-2" style="font-size: 2rem;"></i>
                                                <h6>Unique Domains</h6>
                                                <small class="text-muted">Referring domains</small>
                                            </div>
                                        </div>
                                        <div class="col-md-3 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-shield-check text-warning mb-2" style="font-size: 2rem;"></i>
                                                <h6>Domain Authority</h6>
                                                <small class="text-muted">Link quality score</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="backlinkResults" style="display: none;">
                                <div class="card glass-card mb-4">
                                    <h5 class="mb-3">Backlink Metrics</h5>
                                    <div id="backlinkMetrics" class="row g-3"></div>
                                </div>
                                
                                <div class="card glass-card">
                                    <h5 class="mb-3">Top Backlinks</h5>
                                    <div id="backlinkTable"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 5. TRAFFIC ESTIMATES TAB -->
                <div class="tab-pane fade" id="traffic" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-lg-4">
                            <div class="card glass-card">
                                <h5 class="mb-4">
                                    <i class="bi bi-graph-up text-primary me-2"></i>Traffic Analysis
                                </h5>
                                
                                <form id="trafficAnalysisForm">
                                    <div class="mb-3">
                                        <label for="traffic_competitor_domain" class="form-label">Competitor Domain *</label>
                                        <input type="text" class="form-control" id="traffic_competitor_domain" placeholder="competitor.com" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="traffic_months" class="form-label">Time Period</label>
                                        <select class="form-select" id="traffic_months">
                                            <option value="3">Last 3 months</option>
                                            <option value="6" selected>Last 6 months</option>
                                            <option value="12">Last 12 months</option>
                                        </select>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Estimate Traffic
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div id="trafficLoading" style="display: none;">
                                <div class="card glass-card text-center py-5">
                                    <div class="spinner-border text-primary mb-3"></div>
                                    <h5>Estimating Traffic...</h5>
                                </div>
                            </div>
                            
                            <div id="trafficWelcome" style="display: block;">
                                <div class="card glass-card text-center py-5">
                                    <i class="bi bi-graph-up display-1 text-primary mb-3"></i>
                                    <h4>Traffic Intelligence</h4>
                                    <p class="text-muted mb-4">Estimate competitor traffic and identify growth trends</p>
                                    
                                    <div class="row mt-4">
                                        <div class="col-md-6 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-bar-chart-line text-primary mb-2" style="font-size: 2rem;"></i>
                                                <h6>Traffic Estimation</h6>
                                                <small class="text-muted">Estimate monthly traffic volumes</small>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-arrow-up-circle text-success mb-2" style="font-size: 2rem;"></i>
                                                <h6>Trend Analysis</h6>
                                                <small class="text-muted">Track growth or decline patterns</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="alert alert-info mt-3">
                                        <i class="bi bi-info-circle me-2"></i>
                                        Visualize traffic trends with interactive charts
                                    </div>
                                </div>
                            </div>
                            
                            <div id="trafficResults" style="display: none;">
                                <div class="card glass-card mb-4">
                                    <h5 class="mb-3">Traffic Overview</h5>
                                    <canvas id="trafficChart" height="100"></canvas>
                                </div>
                                
                                <div class="card glass-card">
                                    <h5 class="mb-3">Traffic Breakdown</h5>
                                    <div id="trafficTable"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 6. SERP COMPARISON TAB -->
                <div class="tab-pane fade" id="serp" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-lg-4">
                            <div class="card glass-card">
                                <h5 class="mb-4">
                                    <i class="bi bi-list-ol text-primary me-2"></i>SERP Comparison
                                </h5>
                                
                                <form id="serpComparisonForm">
                                    <div class="mb-3">
                                        <label for="serp_primary_domain" class="form-label">Your Website *</label>
                                        <input type="text" class="form-control" id="serp_primary_domain" placeholder="example.com" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="serp_competitors" class="form-label">Competitor Domains *</label>
                                        <textarea class="form-control" id="serp_competitors" rows="2" placeholder="competitor1.com&#10;competitor2.com" required></textarea>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="serp_keywords" class="form-label">Keywords to Compare *</label>
                                        <textarea class="form-control" id="serp_keywords" rows="3" placeholder="keyword 1&#10;keyword 2&#10;keyword 3" required></textarea>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Compare SERP
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div id="serpLoading" style="display: none;">
                                <div class="card glass-card text-center py-5">
                                    <div class="spinner-border text-primary mb-3"></div>
                                    <h5>Comparing SERP Positions...</h5>
                                </div>
                            </div>
                            
                            <div id="serpWelcome" style="display: block;">
                                <div class="card glass-card text-center py-5">
                                    <i class="bi bi-list-ol display-1 text-warning mb-3"></i>
                                    <h4>SERP Intelligence</h4>
                                    <p class="text-muted mb-4">Compare search rankings for specific keywords against competitors</p>
                                    
                                    <div class="row mt-4 justify-content-center">
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-search text-primary mb-2" style="font-size: 2rem;"></i>
                                                <h6>Position Tracking</h6>
                                                <small class="text-muted">Track keyword rankings</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-people text-info mb-2" style="font-size: 2rem;"></i>
                                                <h6>Competitor Compare</h6>
                                                <small class="text-muted">Side-by-side comparison</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-trophy text-warning mb-2" style="font-size: 2rem;"></i>
                                                <h6>Ranking Opportunities</h6>
                                                <small class="text-muted">Find winnable positions</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="serpResults" style="display: none;">
                                <div class="card glass-card">
                                    <h5 class="mb-3">SERP Comparison Results</h5>
                                    <div id="serpTable"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 7. CHANGE MONITORING TAB -->
                <div class="tab-pane fade" id="monitoring" role="tabpanel">
                    <div class="row g-4">
                        <div class="col-lg-4">
                            <div class="card glass-card">
                                <h5 class="mb-4">
                                    <i class="bi bi-eye text-primary me-2"></i>Monitor Changes
                                </h5>
                                
                                <form id="monitoringForm">
                                    <div class="mb-3">
                                        <label for="monitor_competitor_domain" class="form-label">Competitor Domain *</label>
                                        <input type="text" class="form-control" id="monitor_competitor_domain" placeholder="competitor.com" required>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label for="monitor_days" class="form-label">Time Period</label>
                                        <select class="form-select" id="monitor_days">
                                            <option value="7">Last 7 days</option>
                                            <option value="30" selected>Last 30 days</option>
                                            <option value="90">Last 90 days</option>
                                        </select>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Check Changes
                                    </button>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-lg-8">
                            <div id="monitoringLoading" style="display: none;">
                                <div class="card glass-card text-center py-5">
                                    <div class="spinner-border text-primary mb-3"></div>
                                    <h5>Checking Changes...</h5>
                                </div>
                            </div>
                            
                            <div id="monitoringWelcome" style="display: block;">
                                <div class="card glass-card text-center py-5">
                                    <i class="bi bi-eye display-1 text-info mb-3"></i>
                                    <h4>Change Monitoring</h4>
                                    <p class="text-muted mb-4">Track competitor changes and get alerts on significant updates</p>
                                    
                                    <div class="row mt-4">
                                        <div class="col-md-6 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-bell text-warning mb-2" style="font-size: 2rem;"></i>
                                                <h6>Change Detection</h6>
                                                <small class="text-muted">Monitor competitor updates</small>
                                            </div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <div class="p-3 border rounded">
                                                <i class="bi bi-clock-history text-primary mb-2" style="font-size: 2rem;"></i>
                                                <h6>Historical Tracking</h6>
                                                <small class="text-muted">View change timeline</small>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="alert alert-info mt-3">
                                        <i class="bi bi-info-circle me-2"></i>
                                        Track ranking changes, new backlinks, content updates, and technical changes
                                    </div>
                                </div>
                            </div>
                            
                            <div id="monitoringResults" style="display: none;">
                                <div class="card glass-card">
                                    <h5 class="mb-3">Recent Changes Detected</h5>
                                    <div id="changesTimeline"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="../../assets/js/competitor-seo.js"></script>

<?php include '../includes/footer.php'; ?>
