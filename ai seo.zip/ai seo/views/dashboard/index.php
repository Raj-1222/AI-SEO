<?php
require_once '../../config/init.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Dashboard';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <p class="page-subtitle">Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</p>
            </div>
            
            <!-- Stats Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-6 col-xl-3">
                    <div class="card stat-card glass-card animate-fade-in">
                        <div class="stat-icon orange">
                            <i class="bi bi-globe2"></i>
                        </div>
                        <div class="stat-value counter" data-target="156">0</div>
                        <div class="stat-label">Total Websites</div>
                        <div class="stat-change positive">
                            <i class="bi bi-arrow-up"></i> 12% this month
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-xl-3">
                    <div class="card stat-card glass-card animate-fade-in" style="animation-delay: 0.1s;">
                        <div class="stat-icon blue">
                            <i class="bi bi-file-earmark-text"></i>
                        </div>
                        <div class="stat-value counter" data-target="2847">0</div>
                        <div class="stat-label">Reports Generated</div>
                        <div class="stat-change positive">
                            <i class="bi bi-arrow-up"></i> 8% increase
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-xl-3">
                    <div class="card stat-card glass-card animate-fade-in" style="animation-delay: 0.2s;">
                        <div class="stat-icon green">
                            <i class="bi bi-graph-up-arrow"></i>
                        </div>
                        <div class="stat-value"><span class="counter" data-target="87">0</span>%</div>
                        <div class="stat-label">Average SEO Score</div>
                        <div class="stat-change positive">
                            <i class="bi bi-arrow-up"></i> 5 points up
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-xl-3">
                    <div class="card stat-card glass-card animate-fade-in" style="animation-delay: 0.3s;">
                        <div class="stat-icon purple">
                            <i class="bi bi-activity"></i>
                        </div>
                        <div class="stat-value counter" data-target="43">0</div>
                        <div class="stat-label">Today's Analysis</div>
                        <div class="stat-change neutral">
                            <i class="bi bi-clock"></i> Last scan 2h ago
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Critical Issues & Quick Actions -->
            <div class="row g-4 mb-4">
                <div class="col-lg-8">
                    <div class="card chart-card animate-slide-up">
                        <div class="chart-header">
                            <div>
                                <h3 class="chart-title"><i class="bi bi-exclamation-triangle-fill text-warning me-2"></i>Critical Issues</h3>
                                <p class="text-muted mb-0" style="font-size: 13px;">Issues requiring immediate attention</p>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Website</th>
                                        <th>Issue Type</th>
                                        <th>Severity</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><strong>example.com</strong></td>
                                        <td>Missing Meta Description</td>
                                        <td><span class="badge bg-danger">Critical</span></td>
                                        <td><a href="#" class="btn btn-sm btn-outline-primary">Fix Now</a></td>
                                    </tr>
                                    <tr>
                                        <td><strong>mystore.com</strong></td>
                                        <td>Broken Links (12)</td>
                                        <td><span class="badge bg-warning">High</span></td>
                                        <td><a href="#" class="btn btn-sm btn-outline-primary">View Details</a></td>
                                    </tr>
                                    <tr>
                                        <td><strong>blog.site.com</strong></td>
                                        <td>Slow Page Speed</td>
                                        <td><span class="badge bg-warning">High</span></td>
                                        <td><a href="#" class="btn btn-sm btn-outline-primary">Optimize</a></td>
                                    </tr>
                                    <tr>
                                        <td><strong>portfolio.net</strong></td>
                                        <td>No SSL Certificate</td>
                                        <td><span class="badge bg-danger">Critical</span></td>
                                        <td><a href="#" class="btn btn-sm btn-outline-primary">Enable SSL</a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="card chart-card animate-slide-up" style="animation-delay: 0.1s;">
                        <div class="chart-header">
                            <h3 class="chart-title"><i class="bi bi-lightning-charge-fill text-primary me-2"></i>Quick Actions</h3>
                        </div>
                        <div class="quick-actions">
                            <a href="#" class="quick-action-btn">
                                <div class="action-icon bg-primary-light">
                                    <i class="bi bi-search"></i>
                                </div>
                                <div class="action-text">
                                    <strong>Website Audit</strong>
                                    <small>Scan new website</small>
                                </div>
                                <i class="bi bi-chevron-right"></i>
                            </a>
                            <a href="#" class="quick-action-btn">
                                <div class="action-icon bg-success-light">
                                    <i class="bi bi-file-earmark-plus"></i>
                                </div>
                                <div class="action-text">
                                    <strong>Generate Report</strong>
                                    <small>Create new report</small>
                                </div>
                                <i class="bi bi-chevron-right"></i>
                            </a>
                            <a href="#" class="quick-action-btn">
                                <div class="action-icon bg-warning-light">
                                    <i class="bi bi-key"></i>
                                </div>
                                <div class="action-text">
                                    <strong>Keywords</strong>
                                    <small>Research keywords</small>
                                </div>
                                <i class="bi bi-chevron-right"></i>
                            </a>
                            <a href="#" class="quick-action-btn">
                                <div class="action-icon bg-info-light">
                                    <i class="bi bi-pen"></i>
                                </div>
                                <div class="action-text">
                                    <strong>Meta Generator</strong>
                                    <small>Generate meta tags</small>
                                </div>
                                <i class="bi bi-chevron-right"></i>
                            </a>
                            <a href="#" class="quick-action-btn">
                                <div class="action-icon bg-purple-light">
                                    <i class="bi bi-file-text"></i>
                                </div>
                                <div class="action-text">
                                    <strong>Blog Generator</strong>
                                    <small>AI content writer</small>
                                </div>
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Charts Row -->
            <div class="row g-4 mb-4">
                <div class="col-lg-4">
                    <div class="chart-card animate-fade-in">
                        <div class="chart-header">
                            <h3 class="chart-title">SEO Score Distribution</h3>
                        </div>
                        <canvas id="scoreDistributionChart" height="250"></canvas>
                        <div class="score-legend mt-3">
                            <div class="score-item">
                                <span class="score-dot" style="background: #28A745;"></span>
                                <span>Excellent (90-100)</span>
                                <strong>45%</strong>
                            </div>
                            <div class="score-item">
                                <span class="score-dot" style="background: #FF6B00;"></span>
                                <span>Good (70-89)</span>
                                <strong>35%</strong>
                            </div>
                            <div class="score-item">
                                <span class="score-dot" style="background: #FFC107;"></span>
                                <span>Average (50-69)</span>
                                <strong>15%</strong>
                            </div>
                            <div class="score-item">
                                <span class="score-dot" style="background: #DC3545;"></span>
                                <span>Poor (<50)</span>
                                <strong>5%</strong>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="chart-card animate-fade-in" style="animation-delay: 0.1s;">
                        <div class="chart-header">
                            <h3 class="chart-title">Reports per Month</h3>
                        </div>
                        <canvas id="reportsChart" height="250"></canvas>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="chart-card animate-fade-in" style="animation-delay: 0.2s;">
                        <div class="chart-header">
                            <h3 class="chart-title">Issue Distribution</h3>
                        </div>
                        <canvas id="issueChart" height="250"></canvas>
                        <div class="score-legend mt-3">
                            <div class="score-item">
                                <span class="score-dot" style="background: #0B1F4D;"></span>
                                <span>SEO Issues</span>
                                <strong>142</strong>
                            </div>
                            <div class="score-item">
                                <span class="score-dot" style="background: #FF6B00;"></span>
                                <span>Performance</span>
                                <strong>89</strong>
                            </div>
                            <div class="score-item">
                                <span class="score-dot" style="background: #667EEA;"></span>
                                <span>Accessibility</span>
                                <strong>56</strong>
                            </div>
                            <div class="score-item">
                                <span class="score-dot" style="background: #28A745;"></span>
                                <span>Security</span>
                                <strong>23</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity & Reports Tables -->
            <div class="row g-4 mb-4">
                <div class="col-lg-6">
                    <div class="card chart-card animate-slide-up">
                        <div class="chart-header">
                            <h3 class="chart-title"><i class="bi bi-clock-history me-2"></i>Recent Activity</h3>
                            <a href="#" class="text-decoration-none">View All</a>
                        </div>
                        <div class="activity-list">
                            <div class="activity-item">
                                <div class="activity-icon bg-success">
                                    <i class="bi bi-check-circle"></i>
                                </div>
                                <div class="activity-content">
                                    <strong>Website Audit Completed</strong>
                                    <p class="mb-0">example.com analysis finished</p>
                                    <small class="text-muted">2 minutes ago</small>
                                </div>
                            </div>
                            <div class="activity-item">
                                <div class="activity-icon bg-primary">
                                    <i class="bi bi-file-earmark"></i>
                                </div>
                                <div class="activity-content">
                                    <strong>Report Generated</strong>
                                    <p class="mb-0">Monthly SEO report for mystore.com</p>
                                    <small class="text-muted">1 hour ago</small>
                                </div>
                            </div>
                            <div class="activity-item">
                                <div class="activity-icon bg-warning">
                                    <i class="bi bi-exclamation-triangle"></i>
                                </div>
                                <div class="activity-content">
                                    <strong>Issue Detected</strong>
                                    <p class="mb-0">12 broken links found on blog.site.com</p>
                                    <small class="text-muted">3 hours ago</small>
                                </div>
                            </div>
                            <div class="activity-item">
                                <div class="activity-icon bg-info">
                                    <i class="bi bi-pen"></i>
                                </div>
                                <div class="activity-content">
                                    <strong>Content Generated</strong>
                                    <p class="mb-0">Blog post created via AI Generator</p>
                                    <small class="text-muted">5 hours ago</small>
                                </div>
                            </div>
                            <div class="activity-item">
                                <div class="activity-icon bg-secondary">
                                    <i class="bi bi-key"></i>
                                </div>
                                <div class="activity-content">
                                    <strong>Keywords Updated</strong>
                                    <p class="mb-0">45 new keywords added to portfolio.net</p>
                                    <small class="text-muted">Yesterday</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <div class="card chart-card animate-slide-up" style="animation-delay: 0.1s;">
                        <div class="chart-header">
                            <h3 class="chart-title"><i class="bi bi-file-earmark-text me-2"></i>Latest Reports</h3>
                            <a href="#" class="text-decoration-none">View All</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Website</th>
                                        <th>Score</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <strong>example.com</strong>
                                            <br><small class="text-muted">Full SEO Audit</small>
                                        </td>
                                        <td>
                                            <div class="score-badge excellent">
                                                <i class="bi bi-star-fill"></i> 92
                                            </div>
                                        </td>
                                        <td><small>Today</small></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="#" class="btn btn-sm btn-outline-secondary">
                                                <i class="bi bi-download"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>mystore.com</strong>
                                            <br><small class="text-muted">Quick Scan</small>
                                        </td>
                                        <td>
                                            <div class="score-badge good">
                                                <i class="bi bi-star-fill"></i> 78
                                            </div>
                                        </td>
                                        <td><small>Yesterday</small></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="#" class="btn btn-sm btn-outline-secondary">
                                                <i class="bi bi-download"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>blog.site.com</strong>
                                            <br><small class="text-muted">Content Analysis</small>
                                        </td>
                                        <td>
                                            <div class="score-badge average">
                                                <i class="bi bi-star-fill"></i> 65
                                            </div>
                                        </td>
                                        <td><small>2 days ago</small></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="#" class="btn btn-sm btn-outline-secondary">
                                                <i class="bi bi-download"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <strong>portfolio.net</strong>
                                            <br><small class="text-muted">Performance Test</small>
                                        </td>
                                        <td>
                                            <div class="score-badge excellent">
                                                <i class="bi bi-star-fill"></i> 95
                                            </div>
                                        </td>
                                        <td><small>3 days ago</small></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="#" class="btn btn-sm btn-outline-secondary">
                                                <i class="bi bi-download"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/dashboard-charts.js"></script>

<?php include '../includes/footer.php'; ?>
