<?php
require_once '../../config/init.php';
require_once '../../config/image_optimizer_config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Image Optimization Suite';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <!-- Page Header -->
            <div class="page-header mb-4">
                <h1 class="page-title">
                    <i class="bi bi-images text-primary me-2"></i>
                    Image Optimization Suite
                </h1>
                <p class="page-subtitle">Compress, Resize, Convert & Optimize Your Images for SEO</p>
            </div>

            <!-- Statistics Dashboard -->
            <div class="row g-4 mb-4" id="statsCards">
                <div class="col-lg-3 col-md-6">
                    <div class="card stat-card glass-card">
                        <div class="stat-icon bg-gradient-primary">
                            <i class="bi bi-images"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-number" id="totalImages" data-target="0">0</h3>
                            <p class="stat-label">Images Processed</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card stat-card glass-card">
                        <div class="stat-icon bg-gradient-success">
                            <i class="bi bi-archive"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-number" id="storageSaved" data-target="0">0 MB</h3>
                            <p class="stat-label">Storage Saved</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card stat-card glass-card">
                        <div class="stat-icon bg-gradient-info">
                            <i class="bi bi-download"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-number" id="totalDownloads" data-target="0">0</h3>
                            <p class="stat-label">Total Downloads</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="card stat-card glass-card">
                        <div class="stat-icon bg-gradient-warning">
                            <i class="bi bi-percent"></i>
                        </div>
                        <div class="stat-content">
                            <h3 class="stat-number" id="avgCompression" data-target="0">0%</h3>
                            <p class="stat-label">Avg Compression</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Upload Area -->
            <div class="row g-4 mb-4">
                <div class="col-lg-8">
                    <div class="card glass-card">
                        <h5 class="mb-4">
                            <i class="bi bi-cloud-upload text-primary me-2"></i>
                            Upload Images
                        </h5>

                        <!-- Drag & Drop Area -->
                        <div class="upload-area" id="uploadArea">
                            <div class="upload-icon">
                                <i class="bi bi-cloud-arrow-up"></i>
                            </div>
                            <h4>Drag & Drop Images Here</h4>
                            <p class="text-muted">or click to browse</p>
                            <input type="file" id="fileInput" multiple accept="image/*" style="display: none;">
                            <button type="button" class="btn btn-primary mt-3" id="browseBtn">
                                <i class="bi bi-folder2-open me-2"></i>Browse Files
                            </button>
                            <div class="mt-3">
                                <small class="text-muted">
                                    Supported: JPG, PNG, WEBP, GIF, BMP, TIFF, AVIF<br>
                                    Max size: <?php echo formatBytes(IMG_MAX_UPLOAD_SIZE); ?> per file
                                </small>
                            </div>
                        </div>

                        <!-- Image Preview Container -->
                        <div id="imagePreview" class="image-preview-container mt-4" style="display: none;">
                            <!-- Preview items will be dynamically added here -->
                        </div>

                        <!-- Processing Options -->
                        <div id="processingOptions" class="processing-options mt-4" style="display: none;">
                            <h6 class="mb-3">
                                <i class="bi bi-sliders me-2"></i>Processing Options
                            </h6>

                            <!-- Tabs for different operations -->
                            <ul class="nav nav-pills mb-3" role="tablist">
                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#compressTab">
                                        <i class="bi bi-file-zip me-1"></i>Compress
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#resizeTab">
                                        <i class="bi bi-arrows-fullscreen me-1"></i>Resize
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#convertTab">
                                        <i class="bi bi-arrow-left-right me-1"></i>Convert
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#watermarkTab">
                                        <i class="bi bi-badge-tm me-1"></i>Watermark
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#enhanceTab">
                                        <i class="bi bi-magic me-1"></i>Enhance
                                    </button>
                                </li>
                            </ul>

                            <div class="tab-content">
                                <!-- Compress Tab -->
                                <div class="tab-pane fade show active" id="compressTab">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Compression Level</label>
                                            <select class="form-select" id="compressionLevel">
                                                <option value="lossless">Lossless (100%)</option>
                                                <option value="low">Low Compression (90%)</option>
                                                <option value="medium" selected>Medium Compression (85%)</option>
                                                <option value="high">High Compression (75%)</option>
                                                <option value="maximum">Maximum Compression (60%)</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Quality <span id="qualityValue">85</span>%</label>
                                            <input type="range" class="form-range" id="qualitySlider" min="0" max="100" value="85">
                                        </div>
                                    </div>
                                </div>

                                <!-- Resize Tab -->
                                <div class="tab-pane fade" id="resizeTab">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label class="form-label">Quick Presets</label>
                                            <div class="btn-group-wrap">
                                                <?php foreach (IMG_RESIZE_PRESETS as $key => $preset): ?>
                                                <button type="button" class="btn btn-outline-secondary btn-sm preset-btn" 
                                                        data-width="<?php echo $preset['width']; ?>" 
                                                        data-height="<?php echo $preset['height']; ?>">
                                                    <?php echo $preset['name']; ?>
                                                </button>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Width (px)</label>
                                            <input type="number" class="form-control" id="resizeWidth" placeholder="1920">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Height (px)</label>
                                            <input type="number" class="form-control" id="resizeHeight" placeholder="1080">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">&nbsp;</label>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="maintainRatio" checked>
                                                <label class="form-check-label" for="maintainRatio">
                                                    Lock Aspect Ratio
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Convert Tab -->
                                <div class="tab-pane fade" id="convertTab">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Convert To</label>
                                            <select class="form-select" id="convertFormat">
                                                <option value="">Select Format</option>
                                                <option value="jpg">JPG</option>
                                                <option value="png">PNG</option>
                                                <option value="webp" selected>WEBP (Recommended)</option>
                                                <option value="avif">AVIF (Best Compression)</option>
                                                <option value="gif">GIF</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Quality</label>
                                            <input type="range" class="form-range" id="convertQuality" min="0" max="100" value="85">
                                            <small class="text-muted">Quality: <span id="convertQualityValue">85</span>%</small>
                                        </div>
                                    </div>
                                    <div class="alert alert-info mt-3">
                                        <i class="bi bi-info-circle me-2"></i>
                                        <strong>SEO Tip:</strong> WEBP format reduces file size by 25-35% compared to JPG/PNG with same quality!
                                    </div>
                                </div>

                                <!-- Watermark Tab -->
                                <div class="tab-pane fade" id="watermarkTab">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label">Watermark Text</label>
                                            <input type="text" class="form-control" id="watermarkText" placeholder="© Your Company">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Position</label>
                                            <select class="form-select" id="watermarkPosition">
                                                <option value="top-left">Top Left</option>
                                                <option value="top-center">Top Center</option>
                                                <option value="top-right">Top Right</option>
                                                <option value="center-left">Center Left</option>
                                                <option value="center">Center</option>
                                                <option value="center-right">Center Right</option>
                                                <option value="bottom-left">Bottom Left</option>
                                                <option value="bottom-center">Bottom Center</option>
                                                <option value="bottom-right" selected>Bottom Right</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Opacity <span id="watermarkOpacityValue">50</span>%</label>
                                            <input type="range" class="form-range" id="watermarkOpacity" min="0" max="100" value="50">
                                        </div>
                                    </div>
                                </div>

                                <!-- Enhance Tab -->
                                <div class="tab-pane fade" id="enhanceTab">
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <h6>Transform</h6>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="button" class="btn btn-outline-primary w-100" id="rotate90Btn">
                                                <i class="bi bi-arrow-clockwise me-2"></i>Rotate 90°
                                            </button>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="button" class="btn btn-outline-primary w-100" id="rotate180Btn">
                                                <i class="bi bi-arrow-clockwise me-2"></i>Rotate 180°
                                            </button>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="button" class="btn btn-outline-primary w-100" id="flipHBtn">
                                                <i class="bi bi-arrow-left-right me-2"></i>Flip Horizontal
                                            </button>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="button" class="btn btn-outline-primary w-100" id="flipVBtn">
                                                <i class="bi bi-arrow-down-up me-2"></i>Flip Vertical
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Process Button -->
                            <div class="mt-4">
                                <button type="button" class="btn btn-primary btn-lg" id="processBtn">
                                    <i class="bi bi-gear-fill me-2"></i>Process Images
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-lg ms-2" id="clearBtn">
                                    <i class="bi bi-x-circle me-2"></i>Clear All
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Info & Recent Activity -->
                <div class="col-lg-4">
                    <!-- Today's Activity -->
                    <div class="card glass-card mb-4">
                        <h5 class="mb-3">
                            <i class="bi bi-clock-history text-info me-2"></i>
                            Today's Activity
                        </h5>
                        <div class="activity-stat">
                            <i class="bi bi-images text-primary"></i>
                            <div>
                                <h4 id="todayOptimizations">0</h4>
                                <p>Images Optimized</p>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Tips -->
                    <div class="card glass-card mb-4">
                        <h5 class="mb-3">
                            <i class="bi bi-lightbulb text-warning me-2"></i>
                            SEO Tips
                        </h5>
                        <ul class="tips-list">
                            <li>
                                <i class="bi bi-check-circle text-success"></i>
                                Use WEBP format for 25-35% size reduction
                            </li>
                            <li>
                                <i class="bi bi-check-circle text-success"></i>
                                Keep image file sizes under 200KB for web
                            </li>
                            <li>
                                <i class="bi bi-check-circle text-success"></i>
                                Use descriptive, SEO-friendly filenames
                            </li>
                            <li>
                                <i class="bi bi-check-circle text-success"></i>
                                Optimize images before uploading to your site
                            </li>
                        </ul>
                    </div>

                    <!-- Supported Formats -->
                    <div class="card glass-card">
                        <h5 class="mb-3">
                            <i class="bi bi-file-earmark-image text-primary me-2"></i>
                            Supported Formats
                        </h5>
                        <div class="format-badges">
                            <span class="badge bg-primary">JPG</span>
                            <span class="badge bg-primary">PNG</span>
                            <span class="badge bg-success">WEBP</span>
                            <span class="badge bg-info">AVIF</span>
                            <span class="badge bg-secondary">GIF</span>
                            <span class="badge bg-secondary">BMP</span>
                            <span class="badge bg-secondary">TIFF</span>
                        </div>
                        <div class="mt-3 p-3 bg-light rounded">
                            <small>
                                <strong>Using:</strong> <?php echo IMG_HAS_IMAGICK ? 'ImageMagick' : 'GD Library'; ?><br>
                                <strong>Max Upload:</strong> <?php echo formatBytes(IMG_MAX_UPLOAD_SIZE); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Results Section -->
            <div id="resultsSection" style="display: none;">
                <div class="card glass-card">
                    <h5 class="mb-4">
                        <i class="bi bi-check-circle text-success me-2"></i>
                        Processing Results
                    </h5>
                    <div id="resultsContainer">
                        <!-- Results will be displayed here -->
                    </div>
                </div>
            </div>

            <!-- Processing History -->
            <div class="card glass-card mt-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="mb-0">
                        <i class="bi bi-clock-history text-primary me-2"></i>
                        Processing History
                    </h5>
                    <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-outline-danger" id="bulkDeleteBtn">
                            <i class="bi bi-trash me-1"></i>Delete Selected
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="refreshHistoryBtn">
                            <i class="bi bi-arrow-clockwise me-1"></i>Refresh
                        </button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover" id="historyTable">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAllHistory"></th>
                                <th>Original</th>
                                <th>Optimized</th>
                                <th>Original Size</th>
                                <th>Optimized Size</th>
                                <th>Saved</th>
                                <th>Operation</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="historyTableBody">
                            <tr>
                                <td colspan="9" class="text-center text-muted">
                                    <i class="bi bi-inbox display-1"></i>
                                    <p>No history yet. Start optimizing images!</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<!-- Loading Modal -->
<div class="modal fade" id="processingModal" data-bs-backdrop="static" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center py-5">
                <div class="spinner-border text-primary mb-3" role="status" style="width: 4rem; height: 4rem;">
                    <span class="visually-hidden">Processing...</span>
                </div>
                <h4>Processing Images...</h4>
                <p class="text-muted mb-0" id="processingStatus">Please wait</p>
                <div class="progress mt-3" style="height: 30px;">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" 
                         role="progressbar" 
                         id="processingProgress" 
                         style="width: 0%">0%</div>
                </div>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/image-optimizer.css">
<script src="<?php echo SITE_URL; ?>/assets/js/image-optimizer.js"></script>

<?php include '../includes/footer.php'; ?>
