<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'History';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">Activity History</h1>
                <p class="page-subtitle">View all your past activities</p>
            </div>
            
            <div class="card profile-card glass-card">
                <div class="activity-list">
                    <div class="activity-item">
                        <div class="activity-icon bg-success">
                            <i class="bi bi-check-circle"></i>
                        </div>
                        <div class="activity-content">
                            <strong>Website Audit Completed</strong>
                            <p class="mb-0">example.com analysis finished with score: 92</p>
                            <small class="text-muted">Today at 10:30 AM</small>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon bg-primary">
                            <i class="bi bi-file-earmark"></i>
                        </div>
                        <div class="activity-content">
                            <strong>Report Generated</strong>
                            <p class="mb-0">Monthly SEO report for mystore.com created</p>
                            <small class="text-muted">Yesterday at 3:15 PM</small>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon bg-warning">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                        <div class="activity-content">
                            <strong>Issue Detected</strong>
                            <p class="mb-0">12 broken links found on blog.site.com</p>
                            <small class="text-muted">2 days ago at 9:45 AM</small>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon bg-info">
                            <i class="bi bi-pen"></i>
                        </div>
                        <div class="activity-content">
                            <strong>Content Generated</strong>
                            <p class="mb-0">Blog post "SEO Best Practices" created</p>
                            <small class="text-muted">3 days ago at 2:20 PM</small>
                        </div>
                    </div>
                    
                    <div class="activity-item">
                        <div class="activity-icon bg-secondary">
                            <i class="bi bi-key"></i>
                        </div>
                        <div class="activity-content">
                            <strong>Keywords Updated</strong>
                            <p class="mb-0">45 new keywords added to portfolio.net</p>
                            <small class="text-muted">4 days ago at 11:00 AM</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
