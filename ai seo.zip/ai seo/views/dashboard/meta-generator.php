<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'AI Meta Generator';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="bi bi-robot text-warning me-2"></i>AI Meta Tag Generator
                </h1>
                <p class="page-subtitle">Generate SEO-optimized meta tags using AI powered by Google Gemini</p>
            </div>
            
            <div class="row g-4">
                <!-- Input Section -->
                <div class="col-lg-4">
                    <div class="card glass-card sticky-top" style="top: 20px;">
                        <h5 class="mb-4">
                            <i class="bi bi-gear text-primary me-2"></i>Configuration
                        </h5>
                        
                        <form id="metaGeneratorForm">
                            <div class="mb-3">
                                <label for="focus_keyword" class="form-label">
                                    <i class="bi bi-key me-1"></i>Focus Keyword *
                                </label>
                                <input type="text" class="form-control" id="focus_keyword" 
                                       placeholder="E.g., Digital Marketing Services" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="website_url" class="form-label">
                                    <i class="bi bi-link-45deg me-1"></i>Website URL (Optional)
                                </label>
                                <input type="url" class="form-control" id="website_url" 
                                       placeholder="https://example.com">
                            </div>
                            
                            <div class="mb-4">
                                <label for="page_type" class="form-label">
                                    <i class="bi bi-file-text me-1"></i>Page Type
                                </label>
                                <select class="form-select" id="page_type">
                                    <option value="general">General Page</option>
                                    <option value="homepage">Homepage</option>
                                    <option value="product">Product Page</option>
                                    <option value="service">Service Page</option>
                                    <option value="blog">Blog Post</option>
                                    <option value="landing">Landing Page</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 mb-2" id="generateBtn">
                                <i class="bi bi-stars me-2"></i>Generate Meta Tags
                            </button>
                            
                            <button type="button" class="btn btn-outline-warning w-100 mb-2" id="regenerateBtn" style="display: none;">
                                <i class="bi bi-arrow-clockwise me-2"></i>Regenerate
                            </button>
                            
                            <button type="button" class="btn btn-outline-secondary w-100" id="clearBtn">
                                <i class="bi bi-x-circle me-2"></i>Clear
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Results Section -->
                <div class="col-lg-8">
                    <!-- Loading -->
                    <div id="loadingSection" style="display: none;">
                        <div class="card glass-card text-center py-5">
                            <div class="spinner-border text-primary mb-3" role="status"></div>
                            <h5>Generating Meta Tags with AI...</h5>
                            <p class="text-muted">Crafting SEO-optimized content</p>
                        </div>
                    </div>
                    
                    <!-- Welcome -->
                    <div id="welcomeSection">
                        <div class="card glass-card text-center py-5">
                            <i class="bi bi-tag display-1 text-primary mb-3"></i>
                            <h4>AI-Powered Meta Tag Generation</h4>
                            <p class="text-muted">Enter your focus keyword to generate SEO-optimized meta tags for better search rankings</p>
                        </div>
                    </div>
                    
                    <!-- Results -->
                    <div id="resultsSection" style="display: none;">
                        <!-- SEO Score -->
                        <div class="card glass-card mb-4">
                            <div class="row align-items-center">
                                <div class="col-md-8">
                                    <h5 class="mb-0">SEO Score</h5>
                                    <p class="text-muted mb-0">Based on character count and optimization</p>
                                </div>
                                <div class="col-md-4 text-end">
                                    <div class="seo-score-circle">
                                        <svg viewBox="0 0 100 100" width="80" height="80">
                                            <circle cx="50" cy="50" r="45" fill="none" stroke="#f0f0f0" stroke-width="8"/>
                                            <circle id="scoreCircleMeta" cx="50" cy="50" r="45" fill="none" stroke="#28A745" stroke-width="8" 
                                                    stroke-dasharray="283" stroke-dashoffset="283" transform="rotate(-90 50 50)"/>
                                        </svg>
                                        <div class="score-number-overlay" id="seoScoreValue">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- SEO Title -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-file-text text-primary me-2"></i>SEO Title</h5>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-target="seo_title">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <div class="meta-preview" id="seoTitlePreview"></div>
                            <div class="char-counter mt-2">
                                <small><span id="titleCharCount">0</span> / 60 characters</small>
                                <div class="progress" style="height: 4px;">
                                    <div id="titleProgress" class="progress-bar bg-success" style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Meta Description -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-card-text text-success me-2"></i>Meta Description</h5>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-target="meta_description">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <div class="meta-preview" id="metaDescPreview"></div>
                            <div class="char-counter mt-2">
                                <small><span id="descCharCount">0</span> / 160 characters</small>
                                <div class="progress" style="height: 4px;">
                                    <div id="descProgress" class="progress-bar bg-success" style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- OpenGraph Tags -->
                        <div class="card glass-card mb-4">
                            <h5 class="mb-3"><i class="bi bi-facebook text-primary me-2"></i>OpenGraph Tags (Facebook)</h5>
                            <div class="code-preview mb-2">
                                <code id="ogTagsCode"></code>
                            </div>
                            <button class="btn btn-sm btn-outline-primary copy-btn" data-target="og_tags">
                                <i class="bi bi-clipboard"></i> Copy HTML
                            </button>
                        </div>
                        
                        <!-- Twitter Card Tags -->
                        <div class="card glass-card mb-4">
                            <h5 class="mb-3"><i class="bi bi-twitter text-info me-2"></i>Twitter Card Tags</h5>
                            <div class="code-preview mb-2">
                                <code id="twitterTagsCode"></code>
                            </div>
                            <button class="btn btn-sm btn-outline-primary copy-btn" data-target="twitter_tags">
                                <i class="bi bi-clipboard"></i> Copy HTML
                            </button>
                        </div>
                        
                        <!-- Actions -->
                        <div class="card glass-card">
                            <div class="d-grid gap-2 d-md-flex">
                                <button class="btn btn-success flex-fill" id="saveBtn">
                                    <i class="bi bi-save me-2"></i>Save Meta Tags
                                </button>
                                <button class="btn btn-outline-primary" id="copyAllBtn">
                                    <i class="bi bi-clipboard me-2"></i>Copy All HTML
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</div>

<script src="../../assets/js/meta-generator.js?v=<?php echo time(); ?>"></script>
<?php include '../includes/footer.php'; ?>
