<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Website Audit';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">Website Audit</h1>
                <p class="page-subtitle">AI-Powered SEO Analysis Tool</p>
            </div>
            
            <!-- Audit Form Section -->
            <div class="row g-4 mb-4" id="auditFormSection">
                <div class="col-lg-8">
                    <div class="card profile-card glass-card">
                        <h5 class="mb-4">
                            <i class="bi bi-search text-primary me-2"></i>Launch AI Audit
                        </h5>
                        <form id="auditForm">
                            <div class="mb-3">
                                <label for="website_url" class="form-label">Website URL</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="bi bi-globe"></i>
                                    </span>
                                    <input 
                                        type="url" 
                                        class="form-control" 
                                        id="website_url" 
                                        name="website_url"
                                        placeholder="https://example.com" 
                                        required
                                    >
                                </div>
                                <small class="text-muted">Enter the complete URL including http:// or https://</small>
                            </div>
                            
                            <div class="d-flex gap-2 flex-wrap">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="bi bi-rocket-takeoff me-2"></i>Launch AI Audit
                                </button>
                                <button type="button" id="googlePageSpeedBtn" class="btn btn-outline-primary btn-lg">
                                    <i class="bi bi-google me-2"></i>Google PageSpeed Insights
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="card profile-card glass-card">
                        <h5 class="mb-3">
                            <i class="bi bi-stars text-warning me-2"></i>AI Analysis Features
                        </h5>
                        <ul class="list-unstyled audit-features">
                            <li><i class="bi bi-check-circle-fill text-success"></i> SEO Score Calculation</li>
                            <li><i class="bi bi-check-circle-fill text-success"></i> Meta Tags Analysis</li>
                            <li><i class="bi bi-check-circle-fill text-success"></i> SSL Security Check</li>
                            <li><i class="bi bi-check-circle-fill text-success"></i> CMS Detection</li>
                            <li><i class="bi bi-check-circle-fill text-success"></i> Server Information</li>
                            <li><i class="bi bi-check-circle-fill text-success"></i> Response Time</li>
                            <li><i class="bi bi-check-circle-fill text-success"></i> Mobile Optimization</li>
                            <li><i class="bi bi-check-circle-fill text-success"></i> Performance Metrics</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Loading Animation Section -->
            <div class="audit-loading" id="loadingSection" style="display: none;">
                <div class="card profile-card glass-card text-center py-5">
                    <div class="loading-container">
                        <div class="ai-scanner">
                            <div class="scanner-ring"></div>
                            <div class="scanner-ring"></div>
                            <div class="scanner-ring"></div>
                            <div class="scanner-core">
                                <i class="bi bi-cpu-fill"></i>
                            </div>
                        </div>
                        <h4 class="mt-4 mb-3">AI Audit in Progress</h4>
                        <p class="text-muted mb-4">Analyzing your website...</p>
                        <div class="progress-steps">
                            <div class="step active" id="step1">
                                <i class="bi bi-check-circle"></i>
                                <span>Validating URL</span>
                            </div>
                            <div class="step" id="step2">
                                <i class="bi bi-arrow-repeat spin"></i>
                                <span>Fetching Data</span>
                            </div>
                            <div class="step" id="step3">
                                <i class="bi bi-hourglass"></i>
                                <span>Analyzing SEO</span>
                            </div>
                            <div class="step" id="step4">
                                <i class="bi bi-hourglass"></i>
                                <span>Calculating Score</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Results Section -->
            <div id="resultsSection" style="display: none;">
                <div class="row g-4 mb-4">
                    <div class="col-12">
                        <div class="alert alert-success d-flex align-items-center" role="alert">
                            <i class="bi bi-check-circle-fill me-3 fs-4"></i>
                            <div>
                                <strong>Audit Completed!</strong> Your website has been successfully analyzed.
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- SEO Score Card -->
                <div class="row g-4 mb-4">
                    <div class="col-lg-4">
                        <div class="card profile-card glass-card text-center">
                            <div class="seo-score-circle">
                                <svg viewBox="0 0 200 200">
                                    <circle cx="100" cy="100" r="90" fill="none" stroke="#f0f0f0" stroke-width="12"/>
                                    <circle cx="100" cy="100" r="90" fill="none" stroke="#FF6B00" stroke-width="12" 
                                            id="scoreCircle" stroke-dasharray="565" stroke-dashoffset="565"
                                            transform="rotate(-90 100 100)"/>
                                </svg>
                                <div class="score-value" id="seoScoreValue">0</div>
                            </div>
                            <h5 class="mt-3">SEO Score</h5>
                            <p class="text-muted mb-0" id="scoreLabel">Calculating...</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-8">
                        <div class="card profile-card glass-card">
                            <h5 class="mb-4"><i class="bi bi-info-circle text-primary me-2"></i>Website Information</h5>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label><i class="bi bi-bookmark"></i> Website Title</label>
                                        <p id="websiteTitle">-</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label><i class="bi bi-shield-check"></i> SSL Status</label>
                                        <p id="sslStatus">-</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label><i class="bi bi-translate"></i> Language</label>
                                        <p id="websiteLanguage">-</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <label><i class="bi bi-clock"></i> Response Time</label>
                                        <p id="responseTime">-</p>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="info-item">
                                        <label><i class="bi bi-file-text"></i> Meta Description</label>
                                        <p id="metaDescription">-</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Technical Details -->
                <div class="row g-4 mb-4">
                    <div class="col-lg-6">
                        <div class="card profile-card glass-card">
                            <h5 class="mb-4"><i class="bi bi-server text-primary me-2"></i>Technical Details</h5>
                            <div class="info-item mb-3">
                                <label><i class="bi bi-hdd-network"></i> CMS Detected</label>
                                <p id="cmsDetected">-</p>
                            </div>
                            <div class="info-item mb-3">
                                <label><i class="bi bi-server"></i> Server</label>
                                <p id="serverInfo">-</p>
                            </div>
                            <div class="info-item mb-3">
                                <label><i class="bi bi-globe"></i> IP Address</label>
                                <p id="ipAddress">-</p>
                            </div>
                            <div class="info-item">
                                <label><i class="bi bi-geo-alt"></i> Country</label>
                                <p id="country">-</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="card profile-card glass-card">
                            <h5 class="mb-4"><i class="bi bi-tag text-primary me-2"></i>Meta Keywords</h5>
                            <div id="metaKeywords" class="keywords-container">
                                <span class="badge bg-secondary">No keywords found</span>
                            </div>
                            
                            <div class="mt-4">
                                <button class="btn btn-outline-primary btn-sm me-2" onclick="window.location.reload()">
                                    <i class="bi bi-arrow-clockwise"></i> New Audit
                                </button>
                                <button class="btn btn-outline-secondary btn-sm" id="downloadReport">
                                    <i class="bi bi-download"></i> Download Report
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/audit.js?v=<?php echo time(); ?>"></script>
<?php include '../includes/footer.php'; ?>
