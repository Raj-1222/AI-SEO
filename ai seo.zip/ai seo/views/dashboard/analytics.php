<?php
require_once '../../config/init.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Analytics';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">Analytics</h1>
                <p class="page-subtitle">Track your SEO performance</p>
            </div>
            
            <div class="row g-4">
                <div class="col-lg-12">
                    <div class="card profile-card glass-card">
                        <h5 class="mb-4"><i class="bi bi-graph-up-arrow text-primary me-2"></i>Analytics Dashboard</h5>
                        <p class="text-muted">Advanced analytics coming soon...</p>
                    </div>
                </div>
            </div>
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
