<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'AI Keyword Generator';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="bi bi-robot text-warning me-2"></i>AI Keyword Generator
                </h1>
                <p class="page-subtitle">Generate SEO keywords using AI powered by Google Gemini</p>
            </div>
            
            <div class="row g-4">
                <!-- Input Form -->
                <div class="col-lg-4">
                    <div class="card glass-card sticky-top" style="top: 20px;">
                        <h5 class="mb-4">
                            <i class="bi bi-input-cursor text-primary me-2"></i>Input Details
                        </h5>
                        
                        <form id="keywordGeneratorForm">
                            <div class="mb-3">
                                <label for="website_url" class="form-label">
                                    <i class="bi bi-link-45deg me-1"></i>Website URL *
                                </label>
                                <input type="url" class="form-control" id="website_url" 
                                       placeholder="https://example.com" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="industry" class="form-label">
                                    <i class="bi bi-building me-1"></i>Industry *
                                </label>
                                <input type="text" class="form-control" id="industry" 
                                       placeholder="E.g., Digital Marketing, E-commerce" required>
                            </div>
                            
                            <div class="mb-4">
                                <label for="location" class="form-label">
                                    <i class="bi bi-geo-alt me-1"></i>Location (Optional)
                                </label>
                                <input type="text" class="form-control" id="location" 
                                       placeholder="E.g., New York, USA">
                                <small class="form-text text-muted">Leave empty for global keywords</small>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 mb-2" id="generateBtn">
                                <i class="bi bi-stars me-2"></i>Generate Keywords
                            </button>
                            
                            <button type="button" class="btn btn-outline-secondary w-100" id="clearBtn">
                                <i class="bi bi-arrow-clockwise me-2"></i>Clear
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Results Area -->
                <div class="col-lg-8">
                    <!-- Loading State -->
                    <div id="loadingSection" style="display: none;">
                        <div class="card glass-card text-center py-5">
                            <div class="spinner-border text-primary mb-3" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <h5>Generating Keywords with AI...</h5>
                            <p class="text-muted">This may take a few seconds</p>
                        </div>
                    </div>
                    
                    <!-- Welcome State -->
                    <div id="welcomeSection">
                        <div class="card glass-card text-center py-5">
                            <div class="empty-state">
                                <i class="bi bi-lightbulb display-1 text-warning mb-3"></i>
                                <h4>AI-Powered Keyword Research</h4>
                                <p class="text-muted mb-0">
                                    Enter your website details and let our AI generate comprehensive keyword recommendations
                                    for your SEO strategy.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Results Section -->
                    <div id="resultsSection" style="display: none;">
                        <!-- Action Buttons -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="bi bi-check-circle text-success me-2"></i>Keywords Generated
                                </h5>
                                <div class="btn-group">
                                    <button class="btn btn-sm btn-outline-primary" id="copyAllBtn">
                                        <i class="bi bi-clipboard me-1"></i>Copy All
                                    </button>
                                    <button class="btn btn-sm btn-outline-success" id="exportBtn">
                                        <i class="bi bi-download me-1"></i>Export CSV
                                    </button>
                                    <button class="btn btn-sm btn-primary" id="saveBtn">
                                        <i class="bi bi-save me-1"></i>Save
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Primary Keywords -->
                        <div class="card glass-card mb-4">
                            <h5 class="mb-3">
                                <i class="bi bi-star-fill text-warning me-2"></i>Primary Keywords
                            </h5>
                            <div id="primaryKeywordsContainer"></div>
                        </div>
                        
                        <!-- Secondary Keywords -->
                        <div class="card glass-card mb-4">
                            <h5 class="mb-3">
                                <i class="bi bi-star text-primary me-2"></i>Secondary Keywords
                            </h5>
                            <div id="secondaryKeywordsContainer"></div>
                        </div>
                        
                        <!-- Long-tail Keywords -->
                        <div class="card glass-card">
                            <h5 class="mb-3">
                                <i class="bi bi-search text-info me-2"></i>Long-tail Keywords
                            </h5>
                            <div id="longTailKeywordsContainer"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</div>

<script src="../../assets/js/keywords.js?v=<?php echo time(); ?>"></script>
<?php include '../includes/footer.php'; ?>
