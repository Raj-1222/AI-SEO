<?php
require_once '../../config/init.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'AI Blog Generator';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <div class="page-header">
                <h1 class="page-title">
                    <i class="bi bi-robot text-warning me-2"></i>AI Blog Post Generator
                </h1>
                <p class="page-subtitle">Generate SEO-optimized blog posts using AI powered by Google Gemini</p>
            </div>
            
            <div class="row g-4">
                <!-- Input Section -->
                <div class="col-lg-4">
                    <div class="card glass-card sticky-top" style="top: 20px;">
                        <h5 class="mb-4">
                            <i class="bi bi-gear text-primary me-2"></i>Blog Configuration
                        </h5>
                        
                        <form id="blogGeneratorForm">
                            <div class="mb-3">
                                <label for="keyword" class="form-label">
                                    <i class="bi bi-key me-1"></i>Target Keyword *
                                </label>
                                <input type="text" class="form-control" id="keyword" 
                                       placeholder="E.g., Digital Marketing Strategy" required>
                                <small class="form-text text-muted">Main topic for your blog post</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="word_count" class="form-label">
                                    <i class="bi bi-file-text me-1"></i>Word Count: <span id="wordCountValue">1500</span>
                                </label>
                                <input type="range" class="form-range" id="word_count" 
                                       min="500" max="3000" step="100" value="1500">
                                <div class="d-flex justify-content-between">
                                    <small class="text-muted">500</small>
                                    <small class="text-muted">3000</small>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="language" class="form-label">
                                    <i class="bi bi-translate me-1"></i>Language
                                </label>
                                <select class="form-select" id="language">
                                    <option value="English">English</option>
                                    <option value="Spanish">Spanish</option>
                                    <option value="French">French</option>
                                    <option value="German">German</option>
                                    <option value="Italian">Italian</option>
                                    <option value="Portuguese">Portuguese</option>
                                    <option value="Dutch">Dutch</option>
                                    <option value="Russian">Russian</option>
                                    <option value="Japanese">Japanese</option>
                                    <option value="Chinese">Chinese</option>
                                    <option value="Korean">Korean</option>
                                    <option value="Arabic">Arabic</option>
                                    <option value="Hindi">Hindi</option>
                                </select>
                            </div>
                            
                            <div class="mb-4">
                                <label for="tone" class="form-label">
                                    <i class="bi bi-chat-text me-1"></i>Tone
                                </label>
                                <select class="form-select" id="tone">
                                    <option value="professional">Professional</option>
                                    <option value="casual">Casual</option>
                                    <option value="friendly">Friendly</option>
                                    <option value="formal">Formal</option>
                                    <option value="conversational">Conversational</option>
                                    <option value="authoritative">Authoritative</option>
                                    <option value="enthusiastic">Enthusiastic</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 mb-2" id="generateBtn">
                                <i class="bi bi-stars me-2"></i>Generate Blog Post
                            </button>
                            
                            <button type="button" class="btn btn-outline-warning w-100 mb-2" id="regenerateBtn" style="display: none;">
                                <i class="bi bi-arrow-clockwise me-2"></i>Regenerate
                            </button>
                            
                            <button type="button" class="btn btn-outline-secondary w-100" id="clearBtn">
                                <i class="bi bi-x-circle me-2"></i>Clear
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Results Section -->
                <div class="col-lg-8">
                    <!-- Loading -->
                    <div id="loadingSection" style="display: none;">
                        <div class="card glass-card text-center py-5">
                            <div class="spinner-border text-primary mb-3" style="width: 3rem; height: 3rem;" role="status"></div>
                            <h5>Generating Blog Post with AI...</h5>
                            <p class="text-muted">Creating comprehensive content (~30-60 seconds)</p>
                            <div class="progress mx-auto" style="width: 200px; height: 4px;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" style="width: 100%"></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Welcome -->
                    <div id="welcomeSection">
                        <div class="card glass-card text-center py-5">
                            <i class="bi bi-newspaper display-1 text-primary mb-3"></i>
                            <h4>AI-Powered Blog Content Generation</h4>
                            <p class="text-muted mb-4">Create comprehensive, SEO-optimized blog posts in seconds</p>
                            <div class="row text-start">
                                <div class="col-md-6 mb-3">
                                    <div class="d-flex align-items-start">
                                        <i class="bi bi-check-circle-fill text-success me-2 mt-1"></i>
                                        <div>
                                            <strong>SEO Optimized</strong>
                                            <p class="text-muted small mb-0">Keyword-rich content with proper structure</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="d-flex align-items-start">
                                        <i class="bi bi-check-circle-fill text-success me-2 mt-1"></i>
                                        <div>
                                            <strong>Comprehensive</strong>
                                            <p class="text-muted small mb-0">Complete with outline, sections, and FAQ</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="d-flex align-items-start">
                                        <i class="bi bi-check-circle-fill text-success me-2 mt-1"></i>
                                        <div>
                                            <strong>Ready to Publish</strong>
                                            <p class="text-muted small mb-0">Copy, export, or save directly</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="d-flex align-items-start">
                                        <i class="bi bi-check-circle-fill text-success me-2 mt-1"></i>
                                        <div>
                                            <strong>Multi-Language</strong>
                                            <p class="text-muted small mb-0">Generate content in 13+ languages</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Results -->
                    <div id="resultsSection" style="display: none;">
                        <!-- SEO Score & Actions -->
                        <div class="card glass-card mb-4">
                            <div class="row align-items-center">
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div class="seo-score-circle mx-auto">
                                            <svg viewBox="0 0 100 100" width="100" height="100">
                                                <circle cx="50" cy="50" r="45" fill="none" stroke="#f0f0f0" stroke-width="8"/>
                                                <circle id="scoreCircleBlog" cx="50" cy="50" r="45" fill="none" stroke="#28A745" stroke-width="8" 
                                                        stroke-dasharray="283" stroke-dashoffset="283" transform="rotate(-90 50 50)"/>
                                            </svg>
                                            <div class="score-number-overlay" id="seoScoreValue">0</div>
                                        </div>
                                        <p class="text-muted mt-2 mb-0"><small>SEO Score</small></p>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="d-grid gap-2">
                                        <button class="btn btn-success" id="saveBtn">
                                            <i class="bi bi-save me-2"></i>Save Blog Post
                                        </button>
                                        <div class="btn-group">
                                            <button class="btn btn-outline-primary" id="copyAllBtn">
                                                <i class="bi bi-clipboard me-1"></i>Copy All
                                            </button>
                                            <button class="btn btn-outline-info" id="exportBtn">
                                                <i class="bi bi-download me-1"></i>Export HTML
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Blog Title -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-file-text text-primary me-2"></i>Title</h5>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-target="title">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <h3 class="blog-title" id="blogTitle"></h3>
                        </div>
                        
                        <!-- Outline -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-list-ol text-info me-2"></i>Outline</h5>
                                <button class="btn btn-sm btn-outline-primary" id="toggleOutline">
                                    <i class="bi bi-chevron-up"></i>
                                </button>
                            </div>
                            <div id="blogOutline"></div>
                        </div>
                        
                        <!-- Introduction -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-arrow-return-right text-success me-2"></i>Introduction</h5>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-target="introduction">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <div class="blog-content" id="blogIntroduction"></div>
                        </div>
                        
                        <!-- Main Content Sections -->
                        <div id="blogSections"></div>
                        
                        <!-- FAQ Section -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-question-circle text-warning me-2"></i>FAQ</h5>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-target="faq">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <div id="blogFaq"></div>
                        </div>
                        
                        <!-- Conclusion -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-flag text-danger me-2"></i>Conclusion</h5>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-target="conclusion">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <div class="blog-content" id="blogConclusion"></div>
                        </div>
                        
                        <!-- Call to Action -->
                        <div class="card glass-card mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="mb-0"><i class="bi bi-megaphone text-primary me-2"></i>Call to Action</h5>
                                <button class="btn btn-sm btn-outline-primary copy-btn" data-target="cta">
                                    <i class="bi bi-clipboard"></i> Copy
                                </button>
                            </div>
                            <div class="blog-cta" id="blogCta"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php include '../includes/footer.php'; ?>
    </div>
</div>

<script src="../../assets/js/blog-generator.js"></script>
<?php include '../includes/footer.php'; ?>
