<?php
require_once '../../config/init.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'Canonical URL Checker';
include '../includes/header.php';
?>

<div class="dashboard-wrapper">
    <?php include '../includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../includes/navbar.php'; ?>
        
        <div class="dashboard-content">
            <!-- Page Header -->
            <div class="page-header">
                <h1 class="page-title">
                    <i class="bi bi-link-45deg"></i> Canonical URL Checker
                </h1>
                <p class="page-subtitle">Find missing canonical URLs and get AI-powered recommendations</p>
            </div>
            
            <!-- Input Section -->
            <div class="row mb-4">
                <div class="col-lg-8 mx-auto">
                    <div class="card glass-card">
                        <div class="card-body p-4">
                            <h3 class="mb-3">
                                <i class="bi bi-globe2 text-primary me-2"></i>
                                Enter Website URLs to Check
                            </h3>
                            
                            <form id="canonicalForm">
                                <div class="mb-3">
                                    <label class="form-label">
                                        <i class="bi bi-link me-1"></i> Enter Website URL or Multiple URLs
                                    </label>
                                    <textarea 
                                        class="form-control" 
                                        id="urlInput" 
                                        rows="5" 
                                        placeholder="Enter one URL per line:&#10;https://example.com&#10;https://example.com/about&#10;https://example.com/products"
                                        required
                                    ></textarea>
                                    <small class="text-muted">
                                        <i class="bi bi-info-circle me-1"></i>
                                        Enter one URL per line. You can check multiple pages at once.
                                    </small>
                                </div>
                                
                                <div class="mb-3">
                                    <div class="form-check">
                                        <input 
                                            class="form-check-input" 
                                            type="checkbox" 
                                            id="crawlSitemap" 
                                            value="1"
                                        >
                                        <label class="form-check-label" for="crawlSitemap">
                                            <i class="bi bi-diagram-3 me-1"></i>
                                            Auto-discover URLs from sitemap.xml (if available)
                                        </label>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">
                                        <i class="bi bi-robot me-1"></i> AI Analysis Level
                                    </label>
                                    <select class="form-select" id="aiLevel">
                                        <option value="basic">Basic - Check canonical tags only</option>
                                        <option value="standard" selected>Standard - Check + AI recommendations</option>
                                        <option value="advanced">Advanced - Deep analysis with SEO insights</option>
                                    </select>
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-lg w-100" id="checkBtn">
                                    <i class="bi bi-search me-2"></i>
                                    Check Canonical URLs
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Loading Section -->
            <div class="row mb-4" id="loadingSection" style="display: none;">
                <div class="col-lg-8 mx-auto">
                    <div class="card glass-card text-center">
                        <div class="card-body p-5">
                            <div class="spinner-border text-primary mb-3" style="width: 3rem; height: 3rem;" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <h4 id="loadingText">Analyzing URLs...</h4>
                            <p class="text-muted mb-0" id="loadingSubtext">This may take a few moments</p>
                            <div class="progress mt-3" style="height: 8px;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                     role="progressbar" 
                                     id="progressBar" 
                                     style="width: 0%">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Results Section -->
            <div id="resultsSection" style="display: none;">
                <!-- Summary Cards -->
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card glass-card">
                            <div class="stat-icon green">
                                <i class="bi bi-check-circle"></i>
                            </div>
                            <div class="stat-value" id="totalChecked">0</div>
                            <div class="stat-label">URLs Checked</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card glass-card">
                            <div class="stat-icon orange">
                                <i class="bi bi-exclamation-triangle"></i>
                            </div>
                            <div class="stat-value" id="missingCanonical">0</div>
                            <div class="stat-label">Missing Canonical</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card glass-card">
                            <div class="stat-icon blue">
                                <i class="bi bi-check2-square"></i>
                            </div>
                            <div class="stat-value" id="hasCanonical">0</div>
                            <div class="stat-label">Has Canonical</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card glass-card">
                            <div class="stat-icon purple">
                                <i class="bi bi-exclamation-circle"></i>
                            </div>
                            <div class="stat-value" id="incorrectCanonical">0</div>
                            <div class="stat-label">Incorrect Canonical</div>
                        </div>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="btn-group" role="group">
                            <button class="btn btn-outline-primary" id="downloadReportBtn">
                                <i class="bi bi-download me-2"></i>Download Report
                            </button>
                            <button class="btn btn-outline-success" id="exportCSVBtn">
                                <i class="bi bi-file-earmark-spreadsheet me-2"></i>Export CSV
                            </button>
                            <button class="btn btn-outline-info" id="generateFixesBtn">
                                <i class="bi bi-magic me-2"></i>Generate Fix Code
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Results Table -->
                <div class="row">
                    <div class="col-12">
                        <div class="card chart-card">
                            <div class="chart-header">
                                <h3 class="chart-title">
                                    <i class="bi bi-list-check me-2"></i>
                                    Canonical URL Analysis Results
                                </h3>
                                <div>
                                    <button class="btn btn-sm btn-outline-secondary" id="filterAll">All</button>
                                    <button class="btn btn-sm btn-outline-warning" id="filterMissing">Missing</button>
                                    <button class="btn btn-sm btn-outline-danger" id="filterIncorrect">Incorrect</button>
                                    <button class="btn btn-sm btn-outline-success" id="filterCorrect">Correct</button>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover" id="resultsTable">
                                    <thead>
                                        <tr>
                                            <th>URL</th>
                                            <th>Status</th>
                                            <th>Current Canonical</th>
                                            <th>AI Recommendation</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="resultsTableBody">
                                        <!-- Results will be populated here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- AI Insights Section -->
                <div class="row mt-4" id="aiInsightsSection" style="display: none;">
                    <div class="col-12">
                        <div class="card chart-card">
                            <div class="chart-header">
                                <h3 class="chart-title">
                                    <i class="bi bi-lightbulb text-warning me-2"></i>
                                    AI-Powered SEO Insights
                                </h3>
                            </div>
                            <div class="card-body">
                                <div id="aiInsightsContent"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        
        <footer class="footer">
            <p class="footer-text text-center">
                &copy; <?php echo date('Y'); ?> Aurify AI SEO Automation. All rights reserved.
            </p>
        </footer>
    </div>
</div>

<!-- Modal for detailed view -->
<div class="modal fade" id="detailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-info-circle me-2"></i>
                    Canonical URL Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalBody">
                <!-- Details will be populated here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="copyFixCode">
                    <i class="bi bi-clipboard me-2"></i>Copy Fix Code
                </button>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo SITE_URL; ?>/assets/js/canonical-checker.js"></script>

<?php include '../includes/footer.php'; ?>
