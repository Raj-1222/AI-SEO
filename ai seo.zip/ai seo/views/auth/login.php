<?php
require_once '../../config/init.php';
require_once '../../controllers/AuthController.php';

$auth = new AuthController();
$auth->checkRememberMe();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard/index.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = $auth->handleLogin();
    if ($result['success']) {
        header('Location: ../dashboard/index.php');
        exit();
    } else {
        $error = $result['message'];
    }
}

if (isset($_GET['timeout'])) {
    $error = 'Session expired. Please login again.';
}

$page_title = 'Login';
include '../includes/header.php';
?>

<div class="auth-container">
    <div class="auth-card glass-card">
        <div class="auth-logo">
            <h1><i class="bi bi-lightning-charge-fill"></i> Aurify AI</h1>
            <p>SEO Automation Platform</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['registered'])): ?>
            <div class="alert alert-success" role="alert">
                <i class="bi bi-check-circle me-2"></i>Registration successful! Please login.
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required placeholder="Enter your email">
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required placeholder="Enter your password">
            </div>
            
            <div class="mb-3 d-flex justify-content-between align-items-center">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="remember" name="remember">
                    <label class="form-check-label" for="remember">
                        Remember me
                    </label>
                </div>
                <a href="forgot_password.php" class="text-decoration-none">Forgot Password?</a>
            </div>
            
            <button type="submit" class="btn btn-primary w-100 mb-3">
                <i class="bi bi-box-arrow-in-right me-2"></i>Login
            </button>
        </form>
        
        <div class="text-center">
            <p class="mb-0">Don't have an account? <a href="register.php" class="fw-semibold">Register</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
