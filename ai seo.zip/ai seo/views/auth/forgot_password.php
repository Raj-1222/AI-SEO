<?php
require_once '../../config/init.php';
require_once '../../controllers/AuthController.php';

$auth = new AuthController();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard/index.php');
    exit();
}

$error = '';
$success = '';
$reset_link = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = $auth->handleForgotPassword();
    if ($result['success']) {
        $success = $result['message'];
        $reset_link = $result['reset_link'];
    } else {
        $error = $result['message'];
    }
}

$page_title = 'Forgot Password';
include '../includes/header.php';
?>

<div class="auth-container">
    <div class="auth-card glass-card">
        <div class="auth-logo">
            <h1><i class="bi bi-lightning-charge-fill"></i> Aurify AI</h1>
            <p>Reset your password</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success" role="alert">
                <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
                <?php if ($reset_link): ?>
                    <hr>
                    <small>Reset Link: <a href="<?php echo $reset_link; ?>"><?php echo $reset_link; ?></a></small>
                    <br><small class="text-muted">In production, this link will be sent via email.</small>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="email" name="email" required placeholder="Enter your email">
                    <small class="text-muted">We'll send you a password reset link</small>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 mb-3">
                    <i class="bi bi-envelope me-2"></i>Send Reset Link
                </button>
            </form>
        <?php endif; ?>
        
        <div class="text-center">
            <p class="mb-0">Remember your password? <a href="login.php" class="fw-semibold">Login</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
