<?php
require_once '../../config/init.php';
require_once '../../controllers/AuthController.php';

$auth = new AuthController();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard/index.php');
    exit();
}

$token = isset($_GET['token']) ? $_GET['token'] : '';
$email = isset($_GET['email']) ? $_GET['email'] : '';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_POST['token'] = $token;
    $_POST['email'] = $email;
    
    $result = $auth->handleResetPassword();
    if ($result['success']) {
        $success = $result['message'];
    } else {
        $error = $result['message'];
    }
}

$page_title = 'Reset Password';
include '../includes/header.php';
?>

<div class="auth-container">
    <div class="auth-card glass-card">
        <div class="auth-logo">
            <h1><i class="bi bi-lightning-charge-fill"></i> Aurify AI</h1>
            <p>Create new password</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success" role="alert">
                <i class="bi bi-check-circle me-2"></i><?php echo $success; ?>
            </div>
            <div class="text-center">
                <a href="login.php" class="btn btn-primary">
                    <i class="bi bi-box-arrow-in-right me-2"></i>Login Now
                </a>
            </div>
        <?php else: ?>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="password" class="form-label">New Password</label>
                    <input type="password" class="form-control" id="password" name="password" required placeholder="Enter new password (min. 6 characters)">
                </div>
                
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Confirm new password">
                </div>
                
                <button type="submit" class="btn btn-primary w-100 mb-3">
                    <i class="bi bi-shield-check me-2"></i>Reset Password
                </button>
            </form>
        <?php endif; ?>
        
        <div class="text-center">
            <p class="mb-0">Remember your password? <a href="login.php" class="fw-semibold">Login</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
