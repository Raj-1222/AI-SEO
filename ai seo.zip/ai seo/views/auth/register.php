<?php
require_once '../../config/init.php';
require_once '../../controllers/AuthController.php';

$auth = new AuthController();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../dashboard/index.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = $auth->handleRegister();
    if ($result['success']) {
        header('Location: login.php?registered=1');
        exit();
    } else {
        $error = $result['message'];
    }
}

$page_title = 'Register';
include '../includes/header.php';
?>

<div class="auth-container">
    <div class="auth-card glass-card">
        <div class="auth-logo">
            <h1><i class="bi bi-lightning-charge-fill"></i> Aurify AI</h1>
            <p>Create your account</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-circle me-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" required placeholder="Enter your full name">
            </div>
            
            <div class="mb-3">
                <label for="email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required placeholder="Enter your email">
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required placeholder="Create a password (min. 6 characters)">
            </div>
            
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Confirm your password">
            </div>
            
            <button type="submit" class="btn btn-primary w-100 mb-3">
                <i class="bi bi-person-plus me-2"></i>Create Account
            </button>
        </form>
        
        <div class="text-center">
            <p class="mb-0">Already have an account? <a href="login.php" class="fw-semibold">Login</a></p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
