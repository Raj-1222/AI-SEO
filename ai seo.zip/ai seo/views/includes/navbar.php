<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container-fluid">
        <button class="btn btn-link" id="sidebarToggle">
            <i class="bi bi-list fs-4 text-secondary"></i>
        </button>
        
        <div class="ms-auto user-menu">
            <div class="dropdown">
                <a class="d-flex align-items-center text-decoration-none dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="user-avatar me-2">
                        <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
                    </div>
                    <div class="d-none d-md-block">
                        <div class="fw-semibold" style="color: var(--secondary-color);">
                            <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </div>
                        <small class="text-muted"><?php echo htmlspecialchars($_SESSION['user_role']); ?></small>
                    </div>
                </a>
                
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/views/dashboard/profile.php">
                        <i class="bi bi-person me-2"></i> Profile
                    </a></li>
                    <li><a class="dropdown-item" href="<?php echo SITE_URL; ?>/views/dashboard/settings.php">
                        <i class="bi bi-gear me-2"></i> Settings
                    </a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="<?php echo SITE_URL; ?>/controllers/logout.php">
                        <i class="bi bi-box-arrow-right me-2"></i> Logout
                    </a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
