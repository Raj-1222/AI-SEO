<?php
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<div class="sidebar">
    <div class="sidebar-header">
        <a href="<?php echo SITE_URL; ?>/views/dashboard/index.php" class="sidebar-brand">
            <i class="bi bi-lightning-charge-fill"></i> Aurify AI
        </a>
    </div>
    
    <div class="sidebar-menu">
        <a href="<?php echo SITE_URL; ?>/views/dashboard/index.php" class="menu-item <?php echo $current_page === 'index' ? 'active' : ''; ?>">
            <i class="bi bi-speedometer2"></i>
            <span>Dashboard</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/website-audit.php" class="menu-item <?php echo $current_page === 'website-audit' ? 'active' : ''; ?>">
            <i class="bi bi-search"></i>
            <span>Website Audit</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/reports.php" class="menu-item <?php echo $current_page === 'reports' ? 'active' : ''; ?>">
            <i class="bi bi-file-earmark-text"></i>
            <span>Reports</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/competitor-seo.php" class="menu-item <?php echo $current_page === 'competitor-seo' ? 'active' : ''; ?>">
            <i class="bi bi-trophy"></i>
            <span>Competitor SEO</span>
            <span class="badge bg-warning ms-2">New</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/keywords.php" class="menu-item <?php echo $current_page === 'keywords' ? 'active' : ''; ?>">
            <i class="bi bi-key"></i>
            <span>Keywords</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/meta-generator.php" class="menu-item <?php echo $current_page === 'meta-generator' ? 'active' : ''; ?>">
            <i class="bi bi-pen"></i>
            <span>Meta Generator</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/blog-generator.php" class="menu-item <?php echo $current_page === 'blog-generator' ? 'active' : ''; ?>">
            <i class="bi bi-file-text"></i>
            <span>Blog Generator</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/schema-generator.php" class="menu-item <?php echo $current_page === 'schema-generator' ? 'active' : ''; ?>">
            <i class="bi bi-code-square"></i>
            <span>Schema Generator</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/image-optimizer.php" class="menu-item <?php echo $current_page === 'image-optimizer' ? 'active' : ''; ?>">
            <i class="bi bi-images"></i>
            <span>Image Optimizer</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/canonical-checker.php" class="menu-item <?php echo $current_page === 'canonical-checker' ? 'active' : ''; ?>">
            <i class="bi bi-link-45deg"></i>
            <span>Canonical Checker</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/seo-tools.php" class="menu-item <?php echo $current_page === 'seo-tools' ? 'active' : ''; ?>">
            <i class="bi bi-tools"></i>
            <span>SEO Tools</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/analytics.php" class="menu-item <?php echo $current_page === 'analytics' ? 'active' : ''; ?>">
            <i class="bi bi-bar-chart"></i>
            <span>Analytics</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/settings.php" class="menu-item <?php echo $current_page === 'settings' ? 'active' : ''; ?>">
            <i class="bi bi-gear"></i>
            <span>Settings</span>
        </a>
        
        <a href="<?php echo SITE_URL; ?>/views/dashboard/history.php" class="menu-item <?php echo $current_page === 'history' ? 'active' : ''; ?>">
            <i class="bi bi-clock-history"></i>
            <span>History</span>
        </a>
        
        <hr style="border-color: rgba(255,255,255,0.1); margin: 20px;">
        
        <a href="<?php echo SITE_URL; ?>/controllers/logout.php" class="menu-item">
            <i class="bi bi-box-arrow-right"></i>
            <span>Logout</span>
        </a>
    </div>
</div>
