<?php
require_once 'config/init.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 2; // Auto-login for testing
}

$page_title = 'Website Audit - Simple Test';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .test-container {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 50px rgba(0,0,0,0.3);
        }
        .alert-info {
            background: #d1ecf1;
            border: 2px solid #0c5460;
        }
        .seo-score-circle {
            width: 200px;
            height: 200px;
            margin: 20px auto;
            position: relative;
        }
        .seo-score-circle svg {
            transform: rotate(-90deg);
        }
        .score-value {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 3rem;
            font-weight: bold;
            color: #667eea;
        }
    </style>
</head>
<body>
    <div class="test-container">
        <h1 class="text-center mb-4">🔧 Simple Audit Test</h1>
        
        <div class="alert alert-info">
            <h5>📝 What This Tests:</h5>
            <ul>
                <li>Basic API connectivity</li>
                <li>JSON response handling</li>
                <li>Session management</li>
                <li>Front-end JavaScript</li>
            </ul>
            <p class="mb-0"><strong>This uses a simplified API that doesn't touch the database or complex logic.</strong></p>
        </div>
        
        <!-- Audit Form Section -->
        <div id="auditFormSection">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Launch Simple Audit</h5>
                    <form id="auditForm">
                        <div class="mb-3">
                            <label for="website_url" class="form-label">Website URL</label>
                            <input 
                                type="url" 
                                class="form-control" 
                                id="website_url" 
                                placeholder="https://example.com" 
                                value="https://webcolom.netlify.app/"
                                required
                            >
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-rocket-takeoff me-2"></i>Test Simple Audit
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Loading Section -->
        <div id="loadingSection" style="display: none;">
            <div class="card">
                <div class="card-body text-center py-5">
                    <div class="spinner-border text-primary mb-3" style="width: 3rem; height: 3rem;"></div>
                    <h4>Testing Simple API...</h4>
                    <p class="text-muted">This should be instant</p>
                    <p><strong>Check browser console (F12) for detailed logs</strong></p>
                </div>
            </div>
        </div>
        
        <!-- Results Section -->
        <div id="resultsSection" style="display: none;">
            <div class="alert alert-success">
                <h5>✅ Success!</h5>
                <p class="mb-0">The simple API works! JSON response received successfully.</p>
            </div>
            
            <div class="card mb-4">
                <div class="card-body text-center">
                    <div class="seo-score-circle">
                        <svg viewBox="0 0 200 200">
                            <circle cx="100" cy="100" r="90" fill="none" stroke="#f0f0f0" stroke-width="12"/>
                            <circle cx="100" cy="100" r="90" fill="none" stroke="#667eea" stroke-width="12" 
                                    id="scoreCircle" stroke-dasharray="565" stroke-dashoffset="565"
                                    transform="rotate(-90 100 100)"/>
                        </svg>
                        <div class="score-value" id="seoScoreValue">0</div>
                    </div>
                    <h5 class="mt-3">SEO Score (Test Data)</h5>
                    <p class="text-muted mb-0" id="scoreLabel">Test Mode</p>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Website Information (Test Data)</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <strong>Title:</strong> <span id="websiteTitle">-</span>
                        </div>
                        <div class="col-md-6">
                            <strong>SSL Status:</strong> <span id="sslStatus">-</span>
                        </div>
                        <div class="col-md-6">
                            <strong>Language:</strong> <span id="websiteLanguage">-</span>
                        </div>
                        <div class="col-md-6">
                            <strong>Response Time:</strong> <span id="responseTime">-</span>
                        </div>
                        <div class="col-md-6">
                            <strong>CMS:</strong> <span id="cmsDetected">-</span>
                        </div>
                        <div class="col-md-6">
                            <strong>Server:</strong> <span id="serverInfo">-</span>
                        </div>
                        <div class="col-md-6">
                            <strong>IP:</strong> <span id="ipAddress">-</span>
                        </div>
                        <div class="col-md-6">
                            <strong>Country:</strong> <span id="country">-</span>
                        </div>
                        <div class="col-12">
                            <strong>Description:</strong> <span id="metaDescription">-</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="alert alert-warning">
                <h5>⚠️ Next Steps:</h5>
                <p>This simple test proves your server CAN return JSON successfully.</p>
                <p class="mb-0"><strong>To use full features, upload the fixed files to your server.</strong></p>
            </div>
            
            <button class="btn btn-primary" onclick="location.reload()">
                <i class="bi bi-arrow-clockwise"></i> Test Again
            </button>
        </div>
    </div>
    
    <script src="assets/js/audit-simple.js?v=<?php echo time(); ?>"></script>
</body>
</html>
