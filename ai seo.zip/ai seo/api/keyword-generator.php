<?php
// Suppress all error output first
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Include config (which starts session)
require_once '../config/init.php';
require_once '../controllers/KeywordGeneratorController.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    error_log("KEYWORD API: No session user_id found");
    error_log("KEYWORD API: Session data: " . print_r($_SESSION, true));
    echo json_encode(['success' => false, 'message' => 'Unauthorized - Please login', 'debug' => 'No session']);
    exit();
}

// Log for debugging
error_log("KEYWORD API: Called by user: " . $_SESSION['user_id']);
error_log("KEYWORD API: Request method: " . $_SERVER['REQUEST_METHOD']);

$controller = new KeywordGeneratorController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $rawInput = file_get_contents('php://input');
    error_log("KEYWORD API: Raw input: " . $rawInput);
    
    $input = json_decode($rawInput, true);
    error_log("KEYWORD API: Decoded input: " . print_r($input, true));
    
    $action = $input['action'] ?? 'generate';
    
    if ($action === 'generate') {
        $websiteUrl = $input['website_url'] ?? '';
        $industry = $input['industry'] ?? '';
        $location = $input['location'] ?? '';
        
        error_log("KEYWORD API: Params - URL: $websiteUrl, Industry: $industry, Location: $location");
        
        if (empty($websiteUrl) || empty($industry)) {
            error_log("KEYWORD API: Missing parameters");
            echo json_encode(['success' => false, 'message' => 'Website URL and Industry are required']);
            exit();
        }
        
        error_log("KEYWORD API: Calling controller->generateKeywords()");
        
        // Call controller
        $result = $controller->generateKeywords($websiteUrl, $industry, $location);
        
        // Log result for debugging
        error_log("KEYWORD API: Result success=" . ($result['success'] ? 'true' : 'false'));
        if (!$result['success']) {
            error_log("KEYWORD API: Error message: " . ($result['message'] ?? 'unknown'));
        }
        error_log("KEYWORD API: Full result: " . json_encode($result));
        
        echo json_encode($result);
        
    } elseif ($action === 'save') {
        $websiteUrl = $input['website_url'] ?? '';
        $industry = $input['industry'] ?? '';
        $location = $input['location'] ?? '';
        $keywordsData = $input['keywords_data'] ?? [];
        
        $result = $controller->saveKeywords($websiteUrl, $industry, $location, $keywordsData, $_SESSION['user_id']);
        echo json_encode($result);
    }
    
} elseif ($method === 'GET') {
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
    $keywords = $controller->getSavedKeywords($_SESSION['user_id'], $limit);
    echo json_encode(['success' => true, 'keywords' => $keywords]);
}
