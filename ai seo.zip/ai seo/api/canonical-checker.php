<?php
/**
 * Canonical URL Checker API
 * Analyzes websites for missing or incorrect canonical URLs
 * Uses OpenAI for intelligent recommendations
 */

header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../error_canonical_checker.log');

require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../controllers/OpenAIController.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];

// Get request data
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['urls'])) {
    echo json_encode([
        'success' => false,
        'message' => 'No URLs provided'
    ]);
    exit();
}

$urls = $input['urls'];
$crawl_sitemap = $input['crawl_sitemap'] ?? false;
$ai_level = $input['ai_level'] ?? 'standard';

try {
    // If crawl sitemap is enabled, discover more URLs
    if ($crawl_sitemap && !empty($urls)) {
        $discovered_urls = discoverURLsFromSitemap($urls[0]);
        if (!empty($discovered_urls)) {
            $urls = array_unique(array_merge($urls, $discovered_urls));
        }
    }
    
    $results = [];
    $summary = [
        'total' => count($urls),
        'missing' => 0,
        'has_canonical' => 0,
        'incorrect' => 0,
        'correct' => 0
    ];
    
    // Check each URL
    foreach ($urls as $url) {
        $result = checkCanonicalURL($url, $ai_level);
        $results[] = $result;
        
        // Update summary
        if ($result['status'] === 'missing') {
            $summary['missing']++;
        } elseif ($result['status'] === 'incorrect') {
            $summary['incorrect']++;
        } elseif ($result['status'] === 'correct') {
            $summary['correct']++;
            $summary['has_canonical']++;
        } elseif ($result['status'] === 'self') {
            $summary['has_canonical']++;
            $summary['correct']++;
        }
    }
    
    // Get AI insights if advanced level
    $ai_insights = [];
    if ($ai_level === 'advanced') {
        $ai_insights = generateAIInsights($results, $summary);
    }
    
    // Save to database
    saveCanonicalCheck($user_id, $urls, $results, $summary);
    
    echo json_encode([
        'success' => true,
        'summary' => $summary,
        'results' => $results,
        'ai_insights' => $ai_insights
    ]);
    
} catch (Exception $e) {
    error_log("Canonical Checker Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}


/**
 * Check canonical URL for a single page
 */
function checkCanonicalURL($url, $ai_level) {
    $result = [
        'url' => $url,
        'canonical' => null,
        'status' => 'unknown',
        'ai_recommendation' => null,
        'fix_code' => null,
        'seo_impact' => null,
        'issues' => []
    ];
    
    try {
        // Fetch the page
        $html = fetchURL($url);
        
        if (!$html) {
            $result['status'] = 'error';
            $result['issues'][] = 'Failed to fetch URL';
            return $result;
        }
        
        // Parse HTML
        $dom = new DOMDocument();
        @$dom->loadHTML($html);
        $xpath = new DOMXPath($dom);
        
        // Find canonical link
        $canonicalNodes = $xpath->query('//link[@rel="canonical"]');
        
        if ($canonicalNodes->length === 0) {
            $result['status'] = 'missing';
            $result['issues'][] = 'No canonical tag found';
        } else {
            $canonicalUrl = $canonicalNodes->item(0)->getAttribute('href');
            $result['canonical'] = $canonicalUrl;
            
            // Normalize URLs for comparison
            $normalizedPageUrl = normalizeURL($url);
            $normalizedCanonical = normalizeURL($canonicalUrl);
            
            if ($normalizedPageUrl === $normalizedCanonical) {
                $result['status'] = 'self';
            } elseif (isValidCanonical($url, $canonicalUrl)) {
                $result['status'] = 'correct';
            } else {
                $result['status'] = 'incorrect';
                $result['issues'][] = 'Canonical URL does not match page URL';
            }
            
            // Check for multiple canonical tags
            if ($canonicalNodes->length > 1) {
                $result['issues'][] = 'Multiple canonical tags found (only first one is used)';
            }
        }
        
        // Get AI recommendation if needed
        if ($ai_level !== 'basic' && ($result['status'] === 'missing' || $result['status'] === 'incorrect')) {
            $aiRecommendation = getAIRecommendation($url, $result, $ai_level);
            $result['ai_recommendation'] = $aiRecommendation['recommendation'];
            $result['fix_code'] = $aiRecommendation['fix_code'];
            $result['seo_impact'] = $aiRecommendation['seo_impact'];
        } else {
            // Generate basic recommendation
            $result['ai_recommendation'] = $url;
            $result['fix_code'] = '<link rel="canonical" href="' . htmlspecialchars($url) . '" />';
        }
        
    } catch (Exception $e) {
        error_log("Error checking URL $url: " . $e->getMessage());
        $result['status'] = 'error';
        $result['issues'][] = $e->getMessage();
    }
    
    return $result;
}

/**
 * Fetch URL content
 */
function fetchURL($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => 'Aurify-AI-SEO-Bot/1.0'
    ]);
    
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        return false;
    }
    
    return $html;
}

/**
 * Normalize URL for comparison
 */
function normalizeURL($url) {
    $url = strtolower(trim($url));
    $url = rtrim($url, '/');
    
    // Remove common parameters
    $url = preg_replace('/[?&](utm_[^&]+|fbclid=[^&]+|gclid=[^&]+)/', '', $url);
    
    // Ensure https
    if (strpos($url, 'http://') === 0) {
        $url = str_replace('http://', 'https://', $url);
    }
    
    return $url;
}

/**
 * Check if canonical is valid
 */
function isValidCanonical($pageUrl, $canonicalUrl) {
    // Basic validation
    if (empty($canonicalUrl)) {
        return false;
    }
    
    // Must be absolute URL
    if (!filter_var($canonicalUrl, FILTER_VALIDATE_URL)) {
        return false;
    }
    
    // Should be from same domain (usually)
    $pageDomain = parse_url($pageUrl, PHP_URL_HOST);
    $canonicalDomain = parse_url($canonicalUrl, PHP_URL_HOST);
    
    // Allow subdomains
    return true; // For now, accept any valid URL
}


/**
 * Get AI recommendation using OpenAI
 */
function getAIRecommendation($url, $result, $ai_level) {
    try {
        $openai = new OpenAIController();
        
        $prompt = "You are an SEO expert. Analyze this canonical URL situation:\n\n";
        $prompt .= "Page URL: $url\n";
        $prompt .= "Current Status: {$result['status']}\n";
        if ($result['canonical']) {
            $prompt .= "Current Canonical: {$result['canonical']}\n";
        }
        if (!empty($result['issues'])) {
            $prompt .= "Issues: " . implode(', ', $result['issues']) . "\n";
        }
        
        if ($ai_level === 'advanced') {
            $prompt .= "\nProvide:\n";
            $prompt .= "1. The correct canonical URL\n";
            $prompt .= "2. SEO impact explanation (2-3 sentences)\n";
            $prompt .= "3. Why this canonical is recommended\n";
            $prompt .= "\nFormat your response as JSON with keys: canonical_url, seo_impact, explanation";
        } else {
            $prompt .= "\nProvide the correct canonical URL and a brief explanation (1-2 sentences).";
            $prompt .= "\nFormat: {\"canonical_url\": \"...\", \"explanation\": \"...\"}";
        }
        
        $aiResponse = $openai->chat($prompt, [
            'temperature' => 0.3,
            'max_tokens' => 500
        ]);
        
        // Parse AI response
        $aiData = json_decode($aiResponse, true);
        
        if ($aiData && isset($aiData['canonical_url'])) {
            return [
                'recommendation' => $aiData['canonical_url'],
                'fix_code' => '<link rel="canonical" href="' . htmlspecialchars($aiData['canonical_url']) . '" />',
                'seo_impact' => $aiData['seo_impact'] ?? $aiData['explanation'] ?? 'Proper canonical tags prevent duplicate content issues and consolidate ranking signals.'
            ];
        }
        
    } catch (Exception $e) {
        error_log("AI Recommendation Error: " . $e->getMessage());
    }
    
    // Fallback to basic recommendation
    return [
        'recommendation' => $url,
        'fix_code' => '<link rel="canonical" href="' . htmlspecialchars($url) . '" />',
        'seo_impact' => 'This canonical tag will help search engines understand the preferred version of this page.'
    ];
}

/**
 * Generate overall AI insights
 */
function generateAIInsights($results, $summary) {
    $insights = [];
    
    try {
        $openai = new OpenAIController();
        
        $missingCount = $summary['missing'];
        $incorrectCount = $summary['incorrect'];
        $totalCount = $summary['total'];
        
        $prompt = "As an SEO expert, analyze this canonical URL audit:\n\n";
        $prompt .= "Total URLs checked: $totalCount\n";
        $prompt .= "Missing canonical tags: $missingCount\n";
        $prompt .= "Incorrect canonical tags: $incorrectCount\n";
        $prompt .= "Correct canonical tags: {$summary['correct']}\n\n";
        $prompt .= "Provide 3-4 key insights and recommendations for improving the site's canonical implementation.\n";
        $prompt .= "Format each insight as: {\"type\": \"warning|info|success\", \"title\": \"...\", \"message\": \"...\"}";
        $prompt .= "\nReturn as JSON array.";
        
        $aiResponse = $openai->chat($prompt, [
            'temperature' => 0.5,
            'max_tokens' => 800
        ]);
        
        $aiInsights = json_decode($aiResponse, true);
        
        if (is_array($aiInsights)) {
            $insights = $aiInsights;
        }
        
    } catch (Exception $e) {
        error_log("AI Insights Error: " . $e->getMessage());
    }
    
    // Add default insights if AI fails
    if (empty($insights)) {
        if ($summary['missing'] > 0) {
            $insights[] = [
                'type' => 'warning',
                'title' => 'Missing Canonical Tags',
                'message' => "{$summary['missing']} pages are missing canonical tags. This can lead to duplicate content issues."
            ];
        }
        
        if ($summary['incorrect'] > 0) {
            $insights[] = [
                'type' => 'danger',
                'title' => 'Incorrect Canonical Tags',
                'message' => "{$summary['incorrect']} pages have incorrect canonical tags that may confuse search engines."
            ];
        }
        
        if ($summary['correct'] > 0) {
            $insights[] = [
                'type' => 'success',
                'title' => 'Good Progress',
                'message' => "{$summary['correct']} pages have correct canonical implementation. Keep it up!"
            ];
        }
    }
    
    return $insights;
}

/**
 * Discover URLs from sitemap
 */
function discoverURLsFromSitemap($baseUrl) {
    $urls = [];
    
    try {
        $parsedUrl = parse_url($baseUrl);
        $sitemapUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'] . '/sitemap.xml';
        
        $xml = fetchURL($sitemapUrl);
        if ($xml) {
            $dom = new DOMDocument();
            @$dom->loadXML($xml);
            $xpath = new DOMXPath($dom);
            $xpath->registerNamespace('sm', 'http://www.sitemaps.org/schemas/sitemap/0.9');
            
            $urlNodes = $xpath->query('//sm:url/sm:loc');
            foreach ($urlNodes as $node) {
                $urls[] = $node->textContent;
            }
            
            // Limit to 50 URLs to prevent overwhelming
            $urls = array_slice($urls, 0, 50);
        }
    } catch (Exception $e) {
        error_log("Sitemap discovery error: " . $e->getMessage());
    }
    
    return $urls;
}

/**
 * Save canonical check to database
 */
function saveCanonicalCheck($user_id, $urls, $results, $summary) {
    try {
        $conn = getDBConnection();
        
        $stmt = $conn->prepare("
            INSERT INTO canonical_checks 
            (user_id, urls_checked, total_checked, missing_canonical, incorrect_canonical, has_canonical, results_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $urlsJson = json_encode($urls);
        $resultsJson = json_encode($results);
        
        $stmt->bind_param(
            'isiiiis',
            $user_id,
            $urlsJson,
            $summary['total'],
            $summary['missing'],
            $summary['incorrect'],
            $summary['has_canonical'],
            $resultsJson
        );
        
        $stmt->execute();
        $stmt->close();
        $conn->close();
        
    } catch (Exception $e) {
        error_log("Database save error: " . $e->getMessage());
    }
}
