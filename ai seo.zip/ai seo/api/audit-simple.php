<?php
/**
 * SIMPLE AUDIT API - Minimal Version for Testing
 * This bypasses all complex logic to test if basic API calls work
 */

// Absolutely no output before this
ob_start();
ob_clean();

// Set headers FIRST
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// For testing, auto-create session if missing
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 2; // Your user ID from logs
}

// Simple test response
$response = [
    'success' => true,
    'message' => 'Simple audit API working',
    'website_id' => 999,
    'data' => [
        'title' => 'Test Website',
        'description' => 'Test description',
        'keywords' => 'test, keywords',
        'language' => 'en',
        'ssl_enabled' => 1,
        'cms_detected' => 'Unknown',
        'server_info' => 'Test Server',
        'country' => 'USA',
        'ip_address' => '127.0.0.1',
        'response_time' => 100,
        'seo_score' => 75
    ],
    'test' => true,
    'timestamp' => date('Y-m-d H:i:s')
];

// Clean any buffered output and send JSON
ob_clean();
echo json_encode($response);
exit();
