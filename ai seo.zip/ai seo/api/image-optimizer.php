<?php
/**
 * Image Optimizer API
 * Main API endpoint for image optimization operations
 */

// Enable error logging for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../error_image_optimizer.log');

// Set JSON header
header('Content-Type: application/json');

// Try to load dependencies
try {
    require_once __DIR__ . '/../config/init.php';
    require_once __DIR__ . '/../config/image_optimizer_config.php';
    require_once __DIR__ . '/../controllers/ImageProcessorController.php';
    require_once __DIR__ . '/../models/ImageHistory.php';
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to load dependencies: ' . $e->getMessage(),
        'error_type' => 'dependency_error'
    ]);
    exit();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized - User not logged in',
        'error_type' => 'auth_error'
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Log the action for debugging
error_log("Image Optimizer API - Action: $action, User: $user_id");

// Initialize components with error handling
try {
    $processor = new ImageProcessorController();
    $db = getDBConnection();
    $history = new ImageHistory($db);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to initialize: ' . $e->getMessage(),
        'error_type' => 'initialization_error'
    ]);
    error_log("Image Optimizer API - Initialization Error: " . $e->getMessage());
    exit();
}

try {
    switch ($action) {
        case 'upload':
            handleUpload($user_id, $processor, $history);
            break;
            
        case 'compress':
            handleCompress($user_id, $processor, $history);
            break;
            
        case 'resize':
            handleResize($user_id, $processor, $history);
            break;
            
        case 'convert':
            handleConvert($user_id, $processor, $history);
            break;
            
        case 'watermark':
            handleWatermark($user_id, $processor, $history);
            break;
            
        case 'rotate':
            handleRotate($user_id, $processor, $history);
            break;
            
        case 'flip':
            handleFlip($user_id, $processor, $history);
            break;
            
        case 'crop':
            handleCrop($user_id, $processor, $history);
            break;
            
        case 'metadata':
            handleMetadata($processor);
            break;
            
        case 'download':
            handleDownload($history);
            break;
            
        case 'history':
            handleHistory($user_id, $history);
            break;
            
        case 'stats':
            handleStats($user_id, $history);
            break;
            
        case 'delete':
            handleDelete($user_id, $history);
            break;
            
        case 'bulk_delete':
            handleBulkDelete($user_id, $history);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    $errorMsg = $e->getMessage();
    $errorTrace = $e->getTraceAsString();
    
    error_log("Image Optimizer API Error - Action: $action, Message: $errorMsg");
    error_log("Stack Trace: $errorTrace");
    
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $errorMsg,
        'error_type' => 'exception',
        'action' => $action,
        'trace' => IMG_DEBUG_MODE ? $errorTrace : null
    ]);
}

/**
 * Handle file upload
 */
function handleUpload($user_id, $processor, $history) {
    error_log("Upload handler called for user: $user_id");
    
    if (!isset($_FILES['image'])) {
        error_log("Upload error: No file uploaded");
        echo json_encode(['success' => false, 'message' => 'No file uploaded', 'error_type' => 'no_file']);
        return;
    }
    
    $file = $_FILES['image'];
    error_log("File received: " . $file['name'] . ", Size: " . $file['size'] . ", Type: " . $file['type'] . ", Error: " . $file['error']);
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $uploadErrors = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize in php.ini',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE in HTML form',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
        ];
        $errorMsg = $uploadErrors[$file['error']] ?? 'Unknown upload error';
        error_log("Upload error code {$file['error']}: $errorMsg");
        echo json_encode(['success' => false, 'message' => $errorMsg, 'error_type' => 'upload_error']);
        return;
    }
    
    // Validate file
    $errors = validateImageFile($file);
    if (!empty($errors)) {
        error_log("Validation errors: " . implode(', ', $errors));
        echo json_encode(['success' => false, 'message' => implode(', ', $errors), 'error_type' => 'validation_error']);
        return;
    }
    
    // Generate secure filename
    $originalName = $file['name'];
    $secureFilename = generateSecureFilename($originalName, 'img_');
    
    // Move to original directory
    $originalPath = IMG_ORIGINAL_DIR . $secureFilename;
    error_log("Moving file to: $originalPath");
    
    if (!is_writable(IMG_ORIGINAL_DIR)) {
        error_log("Directory not writable: " . IMG_ORIGINAL_DIR);
        echo json_encode(['success' => false, 'message' => 'Upload directory is not writable', 'error_type' => 'permission_error']);
        return;
    }
    
    if (!move_uploaded_file($file['tmp_name'], $originalPath)) {
        error_log("Failed to move uploaded file from {$file['tmp_name']} to $originalPath");
        echo json_encode(['success' => false, 'message' => 'Failed to save uploaded file', 'error_type' => 'move_error']);
        return;
    }
    
    error_log("File uploaded successfully: $originalPath");
    
    // Get image metadata
    try {
        $metadata = $processor->getImageMetadata($originalPath);
        error_log("Metadata extracted: " . json_encode($metadata));
    } catch (Exception $e) {
        error_log("Failed to get metadata: " . $e->getMessage());
        $metadata = [];
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'File uploaded successfully',
        'data' => [
            'filename' => $secureFilename,
            'original_name' => $originalName,
            'path' => $originalPath,
            'metadata' => $metadata
        ]
    ]);
}

/**
 * Handle image compression
 */
function handleCompress($user_id, $processor, $history) {
    error_log("Compress handler called for user: $user_id");
    
    $filename = $_POST['filename'] ?? '';
    $quality = intval($_POST['quality'] ?? IMG_DEFAULT_QUALITY);
    $format = $_POST['format'] ?? null;
    $compressionType = $_POST['compression_type'] ?? 'medium';
    
    error_log("Compress params - Filename: $filename, Quality: $quality, Format: $format, Type: $compressionType");
    
    if (empty($filename)) {
        error_log("Compress error: Filename is empty");
        echo json_encode(['success' => false, 'message' => 'Filename required', 'error_type' => 'missing_param']);
        return;
    }
    
    $sourcePath = IMG_ORIGINAL_DIR . $filename;
    error_log("Source path: $sourcePath");
    
    if (!file_exists($sourcePath)) {
        error_log("Compress error: Source file not found at $sourcePath");
        echo json_encode(['success' => false, 'message' => 'Source file not found', 'error_type' => 'file_not_found', 'path' => $sourcePath]);
        return;
    }
    
    // Generate optimized filename
    $optimizedFilename = 'opt_' . $filename;
    if ($format) {
        $optimizedFilename = pathinfo($optimizedFilename, PATHINFO_FILENAME) . '.' . $format;
    }
    
    $destinationPath = IMG_OPTIMIZED_DIR . $optimizedFilename;
    error_log("Destination path: $destinationPath");
    
    if (!is_writable(IMG_OPTIMIZED_DIR)) {
        error_log("Directory not writable: " . IMG_OPTIMIZED_DIR);
        echo json_encode(['success' => false, 'message' => 'Optimized directory is not writable', 'error_type' => 'permission_error']);
        return;
    }
    
    // Compress image
    try {
        $result = $processor->compressImage($sourcePath, $destinationPath, $quality, $format);
        error_log("Compression result: " . json_encode($result));
    } catch (Exception $e) {
        error_log("Compression exception: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Compression failed: ' . $e->getMessage(), 'error_type' => 'processing_error']);
        return;
    }
    
    if (!$result['success']) {
        error_log("Compression failed: " . ($result['message'] ?? 'Unknown error'));
        echo json_encode($result);
        return;
    }
    
    // Save to history
    try {
        $originalMetadata = $processor->getImageMetadata($sourcePath);
        
        $history->user_id = $user_id;
        $history->original_name = $filename;
        $history->original_path = $sourcePath;
        $history->optimized_name = $optimizedFilename;
        $history->optimized_path = $destinationPath;
        $history->original_size = $result['original_size'];
        $history->optimized_size = $result['optimized_size'];
        $history->compression_ratio = $result['compression_ratio'];
        $history->saved_bytes = $result['saved_bytes'];
        $history->original_format = $originalMetadata['format'];
        $history->optimized_format = $result['format'];
        $history->original_width = $result['width'];
        $history->original_height = $result['height'];
        $history->optimized_width = $result['width'];
        $history->optimized_height = $result['height'];
        $history->quality_used = $quality;
        $history->compression_type = $compressionType;
        $history->operation_type = 'compression';
        $history->processing_time = $result['processing_time'];
        $history->status = 'completed';
        $history->metadata = json_encode($result);
        
        $history->create();
        $history->updateStatistics($user_id);
        
        error_log("History saved with ID: " . $history->id);
    } catch (Exception $e) {
        error_log("Failed to save history: " . $e->getMessage());
        // Don't fail the whole operation if history save fails
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Image compressed successfully',
        'data' => array_merge($result, [
            'optimized_filename' => $optimizedFilename,
            'history_id' => $history->id ?? null
        ])
    ]);
}

/**
 * Handle image resize
 */
function handleResize($user_id, $processor, $history) {
    $filename = $_POST['filename'] ?? '';
    $width = intval($_POST['width'] ?? 0);
    $height = intval($_POST['height'] ?? 0);
    $maintainRatio = $_POST['maintain_ratio'] ?? 'true';
    $maintainRatio = ($maintainRatio === 'true' || $maintainRatio === true);
    $quality = intval($_POST['quality'] ?? IMG_DEFAULT_QUALITY);
    
    if (empty($filename) || $width <= 0 || $height <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
        return;
    }
    
    $sourcePath = IMG_ORIGINAL_DIR . $filename;
    if (!file_exists($sourcePath)) {
        echo json_encode(['success' => false, 'message' => 'Source file not found']);
        return;
    }
    
    $optimizedFilename = 'resized_' . $filename;
    $destinationPath = IMG_OPTIMIZED_DIR . $optimizedFilename;
    
    $result = $processor->resizeImage($sourcePath, $destinationPath, $width, $height, $maintainRatio, $quality);
    
    if (!$result['success']) {
        echo json_encode($result);
        return;
    }
    
    // Save to history
    $originalMetadata = $processor->getImageMetadata($sourcePath);
    
    $history->user_id = $user_id;
    $history->original_name = $filename;
    $history->original_path = $sourcePath;
    $history->optimized_name = $optimizedFilename;
    $history->optimized_path = $destinationPath;
    $history->original_size = $result['original_size'];
    $history->optimized_size = $result['optimized_size'];
    $history->compression_ratio = $result['compression_ratio'];
    $history->saved_bytes = $result['saved_bytes'];
    $history->original_format = $originalMetadata['format'];
    $history->optimized_format = $originalMetadata['format'];
    $history->original_width = $result['original_width'];
    $history->original_height = $result['original_height'];
    $history->optimized_width = $result['new_width'];
    $history->optimized_height = $result['new_height'];
    $history->quality_used = $quality;
    $history->operation_type = 'resize';
    $history->status = 'completed';
    $history->metadata = json_encode($result);
    
    $history->create();
    $history->updateStatistics($user_id);
    
    echo json_encode([
        'success' => true,
        'message' => 'Image resized successfully',
        'data' => array_merge($result, [
            'optimized_filename' => $optimizedFilename,
            'history_id' => $history->id
        ])
    ]);
}

/**
 * Handle format conversion
 */
function handleConvert($user_id, $processor, $history) {
    $filename = $_POST['filename'] ?? '';
    $format = $_POST['format'] ?? '';
    $quality = intval($_POST['quality'] ?? IMG_DEFAULT_QUALITY);
    
    if (empty($filename) || empty($format)) {
        echo json_encode(['success' => false, 'message' => 'Filename and format required']);
        return;
    }
    
    $sourcePath = IMG_ORIGINAL_DIR . $filename;
    if (!file_exists($sourcePath)) {
        echo json_encode(['success' => false, 'message' => 'Source file not found']);
        return;
    }
    
    $optimizedFilename = pathinfo($filename, PATHINFO_FILENAME) . '_converted.' . $format;
    $destinationPath = IMG_OPTIMIZED_DIR . $optimizedFilename;
    
    $result = $processor->compressImage($sourcePath, $destinationPath, $quality, $format);
    
    if (!$result['success']) {
        echo json_encode($result);
        return;
    }
    
    // Save to history
    $originalMetadata = $processor->getImageMetadata($sourcePath);
    
    $history->user_id = $user_id;
    $history->original_name = $filename;
    $history->original_path = $sourcePath;
    $history->optimized_name = $optimizedFilename;
    $history->optimized_path = $destinationPath;
    $history->original_size = $result['original_size'];
    $history->optimized_size = $result['optimized_size'];
    $history->compression_ratio = $result['compression_ratio'];
    $history->saved_bytes = $result['saved_bytes'];
    $history->original_format = $originalMetadata['format'];
    $history->optimized_format = $format;
    $history->original_width = $result['width'];
    $history->original_height = $result['height'];
    $history->optimized_width = $result['width'];
    $history->optimized_height = $result['height'];
    $history->quality_used = $quality;
    $history->operation_type = 'conversion';
    $history->status = 'completed';
    $history->metadata = json_encode($result);
    
    $history->create();
    $history->updateStatistics($user_id);
    
    echo json_encode([
        'success' => true,
        'message' => 'Image converted successfully',
        'data' => array_merge($result, [
            'optimized_filename' => $optimizedFilename,
            'history_id' => $history->id
        ])
    ]);
}

/**
 * Handle watermark
 */
function handleWatermark($user_id, $processor, $history) {
    $filename = $_POST['filename'] ?? '';
    $text = $_POST['text'] ?? '';
    $position = $_POST['position'] ?? 'bottom-right';
    $opacity = intval($_POST['opacity'] ?? 50);
    $quality = intval($_POST['quality'] ?? IMG_DEFAULT_QUALITY);
    
    if (empty($filename) || empty($text)) {
        echo json_encode(['success' => false, 'message' => 'Filename and text required']);
        return;
    }
    
    $sourcePath = IMG_ORIGINAL_DIR . $filename;
    if (!file_exists($sourcePath)) {
        echo json_encode(['success' => false, 'message' => 'Source file not found']);
        return;
    }
    
    $optimizedFilename = 'wm_' . $filename;
    $destinationPath = IMG_OPTIMIZED_DIR . $optimizedFilename;
    
    $result = $processor->addWatermark($sourcePath, $destinationPath, $text, $position, $opacity, $quality);
    
    if (!$result['success']) {
        echo json_encode($result);
        return;
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Watermark added successfully',
        'data' => [
            'optimized_filename' => $optimizedFilename
        ]
    ]);
}

/**
 * Handle rotate
 */
function handleRotate($user_id, $processor, $history) {
    $filename = $_POST['filename'] ?? '';
    $angle = intval($_POST['angle'] ?? 0);
    $quality = intval($_POST['quality'] ?? IMG_DEFAULT_QUALITY);
    
    if (empty($filename)) {
        echo json_encode(['success' => false, 'message' => 'Filename required']);
        return;
    }
    
    $sourcePath = IMG_ORIGINAL_DIR . $filename;
    $optimizedFilename = 'rotated_' . $filename;
    $destinationPath = IMG_OPTIMIZED_DIR . $optimizedFilename;
    
    $result = $processor->rotateImage($sourcePath, $destinationPath, $angle, $quality);
    
    echo json_encode(array_merge($result, ['optimized_filename' => $optimizedFilename]));
}

/**
 * Handle flip
 */
function handleFlip($user_id, $processor, $history) {
    $filename = $_POST['filename'] ?? '';
    $direction = $_POST['direction'] ?? 'horizontal';
    $quality = intval($_POST['quality'] ?? IMG_DEFAULT_QUALITY);
    
    if (empty($filename)) {
        echo json_encode(['success' => false, 'message' => 'Filename required']);
        return;
    }
    
    $sourcePath = IMG_ORIGINAL_DIR . $filename;
    $optimizedFilename = 'flipped_' . $filename;
    $destinationPath = IMG_OPTIMIZED_DIR . $optimizedFilename;
    
    $result = $processor->flipImage($sourcePath, $destinationPath, $direction, $quality);
    
    echo json_encode(array_merge($result, ['optimized_filename' => $optimizedFilename]));
}

/**
 * Handle crop
 */
function handleCrop($user_id, $processor, $history) {
    $filename = $_POST['filename'] ?? '';
    $x = intval($_POST['x'] ?? 0);
    $y = intval($_POST['y'] ?? 0);
    $width = intval($_POST['width'] ?? 0);
    $height = intval($_POST['height'] ?? 0);
    $quality = intval($_POST['quality'] ?? IMG_DEFAULT_QUALITY);
    
    if (empty($filename) || $width <= 0 || $height <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
        return;
    }
    
    $sourcePath = IMG_ORIGINAL_DIR . $filename;
    $optimizedFilename = 'cropped_' . $filename;
    $destinationPath = IMG_OPTIMIZED_DIR . $optimizedFilename;
    
    $result = $processor->cropImage($sourcePath, $destinationPath, $x, $y, $width, $height, $quality);
    
    echo json_encode(array_merge($result, ['optimized_filename' => $optimizedFilename]));
}

/**
 * Handle metadata request
 */
function handleMetadata($processor) {
    $filename = $_GET['filename'] ?? '';
    
    if (empty($filename)) {
        echo json_encode(['success' => false, 'message' => 'Filename required']);
        return;
    }
    
    $path = IMG_ORIGINAL_DIR . $filename;
    if (!file_exists($path)) {
        echo json_encode(['success' => false, 'message' => 'File not found']);
        return;
    }
    
    $metadata = $processor->getImageMetadata($path);
    
    echo json_encode([
        'success' => true,
        'data' => $metadata
    ]);
}

/**
 * Handle download
 */
function handleDownload($history) {
    $historyId = intval($_GET['history_id'] ?? 0);
    $type = $_GET['type'] ?? 'optimized'; // original or optimized
    
    if ($historyId <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid history ID']);
        return;
    }
    
    $record = $history->getById($historyId);
    if (!$record) {
        echo json_encode(['success' => false, 'message' => 'Record not found']);
        return;
    }
    
    $filePath = ($type === 'original') ? $record['original_path'] : $record['optimized_path'];
    $filename = ($type === 'original') ? $record['original_name'] : $record['optimized_name'];
    
    if (!file_exists($filePath)) {
        echo json_encode(['success' => false, 'message' => 'File not found']);
        return;
    }
    
    // Increment download count
    $history->incrementDownloadCount($historyId);
    
    // Force download
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit();
}

/**
 * Handle history request
 */
function handleHistory($user_id, $history) {
    $limit = intval($_GET['limit'] ?? 50);
    $offset = intval($_GET['offset'] ?? 0);
    
    $records = $history->getByUser($user_id, $limit, $offset);
    
    echo json_encode([
        'success' => true,
        'data' => $records
    ]);
}

/**
 * Handle stats request
 */
function handleStats($user_id, $history) {
    $stats = $history->getStatistics($user_id);
    $recentActivity = $history->getRecentActivity($user_id, 5);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'stats' => $stats,
            'recent_activity' => $recentActivity
        ]
    ]);
}

/**
 * Handle delete
 */
function handleDelete($user_id, $history) {
    $id = intval($_POST['id'] ?? 0);
    
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid ID']);
        return;
    }
    
    $record = $history->getById($id);
    if (!$record || $record['user_id'] != $user_id) {
        echo json_encode(['success' => false, 'message' => 'Record not found or unauthorized']);
        return;
    }
    
    // Delete files
    @unlink($record['original_path']);
    @unlink($record['optimized_path']);
    
    // Delete database record
    $history->delete($id);
    
    echo json_encode(['success' => true, 'message' => 'Record deleted successfully']);
}

/**
 * Handle bulk delete
 */
function handleBulkDelete($user_id, $history) {
    $ids = $_POST['ids'] ?? [];
    
    if (empty($ids) || !is_array($ids)) {
        echo json_encode(['success' => false, 'message' => 'No IDs provided']);
        return;
    }
    
    $deleted = 0;
    foreach ($ids as $id) {
        $record = $history->getById($id);
        if ($record && $record['user_id'] == $user_id) {
            @unlink($record['original_path']);
            @unlink($record['optimized_path']);
            $history->delete($id);
            $deleted++;
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => "$deleted records deleted successfully"
    ]);
}
