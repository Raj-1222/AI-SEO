<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/N8nWebhookController.php';
require_once '../models/Setting.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit();
}

$db = getDBConnection();
$setting = new Setting($db);
$webhookController = new N8nWebhookController();

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'get';
    
    if ($action === 'get') {
        // Get all settings
        $allSettings = $setting->getAll();
        
        // Extract values for response
        $settings = [];
        foreach ($allSettings as $key => $data) {
            $settings[$key] = $data['value'];
        }
        
        echo json_encode([
            'success' => true,
            'settings' => $settings
        ]);
        
    } elseif ($action === 'stats') {
        // Get webhook statistics
        $stats = $webhookController->getStats();
        
        echo json_encode([
            'success' => true,
            'stats' => $stats
        ]);
        
    } elseif ($action === 'logs') {
        // Get recent logs
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
        $logs = $webhookController->getRecentLogs(null, $limit);
        
        echo json_encode([
            'success' => true,
            'logs' => $logs
        ]);
        
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid action'
        ]);
    }
    
} elseif ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? 'save';
    
    if ($action === 'save') {
        // Save settings
        $settingsData = $input['settings'] ?? [];
        
        $saved = 0;
        foreach ($settingsData as $key => $value) {
            // Determine type
            $type = 'text';
            if (is_bool($value)) {
                $type = 'boolean';
                $value = $value ? '1' : '0';
            } elseif (is_numeric($value)) {
                $type = 'number';
            }
            
            if ($setting->set($key, $value, $type)) {
                $saved++;
            }
        }
        
        echo json_encode([
            'success' => true,
            'message' => "$saved settings saved successfully",
            'saved' => $saved
        ]);
        
    } elseif ($action === 'test') {
        // Test webhook connection
        $webhookUrl = $input['webhook_url'] ?? '';
        
        if (empty($webhookUrl)) {
            echo json_encode([
                'success' => false,
                'message' => 'Webhook URL is required'
            ]);
            exit();
        }
        
        // Send test request
        $testData = [
            'test' => true,
            'message' => 'This is a test webhook from Aurify AI SEO Automation',
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        try {
            $ch = curl_init($webhookUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($testData),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'User-Agent: AurifySEO/1.0'
                ],
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => false
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            
            if ($httpCode >= 200 && $httpCode < 300) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Webhook test successful',
                    'status_code' => $httpCode,
                    'response' => json_decode($response, true)
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Webhook test failed',
                    'status_code' => $httpCode,
                    'error' => $error ?: 'HTTP ' . $httpCode
                ]);
            }
            
        } catch (Exception $e) {
            echo json_encode([
                'success' => false,
                'message' => 'Webhook test error',
                'error' => $e->getMessage()
            ]);
        }
        
    } elseif ($action === 'retry') {
        // Retry failed webhook
        $logId = $input['log_id'] ?? 0;
        
        if (!$logId) {
            echo json_encode([
                'success' => false,
                'message' => 'Log ID is required'
            ]);
            exit();
        }
        
        $result = $webhookController->retryWebhook($logId);
        echo json_encode($result);
        
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid action'
        ]);
    }
    
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
