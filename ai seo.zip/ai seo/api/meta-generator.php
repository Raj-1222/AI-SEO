<?php
// Suppress all error output
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/MetaGeneratorController.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$controller = new MetaGeneratorController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? 'generate';
    
    if ($action === 'generate') {
        $focusKeyword = $input['focus_keyword'] ?? '';
        $websiteUrl = $input['website_url'] ?? '';
        $pageType = $input['page_type'] ?? 'general';
        
        if (empty($focusKeyword)) {
            echo json_encode(['success' => false, 'message' => 'Focus keyword is required']);
            exit();
        }
        
        $result = $controller->generateMetaTags($focusKeyword, $websiteUrl, $pageType);
        echo json_encode($result);
        
    } elseif ($action === 'save') {
        $focusKeyword = $input['focus_keyword'] ?? '';
        $metaData = $input['meta_data'] ?? [];
        
        $result = $controller->saveMetaTags($focusKeyword, $metaData, $_SESSION['user_id']);
        echo json_encode($result);
    }
    
} elseif ($method === 'GET') {
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
    $metaTags = $controller->getSavedMetaTags($_SESSION['user_id'], $limit);
    echo json_encode(['success' => true, 'meta_tags' => $metaTags]);
}
