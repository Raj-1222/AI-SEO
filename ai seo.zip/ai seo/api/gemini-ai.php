<?php
// Suppress all error output
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/GeminiAIController.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit();
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit();
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON data'
    ]);
    exit();
}

// Extract data
$websiteData = $input['website_data'] ?? [];
$pageSpeedData = $input['pagespeed_data'] ?? [];
$technicalSeoData = $input['technical_seo_data'] ?? [];
$websiteId = $input['website_id'] ?? null;

// Validate required data
if (empty($websiteData) || empty($pageSpeedData) || empty($technicalSeoData)) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing required data. Please provide website_data, pagespeed_data, and technical_seo_data'
    ]);
    exit();
}

// Initialize controller
$geminiController = new GeminiAIController();

// Generate AI recommendations
$result = $geminiController->generateRecommendations(
    $websiteData,
    $pageSpeedData,
    $technicalSeoData,
    $websiteId
);

echo json_encode($result);
