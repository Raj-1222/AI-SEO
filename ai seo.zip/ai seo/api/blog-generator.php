<?php
// Suppress all error output
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/BlogGeneratorController.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$controller = new BlogGeneratorController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? 'generate';
    
    if ($action === 'generate') {
        $keyword = $input['keyword'] ?? '';
        $wordCount = $input['word_count'] ?? 1500;
        $language = $input['language'] ?? 'English';
        $tone = $input['tone'] ?? 'professional';
        
        if (empty($keyword)) {
            echo json_encode(['success' => false, 'message' => 'Keyword is required']);
            exit();
        }
        
        $result = $controller->generateBlogPost($keyword, $wordCount, $language, $tone);
        echo json_encode($result);
        
    } elseif ($action === 'save') {
        $keyword = $input['keyword'] ?? '';
        $wordCount = $input['word_count'] ?? 1500;
        $language = $input['language'] ?? 'English';
        $tone = $input['tone'] ?? 'professional';
        $blogData = $input['blog_data'] ?? [];
        
        $result = $controller->saveBlogPost($keyword, $wordCount, $language, $tone, $blogData, $_SESSION['user_id']);
        echo json_encode($result);
    }
    
} elseif ($method === 'GET') {
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
    $blogPosts = $controller->getSavedBlogPosts($_SESSION['user_id'], $limit);
    echo json_encode(['success' => true, 'blog_posts' => $blogPosts]);
}
