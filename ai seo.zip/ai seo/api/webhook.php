<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/N8nWebhookController.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized'
    ]);
    exit();
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit();
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON data'
    ]);
    exit();
}

// Extract data
$url = $input['url'] ?? '';
$websiteId = $input['website_id'] ?? null;
$auditResults = $input['audit_results'] ?? [];

if (empty($url)) {
    echo json_encode([
        'success' => false,
        'message' => 'URL is required'
    ]);
    exit();
}

// Initialize webhook controller
$webhookController = new N8nWebhookController();

// Prepare comprehensive webhook data
$webhookData = [
    'url' => $url,
    'user_id' => $_SESSION['user_id'],
    'website_id' => $websiteId,
    'audit_timestamp' => date('Y-m-d H:i:s'),
    'results' => $auditResults
];

// Send to webhook
$result = $webhookController->sendToWebhook($webhookData, $websiteId);

echo json_encode($result);
