<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/AuditController.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$controller = new AuditController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $url = $input['url'] ?? '';
    
    if (empty($url)) {
        echo json_encode(['success' => false, 'message' => 'URL is required']);
        exit();
    }
    
    // Fetch and analyze URL
    try {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            CURLOPT_HEADER => true
        ]);
        
        $startTime = microtime(true);
        $response = curl_exec($ch);
        $endTime = microtime(true);
        $responseTime = round(($endTime - $startTime) * 1000);
        
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($httpCode !== 200 || !$response) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch URL']);
            exit();
        }
        
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headers = substr($response, 0, $headerSize);
        $html = substr($response, $headerSize);
        
        curl_close($ch);
        
        $dom = new DOMDocument();
        @$dom->loadHTML($html);
        
        // Calculate component scores
        $scores = $controller->calculateComponentScores($dom, $url, $headers, $responseTime);
        
        echo json_encode([
            'success' => true,
            'scores' => $scores
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error calculating scores']);
    }
}
