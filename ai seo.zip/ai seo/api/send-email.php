<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/EmailController.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$controller = new EmailController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? 'send';
    
    if ($action === 'send') {
        $recipientEmail = $input['email'] ?? '';
        $reportPath = $input['report_path'] ?? '';
        $websiteUrl = $input['website_url'] ?? '';
        
        if (empty($recipientEmail) || empty($reportPath) || empty($websiteUrl)) {
            echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
            exit();
        }
        
        $result = $controller->sendReportEmail($recipientEmail, $reportPath, $websiteUrl, $_SESSION['user_id']);
        echo json_encode($result);
        
    } elseif ($action === 'statistics') {
        $stats = $controller->getStatistics($_SESSION['user_id']);
        echo json_encode(['success' => true, 'statistics' => $stats]);
    }
    
} elseif ($method === 'GET') {
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
    $logs = $controller->getEmailLogs($_SESSION['user_id'], $limit);
    echo json_encode(['success' => true, 'logs' => $logs]);
}
