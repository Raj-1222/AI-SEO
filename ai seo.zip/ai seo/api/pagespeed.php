<?php
// Suppress all error output to prevent HTML from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set JSON header FIRST before any output
header('Content-Type: application/json');

// Start output buffering to catch any accidental output
ob_start();

try {
    require_once __DIR__ . '/../config/init.php';
    require_once __DIR__ . '/../controllers/PageSpeedController.php';

    // Clean any buffered output before this point
    ob_clean();

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit();
    }
} catch (Exception $e) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit();
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$url = isset($input['url']) ? trim($input['url']) : '';
$website_id = isset($input['website_id']) ? (int)$input['website_id'] : 0;

if (empty($url) || $website_id === 0) {
    echo json_encode(['success' => false, 'message' => 'URL and website ID are required']);
    exit();
}

// Analyze PageSpeed
try {
    $controller = new PageSpeedController();
    $result = $controller->analyzePageSpeed($url, $website_id);
    
    // Clean any buffered output before sending JSON
    ob_clean();
    echo json_encode($result);
} catch (Exception $e) {
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'PageSpeed analysis failed: ' . $e->getMessage()
    ]);
}
