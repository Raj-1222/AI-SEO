<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/PDFReportController.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$controller = new PDFReportController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $websiteId = $input['website_id'] ?? '';
    
    if (empty($websiteId)) {
        echo json_encode(['success' => false, 'message' => 'Website ID is required']);
        exit();
    }
    
    $result = $controller->generateReport($websiteId, $_SESSION['user_id']);
    echo json_encode($result);
}
