<?php
// Suppress all error output
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/init.php';
require_once '../controllers/SchemaGeneratorController.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$controller = new SchemaGeneratorController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? 'generate';
    
    if ($action === 'generate') {
        $type = $input['type'] ?? '';
        $data = $input['data'] ?? [];
        
        if (empty($type)) {
            echo json_encode(['success' => false, 'message' => 'Schema type is required']);
            exit();
        }
        
        $result = $controller->generateSchema($type, $data);
        echo json_encode($result);
        
    } elseif ($action === 'templates') {
        $templates = $controller->getSchemaTemplates();
        echo json_encode(['success' => true, 'templates' => $templates]);
    }
    
} elseif ($method === 'GET') {
    $templates = $controller->getSchemaTemplates();
    echo json_encode(['success' => true, 'templates' => $templates]);
}
