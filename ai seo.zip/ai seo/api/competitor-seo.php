<?php
// Suppress all error output first
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Include config (which starts session)
require_once '../config/init.php';
require_once '../controllers/CompetitorSeoController.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    error_log("COMPETITOR SEO API: No session user_id found");
    echo json_encode(['success' => false, 'message' => 'Unauthorized - Please login']);
    exit();
}

// Log for debugging
error_log("COMPETITOR SEO API: Called by user: " . $_SESSION['user_id']);
error_log("COMPETITOR SEO API: Request method: " . $_SERVER['REQUEST_METHOD']);

$controller = new CompetitorSeoController();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $rawInput = file_get_contents('php://input');
    error_log("COMPETITOR SEO API: Raw input: " . $rawInput);
    
    $input = json_decode($rawInput, true);
    error_log("COMPETITOR SEO API: Decoded input: " . print_r($input, true));
    
    $action = $input['action'] ?? '';
    
    // Validate action
    if (empty($action)) {
        echo json_encode(['success' => false, 'message' => 'Action is required']);
        exit();
    }
    
    try {
        switch ($action) {
            // 1. COMPETITOR DISCOVERY
            case 'discover_competitors':
                $primaryDomain = $input['primary_domain'] ?? '';
                $keywords = $input['keywords'] ?? [];
                $industry = $input['industry'] ?? null;
                
                if (empty($primaryDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Primary domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Discovering competitors for $primaryDomain");
                $result = $controller->discoverCompetitors($primaryDomain, $keywords, $industry);
                echo json_encode($result);
                break;
            
            // 2. COMPETITOR KEYWORD ANALYSIS
            case 'analyze_keywords':
                $competitorDomain = $input['competitor_domain'] ?? '';
                $limit = $input['limit'] ?? 100;
                
                if (empty($competitorDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Competitor domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Analyzing keywords for $competitorDomain");
                $result = $controller->analyzeCompetitorKeywords($competitorDomain, $limit);
                echo json_encode($result);
                break;
            
            // 3. KEYWORD GAP ANALYSIS
            case 'keyword_gap':
                $primaryDomain = $input['primary_domain'] ?? '';
                $competitorDomains = $input['competitor_domains'] ?? [];
                
                if (empty($primaryDomain) || empty($competitorDomains)) {
                    echo json_encode(['success' => false, 'message' => 'Primary domain and competitor domains are required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Analyzing keyword gap for $primaryDomain");
                $result = $controller->analyzeKeywordGap($primaryDomain, $competitorDomains);
                echo json_encode($result);
                break;
            
            // 4. CONTENT GAP ANALYSIS
            case 'content_gap':
                $primaryDomain = $input['primary_domain'] ?? '';
                $competitorDomains = $input['competitor_domains'] ?? [];
                
                if (empty($primaryDomain) || empty($competitorDomains)) {
                    echo json_encode(['success' => false, 'message' => 'Primary domain and competitor domains are required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Analyzing content gap for $primaryDomain");
                $result = $controller->analyzeContentGap($primaryDomain, $competitorDomains);
                echo json_encode($result);
                break;
            
            // 5. COMPETITOR BACKLINKS ANALYSIS
            case 'analyze_backlinks':
                $competitorDomain = $input['competitor_domain'] ?? '';
                $limit = $input['limit'] ?? 100;
                
                if (empty($competitorDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Competitor domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Analyzing backlinks for $competitorDomain");
                $result = $controller->analyzeCompetitorBacklinks($competitorDomain, $limit);
                echo json_encode($result);
                break;
            
            // 6. COMPETITOR TOP PAGES
            case 'top_pages':
                $competitorDomain = $input['competitor_domain'] ?? '';
                $limit = $input['limit'] ?? 20;
                
                if (empty($competitorDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Competitor domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Getting top pages for $competitorDomain");
                $result = $controller->getCompetitorTopPages($competitorDomain, $limit);
                echo json_encode($result);
                break;
            
            // 7. COMPETITOR TRAFFIC ESTIMATES
            case 'traffic_estimate':
                $competitorDomain = $input['competitor_domain'] ?? '';
                $months = $input['months'] ?? 6;
                
                if (empty($competitorDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Competitor domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Estimating traffic for $competitorDomain");
                $result = $controller->estimateCompetitorTraffic($competitorDomain, $months);
                echo json_encode($result);
                break;
            
            // 8. SERP COMPARISON
            case 'serp_comparison':
                $keywords = $input['keywords'] ?? [];
                $primaryDomain = $input['primary_domain'] ?? '';
                $competitorDomains = $input['competitor_domains'] ?? [];
                
                if (empty($keywords) || empty($primaryDomain) || empty($competitorDomains)) {
                    echo json_encode(['success' => false, 'message' => 'Keywords, primary domain, and competitor domains are required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Comparing SERP for $primaryDomain");
                $result = $controller->compareSERP($keywords, $primaryDomain, $competitorDomains);
                echo json_encode($result);
                break;
            
            // 9. COMPETITOR META ANALYSIS
            case 'meta_analysis':
                $competitorDomain = $input['competitor_domain'] ?? '';
                $sampleUrls = $input['sample_urls'] ?? [];
                
                if (empty($competitorDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Competitor domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Analyzing meta tags for $competitorDomain");
                $result = $controller->analyzeCompetitorMeta($competitorDomain, $sampleUrls);
                echo json_encode($result);
                break;
            
            // 10. COMPETITOR CONTENT ANALYSIS
            case 'content_analysis':
                $competitorDomain = $input['competitor_domain'] ?? '';
                $limit = $input['limit'] ?? 20;
                
                if (empty($competitorDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Competitor domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Analyzing content for $competitorDomain");
                $result = $controller->analyzeCompetitorContent($competitorDomain, $limit);
                echo json_encode($result);
                break;
            
            // 11. COMPETITOR CHANGE MONITORING
            case 'monitor_changes':
                $competitorDomain = $input['competitor_domain'] ?? '';
                
                if (empty($competitorDomain)) {
                    echo json_encode(['success' => false, 'message' => 'Competitor domain is required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Monitoring changes for $competitorDomain");
                $result = $controller->monitorCompetitorChanges($competitorDomain);
                echo json_encode($result);
                break;
            
            // COMPREHENSIVE REPORT
            case 'generate_report':
                $primaryDomain = $input['primary_domain'] ?? '';
                $competitorDomains = $input['competitor_domains'] ?? [];
                
                if (empty($primaryDomain) || empty($competitorDomains)) {
                    echo json_encode(['success' => false, 'message' => 'Primary domain and competitor domains are required']);
                    exit();
                }
                
                error_log("COMPETITOR SEO API: Generating comprehensive report for $primaryDomain");
                $result = $controller->generateComprehensiveReport($primaryDomain, $competitorDomains);
                echo json_encode($result);
                break;
            
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid action: ' . $action]);
                break;
        }
        
    } catch (Exception $e) {
        error_log("COMPETITOR SEO API: Exception - " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'An error occurred: ' . $e->getMessage()
        ]);
    }
    
} elseif ($method === 'GET') {
    // GET requests for retrieving saved data
    $action = $_GET['action'] ?? '';
    
    try {
        switch ($action) {
            case 'get_competitors':
                $primaryDomain = $_GET['primary_domain'] ?? '';
                // Retrieve saved competitors from database
                echo json_encode([
                    'success' => true,
                    'message' => 'Retrieved saved competitors',
                    'competitors' => []
                ]);
                break;
            
            case 'get_reports':
                $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
                // Retrieve saved reports
                echo json_encode([
                    'success' => true,
                    'message' => 'Retrieved saved reports',
                    'reports' => []
                ]);
                break;
            
            default:
                echo json_encode(['success' => false, 'message' => 'Invalid GET action']);
                break;
        }
        
    } catch (Exception $e) {
        error_log("COMPETITOR SEO API GET: Exception - " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'An error occurred: ' . $e->getMessage()
        ]);
    }
}
