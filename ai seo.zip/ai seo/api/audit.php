<?php
// Suppress all error output to prevent HTML from breaking JSON
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Set JSON header FIRST before any output
header('Content-Type: application/json');

// Start output buffering to catch any accidental output
ob_start();

try {
    require_once __DIR__ . '/../config/init.php';
    require_once __DIR__ . '/../controllers/AuditController.php';

    // Clean any buffered output before this point
    ob_clean();

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        ob_clean();
        echo json_encode(['success' => false, 'error' => 'Authentication required', 'code' => 'AUTH_REQUIRED']);
        exit();
    }
} catch (Exception $e) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit();
}

// Check request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$url = isset($input['url']) ? trim($input['url']) : '';

if (empty($url)) {
    echo json_encode(['success' => false, 'message' => 'URL is required']);
    exit();
}

// Validate URL format
if (!filter_var($url, FILTER_VALIDATE_URL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid URL format. Please include http:// or https://']);
    exit();
}

// Perform audit
try {
    $controller = new AuditController();
    $result = $controller->auditWebsite($url, $_SESSION['user_id']);
    
    // Clean any buffered output before sending JSON
    ob_clean();
    echo json_encode($result);
} catch (Exception $e) {
    ob_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Audit failed: ' . $e->getMessage()
    ]);
}
