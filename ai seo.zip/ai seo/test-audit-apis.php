<?php
/**
 * Test Audit APIs - Verify all three audit-related APIs return clean JSON
 * This tests: audit.php, pagespeed.php, technical-seo.php
 */

require_once __DIR__ . '/config/init.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Create a test session for testing
    $_SESSION['user_id'] = 2; // Use your user ID from error logs
    echo "⚠️ Created test session with user_id = 2\n\n";
}

echo "=== AUDIT API TEST SUITE ===\n";
echo "Testing all three audit APIs with a sample URL\n";
echo "Time: " . date('Y-m-d H:i:s') . "\n\n";

$testUrl = 'https://example.com';

// Test 1: audit.php
echo "-----------------------------------\n";
echo "TEST 1: Basic Website Audit (audit.php)\n";
echo "-----------------------------------\n";

$ch = curl_init('http://localhost/ai%20seo/api/audit.php');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['url' => $testUrl]),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Cookie: ' . session_name() . '=' . session_id()
    ]
]);

$response1 = curl_exec($ch);
$httpCode1 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode1\n";
echo "Response (first 500 chars): " . substr($response1, 0, 500) . "\n\n";

$isValidJson1 = false;
$data1 = null;
if ($response1) {
    $data1 = json_decode($response1, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        $isValidJson1 = true;
        echo "✅ VALID JSON\n";
        echo "Success: " . ($data1['success'] ? 'true' : 'false') . "\n";
        echo "Message: " . ($data1['message'] ?? 'N/A') . "\n";
        if (isset($data1['website_id'])) {
            echo "Website ID: " . $data1['website_id'] . "\n";
        }
    } else {
        echo "❌ INVALID JSON - Error: " . json_last_error_msg() . "\n";
        echo "Raw response starts with: " . substr($response1, 0, 100) . "\n";
    }
} else {
    echo "❌ NO RESPONSE\n";
}

// If audit was successful, get website_id for next tests
$websiteId = 1; // Default fallback
if ($isValidJson1 && isset($data1['website_id'])) {
    $websiteId = $data1['website_id'];
}

echo "\n";

// Test 2: pagespeed.php
echo "-----------------------------------\n";
echo "TEST 2: PageSpeed Insights (pagespeed.php)\n";
echo "-----------------------------------\n";

$ch = curl_init('http://localhost/ai%20seo/api/pagespeed.php');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode([
        'url' => $testUrl,
        'website_id' => $websiteId
    ]),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Cookie: ' . session_name() . '=' . session_id()
    ]
]);

$response2 = curl_exec($ch);
$httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode2\n";
echo "Response (first 500 chars): " . substr($response2, 0, 500) . "\n\n";

$isValidJson2 = false;
if ($response2) {
    $data2 = json_decode($response2, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        $isValidJson2 = true;
        echo "✅ VALID JSON\n";
        echo "Success: " . ($data2['success'] ? 'true' : 'false') . "\n";
        echo "Message: " . ($data2['message'] ?? 'N/A') . "\n";
    } else {
        echo "❌ INVALID JSON - Error: " . json_last_error_msg() . "\n";
        echo "Raw response starts with: " . substr($response2, 0, 100) . "\n";
    }
} else {
    echo "❌ NO RESPONSE\n";
}

echo "\n";

// Test 3: technical-seo.php
echo "-----------------------------------\n";
echo "TEST 3: Technical SEO Scan (technical-seo.php)\n";
echo "-----------------------------------\n";

$ch = curl_init('http://localhost/ai%20seo/api/technical-seo.php');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode([
        'url' => $testUrl,
        'website_id' => $websiteId
    ]),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Cookie: ' . session_name() . '=' . session_id()
    ]
]);

$response3 = curl_exec($ch);
$httpCode3 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode3\n";
echo "Response (first 500 chars): " . substr($response3, 0, 500) . "\n\n";

$isValidJson3 = false;
if ($response3) {
    $data3 = json_decode($response3, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        $isValidJson3 = true;
        echo "✅ VALID JSON\n";
        echo "Success: " . ($data3['success'] ? 'true' : 'false') . "\n";
        echo "Message: " . ($data3['message'] ?? 'N/A') . "\n";
        if (isset($data3['issues_found'])) {
            echo "Issues Found: " . $data3['issues_found'] . "\n";
        }
    } else {
        echo "❌ INVALID JSON - Error: " . json_last_error_msg() . "\n";
        echo "Raw response starts with: " . substr($response3, 0, 100) . "\n";
    }
} else {
    echo "❌ NO RESPONSE\n";
}

echo "\n";

// Summary
echo "===================================\n";
echo "TEST SUMMARY\n";
echo "===================================\n";
echo "1. audit.php: " . ($isValidJson1 ? '✅ PASS' : '❌ FAIL') . "\n";
echo "2. pagespeed.php: " . ($isValidJson2 ? '✅ PASS' : '❌ FAIL') . "\n";
echo "3. technical-seo.php: " . ($isValidJson3 ? '✅ PASS' : '❌ FAIL') . "\n";
echo "\n";

if ($isValidJson1 && $isValidJson2 && $isValidJson3) {
    echo "🎉 ALL TESTS PASSED! All APIs return valid JSON.\n";
    echo "The website audit module should now work correctly.\n";
    echo "Please clear your browser cache (Ctrl+Shift+Delete) and try again.\n";
} else {
    echo "⚠️ SOME TESTS FAILED\n";
    echo "Please check the error logs for more details:\n";
    echo "- Run view-errors.php in your browser\n";
    echo "- Check PHP error logs on your server\n";
    echo "- Look at browser console (F12) when testing the dashboard\n";
}

echo "\n";
echo "Note: PageSpeed API requires a valid API key. Check config/database.php\n";
echo "===================================\n";
