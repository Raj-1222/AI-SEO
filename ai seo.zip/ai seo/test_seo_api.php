<?php
/**
 * Test SEO API Integration
 * Run this script to test your API connections
 */

require_once __DIR__ . '/config/init.php';
require_once __DIR__ . '/services/RealSeoApiService.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEO API Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .test-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        .test-result {
            padding: 1rem;
            border-radius: 10px;
            margin: 0.5rem 0;
        }
        .test-success {
            background: #d4edda;
            border-left: 4px solid #28a745;
        }
        .test-error {
            background: #f8d7da;
            border-left: 4px solid #dc3545;
        }
        .test-info {
            background: #d1ecf1;
            border-left: 4px solid #0dcaf0;
        }
        pre {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 8px;
            font-size: 0.875rem;
            max-height: 300px;
            overflow: auto;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 1000px;">
        <div class="test-card text-center mb-4">
            <i class="bi bi-gear-fill text-primary" style="font-size: 4rem;"></i>
            <h1 class="mt-3">SEO API Integration Test</h1>
            <p class="text-muted">Testing your SEO API connections and data retrieval</p>
        </div>

        <?php
        $service = new RealSeoApiService();
        
        // Test 1: API Connection
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-1-circle text-primary me-2"></i>API Connection Test</h4>';
        
        $connectionTest = $service->testConnection();
        
        if ($connectionTest['success']) {
            echo '<div class="test-result test-success">';
            echo '<i class="bi bi-check-circle-fill text-success me-2"></i>';
            echo '<strong>Success:</strong> ' . htmlspecialchars($connectionTest['message']);
            echo '<br><small>API Provider: ' . ($connectionTest['api'] ?? 'Unknown') . '</small>';
            echo '</div>';
        } else {
            echo '<div class="test-result test-error">';
            echo '<i class="bi bi-x-circle-fill text-danger me-2"></i>';
            echo '<strong>Failed:</strong> ' . htmlspecialchars($connectionTest['message']);
            echo '</div>';
            echo '<div class="test-result test-info">';
            echo '<i class="bi bi-info-circle me-2"></i>';
            echo '<strong>Next Steps:</strong><br>';
            echo '1. Check your API credentials in config/database.php<br>';
            echo '2. Make sure you have added the API keys<br>';
            echo '3. Verify your API subscription is active<br>';
            echo '4. See REAL_SEO_API_INTEGRATION_GUIDE.md for help';
            echo '</div>';
        }
        echo '</div>';
        
        // Test 2: Competitor Discovery
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-2-circle text-primary me-2"></i>Competitor Discovery Test</h4>';
        
        $testDomain = 'example.com';
        echo '<p class="text-muted">Testing with domain: <code>' . $testDomain . '</code></p>';
        
        try {
            $competitors = $service->discoverCompetitors($testDomain, 5);
            
            if (!empty($competitors)) {
                echo '<div class="test-result test-success">';
                echo '<i class="bi bi-check-circle-fill text-success me-2"></i>';
                echo '<strong>Success:</strong> Found ' . count($competitors) . ' competitors';
                echo '</div>';
                
                echo '<pre>' . json_encode($competitors, JSON_PRETTY_PRINT) . '</pre>';
            } else {
                echo '<div class="test-result test-info">';
                echo '<i class="bi bi-info-circle me-2"></i>';
                echo 'No competitors found (using fallback data)';
                echo '</div>';
            }
        } catch (Exception $e) {
            echo '<div class="test-result test-error">';
            echo '<i class="bi bi-x-circle-fill text-danger me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Test 3: Keyword Data
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-3-circle text-primary me-2"></i>Keyword Analysis Test</h4>';
        
        echo '<p class="text-muted">Testing keyword retrieval for: <code>' . $testDomain . '</code></p>';
        
        try {
            $keywords = $service->getCompetitorKeywords($testDomain, 10);
            
            if (!empty($keywords)) {
                echo '<div class="test-result test-success">';
                echo '<i class="bi bi-check-circle-fill text-success me-2"></i>';
                echo '<strong>Success:</strong> Retrieved ' . count($keywords) . ' keywords';
                echo '</div>';
                
                echo '<pre>' . json_encode(array_slice($keywords, 0, 5), JSON_PRETTY_PRINT) . '</pre>';
            } else {
                echo '<div class="test-result test-info">';
                echo '<i class="bi bi-info-circle me-2"></i>';
                echo 'No keywords found (using fallback data)';
                echo '</div>';
            }
        } catch (Exception $e) {
            echo '<div class="test-result test-error">';
            echo '<i class="bi bi-x-circle-fill text-danger me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Test 4: Backlink Data
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-4-circle text-primary me-2"></i>Backlink Analysis Test</h4>';
        
        echo '<p class="text-muted">Testing backlink retrieval for: <code>' . $testDomain . '</code></p>';
        
        try {
            $backlinks = $service->getBacklinks($testDomain, 5);
            
            if (!empty($backlinks)) {
                echo '<div class="test-result test-success">';
                echo '<i class="bi bi-check-circle-fill text-success me-2"></i>';
                echo '<strong>Success:</strong> Retrieved ' . count($backlinks) . ' backlinks';
                echo '</div>';
                
                echo '<pre>' . json_encode(array_slice($backlinks, 0, 3), JSON_PRETTY_PRINT) . '</pre>';
            } else {
                echo '<div class="test-result test-info">';
                echo '<i class="bi bi-info-circle me-2"></i>';
                echo 'No backlinks found (using fallback data)';
                echo '</div>';
            }
        } catch (Exception $e) {
            echo '<div class="test-result test-error">';
            echo '<i class="bi bi-x-circle-fill text-danger me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Test 5: SERP Data
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-5-circle text-primary me-2"></i>SERP Data Test</h4>';
        
        $testKeyword = 'seo tools';
        echo '<p class="text-muted">Testing SERP data for keyword: <code>' . $testKeyword . '</code></p>';
        
        try {
            $serp = $service->getSerpResults($testKeyword);
            
            if (!empty($serp)) {
                echo '<div class="test-result test-success">';
                echo '<i class="bi bi-check-circle-fill text-success me-2"></i>';
                echo '<strong>Success:</strong> Retrieved SERP data';
                echo '</div>';
                
                echo '<p><strong>Search Volume:</strong> ' . number_format($serp['search_volume']) . '</p>';
                echo '<p><strong>Top 3 Results:</strong></p>';
                echo '<pre>' . json_encode(array_slice($serp['positions'], 0, 3, true), JSON_PRETTY_PRINT) . '</pre>';
            } else {
                echo '<div class="test-result test-info">';
                echo '<i class="bi bi-info-circle me-2"></i>';
                echo 'No SERP data found (using fallback data)';
                echo '</div>';
            }
        } catch (Exception $e) {
            echo '<div class="test-result test-error">';
            echo '<i class="bi bi-x-circle-fill text-danger me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Summary
        echo '<div class="test-card">';
        echo '<h4 class="text-center mb-4">Test Summary</h4>';
        
        if ($connectionTest['success']) {
            echo '<div class="alert alert-success">';
            echo '<h5><i class="bi bi-check-circle-fill me-2"></i>API Integration Active</h5>';
            echo '<p class="mb-0">Your SEO API is configured and working! The Competitor SEO module will use real data.</p>';
            echo '</div>';
            
            echo '<div class="text-center mt-4">';
            echo '<a href="views/dashboard/competitor-seo.php" class="btn btn-primary btn-lg">';
            echo '<i class="bi bi-trophy me-2"></i>Launch Competitor SEO Module';
            echo '</a>';
            echo '</div>';
        } else {
            echo '<div class="alert alert-warning">';
            echo '<h5><i class="bi bi-exclamation-triangle-fill me-2"></i>API Not Configured</h5>';
            echo '<p>The module is using simulated data. To use real competitor data:</p>';
            echo '<ol>';
            echo '<li>Choose an API provider (see REAL_SEO_API_INTEGRATION_GUIDE.md)</li>';
            echo '<li>Sign up and get API credentials</li>';
            echo '<li>Add credentials to config/database.php</li>';
            echo '<li>Run this test again</li>';
            echo '</ol>';
            echo '</div>';
            
            echo '<div class="text-center mt-3">';
            echo '<a href="REAL_SEO_API_INTEGRATION_GUIDE.md" class="btn btn-info me-2" target="_blank">';
            echo '<i class="bi bi-book me-2"></i>Read Integration Guide';
            echo '</a>';
            echo '<a href="views/dashboard/competitor-seo.php" class="btn btn-outline-primary">';
            echo '<i class="bi bi-trophy me-2"></i>Launch Module (Demo Mode)';
            echo '</a>';
            echo '</div>';
        }
        
        echo '</div>';
        ?>

        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-outline-light me-2">
                <i class="bi bi-house"></i> Home
            </a>
            <a href="views/dashboard/index.php" class="btn btn-outline-light">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </div>
    </div>
</body>
</html>
