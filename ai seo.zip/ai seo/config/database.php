<?php
// Database Configuration - Hostinger
define('DB_HOST', 'localhost');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');
define('DB_NAME', 'your_database_name');

// Create connection
function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// Site Configuration
define('SITE_NAME', 'Aurify AI SEO Automation');
define('SITE_URL', 'https://yourdomain.com');
define('SESSION_TIMEOUT', 3600); // 1 hour

// Google PageSpeed Insights API Key
// Get your API key from: https://developers.google.com/speed/docs/insights/v5/get-started
define('PAGESPEED_API_KEY', 'your_google_pagespeed_api_key');

// OpenAI API Configuration (Using ChatGPT/GPT-4)
define('OPENAI_API_KEY', 'your_openai_api_key');
define('OPENAI_API_URL', 'https://api.openai.com/v1/chat/completions');
define('OPENAI_MODEL', 'gpt-4o-mini'); // Fast and cost-effective. Use 'gpt-4' for highest quality

// Legacy compatibility - map to OpenAI
define('GEMINI_API_KEY', OPENAI_API_KEY);
define('GEMINI_API_URL', OPENAI_API_URL);

// Theme Colors
define('PRIMARY_COLOR', '#FF6B00');
define('SECONDARY_COLOR', '#0B1F4D');


// ==================== SEO API CONFIGURATION ====================
// Choose your SEO data provider and add API credentials below

// PRIMARY API PROVIDER
// Options: 'dataforseo', 'serpapi', 'semrush', 'ahrefs', 'valueserp'
define('PRIMARY_SEO_API', 'dataforseo'); // Change this to your preferred provider

// DataForSEO API (Recommended - Most Affordable)
// Sign up: https://app.dataforseo.com/register
// Pricing: Pay-as-you-go, ~$0.0001 per call, $1 trial
define('DATAFORSEO_LOGIN', ''); // Your email
define('DATAFORSEO_PASSWORD', ''); // API password from dashboard

// SerpAPI (Easiest to Start - Free Tier Available)
// Sign up: https://serpapi.com/users/sign_up
// Free: 100 searches/month, Paid: $50/month for 5,000 searches
define('SERPAPI_KEY', ''); // Your API key

// SEMrush API (Premium - Comprehensive Data)
// Sign up: https://www.semrush.com/api-documentation/
// Pricing: Starting at $200/month
define('SEMRUSH_API_KEY', ''); // Your API key

// Ahrefs API (Premium - Best for Backlinks)
// Sign up: https://ahrefs.com/api
// Pricing: Starting at $500/month
define('AHREFS_API_KEY', ''); // Your API key

// ValueSerp API (Budget Option)
// Sign up: https://www.valueserp.com/
// Free tier: 100 requests, Paid: $25/month
define('VALUESERP_KEY', ''); // Your API key

// Moz API (Domain Authority Metrics)
// Sign up: https://moz.com/api
// Pricing: Starting at $99/month
define('MOZ_ACCESS_ID', ''); // Your access ID
define('MOZ_SECRET_KEY', ''); // Your secret key

// API USAGE NOTES:
// 1. Start with SerpAPI free tier (100 searches/month) for testing
// 2. For production, DataForSEO offers best value ($1 trial, pay-as-you-go)
// 3. Module works without APIs (uses simulated data for demo)
// 4. See REAL_SEO_API_INTEGRATION_GUIDE.md for detailed setup

