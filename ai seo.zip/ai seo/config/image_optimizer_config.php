<?php
/**
 * Image Optimizer Configuration
 * Central configuration file for Image Optimization Suite
 */

// Image Upload Settings
define('IMG_MAX_UPLOAD_SIZE', 10485760); // 10MB in bytes
define('IMG_MAX_BATCH_SIZE', 100); // Maximum images per batch
define('IMG_ALLOWED_FORMATS', ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'tiff', 'avif']);
define('IMG_ALLOWED_MIME_TYPES', [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/webp',
    'image/gif',
    'image/bmp',
    'image/tiff',
    'image/avif'
]);

// Image Processing Settings
define('IMG_DEFAULT_QUALITY', 85);
define('IMG_DEFAULT_FORMAT', 'webp');
define('IMG_MAX_DIMENSION', 8000); // Maximum width or height in pixels

// Compression Levels
define('IMG_COMPRESSION_LOSSLESS', 100);
define('IMG_COMPRESSION_LOW', 90);
define('IMG_COMPRESSION_MEDIUM', 85);
define('IMG_COMPRESSION_HIGH', 75);
define('IMG_COMPRESSION_MAXIMUM', 60);

// Directory Structure
$baseDir = dirname(__DIR__);
define('IMG_BASE_DIR', $baseDir);
define('IMG_UPLOAD_DIR', $baseDir . '/uploads/images/');
define('IMG_ORIGINAL_DIR', IMG_UPLOAD_DIR . 'original/');
define('IMG_OPTIMIZED_DIR', IMG_UPLOAD_DIR . 'optimized/');
define('IMG_WATERMARK_DIR', IMG_UPLOAD_DIR . 'watermarks/');
define('IMG_TEMP_DIR', IMG_UPLOAD_DIR . 'temp/');
define('IMG_DOWNLOAD_DIR', $baseDir . '/downloads/images/');

// Create directories if they don't exist
$directories = [
    IMG_UPLOAD_DIR,
    IMG_ORIGINAL_DIR,
    IMG_OPTIMIZED_DIR,
    IMG_WATERMARK_DIR,
    IMG_TEMP_DIR,
    IMG_DOWNLOAD_DIR
];

foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
        // Add .htaccess for security
        $htaccess = $dir . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "Options -Indexes\nOrder Deny,Allow\nAllow from all");
        }
    }
}

// Watermark Settings
define('IMG_WATERMARK_DEFAULT_OPACITY', 50);
define('IMG_WATERMARK_DEFAULT_POSITION', 'bottom-right');
define('IMG_WATERMARK_POSITIONS', [
    'top-left',
    'top-center',
    'top-right',
    'center-left',
    'center',
    'center-right',
    'bottom-left',
    'bottom-center',
    'bottom-right'
]);

// Resize Presets
define('IMG_RESIZE_PRESETS', [
    'instagram_post' => ['width' => 1080, 'height' => 1080, 'name' => 'Instagram Post'],
    'instagram_story' => ['width' => 1080, 'height' => 1920, 'name' => 'Instagram Story'],
    'facebook_post' => ['width' => 1200, 'height' => 630, 'name' => 'Facebook Post'],
    'linkedin_post' => ['width' => 1200, 'height' => 627, 'name' => 'LinkedIn Post'],
    'twitter_post' => ['width' => 1600, 'height' => 900, 'name' => 'Twitter Post'],
    'youtube_thumbnail' => ['width' => 1280, 'height' => 720, 'name' => 'YouTube Thumbnail'],
    'website_banner' => ['width' => 1920, 'height' => 600, 'name' => 'Website Banner'],
    'hero_section' => ['width' => 1920, 'height' => 1080, 'name' => 'Hero Section'],
    'product_image' => ['width' => 800, 'height' => 800, 'name' => 'Product Image'],
    'blog_featured' => ['width' => 1200, 'height' => 630, 'name' => 'Blog Featured'],
    'logo' => ['width' => 512, 'height' => 512, 'name' => 'Logo'],
    'favicon' => ['width' => 32, 'height' => 32, 'name' => 'Favicon']
]);

// Crop Aspect Ratios
define('IMG_CROP_RATIOS', [
    'square' => ['ratio' => 1, 'name' => 'Square (1:1)'],
    '16_9' => ['ratio' => 16/9, 'name' => '16:9 (Widescreen)'],
    '4_3' => ['ratio' => 4/3, 'name' => '4:3 (Standard)'],
    '1_1' => ['ratio' => 1, 'name' => '1:1 (Square)'],
    '9_16' => ['ratio' => 9/16, 'name' => '9:16 (Vertical)'],
    'free' => ['ratio' => 0, 'name' => 'Free Crop']
]);

// Format Conversion Map
define('IMG_CONVERSION_MAP', [
    'png' => ['jpg', 'jpeg', 'webp', 'avif', 'gif'],
    'jpg' => ['png', 'webp', 'avif'],
    'jpeg' => ['png', 'webp', 'avif'],
    'webp' => ['jpg', 'jpeg', 'png', 'avif'],
    'gif' => ['png', 'webp'],
    'bmp' => ['jpg', 'jpeg', 'png', 'webp'],
    'tiff' => ['jpg', 'jpeg', 'png', 'webp'],
    'avif' => ['webp', 'png', 'jpg', 'jpeg']
]);

// Security Settings
define('IMG_SECURITY_TOKEN_LENGTH', 32);
define('IMG_MAX_FILENAME_LENGTH', 255);
define('IMG_SANITIZE_FILENAME', true);

// Performance Settings
define('IMG_MEMORY_LIMIT', '512M');
define('IMG_MAX_EXECUTION_TIME', 300); // 5 minutes

// Set PHP settings for image processing
@ini_set('memory_limit', IMG_MEMORY_LIMIT);
@ini_set('max_execution_time', IMG_MAX_EXECUTION_TIME);

// Error Reporting (disable in production)
define('IMG_DEBUG_MODE', true); // Set to false in production

// SEO Settings
define('IMG_SEO_RECOMMENDED_FORMATS', ['webp', 'avif']);
define('IMG_SEO_MAX_FILE_SIZE', 200 * 1024); // 200KB
define('IMG_SEO_MAX_DIMENSIONS', [
    'web' => 2000,
    'mobile' => 1200
]);

// Check if Imagick is available
define('IMG_HAS_IMAGICK', extension_loaded('imagick'));
define('IMG_HAS_GD', extension_loaded('gd'));

// Fallback to GD if Imagick not available
if (!IMG_HAS_IMAGICK && !IMG_HAS_GD) {
    die('Error: Neither Imagick nor GD library is available. Please install one of them.');
}

// Log which library is being used
define('IMG_LIBRARY', IMG_HAS_IMAGICK ? 'imagick' : 'gd');

/**
 * Get compression quality based on level
 */
function getCompressionQuality($level) {
    switch ($level) {
        case 'lossless':
            return IMG_COMPRESSION_LOSSLESS;
        case 'low':
            return IMG_COMPRESSION_LOW;
        case 'medium':
            return IMG_COMPRESSION_MEDIUM;
        case 'high':
            return IMG_COMPRESSION_HIGH;
        case 'maximum':
            return IMG_COMPRESSION_MAXIMUM;
        default:
            return IMG_DEFAULT_QUALITY;
    }
}

/**
 * Generate secure random filename
 */
function generateSecureFilename($originalName, $prefix = '') {
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $randomString = bin2hex(random_bytes(16));
    $timestamp = time();
    return $prefix . $timestamp . '_' . $randomString . '.' . $extension;
}

/**
 * Sanitize filename
 */
function sanitizeFilename($filename) {
    // Remove any path information
    $filename = basename($filename);
    
    // Get extension
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $nameWithoutExt = pathinfo($filename, PATHINFO_FILENAME);
    
    // Remove special characters, keep only alphanumeric, dash, underscore
    $nameWithoutExt = preg_replace('/[^a-zA-Z0-9\-_]/', '_', $nameWithoutExt);
    
    // Limit length
    if (strlen($nameWithoutExt) > 100) {
        $nameWithoutExt = substr($nameWithoutExt, 0, 100);
    }
    
    return $nameWithoutExt . '.' . $extension;
}

/**
 * Format bytes to human readable
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}

/**
 * Calculate compression ratio
 */
function calculateCompressionRatio($originalSize, $optimizedSize) {
    if ($originalSize == 0) return 0;
    return round((($originalSize - $optimizedSize) / $originalSize) * 100, 2);
}

/**
 * Validate image file
 */
function validateImageFile($file) {
    $errors = [];
    
    // Check if file exists
    if (!isset($file['tmp_name']) || !file_exists($file['tmp_name'])) {
        $errors[] = 'No file uploaded';
        return $errors;
    }
    
    // Check file size
    if ($file['size'] > IMG_MAX_UPLOAD_SIZE) {
        $errors[] = 'File size exceeds maximum allowed size of ' . formatBytes(IMG_MAX_UPLOAD_SIZE);
    }
    
    // Check MIME type
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    
    if (!in_array($mimeType, IMG_ALLOWED_MIME_TYPES)) {
        $errors[] = 'Invalid file type. Allowed types: ' . implode(', ', IMG_ALLOWED_FORMATS);
    }
    
    // Check file extension
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, IMG_ALLOWED_FORMATS)) {
        $errors[] = 'Invalid file extension';
    }
    
    // Verify it's actually an image
    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false) {
        $errors[] = 'File is not a valid image';
    }
    
    return $errors;
}
