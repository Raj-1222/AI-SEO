<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'aurify_seo');

// Create connection
function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// Site Configuration
define('SITE_NAME', 'Aurify AI SEO Automation');
define('SITE_URL', 'http://localhost');
define('SESSION_TIMEOUT', 3600); // 1 hour

// Theme Colors
define('PRIMARY_COLOR', '#FF6B00');
define('SECONDARY_COLOR', '#0B1F4D');
