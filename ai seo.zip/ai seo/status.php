<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Status - Aurify AI SEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body { background: linear-gradient(135deg, #0B1F4D 0%, #1a3a6e 100%); min-height: 100vh; padding: 40px 0; }
        .status-card { background: white; border-radius: 15px; padding: 30px; margin-bottom: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
        .status-ok { color: #28A745; font-size: 24px; }
        .status-error { color: #DC3545; font-size: 24px; }
        .status-warning { color: #FFC107; font-size: 24px; }
        h1 { color: white; text-align: center; margin-bottom: 40px; }
        .info-box { background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 10px 0; }
        .btn-test { background: #FF6B00; color: white; border: none; padding: 10px 30px; border-radius: 8px; }
        .btn-test:hover { background: #e55f00; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="bi bi-activity"></i> Aurify AI SEO - System Status</h1>
        
        <?php
        require_once __DIR__ . '/config/database.php';
        
        // Test 1: Database Connection
        echo '<div class="status-card">';
        echo '<h4><i class="bi bi-database"></i> Database Connection</h4>';
        try {
            $conn = getDBConnection();
            if ($conn->ping()) {
                echo '<p class="status-ok"><i class="bi bi-check-circle-fill"></i> Connected</p>';
                echo '<div class="info-box">';
                echo '<strong>Host:</strong> ' . DB_HOST . '<br>';
                echo '<strong>Database:</strong> ' . DB_NAME . '<br>';
                echo '<strong>Status:</strong> Active';
                echo '</div>';
                $conn->close();
            } else {
                echo '<p class="status-error"><i class="bi bi-x-circle-fill"></i> Not Connected</p>';
            }
        } catch (Exception $e) {
            echo '<p class="status-error"><i class="bi bi-x-circle-fill"></i> Error: ' . $e->getMessage() . '</p>';
        }
        echo '</div>';
        
        // Test 2: OpenAI Configuration
        echo '<div class="status-card">';
        echo '<h4><i class="bi bi-robot"></i> OpenAI API Configuration</h4>';
        
        $apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';
        $apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : '';
        $model = defined('OPENAI_MODEL') ? OPENAI_MODEL : '';
        
        if (empty($apiKey) || $apiKey === 'YOUR_OPENAI_API_KEY_HERE') {
            echo '<p class="status-error"><i class="bi bi-x-circle-fill"></i> Not Configured</p>';
            echo '<div class="alert alert-danger">';
            echo '<strong>API Key Missing!</strong><br>';
            echo 'Please add your OpenAI API key in <code>config/database.php</code>';
            echo '</div>';
        } else {
            echo '<p class="status-ok"><i class="bi bi-check-circle-fill"></i> Configured</p>';
            echo '<div class="info-box">';
            echo '<strong>API Key:</strong> ' . substr($apiKey, 0, 15) . '...' . substr($apiKey, -8) . '<br>';
            echo '<strong>API URL:</strong> ' . htmlspecialchars($apiUrl) . '<br>';
            echo '<strong>Model:</strong> ' . htmlspecialchars($model);
            echo '</div>';
        }
        echo '</div>';
        
        // Test 3: PHP Extensions
        echo '<div class="status-card">';
        echo '<h4><i class="bi bi-gear"></i> PHP Extensions</h4>';
        
        $extensions = [
            'curl' => 'cURL (Required for API calls)',
            'mysqli' => 'MySQLi (Database)',
            'json' => 'JSON (Data parsing)',
            'mbstring' => 'Multibyte String',
            'openssl' => 'OpenSSL (Secure connections)'
        ];
        
        foreach ($extensions as $ext => $desc) {
            if (extension_loaded($ext)) {
                echo '<p class="status-ok"><i class="bi bi-check-circle-fill"></i> ' . $desc . '</p>';
            } else {
                echo '<p class="status-error"><i class="bi bi-x-circle-fill"></i> ' . $desc . ' - <strong>Missing!</strong></p>';
            }
        }
        echo '</div>';
        
        // Test 4: File Permissions
        echo '<div class="status-card">';
        echo '<h4><i class="bi bi-file-earmark-lock"></i> File Permissions</h4>';
        
        $writablePaths = [
            __DIR__ . '/error.log' => 'Error Log',
            __DIR__ . '/config' => 'Config Directory'
        ];
        
        foreach ($writablePaths as $path => $name) {
            if (file_exists($path)) {
                if (is_writable($path)) {
                    echo '<p class="status-ok"><i class="bi bi-check-circle-fill"></i> ' . $name . ' - Writable</p>';
                } else {
                    echo '<p class="status-warning"><i class="bi bi-exclamation-triangle-fill"></i> ' . $name . ' - Read Only</p>';
                }
            } else {
                echo '<p class="status-warning"><i class="bi bi-exclamation-triangle-fill"></i> ' . $name . ' - Not Found</p>';
            }
        }
        echo '</div>';
        
        // Test 5: API Connectivity
        echo '<div class="status-card">';
        echo '<h4><i class="bi bi-cloud-check"></i> OpenAI API Connectivity</h4>';
        
        if (!empty($apiKey) && $apiKey !== 'YOUR_OPENAI_API_KEY_HERE' && function_exists('curl_init')) {
            echo '<p class="text-muted">Testing connection to OpenAI API...</p>';
            
            $testData = [
                'model' => $model,
                'messages' => [
                    ['role' => 'user', 'content' => 'Respond with just: OK']
                ],
                'max_tokens' => 10
            ];
            
            $ch = curl_init($apiUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($testData),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $apiKey
                ],
                CURLOPT_TIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            
            if ($curlError) {
                echo '<p class="status-error"><i class="bi bi-x-circle-fill"></i> Connection Failed</p>';
                echo '<div class="alert alert-danger">';
                echo '<strong>cURL Error:</strong> ' . htmlspecialchars($curlError);
                echo '</div>';
            } elseif ($httpCode === 200) {
                $result = json_decode($response, true);
                if ($result && isset($result['choices'][0]['message']['content'])) {
                    echo '<p class="status-ok"><i class="bi bi-check-circle-fill"></i> Connected & Working</p>';
                    echo '<div class="info-box">';
                    echo '<strong>Status:</strong> API is responding correctly<br>';
                    echo '<strong>Response Time:</strong> Fast<br>';
                    echo '<strong>AI Response:</strong> ' . htmlspecialchars($result['choices'][0]['message']['content']);
                    echo '</div>';
                    echo '<div class="alert alert-success mt-3">';
                    echo '<i class="bi bi-check-circle"></i> <strong>All systems operational!</strong> Your AI modules should work now.';
                    echo '</div>';
                } else {
                    echo '<p class="status-warning"><i class="bi bi-exclamation-triangle-fill"></i> Unexpected Response</p>';
                }
            } else {
                echo '<p class="status-error"><i class="bi bi-x-circle-fill"></i> API Error (HTTP ' . $httpCode . ')</p>';
                
                $errorData = json_decode($response, true);
                if ($errorData && isset($errorData['error']['message'])) {
                    echo '<div class="alert alert-danger">';
                    echo '<strong>Error:</strong> ' . htmlspecialchars($errorData['error']['message']) . '<br><br>';
                    
                    $errorMsg = $errorData['error']['message'];
                    
                    if (stripos($errorMsg, 'API key') !== false || stripos($errorMsg, 'authentication') !== false) {
                        echo '<strong>Solution:</strong><br>';
                        echo '1. Check your API key at <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Dashboard</a><br>';
                        echo '2. Generate a new API key if needed<br>';
                        echo '3. Update config/database.php with the new key';
                    } elseif (stripos($errorMsg, 'quota') !== false || stripos($errorMsg, 'billing') !== false) {
                        echo '<strong>Solution:</strong><br>';
                        echo '1. Go to <a href="https://platform.openai.com/account/billing" target="_blank">OpenAI Billing</a><br>';
                        echo '2. Add a payment method<br>';
                        echo '3. Add credits ($5 minimum)<br>';
                        echo '4. Wait 5-10 minutes for activation';
                    } elseif (stripos($errorMsg, 'model') !== false) {
                        echo '<strong>Solution:</strong><br>';
                        echo '1. Change model in config/database.php to: <code>gpt-3.5-turbo</code><br>';
                        echo '2. This model is available on all plans';
                    }
                    
                    echo '</div>';
                }
            }
        } else {
            echo '<p class="status-warning"><i class="bi bi-exclamation-triangle-fill"></i> Cannot Test</p>';
            echo '<p class="text-muted">Prerequisites not met (API key or cURL)</p>';
        }
        echo '</div>';
        
        // Action Buttons
        echo '<div class="status-card text-center">';
        echo '<h4><i class="bi bi-tools"></i> Diagnostic Tools</h4>';
        echo '<div class="d-grid gap-2 d-md-flex justify-content-md-center">';
        echo '<a href="check-api.php" class="btn btn-test"><i class="bi bi-speedometer2"></i> Quick API Test</a>';
        echo '<a href="test-openai-detailed.php" class="btn btn-test"><i class="bi bi-clipboard-data"></i> Detailed Test</a>';
        echo '<a href="DEBUGGING_STEPS.md" class="btn btn-test" target="_blank"><i class="bi bi-book"></i> Debug Guide</a>';
        echo '</div>';
        echo '</div>';
        ?>
        
        <div class="text-center mt-4">
            <p class="text-white-50">
                <small>Last checked: <?php echo date('Y-m-d H:i:s'); ?> UTC</small>
            </p>
        </div>
    </div>
</body>
</html>
