# Setup Guide for Aurify AI SEO Automation

## 🚀 Quick Setup (5 Minutes)

### Step 1: Clone the Repository

```bash
git clone https://github.com/yourusername/ai-seo.git
cd ai-seo
```

### Step 2: Configure Database

1. Create a MySQL database:
```sql
CREATE DATABASE aurify_seo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

2. Copy the database configuration file:
```bash
cp config/database.example.php config/database.php
```

3. Edit `config/database.php` with your credentials:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_db_user');
define('DB_PASS', 'your_db_password');
define('DB_NAME', 'aurify_seo');
define('SITE_URL', 'https://yourdomain.com');
```

### Step 3: Import Database Schema

Import all SQL files from the `database/` directory:

```bash
# Main schema
mysql -u your_username -p aurify_seo < database/schema.sql

# Additional modules
mysql -u your_username -p aurify_seo < database/canonical_checker_schema.sql
mysql -u your_username -p aurify_seo < database/competitor_seo_schema.sql
mysql -u your_username -p aurify_seo < database/image_optimizer_schema.sql
```

Or import via phpMyAdmin by uploading each `.sql` file.

### Step 4: Configure API Keys

Edit `config/database.php` and add your API keys:

```php
// Google PageSpeed API (Free tier available)
define('PAGESPEED_API_KEY', 'your_google_api_key');

// OpenAI API (For ChatGPT features)
define('OPENAI_API_KEY', 'your_openai_api_key');
```

**Get API Keys:**
- Google PageSpeed: https://developers.google.com/speed/docs/insights/v5/get-started
- OpenAI: https://platform.openai.com/api-keys

### Step 5: Set File Permissions

```bash
# Linux/Unix/Mac
chmod 755 -R .
mkdir -p uploads logs cache
chmod 777 uploads logs cache

# Or via FTP: Set folders to 777, files to 644
```

### Step 6: Access Your Installation

Visit: `https://yourdomain.com`

**Default Admin Login:**
- Email: `admin@aurify.com`
- Password: `admin123`

⚠️ **IMPORTANT:** Change these credentials immediately after first login!

---

## 🔧 Detailed Configuration

### Web Server Configuration

#### Apache (.htaccess)

The included `.htaccess` file should work out of the box. Make sure `mod_rewrite` is enabled:

```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

#### Nginx

Add this to your server block:

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/ai-seo;
    index index.php index.html;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Deny access to sensitive directories
    location ~ ^/(config|database|vendor|logs)/ {
        deny all;
    }

    # Prevent PHP execution in uploads
    location ~* ^/uploads/.*\.php$ {
        deny all;
    }

    location ~ /\.ht {
        deny all;
    }
}
```

### SSL Certificate (HTTPS)

#### Using Let's Encrypt (Free)

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-apache

# Get certificate
sudo certbot --apache -d yourdomain.com

# Auto-renewal (add to crontab)
0 0 * * * certbot renew --quiet
```

### Environment Variables (Recommended)

Instead of hardcoding in `config/database.php`, use environment variables:

1. Create `.env` file from example:
```bash
cp .env.example .env
```

2. Edit `.env` with your values:
```env
DB_HOST=localhost
DB_USER=your_db_user
DB_PASS=your_secure_password
OPENAI_API_KEY=sk-proj-xxxxx
PAGESPEED_API_KEY=AIzaSyxxxxx
```

3. Load in PHP (add to `config/init.php`):
```php
// Load .env file
if (file_exists(__DIR__ . '/../.env')) {
    $env = parse_ini_file(__DIR__ . '/../.env');
    foreach ($env as $key => $value) {
        putenv("$key=$value");
    }
}

// Use environment variables
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'root');
// ... etc
```

### Optional API Keys

#### SEO APIs (for Competitor Analysis)

Choose one provider:

1. **DataForSEO** (Recommended - Cheapest)
   - Sign up: https://app.dataforseo.com/register
   - $1 trial, then pay-as-you-go
   - Add to config:
   ```php
   define('DATAFORSEO_LOGIN', 'your_email@example.com');
   define('DATAFORSEO_PASSWORD', 'your_api_password');
   ```

2. **SerpAPI** (Easiest - Free Tier)
   - Sign up: https://serpapi.com/users/sign_up
   - 100 free searches/month
   - Add to config:
   ```php
   define('SERPAPI_KEY', 'your_serpapi_key');
   ```

#### Email Configuration (Optional)

For sending PDF reports via email:

```php
// SMTP Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your_email@gmail.com');
define('SMTP_PASS', 'your_app_password');
define('SMTP_FROM_EMAIL', 'noreply@yourdomain.com');
define('SMTP_FROM_NAME', 'Aurify AI SEO');
```

**Gmail Users:** Use App Password, not regular password
- Guide: https://support.google.com/accounts/answer/185833

---

## 🔍 Verification

### Test Your Installation

1. **Database Connection:**
   Visit: `/check-api.php`
   Should show database connection status

2. **API Keys:**
   - Dashboard → Settings → API Configuration
   - Test each API key

3. **File Permissions:**
   - Try uploading an image in Image Optimizer
   - Should succeed without errors

### Common Issues

#### "Database connection failed"
```bash
# Check MySQL is running
sudo systemctl status mysql

# Test connection
mysql -u your_username -p
```

#### "Permission denied" errors
```bash
# Fix ownership
sudo chown -R www-data:www-data /path/to/ai-seo

# Fix permissions
chmod 777 uploads logs cache
```

#### "API key invalid"
- Verify no extra spaces in API keys
- Check API key quotas/billing
- Test API keys using their official docs

---

## 📊 Post-Installation

### 1. Change Default Password

```
Login → Profile → Change Password
```

### 2. Configure Settings

```
Dashboard → Settings
- Update site name
- Set primary/secondary colors
- Configure email settings
- Add API keys
```

### 3. Run First Audit

```
Dashboard → Website Audit
Enter URL: yourdomain.com
Click "Generate Report"
```

### 4. Set Up Backups

```bash
# Database backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mysqldump -u DB_USER -pDB_PASS aurify_seo > backup_$DATE.sql
gzip backup_$DATE.sql

# Add to crontab for daily backups
0 2 * * * /path/to/backup.sh
```

---

## 🚀 Production Deployment

### Pre-Deployment Checklist

- [ ] Change default admin password
- [ ] Update all API keys to production keys
- [ ] Set `DEBUG_MODE = false`
- [ ] Enable HTTPS (SSL certificate)
- [ ] Configure proper file permissions
- [ ] Set up automated backups
- [ ] Configure error logging
- [ ] Test all features
- [ ] Enable rate limiting
- [ ] Configure security headers
- [ ] Set up monitoring/alerts

### Optimization

```bash
# Enable PHP opcache
sudo nano /etc/php/7.4/apache2/php.ini

# Add/uncomment:
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=10000
opcache.revalidate_freq=60

# Restart Apache
sudo systemctl restart apache2
```

---

## 📞 Need Help?

- **Documentation:** Check README.md
- **Security:** Read SECURITY.md
- **Issues:** https://github.com/yourusername/ai-seo/issues
- **Email:** support@aurify.com

---

**Setup Complete! 🎉**

You're now ready to optimize websites with AI-powered SEO tools.
