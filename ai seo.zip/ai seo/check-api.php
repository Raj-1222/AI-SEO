<?php
/**
 * Quick API Check - Simple diagnostic tool
 */
require_once __DIR__ . '/config/database.php';

// Enable error display for this test
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

$apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';
$apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : '';
$model = defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini';

// Quick test
$data = [
    'model' => $model,
    'messages' => [
        ['role' => 'user', 'content' => 'Say "Hello" in JSON format: {"message": "Hello"}']
    ],
    'max_tokens' => 50
];

$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ],
    CURLOPT_TIMEOUT => 30
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// Output result
echo json_encode([
    'test' => 'OpenAI API Quick Check',
    'api_key_configured' => !empty($apiKey) && $apiKey !== 'YOUR_OPENAI_API_KEY_HERE',
    'api_key_preview' => substr($apiKey, 0, 10) . '...',
    'api_url' => $apiUrl,
    'model' => $model,
    'http_code' => $httpCode,
    'curl_error' => $error ?: null,
    'response_preview' => substr($response, 0, 500),
    'full_response' => json_decode($response, true),
    'success' => ($httpCode === 200 && empty($error))
], JSON_PRETTY_PRINT);
