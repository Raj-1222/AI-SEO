<?php
/**
 * Test ChatGPT Competitor SEO Integration
 */

require_once __DIR__ . '/config/init.php';
require_once __DIR__ . '/services/CompetitorAIService.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatGPT Competitor SEO Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .test-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        .ai-badge {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 50px;
            display: inline-block;
            margin-bottom: 1rem;
        }
        pre {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 8px;
            max-height: 400px;
            overflow: auto;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 1200px;">
        <div class="test-card text-center mb-4">
            <i class="bi bi-robot text-primary" style="font-size: 4rem;"></i>
            <h1 class="mt-3">ChatGPT Competitor SEO Test</h1>
            <p class="text-muted">Testing AI-powered competitor analysis using your ChatGPT API</p>
            <div class="ai-badge">
                <i class="bi bi-stars me-2"></i>Powered by ChatGPT AI
            </div>
        </div>

        <?php
        $aiService = new CompetitorAIService();
        
        // Test domain
        $testDomain = 'example.com';
        $testIndustry = 'digital marketing agency';
        $testCompetitors = ['competitor1.com', 'competitor2.com'];
        
        // Test 1: Competitor Discovery
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-1-circle text-primary me-2"></i>AI Competitor Discovery</h4>';
        echo '<p class="text-muted">Using ChatGPT to discover competitors for: <code>' . $testDomain . '</code></p>';
        
        try {
            $competitors = $aiService->discoverCompetitors($testDomain, $testIndustry, ['seo', 'marketing']);
            
            echo '<div class="alert alert-success">';
            echo '<i class="bi bi-check-circle-fill me-2"></i>';
            echo '<strong>Success!</strong> ChatGPT discovered ' . count($competitors) . ' competitors';
            echo '</div>';
            
            echo '<h6>Results:</h6>';
            echo '<pre>' . json_encode($competitors, JSON_PRETTY_PRINT) . '</pre>';
        } catch (Exception $e) {
            echo '<div class="alert alert-danger">';
            echo '<i class="bi bi-x-circle-fill me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Test 2: Keyword Analysis
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-2-circle text-primary me-2"></i>AI Keyword Analysis</h4>';
        echo '<p class="text-muted">Using ChatGPT to analyze keywords for: <code>competitor1.com</code></p>';
        
        try {
            $keywords = $aiService->analyzeCompetitorKeywords('competitor1.com', 10);
            
            echo '<div class="alert alert-success">';
            echo '<i class="bi bi-check-circle-fill me-2"></i>';
            echo '<strong>Success!</strong> ChatGPT generated ' . count($keywords) . ' keyword insights';
            echo '</div>';
            
            echo '<h6>Sample Keywords:</h6>';
            echo '<pre>' . json_encode(array_slice($keywords, 0, 5), JSON_PRETTY_PRINT) . '</pre>';
        } catch (Exception $e) {
            echo '<div class="alert alert-danger">';
            echo '<i class="bi bi-x-circle-fill me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Test 3: Keyword Gap Analysis
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-3-circle text-primary me-2"></i>AI Keyword Gap Analysis</h4>';
        echo '<p class="text-muted">Using ChatGPT to identify keyword opportunities</p>';
        
        try {
            $gaps = $aiService->identifyKeywordGaps($testDomain, $testCompetitors, $testIndustry);
            
            echo '<div class="alert alert-success">';
            echo '<i class="bi bi-check-circle-fill me-2"></i>';
            echo '<strong>Success!</strong> ChatGPT identified ' . count($gaps) . ' keyword gaps';
            echo '</div>';
            
            echo '<h6>Top Opportunities:</h6>';
            echo '<pre>' . json_encode(array_slice($gaps, 0, 3), JSON_PRETTY_PRINT) . '</pre>';
        } catch (Exception $e) {
            echo '<div class="alert alert-danger">';
            echo '<i class="bi bi-x-circle-fill me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Test 4: Content Gap Analysis
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-4-circle text-primary me-2"></i>AI Content Gap Analysis</h4>';
        echo '<p class="text-muted">Using ChatGPT to discover content opportunities</p>';
        
        try {
            $contentGaps = $aiService->analyzeContentGaps($testDomain, $testCompetitors, $testIndustry);
            
            echo '<div class="alert alert-success">';
            echo '<i class="bi bi-check-circle-fill me-2"></i>';
            echo '<strong>Success!</strong> ChatGPT found ' . count($contentGaps) . ' content gaps';
            echo '</div>';
            
            echo '<h6>Content Opportunities:</h6>';
            echo '<pre>' . json_encode(array_slice($contentGaps, 0, 3), JSON_PRETTY_PRINT) . '</pre>';
        } catch (Exception $e) {
            echo '<div class="alert alert-danger">';
            echo '<i class="bi bi-x-circle-fill me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Test 5: Traffic Estimation
        echo '<div class="test-card">';
        echo '<h4><i class="bi bi-5-circle text-primary me-2"></i>AI Traffic Estimation</h4>';
        echo '<p class="text-muted">Using ChatGPT to estimate traffic trends</p>';
        
        try {
            $traffic = $aiService->estimateTrafficTrends('competitor1.com', $testIndustry);
            
            echo '<div class="alert alert-success">';
            echo '<i class="bi bi-check-circle-fill me-2"></i>';
            echo '<strong>Success!</strong> ChatGPT estimated traffic for ' . count($traffic['traffic_data']) . ' months';
            echo '<br><strong>Trend:</strong> ' . ucfirst($traffic['trend']);
            echo '<br><strong>Insights:</strong> ' . $traffic['insights'];
            echo '</div>';
            
            echo '<h6>Traffic Data:</h6>';
            echo '<pre>' . json_encode(array_slice($traffic['traffic_data'], 0, 3), JSON_PRETTY_PRINT) . '</pre>';
        } catch (Exception $e) {
            echo '<div class="alert alert-danger">';
            echo '<i class="bi bi-x-circle-fill me-2"></i>';
            echo '<strong>Error:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
        }
        echo '</div>';
        
        // Summary
        echo '<div class="test-card">';
        echo '<h3 class="text-center mb-4">🎉 Integration Summary</h3>';
        
        echo '<div class="alert alert-success">';
        echo '<h5><i class="bi bi-check-circle-fill me-2"></i>ChatGPT Integration Active!</h5>';
        echo '<p class="mb-2">Your Competitor SEO module is now powered by ChatGPT AI:</p>';
        echo '<ul class="mb-0">';
        echo '<li>✅ Intelligent competitor discovery</li>';
        echo '<li>✅ AI-powered keyword analysis</li>';
        echo '<li>✅ Smart keyword gap identification</li>';
        echo '<li>✅ Content opportunity detection</li>';
        echo '<li>✅ Traffic trend estimation</li>';
        echo '<li>✅ Comprehensive AI insights</li>';
        echo '</ul>';
        echo '</div>';
        
        echo '<div class="alert alert-info mt-3">';
        echo '<h6><i class="bi bi-info-circle me-2"></i>Using Your API Key</h6>';
        echo '<p class="mb-0">API Key: <code>' . substr(OPENAI_API_KEY, 0, 20) . '...</code><br>';
        echo 'Model: <strong>' . OPENAI_MODEL . '</strong><br>';
        echo 'Endpoint: <code>' . OPENAI_API_URL . '</code></p>';
        echo '</div>';
        
        echo '<div class="text-center mt-4">';
        echo '<a href="views/dashboard/competitor-seo.php" class="btn btn-primary btn-lg">';
        echo '<i class="bi bi-trophy me-2"></i>Launch Competitor SEO Module';
        echo '</a>';
        echo '</div>';
        
        echo '</div>';
        ?>

        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-outline-light me-2">
                <i class="bi bi-house"></i> Home
            </a>
            <a href="views/dashboard/index.php" class="btn btn-outline-light">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </div>
    </div>
</body>
</html>
