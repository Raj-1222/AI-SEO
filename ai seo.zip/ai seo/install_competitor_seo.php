<?php
/**
 * Competitor SEO Module Installation Script
 * This script sets up the database tables and verifies the module installation
 */

require_once __DIR__ . '/config/init.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Competitor SEO Module - Installation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        .install-container {
            max-width: 900px;
            margin: 0 auto;
        }
        .install-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            margin-bottom: 1.5rem;
        }
        .step-badge {
            width: 40px;
            height: 40px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            font-weight: bold;
            margin-right: 1rem;
        }
        .success-icon {
            color: #28a745;
            font-size: 1.5rem;
        }
        .error-icon {
            color: #dc3545;
            font-size: 1.5rem;
        }
        .warning-icon {
            color: #ffc107;
            font-size: 1.5rem;
        }
        .log-output {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 1rem;
            font-family: monospace;
            font-size: 0.875rem;
            max-height: 400px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="install-container">
        <div class="install-card text-center mb-4">
            <i class="bi bi-trophy text-warning" style="font-size: 4rem;"></i>
            <h1 class="mt-3">Competitor SEO Module</h1>
            <p class="text-muted">Installation & Verification</p>
        </div>

        <?php
        $db = getDBConnection();
        $errors = [];
        $warnings = [];
        $successes = [];

        // Step 1: Check database connection
        echo '<div class="install-card">';
        echo '<h4><span class="step-badge">1</span>Database Connection</h4>';
        
        if ($db) {
            echo '<p><i class="bi bi-check-circle-fill success-icon"></i> Database connection successful</p>';
            $successes[] = 'Database connected';
        } else {
            echo '<p><i class="bi bi-x-circle-fill error-icon"></i> Database connection failed</p>';
            $errors[] = 'Cannot connect to database';
        }
        echo '</div>';

        // Step 2: Install database tables
        if ($db) {
            echo '<div class="install-card">';
            echo '<h4><span class="step-badge">2</span>Database Tables Installation</h4>';
            echo '<div class="log-output">';
            
            $sqlFile = __DIR__ . '/database/competitor_seo_schema.sql';
            
            if (file_exists($sqlFile)) {
                $sql = file_get_contents($sqlFile);
                
                // Remove USE statement and comments
                $sql = preg_replace('/^USE.*?;/m', '', $sql);
                $sql = preg_replace('/^--.*$/m', '', $sql);
                
                // Split by semicolon and execute each statement
                $statements = array_filter(array_map('trim', explode(';', $sql)));
                
                $tableCount = 0;
                foreach ($statements as $statement) {
                    if (empty($statement)) continue;
                    
                    if (stripos($statement, 'CREATE TABLE') !== false) {
                        // Extract table name
                        preg_match('/CREATE TABLE IF NOT EXISTS\s+`?(\w+)`?/i', $statement, $matches);
                        $tableName = $matches[1] ?? 'unknown';
                        
                        if ($db->query($statement)) {
                            echo "✓ Table '$tableName' created/verified successfully<br>";
                            $tableCount++;
                        } else {
                            echo "✗ Error creating table '$tableName': " . $db->error . "<br>";
                            $errors[] = "Failed to create table: $tableName";
                        }
                    }
                }
                
                echo "</div>";
                echo "<p class='mt-3'><i class='bi bi-check-circle-fill success-icon'></i> $tableCount tables installed successfully</p>";
                $successes[] = "$tableCount database tables created";
            } else {
                echo "✗ Schema file not found: $sqlFile<br>";
                echo "</div>";
                $errors[] = 'Schema file missing';
            }
            echo '</div>';
        }

        // Step 3: Verify file structure
        echo '<div class="install-card">';
        echo '<h4><span class="step-badge">3</span>File Structure Verification</h4>';
        
        $requiredFiles = [
            'controllers/CompetitorSeoController.php' => 'Controller',
            'models/CompetitorSeo.php' => 'Model',
            'api/competitor-seo.php' => 'API Endpoint',
            'views/dashboard/competitor-seo.php' => 'Dashboard View',
            'assets/js/competitor-seo.js' => 'JavaScript',
            'assets/css/style.css' => 'Stylesheet'
        ];
        
        $fileCount = 0;
        foreach ($requiredFiles as $file => $description) {
            $fullPath = __DIR__ . '/' . $file;
            if (file_exists($fullPath)) {
                echo "<p><i class='bi bi-check-circle-fill success-icon'></i> $description: <code>$file</code></p>";
                $fileCount++;
            } else {
                echo "<p><i class='bi bi-x-circle-fill error-icon'></i> Missing $description: <code>$file</code></p>";
                $errors[] = "Missing file: $file";
            }
        }
        
        if ($fileCount === count($requiredFiles)) {
            $successes[] = 'All required files present';
        }
        echo '</div>';

        // Step 4: Check permissions and dependencies
        echo '<div class="install-card">';
        echo '<h4><span class="step-badge">4</span>Dependencies & Configuration</h4>';
        
        // Check if models directory is readable
        if (is_readable(__DIR__ . '/models')) {
            echo "<p><i class='bi bi-check-circle-fill success-icon'></i> Models directory is readable</p>";
        } else {
            echo "<p><i class='bi bi-x-circle-fill error-icon'></i> Models directory is not readable</p>";
            $errors[] = 'Models directory not readable';
        }
        
        // Check if API directory is readable
        if (is_readable(__DIR__ . '/api')) {
            echo "<p><i class='bi bi-check-circle-fill success-icon'></i> API directory is readable</p>";
        } else {
            echo "<p><i class='bi bi-x-circle-fill error-icon'></i> API directory is not readable</p>";
            $errors[] = 'API directory not readable';
        }
        
        // Check session
        if (session_status() === PHP_SESSION_ACTIVE) {
            echo "<p><i class='bi bi-check-circle-fill success-icon'></i> PHP sessions are enabled</p>";
        } else {
            echo "<p><i class='bi bi-warning-fill warning-icon'></i> PHP sessions may not be active</p>";
            $warnings[] = 'PHP sessions status unclear';
        }
        
        // Check if user is logged in
        if (isset($_SESSION['user_id'])) {
            echo "<p><i class='bi bi-check-circle-fill success-icon'></i> User session detected (User ID: {$_SESSION['user_id']})</p>";
        } else {
            echo "<p><i class='bi bi-info-circle-fill warning-icon'></i> No user logged in (optional for installation)</p>";
            $warnings[] = 'No user session found';
        }
        
        echo '</div>';

        // Step 5: Test API connectivity
        echo '<div class="install-card">';
        echo '<h4><span class="step-badge">5</span>API Connectivity Test</h4>';
        
        $apiUrl = SITE_URL . '/api/competitor-seo.php';
        echo "<p>API Endpoint: <code>$apiUrl</code></p>";
        
        if (file_exists(__DIR__ . '/api/competitor-seo.php')) {
            echo "<p><i class='bi bi-check-circle-fill success-icon'></i> API endpoint file exists</p>";
            echo "<p><i class='bi bi-info-circle'></i> API requires authentication. Test after logging in.</p>";
            $successes[] = 'API endpoint ready';
        } else {
            echo "<p><i class='bi bi-x-circle-fill error-icon'></i> API endpoint file not found</p>";
            $errors[] = 'API endpoint missing';
        }
        
        echo '</div>';

        // Final Summary
        echo '<div class="install-card">';
        echo '<h3 class="text-center mb-4">Installation Summary</h3>';
        
        echo '<div class="row text-center">';
        echo '<div class="col-md-4">';
        echo '<div class="p-3 border rounded bg-success bg-opacity-10">';
        echo '<i class="bi bi-check-circle-fill text-success" style="font-size: 2rem;"></i>';
        echo '<h4 class="mt-2">' . count($successes) . '</h4>';
        echo '<p class="text-muted mb-0">Successful</p>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="col-md-4">';
        echo '<div class="p-3 border rounded bg-warning bg-opacity-10">';
        echo '<i class="bi bi-exclamation-triangle-fill text-warning" style="font-size: 2rem;"></i>';
        echo '<h4 class="mt-2">' . count($warnings) . '</h4>';
        echo '<p class="text-muted mb-0">Warnings</p>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="col-md-4">';
        echo '<div class="p-3 border rounded bg-danger bg-opacity-10">';
        echo '<i class="bi bi-x-circle-fill text-danger" style="font-size: 2rem;"></i>';
        echo '<h4 class="mt-2">' . count($errors) . '</h4>';
        echo '<p class="text-muted mb-0">Errors</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
        if (count($errors) === 0) {
            echo '<div class="alert alert-success mt-4">';
            echo '<h5><i class="bi bi-check-circle-fill"></i> Installation Successful!</h5>';
            echo '<p class="mb-0">The Competitor SEO module has been installed successfully. You can now access it from the dashboard.</p>';
            echo '</div>';
            
            echo '<div class="text-center mt-4">';
            echo '<a href="views/dashboard/competitor-seo.php" class="btn btn-primary btn-lg">';
            echo '<i class="bi bi-trophy me-2"></i>Launch Competitor SEO';
            echo '</a>';
            echo '</div>';
        } else {
            echo '<div class="alert alert-danger mt-4">';
            echo '<h5><i class="bi bi-x-circle-fill"></i> Installation Issues Detected</h5>';
            echo '<p>Please resolve the following errors:</p>';
            echo '<ul>';
            foreach ($errors as $error) {
                echo "<li>$error</li>";
            }
            echo '</ul>';
            echo '</div>';
        }
        
        if (count($warnings) > 0) {
            echo '<div class="alert alert-warning mt-3">';
            echo '<h6><i class="bi bi-exclamation-triangle-fill"></i> Warnings:</h6>';
            echo '<ul class="mb-0">';
            foreach ($warnings as $warning) {
                echo "<li>$warning</li>";
            }
            echo '</ul>';
            echo '</div>';
        }
        
        echo '</div>';
        
        // Module Features Overview
        echo '<div class="install-card">';
        echo '<h4 class="text-center mb-4">Module Features</h4>';
        echo '<div class="row">';
        
        $features = [
            ['icon' => 'search', 'title' => 'Competitor Discovery', 'desc' => 'Find and identify your top competitors'],
            ['icon' => 'key', 'title' => 'Keyword Analysis', 'desc' => 'Analyze competitor keywords and find gaps'],
            ['icon' => 'file-text', 'title' => 'Content Gap', 'desc' => 'Discover content opportunities'],
            ['icon' => 'link-45deg', 'title' => 'Backlink Analysis', 'desc' => 'Analyze competitor backlink profiles'],
            ['icon' => 'graph-up', 'title' => 'Traffic Estimates', 'desc' => 'Estimate competitor traffic trends'],
            ['icon' => 'list-ol', 'title' => 'SERP Comparison', 'desc' => 'Compare search rankings'],
            ['icon' => 'trophy', 'title' => 'Top Pages', 'desc' => 'Identify top-performing pages'],
            ['icon' => 'code-square', 'title' => 'Meta Analysis', 'desc' => 'Analyze competitor meta tags'],
            ['icon' => 'file-earmark-text', 'title' => 'Content Analysis', 'desc' => 'Deep content strategy analysis'],
            ['icon' => 'eye', 'title' => 'Change Monitoring', 'desc' => 'Track competitor changes'],
            ['icon' => 'bar-chart', 'title' => 'AI Insights', 'desc' => 'Get AI-powered recommendations']
        ];
        
        foreach ($features as $feature) {
            echo '<div class="col-md-4 mb-3">';
            echo '<div class="d-flex align-items-start">';
            echo '<i class="bi bi-' . $feature['icon'] . ' text-primary me-3" style="font-size: 1.5rem;"></i>';
            echo '<div>';
            echo '<h6 class="mb-1">' . $feature['title'] . '</h6>';
            echo '<small class="text-muted">' . $feature['desc'] . '</small>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
        ?>

        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-outline-light">
                <i class="bi bi-house"></i> Back to Home
            </a>
            <a href="views/dashboard/index.php" class="btn btn-outline-light">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
