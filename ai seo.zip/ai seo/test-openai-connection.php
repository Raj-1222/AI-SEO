<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/init.php';

echo "<h1>OpenAI API Connection Test</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
    .success { background: #d4edda; padding: 15px; border-left: 4px solid #28a745; margin: 10px 0; }
    .error { background: #f8d7da; padding: 15px; border-left: 4px solid #dc3545; margin: 10px 0; }
    .info { background: #d1ecf1; padding: 15px; border-left: 4px solid #0c5460; margin: 10px 0; }
    pre { background: #fff; padding: 10px; border: 1px solid #ddd; overflow-x: auto; }
</style>";

// Test 1: Check API Key
echo "<h2>Test 1: API Key Configuration</h2>";
if (defined('OPENAI_API_KEY')) {
    $key = OPENAI_API_KEY;
    $keyPreview = substr($key, 0, 10) . '...' . substr($key, -4);
    echo "<div class='success'>✅ API Key Found: {$keyPreview}</div>";
    echo "<div class='info'>Key Length: " . strlen($key) . " characters</div>";
} else {
    echo "<div class='error'>❌ API Key NOT found in config</div>";
    die();
}

// Test 2: Check API URL
echo "<h2>Test 2: API URL Configuration</h2>";
if (defined('OPENAI_API_URL')) {
    echo "<div class='success'>✅ API URL: " . OPENAI_API_URL . "</div>";
} else {
    echo "<div class='error'>❌ API URL not configured</div>";
}

// Test 3: Check Model
echo "<h2>Test 3: Model Configuration</h2>";
$model = defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini';
echo "<div class='success'>✅ Model: {$model}</div>";

// Test 4: Simple API Call
echo "<h2>Test 4: Making API Call to OpenAI</h2>";
echo "<div class='info'>⏳ Sending request to OpenAI...</div>";

$url = OPENAI_API_URL;
$data = [
    'model' => $model,
    'messages' => [
        [
            'role' => 'system',
            'content' => 'You are a helpful assistant.'
        ],
        [
            'role' => 'user',
            'content' => 'Say "Hello from OpenAI!" in JSON format: {"message": "Hello from OpenAI!", "status": "success"}'
        ]
    ],
    'temperature' => 0.7,
    'max_tokens' => 100,
    'response_format' => ['type' => 'json_object']
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . OPENAI_API_KEY
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => true
]);

$startTime = microtime(true);
$response = curl_exec($ch);
$endTime = microtime(true);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
$curlInfo = curl_getinfo($ch);
curl_close($ch);

$responseTime = round(($endTime - $startTime) * 1000);

echo "<div class='info'>⏱️ Response Time: {$responseTime}ms</div>";
echo "<div class='info'>📊 HTTP Status Code: {$httpCode}</div>";

if ($curlError) {
    echo "<div class='error'>❌ CURL Error: {$curlError}</div>";
}

// Parse response
$result = json_decode($response, true);

if ($httpCode === 200) {
    echo "<div class='success'>✅ API Call Successful!</div>";
    
    if (isset($result['choices'][0]['message']['content'])) {
        $content = $result['choices'][0]['message']['content'];
        echo "<h3>Response Content:</h3>";
        echo "<pre>" . htmlspecialchars($content) . "</pre>";
        
        $parsed = json_decode($content, true);
        if ($parsed && isset($parsed['message'])) {
            echo "<div class='success'>✅ OpenAI is responding correctly!</div>";
            echo "<div class='success'>✅ Message: " . htmlspecialchars($parsed['message']) . "</div>";
        }
    }
    
    // Show usage
    if (isset($result['usage'])) {
        echo "<h3>Token Usage:</h3>";
        echo "<div class='info'>";
        echo "Prompt tokens: " . $result['usage']['prompt_tokens'] . "<br>";
        echo "Completion tokens: " . $result['usage']['completion_tokens'] . "<br>";
        echo "Total tokens: " . $result['usage']['total_tokens'] . "<br>";
        echo "Estimated cost: $" . number_format($result['usage']['total_tokens'] * 0.0000015, 6);
        echo "</div>";
    }
    
} else {
    echo "<div class='error'>❌ API Call Failed</div>";
    
    if ($result && isset($result['error'])) {
        echo "<h3>Error Details:</h3>";
        echo "<div class='error'>";
        echo "<strong>Type:</strong> " . ($result['error']['type'] ?? 'Unknown') . "<br>";
        echo "<strong>Message:</strong> " . ($result['error']['message'] ?? 'Unknown error') . "<br>";
        if (isset($result['error']['code'])) {
            echo "<strong>Code:</strong> " . $result['error']['code'] . "<br>";
        }
        echo "</div>";
        
        // Provide solutions
        echo "<h3>Possible Solutions:</h3>";
        if (strpos($result['error']['message'], 'insufficient_quota') !== false) {
            echo "<div class='info'>
                💡 <strong>Insufficient Quota:</strong><br>
                - Check billing at: <a href='https://platform.openai.com/account/billing' target='_blank'>OpenAI Billing</a><br>
                - Add credit to your account<br>
                - Verify your payment method is active
            </div>";
        }
        if (strpos($result['error']['message'], 'invalid_api_key') !== false) {
            echo "<div class='info'>
                💡 <strong>Invalid API Key:</strong><br>
                - Verify key at: <a href='https://platform.openai.com/api-keys' target='_blank'>OpenAI API Keys</a><br>
                - Generate a new key if needed<br>
                - Update config/database.php with the new key
            </div>";
        }
        if (strpos($result['error']['message'], 'rate_limit') !== false) {
            echo "<div class='info'>
                💡 <strong>Rate Limit:</strong><br>
                - Wait a few seconds and try again<br>
                - You're making requests too quickly<br>
                - Consider upgrading your OpenAI tier
            </div>";
        }
        if (strpos($result['error']['message'], 'model_not_found') !== false) {
            echo "<div class='info'>
                💡 <strong>Model Not Found:</strong><br>
                - Your account may not have access to {$model}<br>
                - Try using 'gpt-3.5-turbo' instead<br>
                - Update OPENAI_MODEL in config/database.php
            </div>";
        }
    }
    
    echo "<h3>Raw Response:</h3>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
}

// Test 5: Check database connection
echo "<h2>Test 5: Database Connection</h2>";
try {
    $conn = getDBConnection();
    if ($conn) {
        echo "<div class='success'>✅ Database Connected</div>";
        
        // Check tables
        $result = $conn->query("SHOW TABLES");
        $tableCount = $result->num_rows;
        echo "<div class='info'>📊 Database has {$tableCount} tables</div>";
        
        if ($tableCount >= 12) {
            echo "<div class='success'>✅ All required tables exist</div>";
        } else {
            echo "<div class='error'>⚠️ Missing some tables (expected 12, found {$tableCount})</div>";
        }
    }
} catch (Exception $e) {
    echo "<div class='error'>❌ Database Error: " . $e->getMessage() . "</div>";
}

// Summary
echo "<h2>📋 Summary</h2>";
if ($httpCode === 200) {
    echo "<div class='success'>";
    echo "<h3>✅ ALL SYSTEMS OPERATIONAL!</h3>";
    echo "<p>Your OpenAI API is working correctly. You can now:</p>";
    echo "<ul>";
    echo "<li>✅ Generate Keywords</li>";
    echo "<li>✅ Generate Meta Tags</li>";
    echo "<li>✅ Generate Blog Posts</li>";
    echo "<li>✅ Get AI Recommendations</li>";
    echo "</ul>";
    echo "<p><strong>Next:</strong> Go to your dashboard and start using the AI features!</p>";
    echo "<p><a href='views/dashboard/index.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Dashboard</a></p>";
    echo "</div>";
} else {
    echo "<div class='error'>";
    echo "<h3>❌ ISSUE DETECTED</h3>";
    echo "<p>There's an issue with the OpenAI API connection. Please review the error details above and follow the suggested solutions.</p>";
    echo "</div>";
}

echo "<hr>";
echo "<h2>🔗 Useful Links</h2>";
echo "<ul>";
echo "<li><a href='https://platform.openai.com/account/billing' target='_blank'>OpenAI Billing Dashboard</a></li>";
echo "<li><a href='https://platform.openai.com/usage' target='_blank'>OpenAI Usage Dashboard</a></li>";
echo "<li><a href='https://platform.openai.com/api-keys' target='_blank'>OpenAI API Keys</a></li>";
echo "<li><a href='https://status.openai.com/' target='_blank'>OpenAI Status Page</a></li>";
echo "</ul>";

echo "<p style='color: #666; font-size: 12px; margin-top: 30px;'>Test completed at: " . date('Y-m-d H:i:s') . "</p>";
?>
