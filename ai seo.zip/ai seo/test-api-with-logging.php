<?php
/**
 * Test Image Optimizer API with Detailed Logging
 * This simulates exactly what the JavaScript does
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Simulate logged-in user (change this to match your user ID)
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; // Change this to your actual user ID
    $_SESSION['username'] = 'test_user';
    $_SESSION['email'] = 'test@example.com';
    echo "<p style='background: yellow; padding: 10px;'>⚠️ Simulating logged-in user with ID = 1</p>";
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Test Image Optimizer API</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        .test { margin: 20px 0; padding: 15px; border: 2px solid #ddd; border-radius: 5px; }
        .success { background: #d4edda; border-color: #28a745; }
        .error { background: #f8d7da; border-color: #dc3545; }
        .info { background: #d1ecf1; border-color: #17a2b8; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; }
        button { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        button:hover { background: #0056b3; }
        #log { margin-top: 20px; max-height: 400px; overflow-y: auto; background: #000; color: #0f0; padding: 10px; font-family: monospace; font-size: 12px; }
        .log-entry { margin: 2px 0; }
        .log-error { color: #f00; }
        .log-success { color: #0f0; }
        .log-info { color: #0ff; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Test Image Optimizer API</h1>
        
        <div class="test info">
            <h3>Test 1: Upload Image</h3>
            <p>Select an image to test the upload functionality:</p>
            <input type="file" id="testImage" accept="image/*">
            <button onclick="testUpload()">Test Upload</button>
        </div>
        
        <div class="test info">
            <h3>Test 2: Get Statistics</h3>
            <button onclick="testStats()">Test Stats API</button>
        </div>
        
        <div class="test info">
            <h3>Test 3: Get History</h3>
            <button onclick="testHistory()">Test History API</button>
        </div>
        
        <div id="results"></div>
        
        <h3>Console Log:</h3>
        <div id="log"></div>
    </div>

    <script>
        const API_URL = 'api/image-optimizer.php';
        
        function log(message, type = 'info') {
            const logDiv = document.getElementById('log');
            const entry = document.createElement('div');
            entry.className = 'log-entry log-' + type;
            entry.textContent = new Date().toLocaleTimeString() + ' - ' + message;
            logDiv.appendChild(entry);
            logDiv.scrollTop = logDiv.scrollHeight;
            console.log(message);
        }
        
        function showResult(title, success, data) {
            const resultsDiv = document.getElementById('results');
            const resultHTML = `
                <div class="test ${success ? 'success' : 'error'}">
                    <h3>${success ? '✓' : '✗'} ${title}</h3>
                    <pre>${JSON.stringify(data, null, 2)}</pre>
                </div>
            `;
            resultsDiv.innerHTML = resultHTML + resultsDiv.innerHTML;
        }
        
        async function testStats() {
            log('Testing stats endpoint...', 'info');
            
            try {
                const response = await fetch(`${API_URL}?action=stats`);
                log('Response status: ' + response.status, 'info');
                
                const text = await response.text();
                log('Raw response: ' + text.substring(0, 200), 'info');
                
                try {
                    const data = JSON.parse(text);
                    log('JSON parsed successfully', 'success');
                    
                    if (data.success) {
                        log('Stats retrieved successfully', 'success');
                        showResult('Statistics API Test', true, data);
                    } else {
                        log('API returned error: ' + (data.message || 'Unknown'), 'error');
                        showResult('Statistics API Test', false, data);
                    }
                } catch (parseError) {
                    log('Failed to parse JSON: ' + parseError.message, 'error');
                    showResult('Statistics API Test', false, {error: 'Invalid JSON', response: text});
                }
                
            } catch (error) {
                log('Request failed: ' + error.message, 'error');
                showResult('Statistics API Test', false, {error: error.message});
            }
        }
        
        async function testHistory() {
            log('Testing history endpoint...', 'info');
            
            try {
                const response = await fetch(`${API_URL}?action=history&limit=10`);
                log('Response status: ' + response.status, 'info');
                
                const text = await response.text();
                log('Raw response length: ' + text.length + ' bytes', 'info');
                
                try {
                    const data = JSON.parse(text);
                    log('JSON parsed successfully', 'success');
                    
                    if (data.success) {
                        log('History retrieved: ' + (data.data ? data.data.length : 0) + ' records', 'success');
                        showResult('History API Test', true, data);
                    } else {
                        log('API returned error: ' + (data.message || 'Unknown'), 'error');
                        showResult('History API Test', false, data);
                    }
                } catch (parseError) {
                    log('Failed to parse JSON: ' + parseError.message, 'error');
                    showResult('History API Test', false, {error: 'Invalid JSON', response: text.substring(0, 500)});
                }
                
            } catch (error) {
                log('Request failed: ' + error.message, 'error');
                showResult('History API Test', false, {error: error.message});
            }
        }
        
        async function testUpload() {
            const fileInput = document.getElementById('testImage');
            
            if (!fileInput.files || fileInput.files.length === 0) {
                log('No file selected', 'error');
                alert('Please select an image file first');
                return;
            }
            
            const file = fileInput.files[0];
            log('Selected file: ' + file.name + ' (' + file.size + ' bytes, ' + file.type + ')', 'info');
            
            const formData = new FormData();
            formData.append('action', 'upload');
            formData.append('image', file);
            
            log('Sending upload request...', 'info');
            
            try {
                const response = await fetch(API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                log('Response status: ' + response.status, 'info');
                
                const text = await response.text();
                log('Raw response: ' + text.substring(0, 200), 'info');
                
                try {
                    const data = JSON.parse(text);
                    log('JSON parsed successfully', 'success');
                    
                    if (data.success) {
                        log('Upload successful! Filename: ' + data.data.filename, 'success');
                        showResult('Upload API Test', true, data);
                        
                        // Now try to compress it
                        setTimeout(() => testCompress(data.data.filename), 1000);
                    } else {
                        log('Upload failed: ' + (data.message || 'Unknown error'), 'error');
                        showResult('Upload API Test', false, data);
                    }
                } catch (parseError) {
                    log('Failed to parse JSON: ' + parseError.message, 'error');
                    showResult('Upload API Test', false, {error: 'Invalid JSON', response: text});
                }
                
            } catch (error) {
                log('Upload request failed: ' + error.message, 'error');
                showResult('Upload API Test', false, {error: error.message});
            }
        }
        
        async function testCompress(filename) {
            log('Testing compression on: ' + filename, 'info');
            
            const formData = new FormData();
            formData.append('action', 'compress');
            formData.append('filename', filename);
            formData.append('quality', 85);
            formData.append('compression_type', 'medium');
            
            try {
                const response = await fetch(API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                log('Compress response status: ' + response.status, 'info');
                
                const text = await response.text();
                log('Raw response: ' + text.substring(0, 200), 'info');
                
                try {
                    const data = JSON.parse(text);
                    log('JSON parsed successfully', 'success');
                    
                    if (data.success) {
                        log('Compression successful!', 'success');
                        log('Original: ' + data.data.original_size + ' bytes', 'info');
                        log('Optimized: ' + data.data.optimized_size + ' bytes', 'info');
                        log('Saved: ' + data.data.compression_ratio + '%', 'success');
                        showResult('Compression API Test', true, data);
                    } else {
                        log('Compression failed: ' + (data.message || 'Unknown error'), 'error');
                        showResult('Compression API Test', false, data);
                    }
                } catch (parseError) {
                    log('Failed to parse JSON: ' + parseError.message, 'error');
                    showResult('Compression API Test', false, {error: 'Invalid JSON', response: text});
                }
                
            } catch (error) {
                log('Compress request failed: ' + error.message, 'error');
                showResult('Compression API Test', false, {error: error.message});
            }
        }
        
        // Auto-test stats on load
        window.onload = function() {
            log('Page loaded, ready for testing', 'info');
            log('API URL: ' + API_URL, 'info');
        };
    </script>
</body>
</html>
