<?php
session_start();
require_once 'config/database.php';

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: views/auth/login.php');
    exit();
}

// Redirect to dashboard if authenticated
header('Location: views/dashboard/index.php');
exit();
