<?php
/**
 * Image Optimizer Diagnostic Tool
 * Check what's wrong with the image optimizer module
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Image Optimizer Diagnostic</h1>";
echo "<style>
body { font-family: Arial, sans-serif; max-width: 900px; margin: 20px auto; padding: 20px; }
.success { color: green; font-weight: bold; }
.error { color: red; font-weight: bold; }
.warning { color: orange; font-weight: bold; }
h2 { background: #0B1F4D; color: white; padding: 10px; margin-top: 20px; }
pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
</style>";

// Test 1: Check if config files exist
echo "<h2>1. Checking Configuration Files</h2>";

$files = [
    'config/init.php',
    'config/image_optimizer_config.php',
    'controllers/ImageProcessorController.php',
    'models/ImageHistory.php',
    'api/image-optimizer.php',
    'views/dashboard/image-optimizer.php',
    'assets/css/image-optimizer.css',
    'assets/js/image-optimizer.js'
];

foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        echo "✅ <span class='success'>Found:</span> $file<br>";
    } else {
        echo "❌ <span class='error'>Missing:</span> $file<br>";
    }
}

// Test 2: Check PHP extensions
echo "<h2>2. Checking PHP Extensions</h2>";

$extensions = [
    'pdo_mysql' => 'Required',
    'fileinfo' => 'Required',
    'zip' => 'Required',
    'imagick' => 'Optional (Preferred)',
    'gd' => 'Optional (Fallback)'
];

foreach ($extensions as $ext => $type) {
    if (extension_loaded($ext)) {
        echo "✅ <span class='success'>$ext:</span> Installed ($type)<br>";
    } else {
        $class = ($type === 'Required') ? 'error' : 'warning';
        echo "❌ <span class='$class'>$ext:</span> Not Installed ($type)<br>";
    }
}

// Test 3: Check database connection
echo "<h2>3. Checking Database Connection</h2>";

try {
    require_once __DIR__ . '/config/init.php';
    $db = getDBConnection();
    echo "✅ <span class='success'>Database connection:</span> OK<br>";
    
    // Check tables
    echo "<h3>Database Tables:</h3>";
    $tables = [
        'image_optimizer_settings',
        'image_processing_history',
        'image_optimizer_stats',
        'image_batch_queue',
        'watermark_templates',
        'image_resize_presets',
        'image_download_log',
        'image_seo_scores'
    ];
    
    foreach ($tables as $table) {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "✅ <span class='success'>$table:</span> Exists<br>";
        } else {
            echo "❌ <span class='error'>$table:</span> Missing<br>";
            echo "<p class='warning'>⚠️ Please run: database/image_optimizer_schema.sql</p>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ <span class='error'>Database connection failed:</span> " . $e->getMessage() . "<br>";
}

// Test 4: Check directories
echo "<h2>4. Checking Directories</h2>";

$dirs = [
    'uploads',
    'uploads/images',
    'uploads/images/original',
    'uploads/images/optimized',
    'uploads/images/watermarks',
    'uploads/images/temp',
    'downloads',
    'downloads/images'
];

foreach ($dirs as $dir) {
    $path = __DIR__ . '/' . $dir;
    if (file_exists($path)) {
        if (is_writable($path)) {
            echo "✅ <span class='success'>$dir:</span> Exists and writable<br>";
        } else {
            echo "⚠️ <span class='warning'>$dir:</span> Exists but NOT writable<br>";
            echo "<p>Run: <code>chmod 755 $path</code></p>";
        }
    } else {
        echo "❌ <span class='error'>$dir:</span> Does not exist<br>";
        echo "<p>Creating directory...</p>";
        if (mkdir($path, 0755, true)) {
            echo "✅ <span class='success'>Created successfully!</span><br>";
        } else {
            echo "❌ <span class='error'>Failed to create</span><br>";
        }
    }
}

// Test 5: Check if image optimizer config loads
echo "<h2>5. Testing Image Optimizer Configuration</h2>";

try {
    require_once __DIR__ . '/config/image_optimizer_config.php';
    echo "✅ <span class='success'>Config loaded successfully</span><br>";
    echo "Max Upload Size: " . formatBytes(IMG_MAX_UPLOAD_SIZE) . "<br>";
    echo "Default Quality: " . IMG_DEFAULT_QUALITY . "%<br>";
    echo "Default Format: " . IMG_DEFAULT_FORMAT . "<br>";
    echo "Using Library: " . IMG_LIBRARY . "<br>";
} catch (Exception $e) {
    echo "❌ <span class='error'>Config error:</span> " . $e->getMessage() . "<br>";
}

// Test 6: Test image processing
echo "<h2>6. Testing Image Processing</h2>";

try {
    if (extension_loaded('imagick')) {
        $test = new Imagick();
        echo "✅ <span class='success'>Imagick test:</span> Passed<br>";
        $test->clear();
        $test->destroy();
    } elseif (extension_loaded('gd')) {
        $test = imagecreatetruecolor(100, 100);
        if ($test) {
            echo "✅ <span class='success'>GD Library test:</span> Passed<br>";
            imagedestroy($test);
        } else {
            echo "❌ <span class='error'>GD Library test:</span> Failed<br>";
        }
    } else {
        echo "❌ <span class='error'>No image library available!</span><br>";
        echo "<p>Please install Imagick or ensure GD is enabled.</p>";
    }
} catch (Exception $e) {
    echo "❌ <span class='error'>Image processing test failed:</span> " . $e->getMessage() . "<br>";
}

// Test 7: Check API endpoint
echo "<h2>7. Testing API Endpoint</h2>";

if (file_exists(__DIR__ . '/api/image-optimizer.php')) {
    echo "✅ <span class='success'>API file exists</span><br>";
    
    // Test if we can include it (syntax check)
    try {
        $apiContent = file_get_contents(__DIR__ . '/api/image-optimizer.php');
        if (strpos($apiContent, '<?php') !== false) {
            echo "✅ <span class='success'>API file syntax looks OK</span><br>";
        }
    } catch (Exception $e) {
        echo "❌ <span class='error'>API file has errors:</span> " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ <span class='error'>API file missing!</span><br>";
}

// Test 8: Check JavaScript file
echo "<h2>8. Checking Frontend Assets</h2>";

if (file_exists(__DIR__ . '/assets/js/image-optimizer.js')) {
    echo "✅ <span class='success'>JavaScript file exists</span><br>";
} else {
    echo "❌ <span class='error'>JavaScript file missing!</span><br>";
}

if (file_exists(__DIR__ . '/assets/css/image-optimizer.css')) {
    echo "✅ <span class='success'>CSS file exists</span><br>";
} else {
    echo "❌ <span class='error'>CSS file missing!</span><br>";
}

// Test 9: Check session
echo "<h2>9. Checking Session</h2>";

if (session_status() === PHP_SESSION_ACTIVE) {
    echo "✅ <span class='success'>Session is active</span><br>";
    if (isset($_SESSION['user_id'])) {
        echo "✅ <span class='success'>User is logged in (ID: " . $_SESSION['user_id'] . ")</span><br>";
    } else {
        echo "⚠️ <span class='warning'>User not logged in</span><br>";
    }
} else {
    echo "❌ <span class='error'>Session not active</span><br>";
}

// Summary
echo "<h2>📋 Summary & Next Steps</h2>";

echo "<div style='background: #e8f4f8; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<h3>Common Issues & Solutions:</h3>";
echo "<ol>";
echo "<li><strong>Missing Database Tables:</strong> Run <code>database/image_optimizer_schema.sql</code> in phpMyAdmin</li>";
echo "<li><strong>Directory Not Writable:</strong> Run <code>chmod 755</code> on upload directories</li>";
echo "<li><strong>No Image Library:</strong> Install Imagick or enable GD extension</li>";
echo "<li><strong>Page Not Loading:</strong> Check PHP error logs for specific errors</li>";
echo "<li><strong>Upload Fails:</strong> Check php.ini: upload_max_filesize and post_max_size</li>";
echo "</ol>";
echo "</div>";

echo "<div style='background: #f0f0f0; padding: 15px; border-radius: 5px;'>";
echo "<h3>Quick Fix Commands:</h3>";
echo "<pre>";
echo "# Create and set permissions for directories\n";
echo "mkdir -p uploads/images/original uploads/images/optimized uploads/images/watermarks uploads/images/temp downloads/images\n";
echo "chmod -R 755 uploads/ downloads/\n\n";

echo "# Import database schema\n";
echo "mysql -u username -p database_name < database/image_optimizer_schema.sql\n\n";

echo "# Check PHP extensions\n";
echo "php -m | grep imagick\n";
echo "php -m | grep gd\n";
echo "</pre>";
echo "</div>";

echo "<hr>";
echo "<p><strong>After fixing issues, visit:</strong> <a href='views/dashboard/image-optimizer.php'>Image Optimizer Dashboard</a></p>";
echo "<p><em>Run this diagnostic again after making changes to verify fixes.</em></p>";

function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB'];
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>
