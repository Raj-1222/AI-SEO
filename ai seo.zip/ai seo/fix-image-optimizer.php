<?php
/**
 * Quick Fix Script for Image Optimizer
 * This will automatically fix common issues
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔧 Image Optimizer Quick Fix</h1>";
echo "<style>
body { font-family: Arial, sans-serif; max-width: 900px; margin: 20px auto; padding: 20px; background: #f5f5f5; }
.box { background: white; padding: 20px; border-radius: 10px; margin: 20px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
.success { color: green; font-weight: bold; }
.error { color: red; font-weight: bold; }
.warning { color: orange; font-weight: bold; }
h2 { color: #0B1F4D; border-bottom: 3px solid #FF6B00; padding-bottom: 10px; }
.btn { display: inline-block; padding: 10px 20px; background: #FF6B00; color: white; text-decoration: none; border-radius: 5px; margin: 5px; }
.btn:hover { background: #E55F00; }
</style>";

// Fix 1: Create Directories
echo "<div class='box'>";
echo "<h2>1️⃣ Creating Required Directories</h2>";

$dirs = [
    'uploads',
    'uploads/images',
    'uploads/images/original',
    'uploads/images/optimized',
    'uploads/images/watermarks',
    'uploads/images/temp',
    'downloads',
    'downloads/images'
];

$allDirsOK = true;

foreach ($dirs as $dir) {
    $path = __DIR__ . '/' . $dir;
    
    if (!file_exists($path)) {
        if (mkdir($path, 0755, true)) {
            echo "✅ <span class='success'>Created:</span> $dir<br>";
            
            // Add .htaccess
            $htaccess = $path . '/.htaccess';
            file_put_contents($htaccess, "Options -Indexes\nOrder Deny,Allow\nAllow from all");
            
            // Add index.php
            $index = $path . '/index.php';
            file_put_contents($index, "<?php\n// Directory access denied\nheader('HTTP/1.0 403 Forbidden');\nexit();");
        } else {
            echo "❌ <span class='error'>Failed to create:</span> $dir<br>";
            $allDirsOK = false;
        }
    } else {
        if (is_writable($path)) {
            echo "✅ <span class='success'>OK:</span> $dir (writable)<br>";
        } else {
            echo "⚠️ <span class='warning'>Warning:</span> $dir exists but not writable<br>";
            // Try to fix permissions
            if (@chmod($path, 0755)) {
                echo "✅ <span class='success'>Fixed permissions</span><br>";
            } else {
                echo "❌ <span class='error'>Cannot fix permissions - do it manually</span><br>";
                $allDirsOK = false;
            }
        }
    }
}

if ($allDirsOK) {
    echo "<p class='success'>✅ All directories are ready!</p>";
} else {
    echo "<p class='error'>⚠️ Some directories need manual attention</p>";
}
echo "</div>";

// Fix 2: Check Database
echo "<div class='box'>";
echo "<h2>2️⃣ Checking Database Tables</h2>";

try {
    require_once __DIR__ . '/config/init.php';
    $db = getDBConnection();
    echo "✅ <span class='success'>Database connected</span><br><br>";
    
    $tables = [
        'image_optimizer_settings',
        'image_processing_history',
        'image_optimizer_stats',
        'image_batch_queue',
        'watermark_templates',
        'image_resize_presets',
        'image_download_log',
        'image_seo_scores'
    ];
    
    $missingTables = [];
    
    foreach ($tables as $table) {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "✅ <span class='success'>$table</span><br>";
        } else {
            echo "❌ <span class='error'>$table</span> - MISSING<br>";
            $missingTables[] = $table;
        }
    }
    
    if (!empty($missingTables)) {
        echo "<br><div style='background: #fff3cd; padding: 15px; border-radius: 5px; border-left: 4px solid #ffc107;'>";
        echo "<strong>⚠️ Database tables are missing!</strong><br><br>";
        echo "<strong>Quick Fix:</strong><br>";
        echo "1. Go to phpMyAdmin<br>";
        echo "2. Select your database: <code>" . DB_NAME . "</code><br>";
        echo "3. Click 'Import' tab<br>";
        echo "4. Upload file: <code>database/image_optimizer_schema.sql</code><br>";
        echo "5. Click 'Go' button<br><br>";
        echo "<strong>Or run this command:</strong><br>";
        echo "<code>mysql -u " . DB_USER . " -p " . DB_NAME . " < database/image_optimizer_schema.sql</code>";
        echo "</div>";
    } else {
        echo "<br><p class='success'>✅ All database tables exist!</p>";
    }
    
} catch (Exception $e) {
    echo "❌ <span class='error'>Database error:</span> " . $e->getMessage() . "<br>";
    echo "<p>Please check your database configuration in <code>config/database.php</code></p>";
}

echo "</div>";

// Fix 3: Check PHP Extensions
echo "<div class='box'>";
echo "<h2>3️⃣ Checking PHP Extensions</h2>";

$required = ['pdo_mysql', 'fileinfo', 'zip'];
$optional = ['imagick', 'gd'];

$allExtOK = true;

echo "<strong>Required Extensions:</strong><br>";
foreach ($required as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ <span class='success'>$ext</span><br>";
    } else {
        echo "❌ <span class='error'>$ext</span> - NOT INSTALLED<br>";
        $allExtOK = false;
    }
}

echo "<br><strong>Image Processing (need at least one):</strong><br>";
$hasImageLib = false;
foreach ($optional as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ <span class='success'>$ext</span><br>";
        $hasImageLib = true;
    } else {
        echo "⚠️ <span class='warning'>$ext</span> - Not installed<br>";
    }
}

if (!$hasImageLib) {
    echo "<br><div style='background: #f8d7da; padding: 15px; border-radius: 5px; border-left: 4px solid #dc3545;'>";
    echo "<strong>❌ Critical: No image processing library!</strong><br><br>";
    echo "Install Imagick (recommended) or enable GD:<br>";
    echo "<code>sudo apt-get install php-imagick</code><br>";
    echo "Then restart Apache/PHP-FPM";
    echo "</div>";
    $allExtOK = false;
} else {
    echo "<br><p class='success'>✅ Image processing available!</p>";
}

echo "</div>";

// Fix 4: Check Files
echo "<div class='box'>";
echo "<h2>4️⃣ Checking Module Files</h2>";

$files = [
    'config/image_optimizer_config.php' => 'Configuration',
    'controllers/ImageProcessorController.php' => 'Image Processor',
    'models/ImageHistory.php' => 'Database Model',
    'api/image-optimizer.php' => 'API Endpoint',
    'views/dashboard/image-optimizer.php' => 'Dashboard View',
    'assets/css/image-optimizer.css' => 'Styles',
    'assets/js/image-optimizer.js' => 'JavaScript'
];

$allFilesOK = true;

foreach ($files as $file => $desc) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        echo "✅ <span class='success'>$desc</span> - $file<br>";
    } else {
        echo "❌ <span class='error'>$desc</span> - $file MISSING<br>";
        $allFilesOK = false;
    }
}

if (!$allFilesOK) {
    echo "<br><p class='error'>⚠️ Some files are missing. Please ensure all files are uploaded.</p>";
}

echo "</div>";

// Summary
echo "<div class='box' style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;'>";
echo "<h2 style='color: white; border-bottom: 3px solid white;'>📋 Summary</h2>";

$issues = 0;

if (!$allDirsOK) {
    echo "❌ Directory issues detected<br>";
    $issues++;
}

if (!empty($missingTables)) {
    echo "❌ Database tables missing<br>";
    $issues++;
}

if (!$allExtOK) {
    echo "❌ PHP extensions missing<br>";
    $issues++;
}

if (!$allFilesOK) {
    echo "❌ Module files missing<br>";
    $issues++;
}

if ($issues === 0) {
    echo "<h3>🎉 Everything looks good!</h3>";
    echo "<p>Your Image Optimizer should be working now!</p>";
    echo "<br>";
    echo "<a href='views/dashboard/image-optimizer.php' class='btn' style='background: white; color: #0B1F4D;'>
        🚀 Go to Image Optimizer
    </a>";
} else {
    echo "<h3>⚠️ Found $issues issue(s)</h3>";
    echo "<p>Please fix the issues above, then run this script again to verify.</p>";
}

echo "</div>";

// Additional Help
echo "<div class='box'>";
echo "<h2>🆘 Need More Help?</h2>";
echo "<ul>";
echo "<li><a href='test-image-optimizer.php' class='btn'>Run Detailed Diagnostic</a></li>";
echo "<li><a href='install_image_optimizer.php' class='btn'>Run Installation Checker</a></li>";
echo "<li><a href='IMAGE_OPTIMIZER_GUIDE.md' class='btn'>Read Full Guide</a></li>";
echo "</ul>";

echo "<h3>Common Solutions:</h3>";
echo "<ol>";
echo "<li><strong>Can't create directories?</strong> Run: <code>chmod 755 uploads downloads</code></li>";
echo "<li><strong>Database tables missing?</strong> Import <code>database/image_optimizer_schema.sql</code></li>";
echo "<li><strong>Imagick not available?</strong> Install: <code>sudo apt-get install php-imagick</code></li>";
echo "<li><strong>Page shows blank?</strong> Check PHP error log: <code>tail -f /var/log/php_errors.log</code></li>";
echo "</ol>";

echo "<h3>Quick Commands:</h3>";
echo "<pre style='background: #2d2d2d; color: #f8f8f2; padding: 15px; border-radius: 5px;'>";
echo "# Fix directory permissions\n";
echo "chmod -R 755 uploads/ downloads/\n\n";
echo "# Import database schema\n";
echo "mysql -u " . (defined('DB_USER') ? DB_USER : 'username') . " -p " . (defined('DB_NAME') ? DB_NAME : 'database') . " < database/image_optimizer_schema.sql\n\n";
echo "# Check PHP extensions\n";
echo "php -m | grep imagick\n";
echo "php -m | grep gd\n\n";
echo "# View PHP error log\n";
echo "tail -f /var/log/php_errors.log";
echo "</pre>";

echo "</div>";

echo "<hr>";
echo "<p style='text-align: center;'><em>Fix Script completed at " . date('Y-m-d H:i:s') . "</em></p>";
?>
