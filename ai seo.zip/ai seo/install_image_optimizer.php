<?php
/**
 * Image Optimizer Installation Script
 * Run this file once to set up the Image Optimization Suite
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Image Optimizer Installation</h1>";
echo "<p>Starting installation process...</p><hr>";

// Step 1: Check PHP version
echo "<h3>Step 1: Checking PHP Version</h3>";
if (version_compare(PHP_VERSION, '8.0.0', '>=')) {
    echo "✅ PHP Version: " . PHP_VERSION . " (OK)<br>";
} else {
    echo "❌ PHP Version: " . PHP_VERSION . " (Requires 8.0+)<br>";
    die("Installation aborted.");
}

// Step 2: Check required PHP extensions
echo "<h3>Step 2: Checking PHP Extensions</h3>";
$requiredExtensions = ['pdo_mysql', 'fileinfo', 'zip'];
$optionalExtensions = ['imagick', 'gd'];

foreach ($requiredExtensions as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ $ext: Installed<br>";
    } else {
        echo "❌ $ext: NOT INSTALLED (REQUIRED)<br>";
        die("Installation aborted. Please install $ext extension.");
    }
}

$hasImageLibrary = false;
foreach ($optionalExtensions as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ $ext: Installed<br>";
        $hasImageLibrary = true;
    } else {
        echo "⚠️  $ext: Not installed (optional)<br>";
    }
}

if (!$hasImageLibrary) {
    die("❌ No image processing library found. Please install either Imagick or GD extension.");
}

// Step 3: Create directories
echo "<h3>Step 3: Creating Directories</h3>";
$directories = [
    'uploads',
    'uploads/images',
    'uploads/images/original',
    'uploads/images/optimized',
    'uploads/images/watermarks',
    'uploads/images/temp',
    'downloads',
    'downloads/images'
];

foreach ($directories as $dir) {
    $path = __DIR__ . '/' . $dir;
    if (!file_exists($path)) {
        if (mkdir($path, 0755, true)) {
            echo "✅ Created: $dir<br>";
        } else {
            echo "❌ Failed to create: $dir<br>";
        }
    } else {
        echo "ℹ️  Already exists: $dir<br>";
    }
    
    // Add .htaccess for security
    $htaccess = $path . '/.htaccess';
    if (!file_exists($htaccess)) {
        $content = "Options -Indexes\nOrder Deny,Allow\nAllow from all";
        file_put_contents($htaccess, $content);
        echo "✅ Added .htaccess to: $dir<br>";
    }
}

// Step 4: Check database connection
echo "<h3>Step 4: Checking Database Connection</h3>";
require_once __DIR__ . '/config/init.php';

try {
    $db = getDBConnection();
    echo "✅ Database connection successful<br>";
    
    // Check if tables exist
    $tables = [
        'image_optimizer_settings',
        'image_processing_history',
        'image_optimizer_stats',
        'image_batch_queue',
        'watermark_templates',
        'image_resize_presets',
        'image_download_log',
        'image_seo_scores'
    ];
    
    echo "<h4>Checking Tables:</h4>";
    foreach ($tables as $table) {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "✅ Table exists: $table<br>";
        } else {
            echo "❌ Table missing: $table<br>";
            echo "⚠️  Please run database/image_optimizer_schema.sql<br>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "<br>";
    echo "Please check your database configuration in config/database.php<br>";
}

// Step 5: Check file permissions
echo "<h3>Step 5: Checking File Permissions</h3>";
$checkDirs = [
    'uploads/images/original',
    'uploads/images/optimized',
    'downloads/images'
];

foreach ($checkDirs as $dir) {
    $path = __DIR__ . '/' . $dir;
    if (is_writable($path)) {
        echo "✅ Writable: $dir<br>";
    } else {
        echo "❌ Not writable: $dir<br>";
        echo "⚠️  Run: chmod 755 $dir<br>";
    }
}

// Step 6: Check configuration
echo "<h3>Step 6: Checking Configuration</h3>";
require_once __DIR__ . '/config/image_optimizer_config.php';

echo "Max Upload Size: " . formatBytes(IMG_MAX_UPLOAD_SIZE) . "<br>";
echo "Default Quality: " . IMG_DEFAULT_QUALITY . "%<br>";
echo "Default Format: " . IMG_DEFAULT_FORMAT . "<br>";
echo "Using Library: " . IMG_LIBRARY . "<br>";
echo "Memory Limit: " . IMG_MEMORY_LIMIT . "<br>";
echo "Max Execution Time: " . IMG_MAX_EXECUTION_TIME . "s<br>";

// Step 7: Test image processing
echo "<h3>Step 7: Testing Image Processing</h3>";
try {
    if (IMG_HAS_IMAGICK) {
        $test = new Imagick();
        echo "✅ Imagick test successful<br>";
        $test->clear();
        $test->destroy();
    } else if (IMG_HAS_GD) {
        $test = imagecreatetruecolor(100, 100);
        if ($test) {
            echo "✅ GD Library test successful<br>";
            imagedestroy($test);
        } else {
            echo "❌ GD Library test failed<br>";
        }
    }
} catch (Exception $e) {
    echo "❌ Image processing test failed: " . $e->getMessage() . "<br>";
}

// Final summary
echo "<hr><h3>Installation Summary</h3>";
echo "<p><strong>Status:</strong> ";

$allGood = $hasImageLibrary && isset($db);
if ($allGood) {
    echo "✅ <span style='color: green; font-size: 20px;'>READY TO USE!</span></p>";
    echo "<p>Navigate to: <a href='views/dashboard/image-optimizer.php'>Image Optimizer Dashboard</a></p>";
} else {
    echo "⚠️  <span style='color: orange; font-size: 20px;'>NEEDS ATTENTION</span></p>";
    echo "<p>Please resolve the issues above before using the Image Optimizer.</p>";
}

echo "<hr>";
echo "<p><strong>Next Steps:</strong></p>";
echo "<ol>";
echo "<li>If database tables are missing, run: <code>database/image_optimizer_schema.sql</code></li>";
echo "<li>Ensure all directories have proper permissions (755)</li>";
echo "<li>Test upload functionality with a small image</li>";
echo "<li>Review configuration in: <code>config/image_optimizer_config.php</code></li>";
echo "<li>Delete this installation file for security: <code>install_image_optimizer.php</code></li>";
echo "</ol>";

echo "<hr>";
echo "<p><em>Installation completed at: " . date('Y-m-d H:i:s') . "</em></p>";

/**
 * Helper function
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB'];
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>

<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        max-width: 900px;
        margin: 50px auto;
        padding: 20px;
        background: #f5f5f5;
    }
    h1 {
        color: #0B1F4D;
        border-bottom: 3px solid #FF6B00;
        padding-bottom: 10px;
    }
    h3 {
        color: #0B1F4D;
        margin-top: 30px;
        background: white;
        padding: 10px 15px;
        border-left: 4px solid #FF6B00;
    }
    code {
        background: #2d2d2d;
        color: #f8f8f2;
        padding: 2px 6px;
        border-radius: 3px;
    }
    a {
        color: #FF6B00;
        text-decoration: none;
        font-weight: bold;
    }
    a:hover {
        text-decoration: underline;
    }
</style>
