<?php
/**
 * Real API Test - Simulates Exact Dashboard Call
 */
session_start();
require_once __DIR__ . '/config/database.php';

// Enable detailed error logging
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Simulate being logged in (use actual user ID if you know it)
if (!isset($_SESSION['user_id'])) {
    // For testing, set a dummy user ID
    $_SESSION['user_id'] = 1;
}

// Load the actual controller
require_once __DIR__ . '/controllers/KeywordGeneratorController.php';

// Make the exact same call as dashboard would
$controller = new KeywordGeneratorController();

$testData = [
    'website_url' => 'https://webcolumn.netlify.app',
    'industry' => 'digital marketing',
    'location' => 'india'
];

echo json_encode([
    'test' => 'Real API Call Test',
    'session_user_id' => $_SESSION['user_id'],
    'api_key_configured' => !empty(OPENAI_API_KEY) && OPENAI_API_KEY !== 'YOUR_OPENAI_API_KEY_HERE',
    'test_data' => $testData,
    'calling_api' => 'Starting API call...'
]) . "\n\n";

// Flush to show progress
flush();

// Now make the actual call
$startTime = microtime(true);
$result = $controller->generateKeywords(
    $testData['website_url'],
    $testData['industry'],
    $testData['location']
);
$endTime = microtime(true);
$duration = round($endTime - $startTime, 2);

echo json_encode([
    'duration_seconds' => $duration,
    'result' => $result,
    'success' => $result['success'] ?? false,
    'has_keywords' => isset($result['primary_keywords']),
    'error_if_any' => $result['message'] ?? null
], JSON_PRETTY_PRINT);
