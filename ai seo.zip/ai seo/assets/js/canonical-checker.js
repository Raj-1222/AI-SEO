/**
 * Canonical URL Checker - JavaScript
 * Handles canonical URL analysis with AI-powered recommendations
 */

let currentResults = [];
let currentFilter = 'all';

document.addEventListener('DOMContentLoaded', function() {
    initializeCanonicalChecker();
});

function initializeCanonicalChecker() {
    const form = document.getElementById('canonicalForm');
    const filterButtons = {
        all: document.getElementById('filterAll'),
        missing: document.getElementById('filterMissing'),
        incorrect: document.getElementById('filterIncorrect'),
        correct: document.getElementById('filterCorrect')
    };
    
    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        checkCanonicalURLs();
    });
    
    // Filter buttons
    Object.keys(filterButtons).forEach(key => {
        if (filterButtons[key]) {
            filterButtons[key].addEventListener('click', () => filterResults(key));
        }
    });
    
    // Export buttons
    document.getElementById('downloadReportBtn')?.addEventListener('click', downloadReport);
    document.getElementById('exportCSVBtn')?.addEventListener('click', exportCSV);
    document.getElementById('generateFixesBtn')?.addEventListener('click', generateFixCode);
}

async function checkCanonicalURLs() {
    const urlInput = document.getElementById('urlInput').value.trim();
    const crawlSitemap = document.getElementById('crawlSitemap').checked;
    const aiLevel = document.getElementById('aiLevel').value;
    
    if (!urlInput) {
        showNotification('Please enter at least one URL', 'error');
        return;
    }
    
    // Parse URLs
    const urls = urlInput.split('\n')
        .map(url => url.trim())
        .filter(url => url && isValidURL(url));
    
    if (urls.length === 0) {
        showNotification('Please enter valid URLs', 'error');
        return;
    }
    
    // Show loading
    showLoading(true);
    document.getElementById('resultsSection').style.display = 'none';
    
    try {
        // Send to API
        const response = await fetch('../../api/canonical-checker.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                urls: urls,
                crawl_sitemap: crawlSitemap,
                ai_level: aiLevel
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentResults = data.results;
            displayResults(data);
            showLoading(false);
            document.getElementById('resultsSection').style.display = 'block';
            
            // Scroll to results
            document.getElementById('resultsSection').scrollIntoView({ 
                behavior: 'smooth', 
                block: 'start' 
            });
        } else {
            throw new Error(data.message || 'Analysis failed');
        }
        
    } catch (error) {
        console.error('Error:', error);
        showNotification(error.message, 'error');
        showLoading(false);
    }
}

function displayResults(data) {
    // Update summary cards
    document.getElementById('totalChecked').textContent = data.summary.total || 0;
    document.getElementById('missingCanonical').textContent = data.summary.missing || 0;
    document.getElementById('hasCanonical').textContent = data.summary.has_canonical || 0;
    document.getElementById('incorrectCanonical').textContent = data.summary.incorrect || 0;
    
    // Display table results
    displayTableResults(data.results);
    
    // Display AI insights if available
    if (data.ai_insights && data.ai_insights.length > 0) {
        displayAIInsights(data.ai_insights);
    }
}

function displayTableResults(results) {
    const tbody = document.getElementById('resultsTableBody');
    tbody.innerHTML = '';
    
    results.forEach((result, index) => {
        const statusBadge = getStatusBadge(result.status);
        const canonicalDisplay = result.canonical || '<span class="text-muted">None found</span>';
        const recommendationDisplay = result.ai_recommendation || '<span class="text-muted">-</span>';
        
        const row = `
            <tr class="result-row" data-status="${result.status}">
                <td>
                    <div class="d-flex align-items-center">
                        <i class="bi bi-link me-2 text-primary"></i>
                        <div>
                            <div class="fw-semibold">${truncateURL(result.url, 50)}</div>
                            <small class="text-muted">${result.url}</small>
                        </div>
                    </div>
                </td>
                <td>${statusBadge}</td>
                <td>
                    <small class="font-monospace">${canonicalDisplay}</small>
                </td>
                <td>
                    <div class="recommendation-box">
                        ${recommendationDisplay}
                    </div>
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="viewDetails(${index})">
                        <i class="bi bi-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-success" onclick="copyCanonical(${index})">
                        <i class="bi bi-clipboard"></i>
                    </button>
                </td>
            </tr>
        `;
        tbody.insertAdjacentHTML('beforeend', row);
    });
}

function displayAIInsights(insights) {
    const section = document.getElementById('aiInsightsSection');
    const content = document.getElementById('aiInsightsContent');
    
    let html = '<div class="row g-3">';
    
    insights.forEach(insight => {
        html += `
            <div class="col-md-6">
                <div class="alert alert-${insight.type || 'info'} d-flex align-items-start">
                    <i class="bi bi-${getInsightIcon(insight.type)} me-3 fs-4"></i>
                    <div>
                        <strong>${insight.title}</strong>
                        <p class="mb-0 mt-1">${insight.message}</p>
                    </div>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    content.innerHTML = html;
    section.style.display = 'block';
}

function getStatusBadge(status) {
    const badges = {
        'missing': '<span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>Missing</span>',
        'incorrect': '<span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i>Incorrect</span>',
        'correct': '<span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Correct</span>',
        'self': '<span class="badge bg-info"><i class="bi bi-arrow-clockwise me-1"></i>Self-referencing</span>'
    };
    return badges[status] || '<span class="badge bg-secondary">Unknown</span>';
}

function getInsightIcon(type) {
    const icons = {
        'warning': 'exclamation-triangle-fill',
        'danger': 'exclamation-octagon-fill',
        'success': 'check-circle-fill',
        'info': 'info-circle-fill'
    };
    return icons[type] || 'lightbulb-fill';
}

function filterResults(filter) {
    currentFilter = filter;
    const rows = document.querySelectorAll('.result-row');
    
    // Update button states
    document.querySelectorAll('[id^="filter"]').forEach(btn => {
        btn.classList.remove('active', 'btn-primary');
        btn.classList.add('btn-outline-secondary');
    });
    
    const activeBtn = document.getElementById(`filter${filter.charAt(0).toUpperCase() + filter.slice(1)}`);
    if (activeBtn) {
        activeBtn.classList.remove('btn-outline-secondary');
        activeBtn.classList.add('active', 'btn-primary');
    }
    
    // Filter rows
    rows.forEach(row => {
        const status = row.dataset.status;
        if (filter === 'all') {
            row.style.display = '';
        } else {
            row.style.display = status === filter ? '' : 'none';
        }
    });
}

function viewDetails(index) {
    const result = currentResults[index];
    const modal = new bootstrap.Modal(document.getElementById('detailModal'));
    const modalBody = document.getElementById('modalBody');
    
    modalBody.innerHTML = `
        <div class="mb-4">
            <h6 class="text-muted mb-2">Page URL</h6>
            <p class="font-monospace">${result.url}</p>
        </div>
        
        <div class="mb-4">
            <h6 class="text-muted mb-2">Status</h6>
            <p>${getStatusBadge(result.status)}</p>
        </div>
        
        <div class="mb-4">
            <h6 class="text-muted mb-2">Current Canonical Tag</h6>
            <pre class="bg-light p-3 rounded"><code>${result.canonical || 'Not found'}</code></pre>
        </div>
        
        <div class="mb-4">
            <h6 class="text-muted mb-2">AI Recommendation</h6>
            <div class="alert alert-info">
                <i class="bi bi-robot me-2"></i>
                ${result.ai_recommendation || 'No recommendation available'}
            </div>
        </div>
        
        <div class="mb-4">
            <h6 class="text-muted mb-2">Suggested Fix</h6>
            <pre class="bg-dark text-light p-3 rounded"><code>${result.fix_code || generateFixCode(result)}</code></pre>
        </div>
        
        ${result.seo_impact ? `
        <div class="mb-4">
            <h6 class="text-muted mb-2">SEO Impact</h6>
            <p>${result.seo_impact}</p>
        </div>
        ` : ''}
    `;
    
    modal.show();
}

function generateFixCode(result) {
    if (result.status === 'correct') {
        return '<!-- Canonical tag is already correct -->';
    }
    
    const canonical = result.ai_recommendation || result.url;
    return `<link rel="canonical" href="${canonical}" />`;
}

function copyCanonical(index) {
    const result = currentResults[index];
    const canonical = result.ai_recommendation || result.url;
    const code = `<link rel="canonical" href="${canonical}" />`;
    
    navigator.clipboard.writeText(code).then(() => {
        showNotification('Canonical tag copied to clipboard!', 'success');
    }).catch(err => {
        console.error('Copy failed:', err);
        showNotification('Failed to copy', 'error');
    });
}

function downloadReport() {
    const report = {
        generated_at: new Date().toISOString(),
        summary: {
            total: currentResults.length,
            missing: currentResults.filter(r => r.status === 'missing').length,
            incorrect: currentResults.filter(r => r.status === 'incorrect').length,
            correct: currentResults.filter(r => r.status === 'correct').length
        },
        results: currentResults
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `canonical-report-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    showNotification('Report downloaded successfully', 'success');
}

function exportCSV() {
    let csv = 'URL,Status,Current Canonical,Recommended Canonical,AI Recommendation\n';
    
    currentResults.forEach(result => {
        csv += `"${result.url}","${result.status}","${result.canonical || ''}","${result.ai_recommendation || ''}","${(result.ai_recommendation || '').replace(/"/g, '""')}"\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `canonical-analysis-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    showNotification('CSV exported successfully', 'success');
}

function generateFixCode() {
    let code = '<!-- Canonical URL Fixes -->\n\n';
    
    currentResults.forEach(result => {
        if (result.status !== 'correct') {
            const canonical = result.ai_recommendation || result.url;
            code += `<!-- For: ${result.url} -->\n`;
            code += `<link rel="canonical" href="${canonical}" />\n\n`;
        }
    });
    
    const modal = new bootstrap.Modal(document.getElementById('detailModal'));
    const modalBody = document.getElementById('modalBody');
    
    modalBody.innerHTML = `
        <h6 class="mb-3">Generated Fix Code</h6>
        <p class="text-muted mb-3">
            Copy and paste these canonical tags into the &lt;head&gt; section of each page.
        </p>
        <pre class="bg-dark text-light p-3 rounded" style="max-height: 400px; overflow-y: auto;"><code>${escapeHtml(code)}</code></pre>
    `;
    
    modal.show();
}

function showLoading(show) {
    document.getElementById('loadingSection').style.display = show ? 'block' : 'none';
    
    if (show) {
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            if (progress >= 90) {
                clearInterval(interval);
            }
            document.getElementById('progressBar').style.width = progress + '%';
        }, 200);
    }
}

function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : type === 'success' ? 'alert-success' : 'alert-info';
    const icon = type === 'error' ? 'exclamation-circle' : type === 'success' ? 'check-circle' : 'info-circle';
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alert.style.zIndex = '9999';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

function isValidURL(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

function truncateURL(url, maxLength) {
    if (url.length <= maxLength) return url;
    return url.substring(0, maxLength) + '...';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
