// Website Audit Module

document.addEventListener('DOMContentLoaded', function() {
    const auditForm = document.getElementById('auditForm');
    const auditFormSection = document.getElementById('auditFormSection');
    const loadingSection = document.getElementById('loadingSection');
    const resultsSection = document.getElementById('resultsSection');
    const googlePageSpeedBtn = document.getElementById('googlePageSpeedBtn');
    
    if (auditForm) {
        auditForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const url = document.getElementById('website_url').value.trim();
            
            if (!url) {
                showNotification('Please enter a website URL', 'error');
                return;
            }
            
            // Validate URL
            if (!isValidURL(url)) {
                showNotification('Please enter a valid URL (including http:// or https://)', 'error');
                return;
            }
            
            // Start audit
            startAudit(url);
        });
    }
    
    // Google PageSpeed Insights redirect
    if (googlePageSpeedBtn) {
        googlePageSpeedBtn.addEventListener('click', function() {
            const url = document.getElementById('website_url').value.trim();
            
            if (!url) {
                showNotification('Please enter a website URL', 'error');
                return;
            }
            
            // Validate URL
            if (!isValidURL(url)) {
                showNotification('Please enter a valid URL (including http:// or https://)', 'error');
                return;
            }
            
            // Open Google PageSpeed Insights in new tab
            const googlePageSpeedUrl = `https://pagespeed.web.dev/report?url=${encodeURIComponent(url)}`;
            window.open(googlePageSpeedUrl, '_blank');
            
            showNotification('Opening Google PageSpeed Insights in new tab...', 'info');
        });
    }
});

// Validate URL
function isValidURL(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

// Start audit process
function startAudit(url) {
    // Disable submit button to prevent double-clicks
    const submitBtn = document.querySelector('#auditForm button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';
    }
    
    // Hide form, show loading
    document.getElementById('auditFormSection').style.display = 'none';
    document.getElementById('loadingSection').style.display = 'block';
    
    // Start progress animation
    animateProgress();
    
    let websiteId = null;
    
    // Step 1: Basic Audit
    fetch('../../api/audit.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: url })
    })
    .then(response => {
        console.log('Audit API - HTTP Status:', response.status);
        
        // Handle authentication errors
        if (response.status === 401) {
            throw createAuditError('AUTH_REQUIRED', 'Your session has expired. Please log in again.');
        }
        
        // Handle server errors
        if (response.status >= 500) {
            throw createAuditError('SERVER_ERROR', 'Audit service is temporarily unavailable. Please try again later.');
        }
        
        return response.text();
    })
    .then(text => {
        console.log('Audit API - Raw response (first 200 chars):', text.substring(0, 200));
        
        // STAGE 3: Parse JSON
        let data;
        try {
            data = JSON.parse(text);
            console.log('Audit API - JSON parsed successfully');
            console.log('Audit API - Parsed data:', data);
        } catch (parseError) {
            console.error('Audit API - Actual JSON parse failure:', parseError);
            console.error('Audit API - Invalid response:', text.substring(0, 500));
            throw createAuditError('INVALID_API_RESPONSE', 'Invalid response received from audit server.');
        }
        
        // STAGE 5: Validate API response structure
        if (typeof data.success === 'undefined') {
            console.error('Audit API - Missing success field in response');
            throw createAuditError('INVALID_API_RESPONSE', 'Invalid response format from audit server.');
        }
        
        // STAGE 6: Handle business/application errors
        if (data.success === false) {
            console.log('Audit API - Business response: success=false');
            console.log('Audit API - Message:', data.message);
            
            // Handle duplicate audit specifically
            if (data.alreadyAudited || data.message === 'This website has already been audited') {
                console.log('Audit API - Website already audited');
                if (data.audit_id) {
                    console.log('Audit API - Existing audit ID:', data.audit_id);
                }
                throw createAuditError('ALREADY_AUDITED', data.message || 'This website has already been audited.', { audit_id: data.audit_id || null });
            }
            
            // Handle other business errors
            throw createAuditError('AUDIT_FAILED', data.message || data.error || 'Unable to complete website audit.');
        }
        
        // STAGE 7: Handle successful audit
        console.log('Audit API - Success! Website ID:', data.website_id);
        websiteId = data.website_id;
        
        // Step 2: PageSpeed Insights
        return fetch('../../api/pagespeed.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: url, website_id: websiteId })
        });
    })
    .then(response => {
        console.log('PageSpeed API - Status:', response.status);
        return response.text();
    })
    .then(text => {
        console.log('PageSpeed API - Raw response:', text.substring(0, 200));
        let pageSpeedData = { success: false, message: 'PageSpeed data unavailable' };
        
        try {
            pageSpeedData = JSON.parse(text);
            console.log('PageSpeed API - Parsed data:', pageSpeedData);
            
            // Even if PageSpeed fails, continue with Technical SEO
            if (!pageSpeedData.success) {
                console.warn('PageSpeed API failed:', pageSpeedData.message);
            }
        } catch (e) {
            console.error('PageSpeed API - JSON parse error:', e);
            console.error('PageSpeed API - Response was:', text);
            console.warn('Continuing without PageSpeed data...');
        }
        
        // Step 3: Technical SEO Scan (Continue regardless of PageSpeed result)
        return fetch('../../api/technical-seo.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: url, website_id: websiteId })
        })
        .then(response => {
            console.log('Technical SEO API - Status:', response.status);
            return response.text();
        })
        .then(text => {
            console.log('Technical SEO API - Raw response:', text.substring(0, 200));
            try {
                const seoData = JSON.parse(text);
                console.log('Technical SEO API - Parsed data:', seoData);
                pageSpeedData.seoIssues = seoData;
                return pageSpeedData;
            } catch (e) {
                console.error('Technical SEO API - JSON parse error:', e);
                console.error('Technical SEO API - Response was:', text);
                throw new Error('Invalid JSON response from technical SEO API');
            }
        });
    })
    .then(completeData => {
        console.log('All APIs complete - Complete data:', completeData);
        
        // Send to n8n webhook if enabled
        sendToWebhook(completeData, websiteId);
        
        // Generate AI recommendations with Gemini
        generateAIRecommendations(completeData, websiteId);
        
        // Show results after delay for better UX
        setTimeout(() => {
            displayResults(completeData);
        }, 1500);
    })
    .catch(error => {
        console.error('Audit error:', error);
        
        // Re-enable submit button
        const submitBtn = document.querySelector('#auditForm button[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="bi bi-rocket-takeoff me-2"></i>Launch AI Audit';
        }
        
        // Handle specific error types
        if (error.code === 'ALREADY_AUDITED') {
            showAlreadyAuditedDialog(error.message, error.details?.audit_id);
        } else if (error.code === 'AUTH_REQUIRED') {
            showError(error.message);
            setTimeout(() => {
                window.location.href = '../../index.php';
            }, 2000);
        } else {
            showError(error.message || 'An error occurred while auditing the website. Please try again.');
        }
    });
}

// Create structured audit error
function createAuditError(code, message, details = null) {
    const error = new Error(message);
    error.code = code;
    error.details = details;
    return error;
}

// Show "Already Audited" dialog
function showAlreadyAuditedDialog(message, auditId) {
    document.getElementById('loadingSection').style.display = 'none';
    document.getElementById('auditFormSection').style.display = 'block';
    
    const alertHtml = `
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <h5 class="alert-heading">
                <i class="bi bi-info-circle me-2"></i>Website Already Audited
            </h5>
            <p>${message}</p>
            <hr>
            <div class="d-flex gap-2">
                ${auditId ? `<button class="btn btn-primary btn-sm" onclick="viewExistingAudit(${auditId})">
                    <i class="bi bi-file-text me-1"></i>View Existing Report
                </button>` : ''}
                <button class="btn btn-secondary btn-sm" onclick="runNewAudit()">
                    <i class="bi bi-arrow-clockwise me-1"></i>Run New Audit
                </button>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    const container = document.querySelector('.dashboard-content');
    const existingAlert = container.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    container.insertBefore(createElementFromHTML(alertHtml), container.firstChild);
}

// View existing audit
function viewExistingAudit(auditId) {
    console.log('Viewing existing audit:', auditId);
    // TODO: Implement navigation to existing audit report
    showNotification('Viewing existing audit report...', 'info');
    // window.location.href = `audit-report.php?id=${auditId}`;
}

// Run new audit (force re-audit)
function runNewAudit() {
    console.log('Force running new audit');
    showNotification('Force re-audit feature coming soon', 'info');
    // TODO: Implement force re-audit functionality
}

// Helper to create element from HTML string
function createElementFromHTML(htmlString) {
    const div = document.createElement('div');
    div.innerHTML = htmlString.trim();
    return div.firstChild;
}

// Animate progress steps
function animateProgress() {
    const steps = [
        { id: 'step1', delay: 0, duration: 800 },
        { id: 'step2', delay: 1000, duration: 1500 },
        { id: 'step3', delay: 2500, duration: 1500 },
        { id: 'step4', delay: 4000, duration: 1500 }
    ];
    
    steps.forEach(step => {
        setTimeout(() => {
            document.getElementById(step.id).classList.add('active');
            
            // Update icon
            const icon = document.querySelector(`#${step.id} i`);
            setTimeout(() => {
                icon.className = 'bi bi-check-circle';
            }, step.duration);
        }, step.delay);
    });
}

// Display audit results
function displayResults(data) {
    document.getElementById('loadingSection').style.display = 'none';
    document.getElementById('resultsSection').style.display = 'block';
    
    // Check if data has the expected structure
    const auditData = data.data || data;
    
    // Populate basic data
    if (auditData.title) {
        document.getElementById('websiteTitle').textContent = auditData.title || 'Not found';
        document.getElementById('metaDescription').textContent = auditData.description || 'Not found';
        document.getElementById('websiteLanguage').textContent = (auditData.language || 'en').toUpperCase();
        document.getElementById('responseTime').textContent = auditData.response_time + ' ms';
        document.getElementById('cmsDetected').textContent = auditData.cms_detected || 'Unknown';
        document.getElementById('serverInfo').textContent = auditData.server_info || 'Unknown';
        document.getElementById('ipAddress').textContent = auditData.ip_address || 'Unknown';
        document.getElementById('country').textContent = auditData.country || 'Unknown';
        
        // SSL Status
        const sslStatus = document.getElementById('sslStatus');
        if (auditData.ssl_enabled) {
            sslStatus.innerHTML = '<span class="badge bg-success"><i class="bi bi-shield-check"></i> Enabled</span>';
        } else {
            sslStatus.innerHTML = '<span class="badge bg-danger"><i class="bi bi-shield-x"></i> Not Enabled</span>';
        }
        
        // Keywords
        if (auditData.meta_keywords && auditData.meta_keywords !== 'No keywords found') {
            const keywords = auditData.meta_keywords.split(',').map(k => k.trim());
            const keywordsHTML = keywords.map(k => 
                `<span class="badge bg-primary me-1 mb-1">${k}</span>`
            ).join('');
            document.getElementById('metaKeywords').innerHTML = keywordsHTML;
        }
        
        // Animate SEO Score
        animateSEOScore(auditData.seo_score);
    }
    
    // Display PageSpeed results if available
    if (data.success && data.data && (data.data.desktop || data.data.mobile)) {
        displayPageSpeedResults(data);
    }
    
    // Display Technical SEO Issues
    if (data.seoIssues) {
        displayTechnicalSeoIssues(data.seoIssues);
    }
    
    // Scroll to results
    document.getElementById('resultsSection').scrollIntoView({ behavior: 'smooth' });
}

// Animate SEO Score Circle
function animateSEOScore(score) {
    const circle = document.getElementById('scoreCircle');
    const scoreValue = document.getElementById('seoScoreValue');
    const scoreLabel = document.getElementById('scoreLabel');
    
    const circumference = 2 * Math.PI * 90;
    const offset = circumference - (score / 100) * circumference;
    
    let current = 0;
    const duration = 2000;
    const stepTime = 20;
    const steps = duration / stepTime;
    const increment = score / steps;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= score) {
            current = score;
            clearInterval(timer);
        }
        
        scoreValue.textContent = Math.round(current);
        const currentOffset = circumference - (current / 100) * circumference;
        circle.style.strokeDashoffset = currentOffset;
    }, stepTime);
    
    // Update label based on score
    if (score >= 90) {
        scoreLabel.textContent = 'Excellent';
        scoreLabel.className = 'text-success mb-0';
        circle.style.stroke = '#28A745';
    } else if (score >= 70) {
        scoreLabel.textContent = 'Good';
        scoreLabel.className = 'text-primary mb-0';
        circle.style.stroke = '#FF6B00';
    } else if (score >= 50) {
        scoreLabel.textContent = 'Average';
        scoreLabel.className = 'text-warning mb-0';
        circle.style.stroke = '#FFC107';
    } else {
        scoreLabel.textContent = 'Needs Improvement';
        scoreLabel.className = 'text-danger mb-0';
        circle.style.stroke = '#DC3545';
    }
}

// Show error
function showError(message) {
    document.getElementById('loadingSection').style.display = 'none';
    document.getElementById('auditFormSection').style.display = 'block';
    showNotification(message, 'error');
}

// Show notification
function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : 'alert-info';
    const icon = type === 'error' ? 'exclamation-circle' : 'info-circle';
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show`;
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.dashboard-content');
    container.insertBefore(alert, container.firstChild);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

// Download report
document.addEventListener('DOMContentLoaded', function() {
    const downloadBtn = document.getElementById('downloadReport');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', function() {
            showNotification('Report download feature coming soon!', 'info');
        });
    }
});

// Send audit data to n8n webhook
function sendToWebhook(auditData, websiteId) {
    // Prepare webhook data
    const webhookData = {
        url: auditData.url || (auditData.data ? auditData.data.url : ''),
        website_id: websiteId,
        audit_results: auditData,
        timestamp: new Date().toISOString()
    };
    
    // Send to webhook
    fetch('../../api/webhook.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(webhookData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Webhook sent successfully:', data);
            // Optionally show webhook status in UI
            displayWebhookStatus(data);
        } else {
            console.warn('Webhook failed:', data.message);
            // Show webhook error if needed
            if (data.message !== 'n8n webhook integration is disabled') {
                displayWebhookStatus(data);
            }
        }
    })
    .catch(error => {
        console.error('Webhook error:', error);
    });
}

// Display webhook status in results
function displayWebhookStatus(webhookResult) {
    // Check if webhook status section exists
    let webhookStatusSection = document.getElementById('webhookStatusSection');
    
    if (!webhookStatusSection) {
        // Create webhook status section
        webhookStatusSection = document.createElement('div');
        webhookStatusSection.id = 'webhookStatusSection';
        webhookStatusSection.className = 'mt-4';
        document.getElementById('resultsSection').appendChild(webhookStatusSection);
    }
    
    const statusClass = webhookResult.success ? 'success' : 'danger';
    const statusIcon = webhookResult.success ? 'check-circle' : 'x-circle';
    
    webhookStatusSection.innerHTML = `
        <div class="row g-4">
            <div class="col-12">
                <div class="card profile-card glass-card">
                    <h5 class="mb-3">
                        <i class="bi bi-webhook text-primary me-2"></i>n8n Webhook Status
                    </h5>
                    <div class="alert alert-${statusClass} d-flex align-items-center">
                        <i class="bi bi-${statusIcon} me-2 fs-5"></i>
                        <div class="flex-grow-1">
                            <strong>${webhookResult.message}</strong>
                            ${webhookResult.status_code ? `<br><small>Status Code: ${webhookResult.status_code}</small>` : ''}
                            ${webhookResult.error ? `<br><small>Error: ${webhookResult.error}</small>` : ''}
                        </div>
                        ${!webhookResult.success && webhookResult.log_id ? `
                            <button class="btn btn-sm btn-warning" onclick="retryWebhookFromAudit(${webhookResult.log_id})">
                                <i class="bi bi-arrow-clockwise me-1"></i>Retry
                            </button>
                        ` : ''}
                    </div>
                    ${webhookResult.response ? `
                        <div class="mt-3">
                            <h6>Response Data:</h6>
                            <pre class="bg-light p-3 rounded"><code>${JSON.stringify(webhookResult.response, null, 2)}</code></pre>
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
}

// Retry webhook from audit page
function retryWebhookFromAudit(logId) {
    if (!confirm('Retry sending this audit to the webhook?')) return;
    
    fetch('../../api/settings.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'retry', log_id: logId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Webhook retry successful!', 'success');
            displayWebhookStatus(data);
        } else {
            showNotification('Retry failed: ' + data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error retrying webhook:', error);
        showNotification('Error retrying webhook', 'error');
    });
}

// Generate AI Recommendations using Gemini
function generateAIRecommendations(auditData, websiteId) {
    // Prepare data for Gemini
    const websiteData = auditData.data || {};
    const pageSpeedData = {
        desktop: auditData.desktop || {},
        mobile: auditData.mobile || {}
    };
    const technicalSeoData = auditData.seoIssues || {};
    
    // Show loading state
    displayAILoadingState();
    
    // Call Gemini API
    fetch('../../api/gemini-ai.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            website_data: websiteData,
            pagespeed_data: pageSpeedData,
            technical_seo_data: technicalSeoData,
            website_id: websiteId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('AI Recommendations generated successfully:', data);
            displayAIRecommendations(data);
        } else {
            console.warn('AI Recommendations failed:', data.message);
            displayAIError(data.message);
        }
    })
    .catch(error => {
        console.error('AI Recommendations error:', error);
        displayAIError('Failed to generate AI recommendations');
    });
}

// Display AI loading state
function displayAILoadingState() {
    let aiSection = document.getElementById('aiRecommendationsSection');
    
    if (!aiSection) {
        aiSection = document.createElement('div');
        aiSection.id = 'aiRecommendationsSection';
        aiSection.className = 'mt-4';
        document.getElementById('resultsSection').appendChild(aiSection);
    }
    
    aiSection.innerHTML = `
        <div class="row g-4">
            <div class="col-12">
                <div class="card profile-card glass-card">
                    <h4 class="mb-3">
                        <i class="bi bi-stars text-warning me-2"></i>AI-Powered Recommendations
                    </h4>
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary mb-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <p class="text-muted">Analyzing your website with Google Gemini AI...</p>
                        <small class="text-muted">This may take a few seconds</small>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Display AI recommendations
function displayAIRecommendations(aiData) {
    const aiSection = document.getElementById('aiRecommendationsSection');
    
    if (!aiSection) return;
    
    const topProblems = aiData.top_problems || [];
    const priorityActions = aiData.priority_actions || [];
    const solutions = aiData.solutions || [];
    const improvements = aiData.estimated_improvements || {};
    
    aiSection.innerHTML = `
        <div class="row g-4">
            <div class="col-12">
                <h4 class="mb-3">
                    <i class="bi bi-stars text-warning me-2"></i>AI-Powered Recommendations by Gemini
                </h4>
            </div>
            
            <!-- AI Summary -->
            <div class="col-12">
                <div class="card ai-card glass-card gradient-border">
                    <div class="ai-badge">
                        <i class="bi bi-robot"></i> AI Analysis
                    </div>
                    <h5 class="mb-3">
                        <i class="bi bi-clipboard-data text-primary me-2"></i>Executive Summary
                    </h5>
                    <p class="lead">${aiData.summary || 'No summary available'}</p>
                </div>
            </div>
            
            <!-- Top Problems -->
            <div class="col-lg-6">
                <div class="card ai-card glass-card">
                    <h5 class="mb-3">
                        <i class="bi bi-exclamation-triangle text-danger me-2"></i>Top SEO Problems
                    </h5>
                    <div class="problems-list">
                        ${topProblems.map((problem, index) => `
                            <div class="problem-item ${problem.severity}">
                                <div class="problem-header">
                                    <span class="problem-number">${index + 1}</span>
                                    <span class="badge bg-${getSeverityColor(problem.severity)}">${problem.severity}</span>
                                </div>
                                <h6 class="problem-title">${problem.problem}</h6>
                                <p class="problem-impact">${problem.impact}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <!-- Priority Actions -->
            <div class="col-lg-6">
                <div class="card ai-card glass-card">
                    <h5 class="mb-3">
                        <i class="bi bi-list-check text-success me-2"></i>Priority Actions
                    </h5>
                    <div class="actions-list">
                        ${priorityActions.map((action, index) => `
                            <div class="action-item">
                                <div class="action-header">
                                    <span class="priority-badge priority-${action.priority}">P${action.priority}</span>
                                    <div class="action-meta">
                                        <span class="badge bg-${getEffortColor(action.effort)}">${action.effort} effort</span>
                                        <span class="badge bg-info">${action.timeline}</span>
                                    </div>
                                </div>
                                <p class="action-text">${action.action}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <!-- Business Impact -->
            <div class="col-12">
                <div class="card ai-card glass-card gradient-border-purple">
                    <h5 class="mb-3">
                        <i class="bi bi-graph-up-arrow text-success me-2"></i>Business Impact Analysis
                    </h5>
                    <p class="business-impact-text">${aiData.business_impact || 'No business impact analysis available'}</p>
                </div>
            </div>
            
            <!-- Solutions -->
            <div class="col-12">
                <div class="card ai-card glass-card">
                    <h5 class="mb-3">
                        <i class="bi bi-tools text-primary me-2"></i>Detailed Solutions
                    </h5>
                    <div class="solutions-grid">
                        ${solutions.map((solution, index) => `
                            <div class="solution-card">
                                <div class="solution-header">
                                    <h6 class="solution-issue">${solution.issue}</h6>
                                    <span class="badge bg-${getDifficultyColor(solution.difficulty)}">${solution.difficulty}</span>
                                </div>
                                <div class="solution-body">
                                    <p class="solution-text">${solution.solution}</p>
                                    <div class="solution-tools">
                                        <i class="bi bi-tools me-1"></i>
                                        <strong>Tools:</strong> ${solution.tools}
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <!-- Estimated Improvements -->
            <div class="col-12">
                <div class="card ai-card glass-card gradient-border-success">
                    <h5 class="mb-3">
                        <i class="bi bi-trophy text-warning me-2"></i>Estimated Improvements
                    </h5>
                    <div class="improvements-grid">
                        <div class="improvement-item">
                            <div class="improvement-icon bg-primary-light">
                                <i class="bi bi-speedometer2"></i>
                            </div>
                            <div class="improvement-content">
                                <strong>SEO Score</strong>
                                <p>${improvements.seo_score || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="improvement-item">
                            <div class="improvement-icon bg-success-light">
                                <i class="bi bi-lightning-charge"></i>
                            </div>
                            <div class="improvement-content">
                                <strong>Performance</strong>
                                <p>${improvements.performance || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="improvement-item">
                            <div class="improvement-icon bg-warning-light">
                                <i class="bi bi-people"></i>
                            </div>
                            <div class="improvement-content">
                                <strong>User Experience</strong>
                                <p>${improvements.user_experience || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="improvement-item">
                            <div class="improvement-icon bg-info-light">
                                <i class="bi bi-cash-coin"></i>
                            </div>
                            <div class="improvement-content">
                                <strong>Conversion Rate</strong>
                                <p>${improvements.conversion_rate || 'N/A'}</p>
                            </div>
                        </div>
                        <div class="improvement-item">
                            <div class="improvement-icon bg-purple-light">
                                <i class="bi bi-search"></i>
                            </div>
                            <div class="improvement-content">
                                <strong>Search Ranking</strong>
                                <p>${improvements.search_ranking || 'N/A'}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Animate cards
    animateAICards();
}

// Display AI error
function displayAIError(message) {
    const aiSection = document.getElementById('aiRecommendationsSection');
    
    if (!aiSection) return;
    
    aiSection.innerHTML = `
        <div class="row g-4">
            <div class="col-12">
                <div class="card profile-card glass-card">
                    <h4 class="mb-3">
                        <i class="bi bi-stars text-warning me-2"></i>AI-Powered Recommendations
                    </h4>
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>AI Analysis Unavailable:</strong> ${message}
                        <br><small class="mt-2 d-block">Please ensure your Gemini API key is configured in config/database.php</small>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Helper functions for AI display
function getSeverityColor(severity) {
    const colors = {
        'critical': 'danger',
        'high': 'orange',
        'medium': 'warning',
        'low': 'info'
    };
    return colors[severity] || 'secondary';
}

function getEffortColor(effort) {
    const colors = {
        'low': 'success',
        'medium': 'warning',
        'high': 'danger'
    };
    return colors[effort] || 'secondary';
}

function getDifficultyColor(difficulty) {
    const colors = {
        'easy': 'success',
        'medium': 'warning',
        'hard': 'danger'
    };
    return colors[difficulty] || 'secondary';
}

// Animate AI cards
function animateAICards() {
    const cards = document.querySelectorAll('.ai-card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.5s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 50);
        }, index * 100);
    });
}


// Display PageSpeed results with circular charts
function displayPageSpeedResults(data) {
    if (!data.success) {
        console.warn('PageSpeed data not available:', data.message);
        return;
    }
    
    const pageSpeedData = data.data;
    const desktopData = pageSpeedData.desktop;
    const mobileData = pageSpeedData.mobile;
    
    // Create PageSpeed section if it doesn't exist
    let pageSpeedSection = document.getElementById('pageSpeedSection');
    if (!pageSpeedSection) {
        pageSpeedSection = document.createElement('div');
        pageSpeedSection.id = 'pageSpeedSection';
        pageSpeedSection.className = 'mt-4';
        document.getElementById('resultsSection').appendChild(pageSpeedSection);
    }
    
    pageSpeedSection.innerHTML = `
        <div class="row g-4 mb-4">
            <div class="col-12">
                <h4 class="mb-3"><i class="bi bi-speedometer2 text-primary me-2"></i>Google PageSpeed Insights</h4>
            </div>
        </div>
        
        <!-- Desktop Scores -->
        <div class="row g-4 mb-4">
            <div class="col-12">
                <h5><i class="bi bi-display me-2"></i>Desktop Performance</h5>
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('Performance', desktopData.performance_score, 'performance')}
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('Accessibility', desktopData.accessibility_score, 'accessibility')}
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('Best Practices', desktopData.best_practices_score, 'best-practices')}
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('SEO', desktopData.seo_score, 'seo')}
            </div>
        </div>
        
        <!-- Mobile Scores -->
        <div class="row g-4 mb-4">
            <div class="col-12">
                <h5><i class="bi bi-phone me-2"></i>Mobile Performance</h5>
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('Performance', mobileData.performance_score, 'performance-mobile')}
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('Accessibility', mobileData.accessibility_score, 'accessibility-mobile')}
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('Best Practices', mobileData.best_practices_score, 'best-practices-mobile')}
            </div>
            <div class="col-md-6 col-lg-3">
                ${createScoreCard('SEO', mobileData.seo_score, 'seo-mobile')}
            </div>
        </div>
        
        <!-- Core Web Vitals -->
        <div class="row g-4 mb-4">
            <div class="col-12">
                <h5><i class="bi bi-lightning-charge text-warning me-2"></i>Core Web Vitals & Metrics</h5>
            </div>
            
            <!-- Desktop Metrics -->
            <div class="col-lg-6">
                <div class="card profile-card glass-card">
                    <h6 class="mb-3"><i class="bi bi-display me-2"></i>Desktop Metrics</h6>
                    <div class="row g-3">
                        ${createMetricItem('LCP', desktopData.lcp_value, desktopData.lcp_score, 's')}
                        ${createMetricItem('CLS', desktopData.cls_value, desktopData.cls_score, '')}
                        ${createMetricItem('TTFB', desktopData.ttfb_value, desktopData.ttfb_score, 's')}
                        ${createMetricItem('FCP', desktopData.fcp_value, desktopData.fcp_score, 's')}
                        ${createMetricItem('Speed Index', desktopData.speed_index_value, desktopData.speed_index_score, 's')}
                    </div>
                </div>
            </div>
            
            <!-- Mobile Metrics -->
            <div class="col-lg-6">
                <div class="card profile-card glass-card">
                    <h6 class="mb-3"><i class="bi bi-phone me-2"></i>Mobile Metrics</h6>
                    <div class="row g-3">
                        ${createMetricItem('LCP', mobileData.lcp_value, mobileData.lcp_score, 's')}
                        ${createMetricItem('CLS', mobileData.cls_value, mobileData.cls_score, '')}
                        ${createMetricItem('TTFB', mobileData.ttfb_value, mobileData.ttfb_score, 's')}
                        ${createMetricItem('FCP', mobileData.fcp_value, mobileData.fcp_score, 's')}
                        ${createMetricItem('Speed Index', mobileData.speed_index_value, mobileData.speed_index_score, 's')}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Animate all circular charts
    animateAllPageSpeedScores();
}

// Create score card with circular chart
function createScoreCard(label, score, id) {
    const color = getScoreColor(score);
    return `
        <div class="card profile-card glass-card text-center p-3">
            <div class="pagespeed-circle" data-score="${score}" data-color="${color}">
                <svg viewBox="0 0 120 120" class="score-svg">
                    <circle cx="60" cy="60" r="54" fill="none" stroke="#f0f0f0" stroke-width="8"/>
                    <circle cx="60" cy="60" r="54" fill="none" stroke="${color}" stroke-width="8" 
                            class="score-circle-${id}" stroke-dasharray="339" stroke-dashoffset="339"
                            transform="rotate(-90 60 60)"/>
                </svg>
                <div class="score-number">${score}</div>
            </div>
            <p class="mt-2 mb-0 fw-semibold">${label}</p>
        </div>
    `;
}

// Create metric item
function createMetricItem(label, value, score, unit) {
    const color = getScoreColor(score);
    const indicator = getScoreIndicator(score);
    return `
        <div class="col-12">
            <div class="metric-item">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <strong>${label}</strong>
                        <small class="d-block text-muted">${value}${unit}</small>
                    </div>
                    <div class="metric-badge" style="background: ${color}20; color: ${color};">
                        ${indicator} ${score}
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Get score color
function getScoreColor(score) {
    if (score >= 90) return '#28A745'; // Green
    if (score >= 50) return '#FF6B00'; // Orange
    return '#DC3545'; // Red
}

// Get score indicator
function getScoreIndicator(score) {
    if (score >= 90) return '●';
    if (score >= 50) return '●';
    return '●';
}

// Animate all PageSpeed scores
function animateAllPageSpeedScores() {
    document.querySelectorAll('.pagespeed-circle').forEach((circle, index) => {
        setTimeout(() => {
            const score = parseInt(circle.dataset.score);
            const color = circle.dataset.color;
            const svg = circle.querySelector('.score-svg');
            const scoreCircle = svg.querySelector(`circle[stroke="${color}"]`);
            const scoreNumber = circle.querySelector('.score-number');
            
            const circumference = 2 * Math.PI * 54;
            const offset = circumference - (score / 100) * circumference;
            
            let current = 0;
            const duration = 1500;
            const stepTime = 20;
            const steps = duration / stepTime;
            const increment = score / steps;
            
            const timer = setInterval(() => {
                current += increment;
                if (current >= score) {
                    current = score;
                    clearInterval(timer);
                }
                
                scoreNumber.textContent = Math.round(current);
                const currentOffset = circumference - (current / 100) * circumference;
                scoreCircle.style.strokeDashoffset = currentOffset;
            }, stepTime);
        }, index * 100);
    });
}


// Display Technical SEO Issues
function displayTechnicalSeoIssues(data) {
    if (!data.success || !data.issues) {
        console.warn('Technical SEO data not available');
        return;
    }
    
    const issues = data.issues;
    
    // Create Technical SEO section
    let technicalSection = document.getElementById('technicalSeoSection');
    if (!technicalSection) {
        technicalSection = document.createElement('div');
        technicalSection.id = 'technicalSeoSection';
        technicalSection.className = 'mt-4';
        document.getElementById('resultsSection').appendChild(technicalSection);
    }
    
    // Group issues by category
    const groupedIssues = {};
    issues.forEach(issue => {
        if (!groupedIssues[issue.category]) {
            groupedIssues[issue.category] = [];
        }
        groupedIssues[issue.category].push(issue);
    });
    
    // Calculate statistics
    const stats = {
        total: issues.length,
        passed: issues.filter(i => i.status === 'pass').length,
        warnings: issues.filter(i => i.status === 'warning').length,
        errors: issues.filter(i => i.status === 'error').length,
        critical: issues.filter(i => i.severity === 'critical').length,
        high: issues.filter(i => i.severity === 'high').length,
        medium: issues.filter(i => i.severity === 'medium').length,
        low: issues.filter(i => i.severity === 'low').length
    };
    
    technicalSection.innerHTML = `
        <div class="row g-4 mb-4">
            <div class="col-12">
                <h4 class="mb-3"><i class="bi bi-gear-fill text-primary me-2"></i>Technical SEO Scanner</h4>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="card profile-card glass-card text-center p-3">
                    <div class="stat-number text-success">${stats.passed}</div>
                    <div class="stat-label">Passed</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card profile-card glass-card text-center p-3">
                    <div class="stat-number text-warning">${stats.warnings}</div>
                    <div class="stat-label">Warnings</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card profile-card glass-card text-center p-3">
                    <div class="stat-number text-danger">${stats.errors}</div>
                    <div class="stat-label">Errors</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card profile-card glass-card text-center p-3">
                    <div class="stat-number text-info">${stats.total}</div>
                    <div class="stat-label">Total Checks</div>
                </div>
            </div>
        </div>
        
        <!-- Issues by Category -->
        <div class="row g-4">
            ${Object.keys(groupedIssues).map(category => `
                <div class="col-lg-6">
                    <div class="card profile-card glass-card">
                        <h5 class="mb-3">
                            <i class="bi bi-${getCategoryIcon(category)} me-2"></i>${category}
                        </h5>
                        <div class="seo-issues-list">
                            ${groupedIssues[category].map(issue => createIssueCard(issue)).join('')}
                        </div>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

// Create issue card
function createIssueCard(issue) {
    const statusClass = {
        'pass': 'success',
        'warning': 'warning',
        'error': 'danger'
    }[issue.status];
    
    const severityClass = {
        'low': 'info',
        'medium': 'warning',
        'high': 'orange',
        'critical': 'danger'
    }[issue.severity];
    
    const statusIcon = {
        'pass': 'check-circle-fill',
        'warning': 'exclamation-triangle-fill',
        'error': 'x-circle-fill'
    }[issue.status];
    
    return `
        <div class="seo-issue-card ${issue.status}">
            <div class="issue-header">
                <div class="issue-status">
                    <i class="bi bi-${statusIcon} text-${statusClass}"></i>
                    <strong>${issue.message}</strong>
                </div>
                <div class="issue-badges">
                    <span class="badge bg-${severityClass}">${issue.severity.toUpperCase()}</span>
                    <span class="badge bg-secondary">Priority: ${issue.priority}</span>
                </div>
            </div>
            <div class="issue-body">
                <p class="recommendation">
                    <i class="bi bi-lightbulb text-warning me-2"></i>
                    ${issue.recommendation}
                </p>
            </div>
        </div>
    `;
}

// Get category icon
function getCategoryIcon(category) {
    const icons = {
        'Meta Tags': 'tags',
        'Content': 'file-text',
        'Technical': 'gear',
        'Security': 'shield-check',
        'Social': 'share',
        'Performance': 'speedometer2',
        'Mobile': 'phone'
    };
    return icons[category] || 'info-circle';
}


// Display Technical SEO Issues
function displayTechnicalSeoIssues(seoData) {
    if (!seoData || !seoData.success || !seoData.issues) {
        console.warn('Technical SEO data not available');
        return;
    }
    
    const issues = seoData.issues;
    
    // Create Technical SEO section
    let technicalSeoSection = document.getElementById('technicalSeoSection');
    if (!technicalSeoSection) {
        technicalSeoSection = document.createElement('div');
        technicalSeoSection.id = 'technicalSeoSection';
        technicalSeoSection.className = 'mt-4';
        document.getElementById('resultsSection').appendChild(technicalSeoSection);
    }
    
    // Group issues by category
    const groupedIssues = groupIssuesByCategory(issues);
    
    // Calculate summary stats
    const stats = calculateIssueStats(issues);
    
    technicalSeoSection.innerHTML = `
        <div class="row g-4 mb-4">
            <div class="col-12">
                <h4 class="mb-3"><i class="bi bi-bug text-danger me-2"></i>Technical SEO Analysis</h4>
            </div>
        </div>
        
        <!-- Summary Stats -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card seo-stat-card stat-error">
                    <div class="stat-icon"><i class="bi bi-x-circle"></i></div>
                    <div class="stat-number">${stats.errors}</div>
                    <div class="stat-label">Errors</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card seo-stat-card stat-warning">
                    <div class="stat-icon"><i class="bi bi-exclamation-triangle"></i></div>
                    <div class="stat-number">${stats.warnings}</div>
                    <div class="stat-label">Warnings</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card seo-stat-card stat-pass">
                    <div class="stat-icon"><i class="bi bi-check-circle"></i></div>
                    <div class="stat-number">${stats.passed}</div>
                    <div class="stat-label">Passed</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card seo-stat-card stat-total">
                    <div class="stat-icon"><i class="bi bi-clipboard-check"></i></div>
                    <div class="stat-number">${stats.total}</div>
                    <div class="stat-label">Total Checks</div>
                </div>
            </div>
        </div>
        
        <!-- Issues by Category -->
        ${Object.keys(groupedIssues).map(category => `
            <div class="category-section mb-4">
                <h5 class="category-title">
                    <i class="bi bi-${getCategoryIcon(category)} me-2"></i>${category}
                </h5>
                <div class="row g-3">
                    ${groupedIssues[category].map(issue => createIssueCard(issue)).join('')}
                </div>
            </div>
        `).join('')}
    `;
}

// Group issues by category
function groupIssuesByCategory(issues) {
    const grouped = {};
    
    issues.forEach(issue => {
        if (!grouped[issue.category]) {
            grouped[issue.category] = [];
        }
        grouped[issue.category].push(issue);
    });
    
    return grouped;
}

// Calculate issue statistics
function calculateIssueStats(issues) {
    return {
        total: issues.length,
        errors: issues.filter(i => i.status === 'error').length,
        warnings: issues.filter(i => i.status === 'warning').length,
        passed: issues.filter(i => i.status === 'pass').length,
        critical: issues.filter(i => i.severity === 'critical').length,
        high: issues.filter(i => i.severity === 'high').length,
        medium: issues.filter(i => i.severity === 'medium').length,
        low: issues.filter(i => i.severity === 'low').length
    };
}

// Get category icon
function getCategoryIcon(category) {
    const icons = {
        'Meta Tags': 'tags',
        'Content': 'file-text',
        'Technical': 'gear',
        'Security': 'shield-check',
        'Social': 'share',
        'Performance': 'speedometer2',
        'Mobile': 'phone'
    };
    return icons[category] || 'bookmark';
}

// Create issue card
function createIssueCard(issue) {
    const statusClass = `status-${issue.status}`;
    const severityClass = `severity-${issue.severity}`;
    const statusIcon = getStatusIcon(issue.status);
    const severityBadge = getSeverityBadge(issue.severity);
    const priorityBadge = getPriorityBadge(issue.priority);
    
    return `
        <div class="col-12">
            <div class="card issue-card ${statusClass}">
                <div class="issue-header">
                    <div class="d-flex align-items-start">
                        <div class="issue-icon ${statusClass}">
                            <i class="bi bi-${statusIcon}"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h6 class="issue-title mb-1">${issue.message}</h6>
                            <p class="issue-type mb-2">
                                <span class="badge badge-type">${issue.issue_type}</span>
                            </p>
                        </div>
                        <div class="issue-badges">
                            ${severityBadge}
                            ${priorityBadge}
                        </div>
                    </div>
                </div>
                <div class="issue-body">
                    <div class="recommendation">
                        <strong><i class="bi bi-lightbulb me-1"></i> Recommendation:</strong>
                        <p>${issue.recommendation}</p>
                    </div>
                    ${issue.details ? `
                        <div class="issue-details">
                            <small class="text-muted">
                                <i class="bi bi-info-circle me-1"></i>
                                ${formatIssueDetails(issue.details)}
                            </small>
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
}

// Get status icon
function getStatusIcon(status) {
    const icons = {
        'pass': 'check-circle-fill',
        'warning': 'exclamation-triangle-fill',
        'error': 'x-circle-fill'
    };
    return icons[status] || 'info-circle-fill';
}

// Get severity badge
function getSeverityBadge(severity) {
    const colors = {
        'critical': 'danger',
        'high': 'warning',
        'medium': 'info',
        'low': 'secondary'
    };
    const color = colors[severity] || 'secondary';
    return `<span class="badge bg-${color}">${severity.toUpperCase()}</span>`;
}

// Get priority badge
function getPriorityBadge(priority) {
    let color = 'secondary';
    if (priority >= 80) color = 'danger';
    else if (priority >= 60) color = 'warning';
    else if (priority >= 40) color = 'info';
    
    return `<span class="badge bg-${color}">P${priority}</span>`;
}

// Format issue details
function formatIssueDetails(details) {
    if (typeof details === 'string') {
        try {
            details = JSON.parse(details);
        } catch (e) {
            return details;
        }
    }
    
    if (typeof details === 'object') {
        const entries = Object.entries(details);
        return entries.map(([key, value]) => {
            if (Array.isArray(value)) {
                return `${key}: ${value.join(', ')}`;
            }
            return `${key}: ${value}`;
        }).join(' | ');
    }
    
    return '';
}

// Update displayResults to include Technical SEO
const originalDisplayResults = displayResults;
displayResults = function(data) {
    // Call original display function
    originalDisplayResults.call(this, data);
    
    // Display Technical SEO issues
    if (data.seoIssues) {
        displayTechnicalSeoIssues(data.seoIssues);
    }
};
