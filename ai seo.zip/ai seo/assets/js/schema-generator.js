// Schema Generator

let currentSchemaType = 'organization';
let currentSchema = null;

// Form field definitions for each schema type
const schemaFields = {
    organization: [
        { name: 'name', label: 'Organization Name *', type: 'text', required: true, placeholder: 'Aurify Marketing' },
        { name: 'url', label: 'Website URL *', type: 'url', required: true, placeholder: 'https://example.com' },
        { name: 'logo', label: 'Logo URL', type: 'url', required: false, placeholder: 'https://example.com/logo.png' },
        { name: 'description', label: 'Description', type: 'textarea', required: false, placeholder: 'Brief company description' },
        { name: 'telephone', label: 'Phone Number', type: 'tel', required: false, placeholder: '+1-555-123-4567' },
        { name: 'email', label: 'Email', type: 'email', required: false, placeholder: 'contact@example.com' }
    ],
    local_business: [
        { name: 'name', label: 'Business Name *', type: 'text', required: true, placeholder: 'My Local Business' },
        { name: 'url', label: 'Website URL *', type: 'url', required: true, placeholder: 'https://example.com' },
        { name: 'image', label: 'Image URL', type: 'url', required: false, placeholder: 'https://example.com/image.jpg' },
        { name: 'telephone', label: 'Phone Number *', type: 'tel', required: true, placeholder: '+1-555-123-4567' },
        { name: 'priceRange', label: 'Price Range', type: 'text', required: false, placeholder: '$$' },
        { name: 'address.street', label: 'Street Address *', type: 'text', required: true, placeholder: '123 Main St' },
        { name: 'address.city', label: 'City *', type: 'text', required: true, placeholder: 'New York' },
        { name: 'address.state', label: 'State/Region *', type: 'text', required: true, placeholder: 'NY' },
        { name: 'address.zip', label: 'Postal Code *', type: 'text', required: true, placeholder: '10001' },
        { name: 'address.country', label: 'Country *', type: 'text', required: true, placeholder: 'US' }
    ],
    product: [
        { name: 'name', label: 'Product Name *', type: 'text', required: true, placeholder: 'Premium Widget' },
        { name: 'description', label: 'Description *', type: 'textarea', required: true, placeholder: 'Product description' },
        { name: 'brand', label: 'Brand Name', type: 'text', required: false, placeholder: 'Brand Name' },
        { name: 'sku', label: 'SKU', type: 'text', required: false, placeholder: 'PROD-12345' },
        { name: 'price', label: 'Price *', type: 'number', required: true, placeholder: '99.99', step: '0.01' },
        { name: 'currency', label: 'Currency *', type: 'text', required: true, placeholder: 'USD' },
        { name: 'url', label: 'Product URL', type: 'url', required: false, placeholder: 'https://example.com/product' },
        { name: 'availability', label: 'Availability', type: 'select', required: false, options: [
            { value: 'https://schema.org/InStock', label: 'In Stock' },
            { value: 'https://schema.org/OutOfStock', label: 'Out of Stock' },
            { value: 'https://schema.org/PreOrder', label: 'Pre-Order' }
        ]}
    ],
    service: [
        { name: 'name', label: 'Service Name *', type: 'text', required: true, placeholder: 'SEO Consulting' },
        { name: 'description', label: 'Description *', type: 'textarea', required: true, placeholder: 'Service description' },
        { name: 'provider', label: 'Provider Name *', type: 'text', required: true, placeholder: 'Company Name' },
        { name: 'serviceType', label: 'Service Type', type: 'text', required: false, placeholder: 'Consulting' },
        { name: 'areaServed', label: 'Area Served', type: 'text', required: false, placeholder: 'United States' },
        { name: 'price', label: 'Price', type: 'number', required: false, placeholder: '499.00', step: '0.01' },
        { name: 'currency', label: 'Currency', type: 'text', required: false, placeholder: 'USD' }
    ],
    article: [
        { name: 'headline', label: 'Article Headline *', type: 'text', required: true, placeholder: 'Article Title' },
        { name: 'author', label: 'Author Name *', type: 'text', required: true, placeholder: 'John Doe' },
        { name: 'publisher', label: 'Publisher Name *', type: 'text', required: true, placeholder: 'Company Name' },
        { name: 'publisherLogo', label: 'Publisher Logo URL', type: 'url', required: false, placeholder: 'https://example.com/logo.png' },
        { name: 'datePublished', label: 'Published Date *', type: 'date', required: true },
        { name: 'dateModified', label: 'Modified Date', type: 'date', required: false },
        { name: 'image', label: 'Article Image URL', type: 'url', required: false, placeholder: 'https://example.com/image.jpg' },
        { name: 'description', label: 'Description', type: 'textarea', required: false, placeholder: 'Article summary' }
    ],
    faq: [
        { name: 'questions', label: 'FAQ Questions & Answers', type: 'faq', required: true }
    ],
    breadcrumb: [
        { name: 'items', label: 'Breadcrumb Items', type: 'breadcrumb', required: true }
    ]
};

document.addEventListener('DOMContentLoaded', function() {
    // Schema type selection
    document.querySelectorAll('.schema-type-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.schema-type-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            currentSchemaType = this.dataset.type;
            updateFormTitle();
            renderForm();
            hideResults();
        });
    });
    
    // View toggle
    document.getElementById('viewJsonBtn').addEventListener('click', function() {
        showJsonView();
    });
    
    document.getElementById('viewHtmlBtn').addEventListener('click', function() {
        showHtmlView();
    });
    
    // Initial render
    renderForm();
});

function updateFormTitle() {
    const titles = {
        organization: 'Organization Schema',
        local_business: 'Local Business Schema',
        product: 'Product Schema',
        service: 'Service Schema',
        article: 'Article Schema',
        faq: 'FAQ Schema',
        breadcrumb: 'Breadcrumb Schema'
    };
    document.getElementById('formTitle').textContent = titles[currentSchemaType];
}

function renderForm() {
    const fields = schemaFields[currentSchemaType];
    const container = document.getElementById('formFields');
    
    let html = '';
    
    fields.forEach(field => {
        if (field.type === 'faq') {
            html += renderFAQField(field);
        } else if (field.type === 'breadcrumb') {
            html += renderBreadcrumbField(field);
        } else {
            html += renderStandardField(field);
        }
    });
    
    container.innerHTML = html;
    
    // Setup form submission
    document.getElementById('schemaForm').onsubmit = function(e) {
        e.preventDefault();
        generateSchema();
    };
    
    // Setup dynamic fields
    if (currentSchemaType === 'faq') {
        setupFAQHandlers();
    } else if (currentSchemaType === 'breadcrumb') {
        setupBreadcrumbHandlers();
    }
}

function renderStandardField(field) {
    const requiredMark = field.required ? ' *' : '';
    
    let inputHtml = '';
    
    if (field.type === 'textarea') {
        inputHtml = `<textarea class="form-control" name="${field.name}" 
                     placeholder="${field.placeholder || ''}" 
                     ${field.required ? 'required' : ''} rows="3"></textarea>`;
    } else if (field.type === 'select') {
        inputHtml = `<select class="form-select" name="${field.name}" ${field.required ? 'required' : ''}>
                        <option value="">Select...</option>`;
        field.options.forEach(opt => {
            inputHtml += `<option value="${opt.value}">${opt.label}</option>`;
        });
        inputHtml += '</select>';
    } else {
        inputHtml = `<input type="${field.type}" class="form-control" name="${field.name}" 
                     placeholder="${field.placeholder || ''}" 
                     ${field.step ? 'step="' + field.step + '"' : ''}
                     ${field.required ? 'required' : ''}>`;
    }
    
    return `
        <div class="mb-3">
            <label class="form-label">${field.label}</label>
            ${inputHtml}
        </div>
    `;
}

function renderFAQField(field) {
    return `
        <div class="mb-3">
            <label class="form-label">${field.label} *</label>
            <div id="faqContainer">
                <div class="faq-entry mb-3">
                    <input type="text" class="form-control mb-2" placeholder="Question" required>
                    <textarea class="form-control" placeholder="Answer" rows="2" required></textarea>
                </div>
            </div>
            <button type="button" class="btn btn-sm btn-outline-primary" id="addFaqBtn">
                <i class="bi bi-plus-circle me-1"></i>Add Question
            </button>
        </div>
    `;
}

function renderBreadcrumbField(field) {
    return `
        <div class="mb-3">
            <label class="form-label">${field.label} *</label>
            <div id="breadcrumbContainer">
                <div class="breadcrumb-entry mb-3">
                    <input type="text" class="form-control mb-2" placeholder="Page Name (e.g., Home)" required>
                    <input type="url" class="form-control" placeholder="Page URL" required>
                </div>
            </div>
            <button type="button" class="btn btn-sm btn-outline-primary" id="addBreadcrumbBtn">
                <i class="bi bi-plus-circle me-1"></i>Add Item
            </button>
        </div>
    `;
}

function setupFAQHandlers() {
    document.getElementById('addFaqBtn').addEventListener('click', function() {
        const container = document.getElementById('faqContainer');
        const entry = document.createElement('div');
        entry.className = 'faq-entry mb-3';
        entry.innerHTML = `
            <div class="d-flex align-items-start gap-2">
                <div class="flex-grow-1">
                    <input type="text" class="form-control mb-2" placeholder="Question" required>
                    <textarea class="form-control" placeholder="Answer" rows="2" required></textarea>
                </div>
                <button type="button" class="btn btn-sm btn-outline-danger remove-faq">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `;
        container.appendChild(entry);
        
        entry.querySelector('.remove-faq').addEventListener('click', function() {
            entry.remove();
        });
    });
}

function setupBreadcrumbHandlers() {
    document.getElementById('addBreadcrumbBtn').addEventListener('click', function() {
        const container = document.getElementById('breadcrumbContainer');
        const entry = document.createElement('div');
        entry.className = 'breadcrumb-entry mb-3';
        entry.innerHTML = `
            <div class="d-flex align-items-start gap-2">
                <div class="flex-grow-1">
                    <input type="text" class="form-control mb-2" placeholder="Page Name" required>
                    <input type="url" class="form-control" placeholder="Page URL" required>
                </div>
                <button type="button" class="btn btn-sm btn-outline-danger remove-breadcrumb">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `;
        container.appendChild(entry);
        
        entry.querySelector('.remove-breadcrumb').addEventListener('click', function() {
            entry.remove();
        });
    });
}

function generateSchema() {
    const formData = new FormData(document.getElementById('schemaForm'));
    let data = {};
    
    // Handle regular fields
    for (let [key, value] of formData.entries()) {
        if (key.includes('.')) {
            const parts = key.split('.');
            if (!data[parts[0]]) data[parts[0]] = {};
            data[parts[0]][parts[1]] = value;
        } else {
            data[key] = value;
        }
    }
    
    // Handle FAQ
    if (currentSchemaType === 'faq') {
        const faqEntries = document.querySelectorAll('#faqContainer .faq-entry');
        data.questions = [];
        faqEntries.forEach(entry => {
            const inputs = entry.querySelectorAll('input, textarea');
            data.questions.push({
                question: inputs[0].value,
                answer: inputs[1].value
            });
        });
    }
    
    // Handle Breadcrumb
    if (currentSchemaType === 'breadcrumb') {
        const breadcrumbEntries = document.querySelectorAll('#breadcrumbContainer .breadcrumb-entry');
        data.items = [];
        breadcrumbEntries.forEach(entry => {
            const inputs = entry.querySelectorAll('input');
            data.items.push({
                name: inputs[0].value,
                url: inputs[1].value
            });
        });
    }
    
    // Call API
    fetch('../../api/schema-generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'generate',
            type: currentSchemaType,
            data: data
        })
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            currentSchema = result;
            displaySchema(result);
            showResults();
        } else {
            showNotification(result.message || 'Failed to generate schema', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error generating schema', 'error');
    });
}

function displaySchema(result) {
    document.getElementById('schemaJson').textContent = result.json;
    document.getElementById('schemaHtml').textContent = result.html;
    
    // Setup buttons
    document.getElementById('copyBtn').onclick = function() {
        copyToClipboard(result.json, this);
    };
    
    document.getElementById('downloadBtn').onclick = function() {
        downloadSchema(result.json);
    };
}

function showResults() {
    document.getElementById('resultsSection').style.display = 'block';
    document.getElementById('resultsSection').scrollIntoView({ behavior: 'smooth' });
}

function hideResults() {
    document.getElementById('resultsSection').style.display = 'none';
}

function showJsonView() {
    document.getElementById('jsonView').style.display = 'block';
    document.getElementById('htmlView').style.display = 'none';
    document.getElementById('viewJsonBtn').classList.add('active');
    document.getElementById('viewHtmlBtn').classList.remove('active');
}

function showHtmlView() {
    document.getElementById('jsonView').style.display = 'none';
    document.getElementById('htmlView').style.display = 'block';
    document.getElementById('viewJsonBtn').classList.remove('active');
    document.getElementById('viewHtmlBtn').classList.add('active');
}

function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        const originalHTML = button.innerHTML;
        button.innerHTML = '<i class="bi bi-check"></i> Copied!';
        button.classList.add('btn-success');
        
        setTimeout(() => {
            button.innerHTML = originalHTML;
            button.classList.remove('btn-success');
        }, 2000);
        
        showNotification('Schema copied to clipboard!', 'success');
    });
}

function downloadSchema(json) {
    const blob = new Blob([json], { type: 'application/ld+json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `schema-${currentSchemaType}-${Date.now()}.json`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    showNotification('Schema downloaded successfully!', 'success');
}

function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : (type === 'success' ? 'alert-success' : 'alert-info');
    const icon = type === 'error' ? 'exclamation-circle' : (type === 'success' ? 'check-circle' : 'info-circle');
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}
