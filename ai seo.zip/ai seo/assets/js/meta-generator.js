// AI Meta Generator

let currentMetaData = null;

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('metaGeneratorForm');
    const clearBtn = document.getElementById('clearBtn');
    const regenerateBtn = document.getElementById('regenerateBtn');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        generateMetaTags();
    });
    
    clearBtn.addEventListener('click', function() {
        form.reset();
        document.getElementById('welcomeSection').style.display = 'block';
        document.getElementById('resultsSection').style.display = 'none';
        document.getElementById('regenerateBtn').style.display = 'none';
        currentMetaData = null;
    });
    
    regenerateBtn.addEventListener('click', function() {
        generateMetaTags();
    });
});

function generateMetaTags() {
    const focusKeyword = document.getElementById('focus_keyword').value;
    const websiteUrl = document.getElementById('website_url').value;
    const pageType = document.getElementById('page_type').value;
    
    // Hide sections
    document.getElementById('welcomeSection').style.display = 'none';
    document.getElementById('resultsSection').style.display = 'none';
    document.getElementById('loadingSection').style.display = 'block';
    
    fetch('../../api/meta-generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'generate',
            focus_keyword: focusKeyword,
            website_url: websiteUrl,
            page_type: pageType
        })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('loadingSection').style.display = 'none';
        
        if (data.success) {
            currentMetaData = {
                focus_keyword: focusKeyword,
                meta_data: data
            };
            
            displayMetaTags(data);
            document.getElementById('resultsSection').style.display = 'block';
            document.getElementById('regenerateBtn').style.display = 'block';
        } else {
            showNotification(data.message || 'Failed to generate meta tags', 'error');
            document.getElementById('welcomeSection').style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('loadingSection').style.display = 'none';
        document.getElementById('welcomeSection').style.display = 'block';
        showNotification('Error generating meta tags', 'error');
    });
}

function displayMetaTags(data) {
    // SEO Title
    document.getElementById('seoTitlePreview').textContent = data.seo_title;
    updateCharCounter('title', data.seo_title, 60);
    
    // Meta Description
    document.getElementById('metaDescPreview').textContent = data.meta_description;
    updateCharCounter('desc', data.meta_description, 160);
    
    // OpenGraph Tags
    const ogHTML = `<meta property="og:title" content="${data.og_title}" />
<meta property="og:description" content="${data.og_description}" />
<meta property="og:image" content="YOUR_IMAGE_URL" />
<meta property="og:type" content="website" />`;
    document.getElementById('ogTagsCode').textContent = ogHTML;
    
    // Twitter Tags
    const twitterHTML = `<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${data.twitter_title}" />
<meta name="twitter:description" content="${data.twitter_description}" />
<meta name="twitter:image" content="YOUR_IMAGE_URL" />`;
    document.getElementById('twitterTagsCode').textContent = twitterHTML;
    
    // SEO Score
    animateSEOScore(data.seo_score || 0);
    
    // Setup copy buttons
    setupCopyButtons(data);
    
    // Setup action buttons
    setupActionButtons();
}

function updateCharCounter(type, text, maxChars) {
    const charCount = text.length;
    const percentage = (charCount / maxChars) * 100;
    
    document.getElementById(type + 'CharCount').textContent = charCount;
    const progress = document.getElementById(type + 'Progress');
    progress.style.width = Math.min(percentage, 100) + '%';
    
    // Color coding
    if (charCount > maxChars) {
        progress.classList.remove('bg-success', 'bg-warning');
        progress.classList.add('bg-danger');
    } else if (charCount > maxChars * 0.9) {
        progress.classList.remove('bg-success', 'bg-danger');
        progress.classList.add('bg-warning');
    } else {
        progress.classList.remove('bg-warning', 'bg-danger');
        progress.classList.add('bg-success');
    }
}

function animateSEOScore(score) {
    const circle = document.getElementById('scoreCircleMeta');
    const scoreValue = document.getElementById('seoScoreValue');
    
    const circumference = 2 * Math.PI * 45;
    const offset = circumference - (score / 100) * circumference;
    
    let current = 0;
    const duration = 2000;
    const stepTime = 20;
    const steps = duration / stepTime;
    const increment = score / steps;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= score) {
            current = score;
            clearInterval(timer);
        }
        
        scoreValue.textContent = Math.round(current);
        const currentOffset = circumference - (current / 100) * circumference;
        circle.style.strokeDashoffset = currentOffset;
    }, stepTime);
    
    // Color based on score
    if (score >= 80) {
        circle.style.stroke = '#28A745';
    } else if (score >= 60) {
        circle.style.stroke = '#FF6B00';
    } else {
        circle.style.stroke = '#DC3545';
    }
}

function setupCopyButtons(data) {
    document.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const target = this.dataset.target;
            let textToCopy = '';
            
            if (target === 'seo_title') {
                textToCopy = data.seo_title;
            } else if (target === 'meta_description') {
                textToCopy = data.meta_description;
            } else if (target === 'og_tags') {
                textToCopy = document.getElementById('ogTagsCode').textContent;
            } else if (target === 'twitter_tags') {
                textToCopy = document.getElementById('twitterTagsCode').textContent;
            }
            
            copyToClipboard(textToCopy, this);
        });
    });
}

function setupActionButtons() {
    // Save button
    document.getElementById('saveBtn').addEventListener('click', function() {
        if (!currentMetaData) return;
        saveMetaTags();
    });
    
    // Copy all HTML
    document.getElementById('copyAllBtn').addEventListener('click', function() {
        if (!currentMetaData) return;
        
        const allHTML = `<!-- SEO Meta Tags -->
<title>${currentMetaData.meta_data.seo_title}</title>
<meta name="description" content="${currentMetaData.meta_data.meta_description}" />

<!-- OpenGraph Tags -->
${document.getElementById('ogTagsCode').textContent}

<!-- Twitter Card Tags -->
${document.getElementById('twitterTagsCode').textContent}`;
        
        copyToClipboard(allHTML, this);
    });
}

function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        const originalHTML = button.innerHTML;
        button.innerHTML = '<i class="bi bi-check"></i> Copied!';
        button.classList.add('btn-success');
        
        setTimeout(() => {
            button.innerHTML = originalHTML;
            button.classList.remove('btn-success');
        }, 2000);
        
        showNotification('Copied to clipboard!', 'success');
    });
}

function saveMetaTags() {
    fetch('../../api/meta-generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'save',
            ...currentMetaData
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Meta tags saved successfully!', 'success');
        } else {
            showNotification(data.message || 'Failed to save meta tags', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error saving meta tags', 'error');
    });
}

function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : (type === 'success' ? 'alert-success' : 'alert-info');
    const icon = type === 'error' ? 'exclamation-circle' : (type === 'success' ? 'check-circle' : 'info-circle');
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}
