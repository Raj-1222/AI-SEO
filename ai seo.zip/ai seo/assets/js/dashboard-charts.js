// Dashboard Charts and Animations

// Counter Animation for Stats
document.addEventListener('DOMContentLoaded', function() {
    // Animate counters
    const counters = document.querySelectorAll('.counter');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000; // 2 seconds
        const increment = target / (duration / 16); // 60fps
        let current = 0;
        
        const updateCounter = () => {
            current += increment;
            if (current < target) {
                counter.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        };
        
        updateCounter();
    });
    
    // Initialize all charts
    initCharts();
});

function initCharts() {
    // SEO Score Distribution Chart (Doughnut)
    const scoreCtx = document.getElementById('scoreDistributionChart');
    if (scoreCtx) {
        new Chart(scoreCtx.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['Excellent (90-100)', 'Good (70-89)', 'Average (50-69)', 'Poor (<50)'],
                datasets: [{
                    data: [45, 35, 15, 5],
                    backgroundColor: ['#28A745', '#FF6B00', '#FFC107', '#DC3545'],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + '%';
                            }
                        }
                    }
                },
                animation: {
                    animateRotate: true,
                    animateScale: true,
                    duration: 1500,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }

    // Reports per Month Chart (Bar)
    const reportsCtx = document.getElementById('reportsChart');
    if (reportsCtx) {
        new Chart(reportsCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Reports Generated',
                    data: [320, 450, 380, 520, 490, 630],
                    backgroundColor: '#FF6B00',
                    borderRadius: 8,
                    hoverBackgroundColor: '#E55F00'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            font: {
                                size: 11
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                size: 11
                            }
                        }
                    }
                },
                animation: {
                    duration: 1500,
                    easing: 'easeInOutQuart',
                    delay: (context) => {
                        return context.dataIndex * 100;
                    }
                }
            }
        });
    }

    // Issue Distribution Chart (Doughnut)
    const issueCtx = document.getElementById('issueChart');
    if (issueCtx) {
        new Chart(issueCtx.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['SEO Issues', 'Performance', 'Accessibility', 'Security'],
                datasets: [{
                    data: [142, 89, 56, 23],
                    backgroundColor: ['#0B1F4D', '#FF6B00', '#667EEA', '#28A745'],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.parsed + ' issues';
                            }
                        }
                    }
                },
                animation: {
                    animateRotate: true,
                    animateScale: true,
                    duration: 1500,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
}
