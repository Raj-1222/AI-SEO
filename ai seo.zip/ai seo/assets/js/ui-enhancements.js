/**
 * Aurify AI - UI Enhancement Script
 * Version: 2.0
 * Modern interactions and animations
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all UI enhancements
    initSidebarToggle();
    initCounterAnimations();
    initScrollAnimations();
    initTooltips();
    initCopyButtons();
    initFormValidation();
    initLoadingStates();
    initTableInteractions();
});

/**
 * Sidebar Toggle for Mobile
 */
function initSidebarToggle() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
            document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
        });
        
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
    
    // Close sidebar when clicking a menu item on mobile
    if (window.innerWidth <= 768) {
        const menuItems = document.querySelectorAll('.menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', function() {
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }
}

/**
 * Animated Counter for Statistics
 */
function initCounterAnimations() {
    const counters = document.querySelectorAll('.counter');
    
    const animateCounter = (element) => {
        const target = parseInt(element.getAttribute('data-target'));
        const duration = 2000; // 2 seconds
        const increment = target / (duration / 16); // 60fps
        let current = 0;
        
        const updateCounter = () => {
            current += increment;
            if (current < target) {
                element.textContent = Math.floor(current);
                requestAnimationFrame(updateCounter);
            } else {
                element.textContent = target;
            }
        };
        
        updateCounter();
    };
    
    // Intersection Observer for triggering animations when visible
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && entry.target.textContent === '0') {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    counters.forEach(counter => observer.observe(counter));
}

/**
 * Scroll-triggered Animations
 */
function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('.animate-fade-in, .animate-slide-up, .animate-scale-in');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });
}

/**
 * Enhanced Tooltips
 */
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    if (typeof bootstrap !== 'undefined') {
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl, {
                animation: true,
                delay: { show: 300, hide: 100 }
            });
        });
    }
}

/**
 * Copy to Clipboard Functionality
 */
function initCopyButtons() {
    const copyButtons = document.querySelectorAll('.copy-btn');
    
    copyButtons.forEach(button => {
        button.addEventListener('click', async function(e) {
            e.preventDefault();
            
            const target = this.getAttribute('data-target');
            let textToCopy = '';
            
            // Get text based on target
            if (target === 'title') {
                textToCopy = document.getElementById('blogTitle')?.textContent || '';
            } else if (target === 'seo_title') {
                textToCopy = document.getElementById('seoTitlePreview')?.textContent || '';
            } else if (target === 'meta_description') {
                textToCopy = document.getElementById('metaDescPreview')?.textContent || '';
            } else if (target === 'og_tags') {
                textToCopy = document.getElementById('ogTagsCode')?.textContent || '';
            } else if (target === 'twitter_tags') {
                textToCopy = document.getElementById('twitterTagsCode')?.textContent || '';
            }
            
            // Copy to clipboard
            try {
                await navigator.clipboard.writeText(textToCopy);
                
                // Visual feedback
                const originalHTML = this.innerHTML;
                const originalClasses = this.className;
                
                this.innerHTML = '<i class="bi bi-check-lg"></i> Copied!';
                this.classList.add('copied', 'btn-success');
                this.classList.remove('btn-outline-primary');
                
                setTimeout(() => {
                    this.innerHTML = originalHTML;
                    this.className = originalClasses;
                }, 2000);
            } catch (err) {
                console.error('Failed to copy:', err);
                showNotification('Failed to copy to clipboard', 'error');
            }
        });
    });
}

/**
 * Enhanced Form Validation
 */
function initFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
        
        // Real-time validation feedback
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                if (this.value) {
                    this.classList.add(this.checkValidity() ? 'is-valid' : 'is-invalid');
                }
            });
            
            input.addEventListener('input', function() {
                if (this.classList.contains('is-invalid') || this.classList.contains('is-valid')) {
                    this.classList.remove('is-invalid', 'is-valid');
                    this.classList.add(this.checkValidity() ? 'is-valid' : 'is-invalid');
                }
            });
        });
    });
}

/**
 * Loading State Management
 */
function initLoadingStates() {
    // Add loading class to buttons on form submit
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn && !submitBtn.disabled) {
                submitBtn.classList.add('loading');
                submitBtn.disabled = true;
            }
        });
    });
}

/**
 * Enhanced Table Interactions
 */
function initTableInteractions() {
    const tables = document.querySelectorAll('.table-hover tbody tr');
    
    tables.forEach(row => {
        row.addEventListener('click', function() {
            // Add pulse animation on click
            this.style.animation = 'none';
            setTimeout(() => {
                this.style.animation = 'pulse 0.3s ease';
            }, 10);
        });
    });
    
    // Table responsive scroll indicator
    const tableContainers = document.querySelectorAll('.table-responsive');
    tableContainers.forEach(container => {
        const checkScroll = () => {
            const isScrollable = container.scrollWidth > container.clientWidth;
            const isScrolledToEnd = container.scrollLeft + container.clientWidth >= container.scrollWidth - 10;
            
            container.classList.toggle('scrolling', isScrollable && !isScrolledToEnd);
        };
        
        container.addEventListener('scroll', checkScroll);
        window.addEventListener('resize', checkScroll);
        checkScroll();
    });
}

/**
 * Show Notification (Toast)
 */
function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : 
                      type === 'success' ? 'alert-success' : 
                      type === 'warning' ? 'alert-warning' : 'alert-info';
    
    const icon = type === 'error' ? 'exclamation-circle' : 
                 type === 'success' ? 'check-circle' : 
                 type === 'warning' ? 'exclamation-triangle' : 'info-circle';
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alert.style.zIndex = '9999';
    alert.style.minWidth = '300px';
    alert.style.maxWidth = '500px';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

/**
 * Smooth Scroll to Element
 */
function scrollToElement(elementId, offset = 100) {
    const element = document.getElementById(elementId);
    if (element) {
        const yOffset = -offset;
        const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
        
        window.scrollTo({
            top: y,
            behavior: 'smooth'
        });
    }
}

/**
 * Range Slider Value Display
 */
const rangeInputs = document.querySelectorAll('input[type="range"]');
rangeInputs.forEach(input => {
    const valueDisplay = document.getElementById(input.id + 'Value');
    if (valueDisplay) {
        input.addEventListener('input', function() {
            valueDisplay.textContent = this.value;
        });
    }
});

/**
 * Character Counter for Textareas
 */
const textareas = document.querySelectorAll('textarea[maxlength]');
textareas.forEach(textarea => {
    const maxLength = textarea.getAttribute('maxlength');
    const counter = document.createElement('small');
    counter.className = 'form-text text-muted d-block text-end mt-1';
    counter.textContent = `0 / ${maxLength}`;
    textarea.parentNode.appendChild(counter);
    
    textarea.addEventListener('input', function() {
        const currentLength = this.value.length;
        counter.textContent = `${currentLength} / ${maxLength}`;
        counter.classList.toggle('text-warning', currentLength > maxLength * 0.8);
        counter.classList.toggle('text-danger', currentLength === parseInt(maxLength));
    });
});

/**
 * Ripple Effect on Buttons
 */
document.addEventListener('click', function(e) {
    const target = e.target.closest('.btn, .menu-item, .quick-action-btn');
    if (target) {
        const ripple = document.createElement('span');
        ripple.className = 'ripple';
        ripple.style.left = e.offsetX + 'px';
        ripple.style.top = e.offsetY + 'px';
        target.appendChild(ripple);
        
        setTimeout(() => ripple.remove(), 600);
    }
});

/**
 * Lazy Loading Images
 */
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    const lazyImages = document.querySelectorAll('img.lazy');
    lazyImages.forEach(img => imageObserver.observe(img));
}

/**
 * Keyboard Shortcuts
 */
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + K to focus search
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('input[type="search"]');
        if (searchInput) searchInput.focus();
    }
    
    // ESC to close modals/sidebar
    if (e.key === 'Escape') {
        const sidebar = document.querySelector('.sidebar.active');
        const overlay = document.querySelector('.sidebar-overlay.active');
        if (sidebar && overlay) {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    }
});

/**
 * Auto-save Form Data (Local Storage)
 */
function initAutoSave(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    const saveKey = `form_${formId}_autosave`;
    
    // Load saved data
    const savedData = localStorage.getItem(saveKey);
    if (savedData) {
        const data = JSON.parse(savedData);
        Object.keys(data).forEach(key => {
            const input = form.querySelector(`[name="${key}"]`);
            if (input) input.value = data[key];
        });
    }
    
    // Save on input
    form.addEventListener('input', debounce(function() {
        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => data[key] = value);
        localStorage.setItem(saveKey, JSON.stringify(data));
    }, 1000));
    
    // Clear on successful submit
    form.addEventListener('submit', function() {
        localStorage.removeItem(saveKey);
    });
}

/**
 * Debounce Helper
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Export Functions for Global Use
 */
window.AurifyUI = {
    showNotification,
    scrollToElement,
    initAutoSave
};
