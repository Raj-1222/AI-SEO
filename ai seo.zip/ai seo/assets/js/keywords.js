// AI Keyword Generator

let currentKeywordsData = null;

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('keywordGeneratorForm');
    const generateBtn = document.getElementById('generateBtn');
    const clearBtn = document.getElementById('clearBtn');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        generateKeywords();
    });
    
    clearBtn.addEventListener('click', function() {
        form.reset();
        document.getElementById('welcomeSection').style.display = 'block';
        document.getElementById('resultsSection').style.display = 'none';
        currentKeywordsData = null;
    });
});

function generateKeywords() {
    const websiteUrl = document.getElementById('website_url').value;
    const industry = document.getElementById('industry').value;
    const location = document.getElementById('location').value;
    
    // Hide welcome, show loading
    document.getElementById('welcomeSection').style.display = 'none';
    document.getElementById('resultsSection').style.display = 'none';
    document.getElementById('loadingSection').style.display = 'block';
    
    fetch('../../api/keyword-generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'generate',
            website_url: websiteUrl,
            industry: industry,
            location: location
        })
    })
    .then(response => {
        // Log response for debugging
        console.log('Response status:', response.status);
        if (!response.ok) {
            throw new Error('HTTP error ' + response.status);
        }
        return response.text();
    })
    .then(text => {
        // Log raw response for debugging
        console.log('Raw response:', text.substring(0, 200));
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error('JSON parse error:', e);
            console.error('Response was:', text);
            throw new Error('Invalid JSON response');
        }
    })
    .then(data => {
        console.log('Parsed data:', data);
        document.getElementById('loadingSection').style.display = 'none';
        
        if (data.success) {
            currentKeywordsData = {
                website_url: websiteUrl,
                industry: industry,
                location: location,
                keywords_data: {
                    primary_keywords: data.primary_keywords,
                    secondary_keywords: data.secondary_keywords,
                    long_tail_keywords: data.long_tail_keywords
                }
            };
            
            displayKeywords(data);
            document.getElementById('resultsSection').style.display = 'block';
        } else {
            showNotification(data.message || 'Failed to generate keywords', 'error');
            document.getElementById('welcomeSection').style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('loadingSection').style.display = 'none';
        document.getElementById('welcomeSection').style.display = 'block';
        showNotification('Error generating keywords', 'error');
    });
}

function displayKeywords(data) {
    displayKeywordSection(data.primary_keywords, 'primaryKeywordsContainer', 'primary');
    displayKeywordSection(data.secondary_keywords, 'secondaryKeywordsContainer', 'secondary');
    displayKeywordSection(data.long_tail_keywords, 'longTailKeywordsContainer', 'longtail');
    
    // Setup action buttons
    setupActionButtons();
}

function displayKeywordSection(keywords, containerId, type) {
    const container = document.getElementById(containerId);
    
    if (!keywords || keywords.length === 0) {
        container.innerHTML = '<p class="text-muted">No keywords generated</p>';
        return;
    }
    
    let html = '<div class="keyword-cards">';
    
    keywords.forEach((kw, index) => {
        const difficultyColor = getDifficultyColor(kw.difficulty);
        const priorityColor = getPriorityColor(kw.priority);
        const intentIcon = getIntentIcon(kw.search_intent);
        
        html += `
            <div class="keyword-card" data-keyword='${JSON.stringify(kw)}'>
                <div class="keyword-header">
                    <h6 class="keyword-text">${kw.keyword}</h6>
                    <button class="btn-copy-keyword" onclick="copyKeyword('${kw.keyword}', this)">
                        <i class="bi bi-clipboard"></i>
                    </button>
                </div>
                <div class="keyword-meta">
                    <span class="badge bg-${difficultyColor}">${kw.difficulty}</span>
                    <span class="badge bg-${priorityColor}">${kw.priority} priority</span>
                    <span class="badge bg-info">${intentIcon} ${kw.search_intent}</span>
                </div>
                <div class="keyword-stats mt-2">
                    <small class="text-muted">
                        <i class="bi bi-graph-up me-1"></i>Volume: ${kw.search_volume}
                        ${kw.monthly_searches ? ` (~${kw.monthly_searches}/mo)` : ''}
                    </small>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

function getDifficultyColor(difficulty) {
    const colors = {
        'easy': 'success',
        'medium': 'warning',
        'hard': 'danger'
    };
    return colors[difficulty] || 'secondary';
}

function getPriorityColor(priority) {
    const colors = {
        'high': 'danger',
        'medium': 'warning',
        'low': 'info'
    };
    return colors[priority] || 'secondary';
}

function getIntentIcon(intent) {
    const icons = {
        'informational': '📚',
        'navigational': '🧭',
        'transactional': '💰',
        'commercial': '🛒'
    };
    return icons[intent] || '🔍';
}

function copyKeyword(keyword, button) {
    navigator.clipboard.writeText(keyword).then(() => {
        const icon = button.querySelector('i');
        icon.className = 'bi bi-check';
        button.classList.add('copied');
        
        setTimeout(() => {
            icon.className = 'bi bi-clipboard';
            button.classList.remove('copied');
        }, 2000);
    });
}

function setupActionButtons() {
    // Copy All
    document.getElementById('copyAllBtn').addEventListener('click', function() {
        if (!currentKeywordsData) return;
        
        let allKeywords = [];
        const data = currentKeywordsData.keywords_data;
        
        allKeywords = allKeywords.concat(data.primary_keywords.map(k => k.keyword));
        allKeywords = allKeywords.concat(data.secondary_keywords.map(k => k.keyword));
        allKeywords = allKeywords.concat(data.long_tail_keywords.map(k => k.keyword));
        
        navigator.clipboard.writeText(allKeywords.join('\n')).then(() => {
            showNotification('All keywords copied to clipboard!', 'success');
        });
    });
    
    // Export CSV
    document.getElementById('exportBtn').addEventListener('click', function() {
        if (!currentKeywordsData) return;
        exportToCSV();
    });
    
    // Save
    document.getElementById('saveBtn').addEventListener('click', function() {
        if (!currentKeywordsData) return;
        saveKeywords();
    });
}

function exportToCSV() {
    const data = currentKeywordsData.keywords_data;
    let csv = 'Type,Keyword,Difficulty,Priority,Search Intent,Search Volume,Monthly Searches\n';
    
    // Primary keywords
    data.primary_keywords.forEach(kw => {
        csv += `Primary,"${kw.keyword}",${kw.difficulty},${kw.priority},${kw.search_intent},${kw.search_volume},${kw.monthly_searches || 'N/A'}\n`;
    });
    
    // Secondary keywords
    data.secondary_keywords.forEach(kw => {
        csv += `Secondary,"${kw.keyword}",${kw.difficulty},${kw.priority},${kw.search_intent},${kw.search_volume},${kw.monthly_searches || 'N/A'}\n`;
    });
    
    // Long-tail keywords
    data.long_tail_keywords.forEach(kw => {
        csv += `Long-tail,"${kw.keyword}",${kw.difficulty},${kw.priority},${kw.search_intent},${kw.search_volume},${kw.monthly_searches || 'N/A'}\n`;
    });
    
    // Download
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `keywords-${Date.now()}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    showNotification('Keywords exported successfully!', 'success');
}

function saveKeywords() {
    fetch('../../api/keyword-generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'save',
            ...currentKeywordsData
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Keywords saved successfully!', 'success');
        } else {
            showNotification(data.message || 'Failed to save keywords', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error saving keywords', 'error');
    });
}

function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : (type === 'success' ? 'alert-success' : 'alert-info');
    const icon = type === 'error' ? 'exclamation-circle' : (type === 'success' ? 'check-circle' : 'info-circle');
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}
