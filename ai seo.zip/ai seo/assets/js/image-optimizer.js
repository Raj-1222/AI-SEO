/**
 * Image Optimizer Suite - JavaScript
 * Handles all image upload, processing, and optimization operations
 */

// Global variables
let uploadedFiles = [];
let currentImageIndex = 0;
const API_URL = '../../api/image-optimizer.php';

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeImageOptimizer();
    loadStatistics();
    loadHistory();
});

/**
 * Initialize all event listeners and UI components
 */
function initializeImageOptimizer() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    const browseBtn = document.getElementById('browseBtn');
    const processBtn = document.getElementById('processBtn');
    const clearBtn = document.getElementById('clearBtn');
    
    // Upload area click
    uploadArea.addEventListener('click', () => fileInput.click());
    browseBtn.addEventListener('click', () => fileInput.click());
    
    // File input change
    fileInput.addEventListener('change', handleFileSelect);
    
    // Drag and drop
    uploadArea.addEventListener('dragover', handleDragOver);
    uploadArea.addEventListener('dragleave', handleDragLeave);
    uploadArea.addEventListener('drop', handleDrop);
    
    // Process button
    processBtn.addEventListener('click', processImages);
    
    // Clear button
    clearBtn.addEventListener('click', clearAllImages);
    
    // Quality sliders
    document.getElementById('qualitySlider').addEventListener('input', function() {
        document.getElementById('qualityValue').textContent = this.value;
    });
    
    document.getElementById('convertQuality').addEventListener('input', function() {
        document.getElementById('convertQualityValue').textContent = this.value;
    });
    
    document.getElementById('watermarkOpacity').addEventListener('input', function() {
        document.getElementById('watermarkOpacityValue').textContent = this.value;
    });
    
    // Compression level change
    document.getElementById('compressionLevel').addEventListener('change', function() {
        const qualityMap = {
            'lossless': 100,
            'low': 90,
            'medium': 85,
            'high': 75,
            'maximum': 60
        };
        const slider = document.getElementById('qualitySlider');
        slider.value = qualityMap[this.value];
        document.getElementById('qualityValue').textContent = slider.value;
    });
    
    // Preset buttons
    document.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.getElementById('resizeWidth').value = this.dataset.width;
            document.getElementById('resizeHeight').value = this.dataset.height;
        });
    });
    
    // Transform buttons
    document.getElementById('rotate90Btn').addEventListener('click', () => rotateImage(90));
    document.getElementById('rotate180Btn').addEventListener('click', () => rotateImage(180));
    document.getElementById('flipHBtn').addEventListener('click', () => flipImage('horizontal'));
    document.getElementById('flipVBtn').addEventListener('click', () => flipImage('vertical'));
    
    // History actions
    document.getElementById('refreshHistoryBtn').addEventListener('click', loadHistory);
    document.getElementById('bulkDeleteBtn').addEventListener('click', bulkDeleteHistory);
    document.getElementById('selectAllHistory').addEventListener('change', toggleSelectAll);
}

/**
 * Handle file selection
 */
function handleFileSelect(e) {
    const files = Array.from(e.target.files);
    addFilesToQueue(files);
}

/**
 * Handle drag over
 */
function handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById('uploadArea').classList.add('drag-over');
}

/**
 * Handle drag leave
 */
function handleDragLeave(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById('uploadArea').classList.remove('drag-over');
}

/**
 * Handle file drop
 */
function handleDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    document.getElementById('uploadArea').classList.remove('drag-over');
    
    const files = Array.from(e.dataTransfer.files);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length === 0) {
        showNotification('Please drop image files only', 'error');
        return;
    }
    
    addFilesToQueue(imageFiles);
}

/**
 * Add files to upload queue
 */
function addFilesToQueue(files) {
    if (files.length === 0) return;
    
    // Validate file sizes
    const maxSize = 10 * 1024 * 1024; // 10MB
    const validFiles = files.filter(file => {
        if (file.size > maxSize) {
            showNotification(`${file.name} exceeds maximum size of 10MB`, 'error');
            return false;
        }
        return true;
    });
    
    if (validFiles.length === 0) return;
    
    uploadedFiles = uploadedFiles.concat(validFiles);
    displayImagePreviews();
    
    // Show processing options
    document.getElementById('processingOptions').style.display = 'block';
    
    showNotification(`${validFiles.length} image(s) added successfully`, 'success');
}

/**
 * Display image previews
 */
function displayImagePreviews() {
    const container = document.getElementById('imagePreview');
    container.innerHTML = '';
    container.style.display = 'block';
    
    uploadedFiles.forEach((file, index) => {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            const previewHTML = `
                <div class="image-preview-item" data-index="${index}">
                    <img src="${e.target.result}" alt="${file.name}">
                    <button class="remove-btn" onclick="removeImage(${index})">
                        <i class="bi bi-x"></i>
                    </button>
                    <div class="image-preview-info">
                        <h6 title="${file.name}">${file.name}</h6>
                        <div class="image-preview-meta">
                            <span>${formatBytes(file.size)}</span>
                            <span>${file.type.split('/')[1].toUpperCase()}</span>
                        </div>
                        <div class="image-preview-meta">
                            <span id="img-dimensions-${index}">Loading...</span>
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', previewHTML);
            
            // Get image dimensions
            const img = new Image();
            img.onload = function() {
                document.getElementById(`img-dimensions-${index}`).textContent = 
                    `${this.width} × ${this.height}`;
            };
            img.src = e.target.result;
        };
        
        reader.readAsDataURL(file);
    });
}

/**
 * Remove image from queue
 */
function removeImage(index) {
    uploadedFiles.splice(index, 1);
    
    if (uploadedFiles.length === 0) {
        document.getElementById('imagePreview').style.display = 'none';
        document.getElementById('processingOptions').style.display = 'none';
    } else {
        displayImagePreviews();
    }
    
    showNotification('Image removed', 'info');
}

/**
 * Clear all images
 */
function clearAllImages() {
    uploadedFiles = [];
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('processingOptions').style.display = 'none';
    document.getElementById('resultsSection').style.display = 'none';
    document.getElementById('fileInput').value = '';
    showNotification('All images cleared', 'info');
}

/**
 * Process images based on selected operation
 */
async function processImages() {
    if (uploadedFiles.length === 0) {
        showNotification('Please upload images first', 'error');
        return;
    }
    
    console.log('Starting to process', uploadedFiles.length, 'images');
    
    // Get active tab
    const activeTab = document.querySelector('.nav-pills .nav-link.active');
    const operation = activeTab.getAttribute('data-bs-target').replace('#', '').replace('Tab', '');
    
    console.log('Operation:', operation);
    
    // Show processing modal
    showProcessingModal();
    
    const results = [];
    let successCount = 0;
    let failCount = 0;
    
    for (let i = 0; i < uploadedFiles.length; i++) {
        const file = uploadedFiles[i];
        updateProcessingProgress(i + 1, uploadedFiles.length, file.name);
        
        try {
            console.log('Processing file:', file.name);
            
            // First upload the file
            const uploadResult = await uploadFile(file);
            console.log('Upload result:', uploadResult);
            
            if (!uploadResult.success) {
                failCount++;
                results.push({ success: false, filename: file.name, error: uploadResult.message || 'Upload failed' });
                continue;
            }
            
            const filename = uploadResult.data.filename;
            console.log('Uploaded as:', filename);
            
            // Then process based on operation
            let processResult;
            switch (operation) {
                case 'compress':
                    processResult = await compressImage(filename);
                    break;
                case 'resize':
                    processResult = await resizeImage(filename);
                    break;
                case 'convert':
                    processResult = await convertImage(filename);
                    break;
                case 'watermark':
                    processResult = await watermarkImage(filename);
                    break;
                default:
                    processResult = await compressImage(filename);
            }
            
            console.log('Process result:', processResult);
            
            if (processResult.success) {
                successCount++;
            } else {
                failCount++;
            }
            
            results.push({
                success: processResult.success,
                filename: file.name,
                data: processResult.data,
                error: processResult.message || processResult.error
            });
            
        } catch (error) {
            console.error('Error processing', file.name, ':', error);
            failCount++;
            results.push({ success: false, filename: file.name, error: error.message || 'Unknown error' });
        }
    }
    
    console.log('Processing complete. Success:', successCount, 'Failed:', failCount);
    
    // Hide processing modal
    hideProcessingModal();
    
    // Display results
    if (results.length > 0) {
        displayResults(results);
        
        // Only clear if at least one succeeded
        if (successCount > 0) {
            // Refresh statistics and history
            loadStatistics();
            loadHistory();
            
            // Clear uploaded files after showing results
            setTimeout(() => {
                clearAllImages();
            }, 1000);
        } else {
            // Don't clear if all failed - let user try again
            showNotification('All images failed to process. Please check the errors and try again.', 'error');
        }
    } else {
        showNotification('No images were processed', 'error');
    }
}

/**
 * Upload file to server
 */
async function uploadFile(file) {
    const formData = new FormData();
    formData.append('action', 'upload');
    formData.append('image', file);
    
    const response = await fetch(API_URL, {
        method: 'POST',
        body: formData
    });
    
    return await response.json();
}

/**
 * Compress image
 */
async function compressImage(filename) {
    const quality = document.getElementById('qualitySlider').value;
    const compressionType = document.getElementById('compressionLevel').value;
    const format = document.getElementById('convertFormat').value;
    
    const formData = new FormData();
    formData.append('action', 'compress');
    formData.append('filename', filename);
    formData.append('quality', quality);
    formData.append('compression_type', compressionType);
    if (format) formData.append('format', format);
    
    const response = await fetch(API_URL, {
        method: 'POST',
        body: formData
    });
    
    return await response.json();
}

/**
 * Resize image
 */
async function resizeImage(filename) {
    const width = document.getElementById('resizeWidth').value;
    const height = document.getElementById('resizeHeight').value;
    const maintainRatio = document.getElementById('maintainRatio').checked;
    const quality = document.getElementById('qualitySlider').value;
    
    if (!width || !height) {
        return { success: false, message: 'Please enter width and height' };
    }
    
    const formData = new FormData();
    formData.append('action', 'resize');
    formData.append('filename', filename);
    formData.append('width', width);
    formData.append('height', height);
    formData.append('maintain_ratio', maintainRatio);
    formData.append('quality', quality);
    
    const response = await fetch(API_URL, {
        method: 'POST',
        body: formData
    });
    
    return await response.json();
}

/**
 * Convert image format
 */
async function convertImage(filename) {
    const format = document.getElementById('convertFormat').value;
    const quality = document.getElementById('convertQuality').value;
    
    if (!format) {
        return { success: false, message: 'Please select a format' };
    }
    
    const formData = new FormData();
    formData.append('action', 'convert');
    formData.append('filename', filename);
    formData.append('format', format);
    formData.append('quality', quality);
    
    const response = await fetch(API_URL, {
        method: 'POST',
        body: formData
    });
    
    return await response.json();
}

/**
 * Add watermark to image
 */
async function watermarkImage(filename) {
    const text = document.getElementById('watermarkText').value;
    const position = document.getElementById('watermarkPosition').value;
    const opacity = document.getElementById('watermarkOpacity').value;
    const quality = document.getElementById('qualitySlider').value;
    
    if (!text) {
        return { success: false, message: 'Please enter watermark text' };
    }
    
    const formData = new FormData();
    formData.append('action', 'watermark');
    formData.append('filename', filename);
    formData.append('text', text);
    formData.append('position', position);
    formData.append('opacity', opacity);
    formData.append('quality', quality);
    
    const response = await fetch(API_URL, {
        method: 'POST',
        body: formData
    });
    
    return await response.json();
}

/**
 * Rotate image
 */
async function rotateImage(angle) {
    if (uploadedFiles.length === 0) {
        showNotification('Please upload an image first', 'error');
        return;
    }
    
    showNotification('Rotation feature will be added to the next process', 'info');
}

/**
 * Flip image
 */
async function flipImage(direction) {
    if (uploadedFiles.length === 0) {
        showNotification('Please upload an image first', 'error');
        return;
    }
    
    showNotification('Flip feature will be added to the next process', 'info');
}

/**
 * Display processing results
 */
function displayResults(results) {
    console.log('Displaying results:', results);
    
    const section = document.getElementById('resultsSection');
    const container = document.getElementById('resultsContainer');
    container.innerHTML = '';
    
    const successCount = results.filter(r => r.success).length;
    const failedCount = results.length - successCount;
    
    // Summary
    const summaryHTML = `
        <div class="alert alert-${successCount > 0 ? 'success' : 'danger'} mb-4">
            <h5><i class="bi bi-${successCount > 0 ? 'check-circle' : 'exclamation-circle'} me-2"></i>Processing ${successCount > 0 ? 'Complete' : 'Failed'}!</h5>
            <p class="mb-0">Successfully processed: <strong>${successCount}</strong> | Failed: <strong>${failedCount}</strong></p>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', summaryHTML);
    
    // Individual results
    results.forEach(result => {
        if (result.success && result.data) {
            const resultHTML = `
                <div class="result-card">
                    <h6><i class="bi bi-check-circle text-success me-2"></i>${result.filename}</h6>
                    <div class="result-stats">
                        <div class="result-stat-item">
                            <h5>${formatBytes(result.data.original_size)}</h5>
                            <p>Original Size</p>
                        </div>
                        <div class="result-stat-item">
                            <h5>${formatBytes(result.data.optimized_size)}</h5>
                            <p>Optimized Size</p>
                        </div>
                        <div class="result-stat-item">
                            <h5>${formatBytes(result.data.saved_bytes)}</h5>
                            <p>Saved</p>
                        </div>
                        <div class="result-stat-item">
                            <h5 class="text-success">${result.data.compression_ratio}%</h5>
                            <p>Compression</p>
                        </div>
                    </div>
                    <div class="mt-3">
                        <button class="btn btn-primary btn-sm" onclick="downloadOptimized(${result.data.history_id})">
                            <i class="bi bi-download me-1"></i>Download Optimized
                        </button>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', resultHTML);
        } else {
            const errorMsg = result.error || 'Unknown error occurred';
            const errorHTML = `
                <div class="alert alert-danger d-flex align-items-start">
                    <i class="bi bi-exclamation-triangle me-3 fs-4"></i>
                    <div class="flex-grow-1">
                        <strong>${result.filename}:</strong> ${errorMsg}
                        <br><small class="text-muted">Please check the file and try again</small>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', errorHTML);
        }
    });
    
    // Show section and scroll to it
    section.style.display = 'block';
    section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

/**
 * Load statistics
 */
async function loadStatistics() {
    try {
        const response = await fetch(`${API_URL}?action=stats`);
        const result = await response.json();
        
        if (result.success) {
            const stats = result.data.stats;
            
            // Animate counters
            animateCounter('totalImages', parseInt(stats.total_images) || 0);
            animateCounter('totalDownloads', parseInt(stats.total_downloads) || 0);
            animateCounter('todayOptimizations', parseInt(stats.today_optimizations) || 0);
            
            // Storage saved
            const storageSaved = parseInt(stats.total_storage_saved) || 0;
            document.getElementById('storageSaved').textContent = formatBytes(storageSaved);
            
            // Average compression
            const avgCompression = parseFloat(stats.avg_compression) || 0;
            document.getElementById('avgCompression').textContent = avgCompression.toFixed(1) + '%';
        }
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

/**
 * Load processing history
 */
async function loadHistory() {
    try {
        const response = await fetch(`${API_URL}?action=history&limit=50`);
        const result = await response.json();
        
        if (result.success) {
            displayHistory(result.data);
        }
    } catch (error) {
        console.error('Error loading history:', error);
    }
}

/**
 * Display history in table
 */
function displayHistory(records) {
    const tbody = document.getElementById('historyTableBody');
    tbody.innerHTML = '';
    
    if (records.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-muted">
                    <i class="bi bi-inbox display-1"></i>
                    <p>No history yet. Start optimizing images!</p>
                </td>
            </tr>
        `;
        return;
    }
    
    records.forEach(record => {
        const row = `
            <tr>
                <td><input type="checkbox" class="history-checkbox" value="${record.id}"></td>
                <td>${record.original_name}</td>
                <td>${record.optimized_name}</td>
                <td>${formatBytes(record.original_size)}</td>
                <td>${formatBytes(record.optimized_size)}</td>
                <td><span class="text-success fw-bold">${formatBytes(record.saved_bytes)} (${record.compression_ratio}%)</span></td>
                <td><span class="operation-badge operation-${record.operation_type}">${record.operation_type}</span></td>
                <td>${formatDate(record.created_at)}</td>
                <td>
                    <div class="action-btn-group">
                        <button class="btn btn-sm btn-primary" onclick="downloadOptimized(${record.id})" title="Download">
                            <i class="bi bi-download"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteHistory(${record.id})" title="Delete">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
        tbody.insertAdjacentHTML('beforeend', row);
    });
}

/**
 * Download optimized image
 */
function downloadOptimized(historyId) {
    window.location.href = `${API_URL}?action=download&history_id=${historyId}&type=optimized`;
}

/**
 * Delete history record
 */
async function deleteHistory(id) {
    if (!confirm('Are you sure you want to delete this record?')) return;
    
    const formData = new FormData();
    formData.append('action', 'delete');
    formData.append('id', id);
    
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification('Record deleted successfully', 'success');
            loadHistory();
            loadStatistics();
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        showNotification('Error deleting record', 'error');
    }
}

/**
 * Bulk delete history
 */
async function bulkDeleteHistory() {
    const checkboxes = document.querySelectorAll('.history-checkbox:checked');
    
    if (checkboxes.length === 0) {
        showNotification('Please select records to delete', 'error');
        return;
    }
    
    if (!confirm(`Are you sure you want to delete ${checkboxes.length} record(s)?`)) return;
    
    const ids = Array.from(checkboxes).map(cb => cb.value);
    
    const formData = new FormData();
    formData.append('action', 'bulk_delete');
    formData.append('ids', JSON.stringify(ids));
    
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification(result.message, 'success');
            loadHistory();
            loadStatistics();
        } else {
            showNotification(result.message, 'error');
        }
    } catch (error) {
        showNotification('Error deleting records', 'error');
    }
}

/**
 * Toggle select all checkboxes
 */
function toggleSelectAll(e) {
    const checkboxes = document.querySelectorAll('.history-checkbox');
    checkboxes.forEach(cb => cb.checked = e.target.checked);
}

/**
 * Show processing modal
 */
function showProcessingModal() {
    const modal = new bootstrap.Modal(document.getElementById('processingModal'));
    modal.show();
}

/**
 * Hide processing modal
 */
function hideProcessingModal() {
    const modal = bootstrap.Modal.getInstance(document.getElementById('processingModal'));
    if (modal) modal.hide();
}

/**
 * Update processing progress
 */
function updateProcessingProgress(current, total, filename) {
    const percentage = Math.round((current / total) * 100);
    const progressBar = document.getElementById('processingProgress');
    const status = document.getElementById('processingStatus');
    
    progressBar.style.width = percentage + '%';
    progressBar.textContent = percentage + '%';
    status.textContent = `Processing ${filename} (${current}/${total})`;
}

/**
 * Animate counter
 */
function animateCounter(elementId, target) {
    const element = document.getElementById(elementId);
    const duration = 2000;
    const steps = 60;
    const stepValue = target / steps;
    const stepDuration = duration / steps;
    let current = 0;
    
    const timer = setInterval(() => {
        current += stepValue;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        element.textContent = Math.round(current);
    }, stepDuration);
}

/**
 * Format bytes to human readable
 */
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
}

/**
 * Format date
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

/**
 * Show notification
 */
function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : type === 'success' ? 'alert-success' : 'alert-info';
    const icon = type === 'error' ? 'exclamation-circle' : type === 'success' ? 'check-circle' : 'info-circle';
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alert.style.zIndex = '9999';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}
