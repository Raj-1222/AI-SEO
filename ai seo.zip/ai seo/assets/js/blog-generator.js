// AI Blog Generator

let currentBlogData = null;

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('blogGeneratorForm');
    const clearBtn = document.getElementById('clearBtn');
    const regenerateBtn = document.getElementById('regenerateBtn');
    const wordCountInput = document.getElementById('word_count');
    const wordCountValue = document.getElementById('wordCountValue');
    
    // Update word count display
    wordCountInput.addEventListener('input', function() {
        wordCountValue.textContent = this.value;
    });
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        generateBlogPost();
    });
    
    clearBtn.addEventListener('click', function() {
        form.reset();
        wordCountValue.textContent = '1500';
        document.getElementById('welcomeSection').style.display = 'block';
        document.getElementById('resultsSection').style.display = 'none';
        document.getElementById('regenerateBtn').style.display = 'none';
        currentBlogData = null;
    });
    
    regenerateBtn.addEventListener('click', function() {
        generateBlogPost();
    });
});

function generateBlogPost() {
    const keyword = document.getElementById('keyword').value;
    const wordCount = document.getElementById('word_count').value;
    const language = document.getElementById('language').value;
    const tone = document.getElementById('tone').value;
    
    // Hide sections
    document.getElementById('welcomeSection').style.display = 'none';
    document.getElementById('resultsSection').style.display = 'none';
    document.getElementById('loadingSection').style.display = 'block';
    
    fetch('../../api/blog-generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'generate',
            keyword: keyword,
            word_count: parseInt(wordCount),
            language: language,
            tone: tone
        })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('loadingSection').style.display = 'none';
        
        if (data.success) {
            currentBlogData = {
                keyword: keyword,
                word_count: parseInt(wordCount),
                language: language,
                tone: tone,
                blog_data: data
            };
            
            displayBlogPost(data);
            document.getElementById('resultsSection').style.display = 'block';
            document.getElementById('regenerateBtn').style.display = 'block';
            
            // Scroll to results
            document.getElementById('resultsSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else {
            showNotification(data.message || 'Failed to generate blog post', 'error');
            document.getElementById('welcomeSection').style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('loadingSection').style.display = 'none';
        document.getElementById('welcomeSection').style.display = 'block';
        showNotification('Error generating blog post', 'error');
    });
}

function displayBlogPost(data) {
    // Title
    document.getElementById('blogTitle').textContent = data.title;
    
    // Outline
    displayOutline(data.outline);
    
    // Introduction
    document.getElementById('blogIntroduction').innerHTML = formatContent(data.introduction);
    
    // Main Sections
    displaySections(data.sections);
    
    // FAQ
    displayFAQ(data.faq);
    
    // Conclusion
    document.getElementById('blogConclusion').innerHTML = formatContent(data.conclusion);
    
    // Call to Action
    document.getElementById('blogCta').innerHTML = formatContent(data.call_to_action);
    
    // SEO Score
    animateSEOScore(data.seo_score || 0);
    
    // Setup buttons
    setupCopyButtons();
    setupActionButtons();
    setupToggleOutline();
}

function displayOutline(outline) {
    const container = document.getElementById('blogOutline');
    
    if (!outline || outline.length === 0) {
        container.innerHTML = '<p class="text-muted">No outline available</p>';
        return;
    }
    
    let html = '<ol class="blog-outline">';
    outline.forEach(item => {
        html += `<li>${item}</li>`;
    });
    html += '</ol>';
    
    container.innerHTML = html;
}

function displaySections(sections) {
    const container = document.getElementById('blogSections');
    
    if (!sections || sections.length === 0) {
        container.innerHTML = '';
        return;
    }
    
    let html = '';
    sections.forEach((section, index) => {
        html += `
            <div class="card glass-card mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">
                        <i class="bi bi-file-text text-primary me-2"></i>
                        Section ${index + 1}
                    </h5>
                    <button class="btn btn-sm btn-outline-primary copy-btn" data-target="section_${index}">
                        <i class="bi bi-clipboard"></i> Copy
                    </button>
                </div>
                <h4 class="blog-section-heading">${section.heading}</h4>
                <div class="blog-content" id="section_${index}_content">${formatContent(section.content)}</div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

function displayFAQ(faq) {
    const container = document.getElementById('blogFaq');
    
    if (!faq || faq.length === 0) {
        container.innerHTML = '<p class="text-muted">No FAQ available</p>';
        return;
    }
    
    let html = '<div class="faq-container">';
    faq.forEach((item, index) => {
        html += `
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFAQ(${index})">
                    <strong>Q: ${item.question}</strong>
                    <i class="bi bi-chevron-down"></i>
                </button>
                <div class="faq-answer" id="faq_${index}">
                    <p><strong>A:</strong> ${item.answer}</p>
                </div>
            </div>
        `;
    });
    html += '</div>';
    
    container.innerHTML = html;
}

function toggleFAQ(index) {
    const answer = document.getElementById(`faq_${index}`);
    const isOpen = answer.style.display === 'block';
    
    // Close all FAQs
    document.querySelectorAll('.faq-answer').forEach(el => {
        el.style.display = 'none';
    });
    
    // Open clicked FAQ if it was closed
    if (!isOpen) {
        answer.style.display = 'block';
    }
}

function setupToggleOutline() {
    const toggleBtn = document.getElementById('toggleOutline');
    const outline = document.getElementById('blogOutline');
    
    toggleBtn.addEventListener('click', function() {
        if (outline.style.display === 'none') {
            outline.style.display = 'block';
            this.querySelector('i').className = 'bi bi-chevron-up';
        } else {
            outline.style.display = 'none';
            this.querySelector('i').className = 'bi bi-chevron-down';
        }
    });
}

function formatContent(text) {
    if (!text) return '';
    
    // Convert line breaks to paragraphs
    const paragraphs = text.split('\n\n').filter(p => p.trim());
    
    let html = '';
    paragraphs.forEach(para => {
        // Check if it's a heading (starts with ###)
        if (para.trim().startsWith('###')) {
            const heading = para.replace(/^###\s*/, '').trim();
            html += `<h3 class="blog-subheading">${heading}</h3>`;
        } else if (para.trim().startsWith('##')) {
            const heading = para.replace(/^##\s*/, '').trim();
            html += `<h2 class="blog-section-heading">${heading}</h2>`;
        } else {
            html += `<p>${para.trim()}</p>`;
        }
    });
    
    return html || `<p>${text}</p>`;
}

function animateSEOScore(score) {
    const circle = document.getElementById('scoreCircleBlog');
    const scoreValue = document.getElementById('seoScoreValue');
    
    const circumference = 2 * Math.PI * 45;
    const offset = circumference - (score / 100) * circumference;
    
    let current = 0;
    const duration = 2000;
    const stepTime = 20;
    const steps = duration / stepTime;
    const increment = score / steps;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= score) {
            current = score;
            clearInterval(timer);
        }
        
        scoreValue.textContent = Math.round(current);
        const currentOffset = circumference - (current / 100) * circumference;
        circle.style.strokeDashoffset = currentOffset;
    }, stepTime);
    
    // Color based on score
    if (score >= 80) {
        circle.style.stroke = '#28A745';
    } else if (score >= 60) {
        circle.style.stroke = '#FF6B00';
    } else {
        circle.style.stroke = '#DC3545';
    }
}

function setupCopyButtons() {
    document.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const target = this.dataset.target;
            let textToCopy = '';
            
            if (target === 'title') {
                textToCopy = document.getElementById('blogTitle').textContent;
            } else if (target === 'introduction') {
                textToCopy = document.getElementById('blogIntroduction').innerText;
            } else if (target === 'conclusion') {
                textToCopy = document.getElementById('blogConclusion').innerText;
            } else if (target === 'cta') {
                textToCopy = document.getElementById('blogCta').innerText;
            } else if (target === 'faq') {
                textToCopy = extractFAQText();
            } else if (target.startsWith('section_')) {
                const index = target.split('_')[1];
                const heading = document.querySelectorAll('.blog-section-heading')[index];
                const content = document.getElementById(`section_${index}_content`);
                textToCopy = heading.textContent + '\n\n' + content.innerText;
            }
            
            copyToClipboard(textToCopy, this);
        });
    });
}

function extractFAQText() {
    const faqItems = document.querySelectorAll('.faq-item');
    let text = '';
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question strong').textContent;
        const answer = item.querySelector('.faq-answer p').textContent;
        text += `${question}\n${answer}\n\n`;
    });
    
    return text.trim();
}

function setupActionButtons() {
    // Save button
    document.getElementById('saveBtn').addEventListener('click', function() {
        if (!currentBlogData) return;
        saveBlogPost();
    });
    
    // Copy all button
    document.getElementById('copyAllBtn').addEventListener('click', function() {
        if (!currentBlogData) return;
        copyAllContent();
    });
    
    // Export button
    document.getElementById('exportBtn').addEventListener('click', function() {
        if (!currentBlogData) return;
        exportToHTML();
    });
}

function copyAllContent() {
    const title = document.getElementById('blogTitle').textContent;
    const introduction = document.getElementById('blogIntroduction').innerText;
    const sections = Array.from(document.querySelectorAll('#blogSections .card')).map(card => {
        const heading = card.querySelector('.blog-section-heading').textContent;
        const content = card.querySelector('.blog-content').innerText;
        return `${heading}\n\n${content}`;
    }).join('\n\n');
    const faq = extractFAQText();
    const conclusion = document.getElementById('blogConclusion').innerText;
    const cta = document.getElementById('blogCta').innerText;
    
    const fullContent = `${title}\n\n${introduction}\n\n${sections}\n\nFAQ\n\n${faq}\n\nConclusion\n\n${conclusion}\n\nCall to Action\n\n${cta}`;
    
    copyToClipboard(fullContent, document.getElementById('copyAllBtn'));
}

function exportToHTML() {
    const title = document.getElementById('blogTitle').textContent;
    const introduction = document.getElementById('blogIntroduction').innerHTML;
    const sections = Array.from(document.querySelectorAll('#blogSections .card')).map(card => {
        const heading = card.querySelector('.blog-section-heading').textContent;
        const content = card.querySelector('.blog-content').innerHTML;
        return `<h2>${heading}</h2>\n${content}`;
    }).join('\n\n');
    const faq = document.getElementById('blogFaq').innerHTML;
    const conclusion = document.getElementById('blogConclusion').innerHTML;
    const cta = document.getElementById('blogCta').innerHTML;
    
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; line-height: 1.6; }
        h1 { color: #333; border-bottom: 3px solid #FF6B00; padding-bottom: 10px; }
        h2 { color: #0B1F4D; margin-top: 30px; }
        h3 { color: #555; }
        p { margin: 15px 0; color: #444; }
        .faq-item { margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 4px solid #FF6B00; }
        .cta { background: #FF6B00; color: white; padding: 20px; border-radius: 8px; text-align: center; margin-top: 40px; }
    </style>
</head>
<body>
    <h1>${title}</h1>
    
    <div class="introduction">
        ${introduction}
    </div>
    
    <div class="main-content">
        ${sections}
    </div>
    
    <div class="faq">
        <h2>Frequently Asked Questions</h2>
        ${faq}
    </div>
    
    <div class="conclusion">
        <h2>Conclusion</h2>
        ${conclusion}
    </div>
    
    <div class="cta">
        ${cta}
    </div>
</body>
</html>`;
    
    // Download HTML file
    const blob = new Blob([html], { type: 'text/html' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `blog-post-${Date.now()}.html`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    showNotification('Blog post exported successfully!', 'success');
}

function saveBlogPost() {
    fetch('../../api/blog-generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'save',
            ...currentBlogData
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Blog post saved successfully!', 'success');
        } else {
            showNotification(data.message || 'Failed to save blog post', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error saving blog post', 'error');
    });
}

function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        const originalHTML = button.innerHTML;
        button.innerHTML = '<i class="bi bi-check"></i> Copied!';
        button.classList.add('btn-success');
        
        setTimeout(() => {
            button.innerHTML = originalHTML;
            button.classList.remove('btn-success');
        }, 2000);
        
        showNotification('Copied to clipboard!', 'success');
    });
}

function showNotification(message, type = 'info') {
    const alertClass = type === 'error' ? 'alert-danger' : (type === 'success' ? 'alert-success' : 'alert-info');
    const icon = type === 'error' ? 'exclamation-circle' : (type === 'success' ? 'check-circle' : 'info-circle');
    
    const alert = document.createElement('div');
    alert.className = `alert ${alertClass} alert-dismissible fade show position-fixed`;
    alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alert.innerHTML = `
        <i class="bi bi-${icon} me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}
