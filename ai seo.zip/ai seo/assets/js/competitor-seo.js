// Competitor SEO Analysis Module

let currentAnalysisData = null;
let trafficChart = null;

document.addEventListener('DOMContentLoaded', function() {
    initializeForms();
});

function initializeForms() {
    // 1. Competitor Discovery Form
    const discoveryForm = document.getElementById('discoveryForm');
    if (discoveryForm) {
        discoveryForm.addEventListener('submit', handleDiscoverySubmit);
    }
    
    // 2. Keyword Analysis Form
    const keywordAnalysisForm = document.getElementById('keywordAnalysisForm');
    if (keywordAnalysisForm) {
        keywordAnalysisForm.addEventListener('submit', handleKeywordAnalysisSubmit);
    }
    
    // 3. Content Analysis Form
    const contentAnalysisForm = document.getElementById('contentAnalysisForm');
    if (contentAnalysisForm) {
        contentAnalysisForm.addEventListener('submit', handleContentAnalysisSubmit);
    }
    
    // 4. Backlink Analysis Form
    const backlinkAnalysisForm = document.getElementById('backlinkAnalysisForm');
    if (backlinkAnalysisForm) {
        backlinkAnalysisForm.addEventListener('submit', handleBacklinkAnalysisSubmit);
    }
    
    // 5. Traffic Analysis Form
    const trafficAnalysisForm = document.getElementById('trafficAnalysisForm');
    if (trafficAnalysisForm) {
        trafficAnalysisForm.addEventListener('submit', handleTrafficAnalysisSubmit);
    }
    
    // 6. SERP Comparison Form
    const serpComparisonForm = document.getElementById('serpComparisonForm');
    if (serpComparisonForm) {
        serpComparisonForm.addEventListener('submit', handleSerpComparisonSubmit);
    }
    
    // 7. Monitoring Form
    const monitoringForm = document.getElementById('monitoringForm');
    if (monitoringForm) {
        monitoringForm.addEventListener('submit', handleMonitoringSubmit);
    }
}

// ==================== 1. COMPETITOR DISCOVERY ====================

function handleDiscoverySubmit(e) {
    e.preventDefault();
    
    const primaryDomain = document.getElementById('primary_domain').value;
    const industry = document.getElementById('industry').value;
    const keywordsText = document.getElementById('keywords').value;
    const keywords = keywordsText ? keywordsText.split('\n').filter(k => k.trim()) : [];
    
    showLoading('discovery');
    
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'discover_competitors',
            primary_domain: primaryDomain,
            keywords: keywords,
            industry: industry
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('discovery');
        
        if (data.success) {
            displayCompetitors(data.competitors);
            showResults('discovery');
        } else {
            showNotification(data.message || 'Failed to discover competitors', 'error');
            showWelcome('discovery');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('discovery');
        showNotification('Error discovering competitors', 'error');
        showWelcome('discovery');
    });
}

function displayCompetitors(competitors) {
    const container = document.getElementById('competitorsTable');
    
    let html = '<div class="alert alert-info mb-3"><i class="bi bi-robot me-2"></i><strong>Powered by ChatGPT AI</strong> - Intelligent competitor discovery</div>';
    html += '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Rank</th><th>Domain</th><th>Similarity Score</th><th>Common Keywords</th><th>Actions</th>';
    html += '</tr></thead><tbody>';
    
    competitors.forEach((competitor, index) => {
        html += '<tr>';
        html += `<td><span class="badge bg-primary">#${index + 1}</span></td>`;
        html += `<td><strong>${competitor.domain}</strong></td>`;
        html += `<td><div class="progress" style="width: 100px;"><div class="progress-bar bg-success" style="width: ${competitor.similarity_score}%">${competitor.similarity_score}%</div></div></td>`;
        html += `<td><span class="badge bg-info">${competitor.common_keywords} keywords</span></td>`;
        html += `<td>
            <button class="btn btn-sm btn-outline-primary" onclick="analyzeCompetitor('${competitor.domain}')">
                <i class="bi bi-search"></i> Analyze
            </button>
        </td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
}

function analyzeCompetitor(domain) {
    // Switch to keyword analysis tab and pre-fill the domain
    const keywordTab = document.getElementById('keywords-tab');
    keywordTab.click();
    
    setTimeout(() => {
        const competitorDomainsField = document.getElementById('competitor_domains');
        if (competitorDomainsField) {
            competitorDomainsField.value = domain;
        }
    }, 100);
}

// ==================== 2. KEYWORD ANALYSIS ====================

function handleKeywordAnalysisSubmit(e) {
    e.preventDefault();
    
    const analysisType = document.getElementById('keyword_analysis_type').value;
    const primaryDomain = document.getElementById('kw_primary_domain').value;
    const competitorDomainsText = document.getElementById('competitor_domains').value;
    const competitorDomains = competitorDomainsText.split('\n').filter(d => d.trim());
    
    showLoading('keyword');
    
    if (analysisType === 'keyword_gap') {
        performKeywordGapAnalysis(primaryDomain, competitorDomains);
    } else if (analysisType === 'competitor_keywords') {
        performCompetitorKeywordAnalysis(competitorDomains[0]);
    }
}

function performKeywordGapAnalysis(primaryDomain, competitorDomains) {
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'keyword_gap',
            primary_domain: primaryDomain,
            competitor_domains: competitorDomains
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('keyword');
        
        if (data.success) {
            displayKeywordGapResults(data);
            showResults('keyword');
        } else {
            showNotification(data.message || 'Failed to analyze keyword gap', 'error');
            showWelcome('keyword');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('keyword');
        showNotification('Error analyzing keywords', 'error');
        showWelcome('keyword');
    });
}

function performCompetitorKeywordAnalysis(competitorDomain) {
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'analyze_keywords',
            competitor_domain: competitorDomain,
            limit: 100
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('keyword');
        
        if (data.success) {
            displayCompetitorKeywords(data);
            showResults('keyword');
        } else {
            showNotification(data.message || 'Failed to analyze keywords', 'error');
            showWelcome('keyword');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('keyword');
        showNotification('Error analyzing keywords', 'error');
        showWelcome('keyword');
    });
}

function displayKeywordGapResults(data) {
    // Display stats
    const statsContainer = document.getElementById('keywordStats');
    let statsHtml = '';
    
    statsHtml += `<div class="col-md-12 mb-3">
        <div class="alert alert-success">
            <i class="bi bi-robot me-2"></i><strong>Powered by ChatGPT AI</strong> - Smart keyword gap analysis with actionable insights
        </div>
    </div>`;
    
    statsHtml += `<div class="col-md-3">
        <div class="stat-card bg-primary bg-opacity-10 p-3 rounded">
            <div class="stat-value text-primary">${data.total_opportunities}</div>
            <div class="stat-label">Total Opportunities</div>
        </div>
    </div>`;
    
    statsHtml += `<div class="col-md-3">
        <div class="stat-card bg-danger bg-opacity-10 p-3 rounded">
            <div class="stat-value text-danger">${data.high_priority}</div>
            <div class="stat-label">High Priority</div>
        </div>
    </div>`;
    
    statsContainer.innerHTML = statsHtml;
    
    // Display keyword table
    const tableContainer = document.getElementById('keywordTable');
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Keyword</th><th>Gap Type</th><th>Search Volume</th><th>Positions</th><th>Opportunity</th>';
    html += '</tr></thead><tbody>';
    
    data.gaps.slice(0, 50).forEach(gap => {
        const gapTypeBadge = gap.gap_type === 'competitor_only' ? 'bg-danger' : 'bg-warning';
        html += '<tr>';
        html += `<td><strong>${gap.keyword}</strong><br><small class="text-muted">${gap.competitor_domain}</small></td>`;
        html += `<td><span class="badge ${gapTypeBadge}">${gap.gap_type.replace('_', ' ')}</span></td>`;
        html += `<td>${gap.search_volume.toLocaleString()}</td>`;
        html += `<td>Them: <span class="badge bg-success">#${gap.competitor_position}</span> Us: <span class="badge bg-secondary">${gap.our_position || 'N/A'}</span></td>`;
        html += `<td><strong>${gap.opportunity_score.toLocaleString()}</strong></td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    tableContainer.innerHTML = html;
}

function displayCompetitorKeywords(data) {
    const statsContainer = document.getElementById('keywordStats');
    let statsHtml = `<div class="col-md-3">
        <div class="stat-card bg-primary bg-opacity-10 p-3 rounded">
            <div class="stat-value text-primary">${data.total}</div>
            <div class="stat-label">Total Keywords</div>
        </div>
    </div>`;
    
    statsContainer.innerHTML = statsHtml;
    
    const tableContainer = document.getElementById('keywordTable');
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Keyword</th><th>Position</th><th>Search Volume</th><th>Difficulty</th><th>Traffic</th>';
    html += '</tr></thead><tbody>';
    
    data.keywords.forEach(keyword => {
        html += '<tr>';
        html += `<td><strong>${keyword.keyword}</strong></td>`;
        html += `<td><span class="badge bg-success">#${keyword.position}</span></td>`;
        html += `<td>${keyword.search_volume.toLocaleString()}</td>`;
        html += `<td><span class="badge bg-${getDifficultyColor(keyword.keyword_difficulty)}">${keyword.keyword_difficulty}/100</span></td>`;
        html += `<td>${keyword.traffic_estimate.toLocaleString()}</td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    tableContainer.innerHTML = html;
}

// ==================== 3. CONTENT ANALYSIS ====================

function handleContentAnalysisSubmit(e) {
    e.preventDefault();
    
    const analysisType = document.getElementById('content_analysis_type').value;
    const primaryDomain = document.getElementById('content_primary_domain').value;
    const competitorDomainsText = document.getElementById('content_competitor_domains').value;
    const competitorDomains = competitorDomainsText.split('\n').filter(d => d.trim());
    
    showLoading('content');
    
    if (analysisType === 'content_gap') {
        performContentGapAnalysis(primaryDomain, competitorDomains);
    } else if (analysisType === 'content_quality') {
        performContentQualityAnalysis(competitorDomains[0]);
    } else if (analysisType === 'top_pages') {
        performTopPagesAnalysis(competitorDomains[0]);
    }
}

function performContentGapAnalysis(primaryDomain, competitorDomains) {
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'content_gap',
            primary_domain: primaryDomain,
            competitor_domains: competitorDomains
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('content');
        
        if (data.success) {
            displayContentGapResults(data);
            showResults('content');
        } else {
            showNotification(data.message || 'Failed to analyze content gap', 'error');
            showWelcome('content');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('content');
        showNotification('Error analyzing content', 'error');
        showWelcome('content');
    });
}

function performContentQualityAnalysis(competitorDomain) {
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'content_analysis',
            competitor_domain: competitorDomain,
            limit: 20
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('content');
        
        if (data.success) {
            displayContentQualityResults(data);
            showResults('content');
        } else {
            showNotification(data.message || 'Failed to analyze content', 'error');
            showWelcome('content');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('content');
        showNotification('Error analyzing content', 'error');
        showWelcome('content');
    });
}

function performTopPagesAnalysis(competitorDomain) {
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'top_pages',
            competitor_domain: competitorDomain,
            limit: 20
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('content');
        
        if (data.success) {
            displayTopPagesResults(data);
            showResults('content');
        } else {
            showNotification(data.message || 'Failed to get top pages', 'error');
            showWelcome('content');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('content');
        showNotification('Error getting top pages', 'error');
        showWelcome('content');
    });
}

function displayContentGapResults(data) {
    const metricsContainer = document.getElementById('contentMetrics');
    let metricsHtml = `<div class="col-md-4">
        <div class="stat-card bg-info bg-opacity-10 p-3 rounded">
            <div class="stat-value text-info">${data.total}</div>
            <div class="stat-label">Content Gaps Found</div>
        </div>
    </div>`;
    
    metricsContainer.innerHTML = metricsHtml;
    
    const tableContainer = document.getElementById('contentTable');
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Topic</th><th>Competitor</th><th>Priority</th><th>Est. Traffic</th>';
    html += '</tr></thead><tbody>';
    
    data.content_gaps.forEach(gap => {
        html += '<tr>';
        html += `<td><strong>${gap.topic}</strong></td>`;
        html += `<td>${gap.competitor_domain}</td>`;
        html += `<td><span class="badge bg-${getPriorityColor(gap.priority)}">${gap.priority}</span></td>`;
        html += `<td>${gap.estimated_traffic.toLocaleString()}</td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    tableContainer.innerHTML = html;
}

function displayContentQualityResults(data) {
    const metricsContainer = document.getElementById('contentMetrics');
    let metricsHtml = '';
    
    metricsHtml += `<div class="col-md-3">
        <div class="stat-card bg-primary bg-opacity-10 p-3 rounded">
            <div class="stat-value text-primary">${data.metrics.avg_word_count}</div>
            <div class="stat-label">Avg Word Count</div>
        </div>
    </div>`;
    
    metricsHtml += `<div class="col-md-3">
        <div class="stat-card bg-success bg-opacity-10 p-3 rounded">
            <div class="stat-value text-success">${data.metrics.avg_seo_score}</div>
            <div class="stat-label">Avg SEO Score</div>
        </div>
    </div>`;
    
    metricsContainer.innerHTML = metricsHtml;
    
    const tableContainer = document.getElementById('contentTable');
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Title</th><th>Type</th><th>Word Count</th><th>SEO Score</th><th>Traffic</th>';
    html += '</tr></thead><tbody>';
    
    data.content_analysis.forEach(content => {
        html += '<tr>';
        html += `<td><strong>${content.title}</strong><br><small class="text-muted">${content.url.substring(0, 50)}...</small></td>`;
        html += `<td><span class="badge bg-secondary">${content.content_type}</span></td>`;
        html += `<td>${content.word_count.toLocaleString()}</td>`;
        html += `<td><span class="badge bg-${getScoreColor(content.seo_score)}">${content.seo_score}/100</span></td>`;
        html += `<td>${content.estimated_traffic.toLocaleString()}</td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    tableContainer.innerHTML = html;
}

function displayTopPagesResults(data) {
    const tableContainer = document.getElementById('contentTable');
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Page</th><th>Traffic</th><th>Keywords</th><th>Backlinks</th><th>Social</th>';
    html += '</tr></thead><tbody>';
    
    data.top_pages.forEach(page => {
        html += '<tr>';
        html += `<td><strong>${page.title}</strong><br><small class="text-muted">${page.url.substring(0, 60)}...</small></td>`;
        html += `<td><strong class="text-primary">${page.estimated_traffic.toLocaleString()}</strong></td>`;
        html += `<td>${page.ranking_keywords}</td>`;
        html += `<td>${page.backlinks_count}</td>`;
        html += `<td>${page.social_shares.toLocaleString()}</td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    tableContainer.innerHTML = html;
}

// ==================== 4. BACKLINK ANALYSIS ====================

function handleBacklinkAnalysisSubmit(e) {
    e.preventDefault();
    
    const competitorDomain = document.getElementById('backlink_competitor_domain').value;
    const limit = document.getElementById('backlink_limit').value;
    
    showLoading('backlink');
    
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'analyze_backlinks',
            competitor_domain: competitorDomain,
            limit: parseInt(limit)
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('backlink');
        
        if (data.success) {
            displayBacklinkResults(data);
            showResults('backlink');
        } else {
            showNotification(data.message || 'Failed to analyze backlinks', 'error');
            showWelcome('backlink');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('backlink');
        showNotification('Error analyzing backlinks', 'error');
        showWelcome('backlink');
    });
}

function displayBacklinkResults(data) {
    const metricsContainer = document.getElementById('backlinkMetrics');
    let metricsHtml = '';
    
    metricsHtml += `<div class="col-md-3">
        <div class="stat-card bg-primary bg-opacity-10 p-3 rounded">
            <div class="stat-value text-primary">${data.metrics.total_backlinks}</div>
            <div class="stat-label">Total Backlinks</div>
        </div>
    </div>`;
    
    metricsHtml += `<div class="col-md-3">
        <div class="stat-card bg-success bg-opacity-10 p-3 rounded">
            <div class="stat-value text-success">${data.metrics.dofollow}</div>
            <div class="stat-label">Dofollow Links</div>
        </div>
    </div>`;
    
    metricsHtml += `<div class="col-md-3">
        <div class="stat-card bg-info bg-opacity-10 p-3 rounded">
            <div class="stat-value text-info">${data.metrics.unique_domains}</div>
            <div class="stat-label">Unique Domains</div>
        </div>
    </div>`;
    
    metricsHtml += `<div class="col-md-3">
        <div class="stat-card bg-warning bg-opacity-10 p-3 rounded">
            <div class="stat-value text-warning">${data.metrics.avg_domain_authority}</div>
            <div class="stat-label">Avg Domain Authority</div>
        </div>
    </div>`;
    
    metricsContainer.innerHTML = metricsHtml;
    
    const tableContainer = document.getElementById('backlinkTable');
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Source</th><th>Anchor Text</th><th>DA</th><th>Type</th><th>Status</th>';
    html += '</tr></thead><tbody>';
    
    data.backlinks.slice(0, 50).forEach(backlink => {
        html += '<tr>';
        html += `<td><small>${backlink.source_url.substring(0, 50)}...</small></td>`;
        html += `<td>${backlink.anchor_text.substring(0, 30)}</td>`;
        html += `<td><span class="badge bg-${getDAColor(backlink.domain_authority)}">${backlink.domain_authority}</span></td>`;
        html += `<td><span class="badge ${backlink.link_type === 'dofollow' ? 'bg-success' : 'bg-secondary'}">${backlink.link_type}</span></td>`;
        html += `<td><span class="badge bg-${backlink.status === 'active' ? 'success' : 'danger'}">${backlink.status}</span></td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    tableContainer.innerHTML = html;
}

// ==================== 5. TRAFFIC ANALYSIS ====================

function handleTrafficAnalysisSubmit(e) {
    e.preventDefault();
    
    const competitorDomain = document.getElementById('traffic_competitor_domain').value;
    const months = document.getElementById('traffic_months').value;
    
    showLoading('traffic');
    
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'traffic_estimate',
            competitor_domain: competitorDomain,
            months: parseInt(months)
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('traffic');
        
        if (data.success) {
            displayTrafficResults(data);
            showResults('traffic');
        } else {
            showNotification(data.message || 'Failed to estimate traffic', 'error');
            showWelcome('traffic');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('traffic');
        showNotification('Error estimating traffic', 'error');
        showWelcome('traffic');
    });
}

function displayTrafficResults(data) {
    // Add AI badge
    const tableContainer = document.getElementById('trafficTable');
    let html = '<div class="alert alert-info mb-3"><i class="bi bi-robot me-2"></i><strong>Powered by ChatGPT AI</strong> - Intelligent traffic estimation and trend analysis</div>';
    
    // Add trend indicator
    html += `<div class="alert alert-${data.trend === 'growing' ? 'success' : data.trend === 'declining' ? 'danger' : 'info'} mb-3">
        <i class="bi bi-graph-${data.trend === 'growing' ? 'up' : data.trend === 'declining' ? 'down' : 'up'}-arrow me-2"></i>
        Traffic Trend: <strong>${data.trend.toUpperCase()}</strong>
        ${data.insights ? '<br><small>' + data.insights + '</small>' : ''}
    </div>`;
    
    // Create chart
    const ctx = document.getElementById('trafficChart');
    
    if (trafficChart) {
        trafficChart.destroy();
    }
    
    const labels = data.traffic_data.map(d => new Date(d.month_year).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }));
    const organicData = data.traffic_data.map(d => d.organic_traffic);
    const paidData = data.traffic_data.map(d => d.paid_traffic);
    const totalData = data.traffic_data.map(d => d.total_traffic);
    
    trafficChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Total Traffic',
                    data: totalData,
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Organic Traffic',
                    data: organicData,
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Paid Traffic',
                    data: paidData,
                    borderColor: 'rgb(255, 99, 132)',
                    backgroundColor: 'rgba(255, 99, 132, 0.1)',
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Traffic Trend - ' + data.competitor_domain
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
    
    // Display table
    html += '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Month</th><th>Total</th><th>Organic</th><th>Paid</th><th>Direct</th><th>Referral</th><th>Social</th>';
    html += '</tr></thead><tbody>';
    
    data.traffic_data.forEach(traffic => {
        html += '<tr>';
        html += `<td>${new Date(traffic.month_year).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</td>`;
        html += `<td><strong>${traffic.total_traffic.toLocaleString()}</strong></td>`;
        html += `<td>${traffic.organic_traffic.toLocaleString()}</td>`;
        html += `<td>${traffic.paid_traffic.toLocaleString()}</td>`;
        html += `<td>${traffic.direct_traffic.toLocaleString()}</td>`;
        html += `<td>${traffic.referral_traffic.toLocaleString()}</td>`;
        html += `<td>${traffic.social_traffic.toLocaleString()}</td>`;
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    
    tableContainer.innerHTML = html;
}

// ==================== 6. SERP COMPARISON ====================

function handleSerpComparisonSubmit(e) {
    e.preventDefault();
    
    const primaryDomain = document.getElementById('serp_primary_domain').value;
    const competitorsText = document.getElementById('serp_competitors').value;
    const keywordsText = document.getElementById('serp_keywords').value;
    
    const competitorDomains = competitorsText.split('\n').filter(d => d.trim());
    const keywords = keywordsText.split('\n').filter(k => k.trim());
    
    showLoading('serp');
    
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'serp_comparison',
            keywords: keywords,
            primary_domain: primaryDomain,
            competitor_domains: competitorDomains
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('serp');
        
        if (data.success) {
            displaySerpResults(data);
            showResults('serp');
        } else {
            showNotification(data.message || 'Failed to compare SERP', 'error');
            showWelcome('serp');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('serp');
        showNotification('Error comparing SERP', 'error');
        showWelcome('serp');
    });
}

function displaySerpResults(data) {
    const tableContainer = document.getElementById('serpTable');
    let html = '<div class="table-responsive"><table class="table table-hover">';
    html += '<thead><tr>';
    html += '<th>Keyword</th><th>Search Volume</th><th>Your Position</th><th>Competitor Positions</th>';
    html += '</tr></thead><tbody>';
    
    data.serp_comparison.forEach(serp => {
        html += '<tr>';
        html += `<td><strong>${serp.keyword}</strong></td>`;
        html += `<td>${serp.search_volume.toLocaleString()}</td>`;
        
        // Find our position
        let ourPosition = 'Not ranking';
        for (const [domain, position] of Object.entries(serp.positions)) {
            if (domain === document.getElementById('serp_primary_domain').value) {
                ourPosition = `<span class="badge bg-primary">#${position.position}</span>`;
                break;
            }
        }
        html += `<td>${ourPosition}</td>`;
        
        // Show competitor positions
        let competitorPositions = '';
        for (const [domain, position] of Object.entries(serp.positions)) {
            if (domain !== document.getElementById('serp_primary_domain').value) {
                competitorPositions += `<span class="badge bg-secondary me-1">${domain}: #${position.position}</span>`;
            }
        }
        html += `<td>${competitorPositions}</td>`;
        
        html += '</tr>';
    });
    
    html += '</tbody></table></div>';
    tableContainer.innerHTML = html;
}

// ==================== 7. CHANGE MONITORING ====================

function handleMonitoringSubmit(e) {
    e.preventDefault();
    
    const competitorDomain = document.getElementById('monitor_competitor_domain').value;
    
    showLoading('monitoring');
    
    fetch('../../api/competitor-seo.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'monitor_changes',
            competitor_domain: competitorDomain
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('monitoring');
        
        if (data.success) {
            displayMonitoringResults(data);
            showResults('monitoring');
        } else {
            showNotification(data.message || 'Failed to monitor changes', 'error');
            showWelcome('monitoring');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        hideLoading('monitoring');
        showNotification('Error monitoring changes', 'error');
        showWelcome('monitoring');
    });
}

function displayMonitoringResults(data) {
    const container = document.getElementById('changesTimeline');
    
    if (data.changes.length === 0) {
        container.innerHTML = '<div class="alert alert-info">No significant changes detected in the selected time period.</div>';
        return;
    }
    
    let html = '<div class="timeline">';
    
    data.changes.forEach(change => {
        const impactColor = getImpactLevelColor(change.impact_level);
        const changeIcon = getChangeTypeIcon(change.change_type);
        
        html += `<div class="timeline-item mb-4 p-3 border-start border-3 border-${impactColor}">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <h6 class="mb-0">
                    <i class="bi bi-${changeIcon} text-${impactColor} me-2"></i>
                    ${change.change_type.toUpperCase().replace('_', ' ')}
                </h6>
                <span class="badge bg-${impactColor}">${change.impact_level}</span>
            </div>
            <p class="mb-2">${change.change_description}</p>
            ${change.old_value ? `<small class="text-muted">Old: ${change.old_value} → New: ${change.new_value}</small>` : ''}
        </div>`;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

// ==================== HELPER FUNCTIONS ====================

function showLoading(section) {
    document.getElementById(`${section}Welcome`).style.display = 'none';
    document.getElementById(`${section}Results`).style.display = 'none';
    document.getElementById(`${section}Loading`).style.display = 'block';
}

function hideLoading(section) {
    document.getElementById(`${section}Loading`).style.display = 'none';
}

function showWelcome(section) {
    document.getElementById(`${section}Welcome`).style.display = 'block';
    document.getElementById(`${section}Results`).style.display = 'none';
}

function showResults(section) {
    document.getElementById(`${section}Welcome`).style.display = 'none';
    document.getElementById(`${section}Results`).style.display = 'block';
}

function getDifficultyColor(difficulty) {
    if (difficulty >= 70) return 'danger';
    if (difficulty >= 40) return 'warning';
    return 'success';
}

function getPriorityColor(priority) {
    const colors = {
        'critical': 'danger',
        'high': 'warning',
        'medium': 'info',
        'low': 'secondary'
    };
    return colors[priority] || 'secondary';
}

function getScoreColor(score) {
    if (score >= 80) return 'success';
    if (score >= 60) return 'info';
    if (score >= 40) return 'warning';
    return 'danger';
}

function getDAColor(da) {
    if (da >= 70) return 'success';
    if (da >= 40) return 'info';
    if (da >= 20) return 'warning';
    return 'secondary';
}

function getImpactLevelColor(level) {
    const colors = {
        'critical': 'danger',
        'high': 'warning',
        'medium': 'info',
        'low': 'secondary'
    };
    return colors[level] || 'secondary';
}

function getChangeTypeIcon(type) {
    const icons = {
        'ranking': 'graph-up',
        'backlink': 'link-45deg',
        'traffic': 'graph-up-arrow',
        'content': 'file-text',
        'technical': 'gear',
        'meta': 'code-square'
    };
    return icons[type] || 'circle';
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}
