// SIMPLE AUDIT MODULE - For Testing Only
// This uses a simplified API to test if the basic flow works

document.addEventListener('DOMContentLoaded', function() {
    const auditForm = document.getElementById('auditForm');
    
    if (auditForm) {
        auditForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const url = document.getElementById('website_url').value.trim();
            
            if (!url) {
                alert('Please enter a website URL');
                return;
            }
            
            console.log('=== SIMPLE AUDIT TEST ===');
            console.log('Starting simple audit for:', url);
            
            // Hide form, show loading
            document.getElementById('auditFormSection').style.display = 'none';
            document.getElementById('loadingSection').style.display = 'block';
            
            // Call simple API
            fetch('../../api/audit-simple.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ url: url })
            })
            .then(response => {
                console.log('Response status:', response.status);
                console.log('Response headers:', response.headers);
                return response.text();
            })
            .then(text => {
                console.log('Raw response:', text);
                
                try {
                    const data = JSON.parse(text);
                    console.log('Parsed data:', data);
                    
                    if (data.success) {
                        console.log('✅ SUCCESS! API returned valid JSON');
                        console.log('Website ID:', data.website_id);
                        
                        // Show success message
                        setTimeout(() => {
                            document.getElementById('loadingSection').style.display = 'none';
                            document.getElementById('resultsSection').style.display = 'block';
                            
                            // Populate with test data
                            document.getElementById('websiteTitle').textContent = data.data.title;
                            document.getElementById('metaDescription').textContent = data.data.description;
                            document.getElementById('websiteLanguage').textContent = data.data.language.toUpperCase();
                            document.getElementById('responseTime').textContent = data.data.response_time + ' ms';
                            document.getElementById('cmsDetected').textContent = data.data.cms_detected;
                            document.getElementById('serverInfo').textContent = data.data.server_info;
                            document.getElementById('ipAddress').textContent = data.data.ip_address;
                            document.getElementById('country').textContent = data.data.country;
                            
                            // SSL Status
                            const sslStatus = document.getElementById('sslStatus');
                            if (data.data.ssl_enabled) {
                                sslStatus.innerHTML = '<span class="badge bg-success"><i class="bi bi-shield-check"></i> Enabled</span>';
                            }
                            
                            // Animate SEO Score
                            const scoreValue = document.getElementById('seoScoreValue');
                            const scoreCircle = document.getElementById('scoreCircle');
                            const scoreLabel = document.getElementById('scoreLabel');
                            
                            let current = 0;
                            const target = data.data.seo_score;
                            const duration = 2000;
                            const stepTime = 20;
                            const steps = duration / stepTime;
                            const increment = target / steps;
                            
                            const timer = setInterval(() => {
                                current += increment;
                                if (current >= target) {
                                    current = target;
                                    clearInterval(timer);
                                }
                                scoreValue.textContent = Math.round(current);
                            }, stepTime);
                            
                            scoreLabel.textContent = 'Test Mode';
                            scoreLabel.className = 'text-success mb-0';
                            
                            alert('✅ SUCCESS! The simple API works!\n\nThis proves the server can return JSON.\nThe issue is with the complex audit logic or database.\n\nNext: Upload the fixed files to use full features.');
                            
                        }, 1500);
                    } else {
                        throw new Error(data.message || 'API returned success=false');
                    }
                    
                } catch (e) {
                    console.error('❌ JSON Parse Error:', e);
                    console.error('Response was:', text.substring(0, 500));
                    
                    document.getElementById('loadingSection').style.display = 'none';
                    document.getElementById('auditFormSection').style.display = 'block';
                    
                    alert('❌ ERROR: API did not return valid JSON\n\n' +
                          'This means there is a server configuration issue.\n\n' +
                          'Error: ' + e.message + '\n\n' +
                          'Check browser console (F12) for details.');
                }
            })
            .catch(error => {
                console.error('❌ Network Error:', error);
                
                document.getElementById('loadingSection').style.display = 'none';
                document.getElementById('auditFormSection').style.display = 'block';
                
                alert('❌ NETWORK ERROR\n\n' +
                      'Could not reach the API.\n\n' +
                      'Error: ' + error.message);
            });
        });
    }
});
