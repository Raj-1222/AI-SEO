<?php
/**
 * Competitor AI Service
 * Uses ChatGPT API to provide intelligent competitor analysis
 */

class CompetitorAIService {
    private $apiKey;
    private $apiUrl;
    private $model;
    
    public function __construct() {
        $this->apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';
        $this->apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : 'https://api.openai.com/v1/chat/completions';
        $this->model = defined('OPENAI_MODEL') ? OPENAI_MODEL : 'gpt-4o-mini';
    }
    
    /**
     * Discover competitors using AI
     */
    public function discoverCompetitors($domain, $industry, $keywords = []) {
        $prompt = $this->buildCompetitorDiscoveryPrompt($domain, $industry, $keywords);
        $response = $this->callChatGPT($prompt);
        
        if ($response['success']) {
            return $this->parseCompetitorList($response['content']);
        }
        
        return $this->getFallbackCompetitors($domain);
    }
    
    /**
     * Analyze competitor keywords
     */
    public function analyzeCompetitorKeywords($competitorDomain, $limit = 100) {
        $prompt = $this->buildKeywordAnalysisPrompt($competitorDomain, $limit);
        $response = $this->callChatGPT($prompt);
        
        if ($response['success']) {
            return $this->parseKeywordData($response['content']);
        }
        
        return $this->getFallbackKeywords($competitorDomain, $limit);
    }
    
    /**
     * Identify keyword gaps
     */
    public function identifyKeywordGaps($primaryDomain, $competitorDomains, $industry) {
        $prompt = $this->buildKeywordGapPrompt($primaryDomain, $competitorDomains, $industry);
        $response = $this->callChatGPT($prompt);
        
        if ($response['success']) {
            return $this->parseKeywordGaps($response['content']);
        }
        
        return [];
    }
    
    /**
     * Analyze content gaps
     */
    public function analyzeContentGaps($primaryDomain, $competitorDomains, $industry) {
        $prompt = $this->buildContentGapPrompt($primaryDomain, $competitorDomains, $industry);
        $response = $this->callChatGPT($prompt);
        
        if ($response['success']) {
            return $this->parseContentGaps($response['content']);
        }
        
        return [];
    }
    
    /**
     * Generate backlink opportunities
     */
    public function generateBacklinkOpportunities($domain, $industry) {
        $prompt = $this->buildBacklinkOpportunitiesPrompt($domain, $industry);
        $response = $this->callChatGPT($prompt);
        
        if ($response['success']) {
            return $this->parseBacklinkOpportunities($response['content']);
        }
        
        return [];
    }
    
    /**
     * Estimate traffic and trends
     */
    public function estimateTrafficTrends($competitorDomain, $industry) {
        $prompt = $this->buildTrafficEstimationPrompt($competitorDomain, $industry);
        $response = $this->callChatGPT($prompt);
        
        if ($response['success']) {
            return $this->parseTrafficData($response['content']);
        }
        
        return $this->getFallbackTrafficData();
    }
    
    /**
     * Generate comprehensive competitor report
     */
    public function generateCompetitorReport($primaryDomain, $competitorDomains, $industry) {
        $prompt = $this->buildComprehensiveReportPrompt($primaryDomain, $competitorDomains, $industry);
        $response = $this->callChatGPT($prompt, 4096); // Longer response for comprehensive report
        
        if ($response['success']) {
            return [
                'success' => true,
                'report' => $this->parseComprehensiveReport($response['content']),
                'raw_analysis' => $response['content']
            ];
        }
        
        return ['success' => false, 'message' => 'Failed to generate report'];
    }
    
    // ==================== PROMPT BUILDERS ====================
    
    private function buildCompetitorDiscoveryPrompt($domain, $industry, $keywords) {
        $keywordText = !empty($keywords) ? "\nTarget keywords: " . implode(', ', $keywords) : '';
        
        return "Act as an expert SEO analyst. Identify the top 10 direct competitors for this website:

Domain: {$domain}
Industry: {$industry}{$keywordText}

Provide a JSON response with this exact format:
{
  \"competitors\": [
    {
      \"domain\": \"competitor1.com\",
      \"similarity_score\": 85,
      \"common_keywords\": 150,
      \"strength\": \"Strong content strategy and backlinks\",
      \"weakness\": \"Weak on-page SEO\"
    }
  ]
}

Focus on real, well-known competitors in the {$industry} industry. Include similarity score (0-100) and estimated common keywords.";
    }
    
    private function buildKeywordAnalysisPrompt($domain, $limit) {
        return "Act as an SEO keyword researcher. Generate a realistic list of {$limit} keywords that {$domain} likely ranks for.

Provide a JSON response with this exact format:
{
  \"keywords\": [
    {
      \"keyword\": \"example keyword\",
      \"search_volume\": 5000,
      \"keyword_difficulty\": 45,
      \"cpc_value\": 2.50,
      \"position\": 5,
      \"traffic_estimate\": 250,
      \"competition\": \"medium\",
      \"trend\": \"up\"
    }
  ]
}

Make the keywords relevant to {$domain}'s industry. Include realistic metrics.";
    }
    
    private function buildKeywordGapPrompt($primaryDomain, $competitorDomains, $industry) {
        $competitors = is_array($competitorDomains) ? implode(', ', $competitorDomains) : $competitorDomains;
        
        return "Act as an SEO strategist. Identify keyword opportunities for {$primaryDomain} by analyzing gaps compared to competitors: {$competitors}.

Industry: {$industry}

Provide a JSON response with this exact format:
{
  \"gaps\": [
    {
      \"keyword\": \"example keyword gap\",
      \"gap_type\": \"competitor_only\",
      \"competitor_domain\": \"competitor1.com\",
      \"competitor_position\": 3,
      \"our_position\": 0,
      \"search_volume\": 3000,
      \"opportunity_score\": 8500,
      \"priority\": \"high\",
      \"reasoning\": \"High volume, low difficulty\"
    }
  ]
}

Focus on realistic, actionable keyword opportunities. Gap types: competitor_only, lower_ranking, missing_opportunity.";
    }
    
    private function buildContentGapPrompt($primaryDomain, $competitorDomains, $industry) {
        $competitors = is_array($competitorDomains) ? implode(', ', $competitorDomains) : $competitorDomains;
        
        return "Act as a content strategist. Identify content topics that competitors cover but {$primaryDomain} is missing.

Competitors: {$competitors}
Industry: {$industry}

Provide a JSON response with this exact format:
{
  \"content_gaps\": [
    {
      \"topic\": \"Ultimate Guide to [Topic]\",
      \"competitor_domain\": \"competitor1.com\",
      \"keyword_cluster\": [\"keyword1\", \"keyword2\", \"keyword3\"],
      \"estimated_traffic\": 2500,
      \"priority\": \"high\",
      \"content_type\": \"guide\",
      \"recommended_action\": \"Create comprehensive guide with case studies\"
    }
  ]
}

Provide 10-15 realistic content gap opportunities.";
    }
    
    private function buildBacklinkOpportunitiesPrompt($domain, $industry) {
        return "Act as a link building expert. Generate realistic backlink opportunities for {$domain} in the {$industry} industry.

Provide a JSON response with this exact format:
{
  \"opportunities\": [
    {
      \"source_domain\": \"example-source.com\",
      \"source_type\": \"industry blog\",
      \"domain_authority\": 65,
      \"opportunity_type\": \"guest post\",
      \"difficulty\": \"medium\",
      \"estimated_value\": \"high\",
      \"strategy\": \"Pitch data-driven article on [topic]\"
    }
  ]
}

Include 20+ realistic link building opportunities. Types: guest post, resource page, broken link, competitor mention, industry directory.";
    }
    
    private function buildTrafficEstimationPrompt($domain, $industry) {
        return "Act as a traffic analyst. Estimate monthly traffic for {$domain} in the {$industry} industry over the last 6 months.

Provide a JSON response with this exact format:
{
  \"traffic_data\": [
    {
      \"month_year\": \"2024-04-01\",
      \"organic_traffic\": 45000,
      \"paid_traffic\": 5000,
      \"direct_traffic\": 10000,
      \"referral_traffic\": 3000,
      \"social_traffic\": 2000,
      \"total_traffic\": 65000,
      \"bounce_rate\": 45,
      \"avg_session_duration\": 180,
      \"pages_per_session\": 3.2
    }
  ],
  \"trend\": \"growing\",
  \"insights\": \"Traffic shows steady 15% month-over-month growth\"
}

Provide realistic estimates with a clear trend analysis.";
    }
    
    private function buildComprehensiveReportPrompt($primaryDomain, $competitorDomains, $industry) {
        $competitors = is_array($competitorDomains) ? implode(', ', $competitorDomains) : $competitorDomains;
        
        return "Act as an expert SEO analyst. Generate a comprehensive competitive analysis report.

Primary Domain: {$primaryDomain}
Competitors: {$competitors}
Industry: {$industry}

Provide a detailed JSON response with this format:
{
  \"executive_summary\": \"Brief overview of competitive landscape\",
  \"competitive_positioning\": {
    \"strengths\": [\"strength 1\", \"strength 2\"],
    \"weaknesses\": [\"weakness 1\", \"weakness 2\"],
    \"opportunities\": [\"opportunity 1\", \"opportunity 2\"],
    \"threats\": [\"threat 1\", \"threat 2\"]
  },
  \"key_insights\": [
    \"insight 1\",
    \"insight 2\",
    \"insight 3\"
  ],
  \"priority_actions\": [
    {
      \"action\": \"Action description\",
      \"priority\": \"high\",
      \"effort\": \"medium\",
      \"impact\": \"high\",
      \"timeline\": \"1-2 months\"
    }
  ],
  \"keyword_recommendations\": [\"keyword1\", \"keyword2\"],
  \"content_recommendations\": [\"content topic 1\", \"content topic 2\"],
  \"backlink_strategy\": \"Brief backlink strategy\",
  \"competitive_advantages\": [\"advantage 1\", \"advantage 2\"],
  \"risk_assessment\": \"Brief risk assessment\"
}

Be specific, actionable, and realistic.";
    }
    
    // ==================== AI API CALL ====================
    
    private function callChatGPT($prompt, $maxTokens = 2048) {
        if (empty($this->apiKey)) {
            return ['success' => false, 'message' => 'OpenAI API key not configured'];
        }
        
        $data = [
            'model' => $this->model,
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are an expert SEO analyst and competitive intelligence specialist. Always respond with valid JSON only, no additional text.'
                ],
                [
                    'role' => 'user',
                    'content' => $prompt
                ]
            ],
            'max_tokens' => $maxTokens,
            'temperature' => 0.7
        ];
        
        $ch = curl_init($this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            error_log("ChatGPT API Error: HTTP $httpCode - $response");
            return ['success' => false, 'message' => 'API request failed'];
        }
        
        $result = json_decode($response, true);
        
        if (isset($result['choices'][0]['message']['content'])) {
            return [
                'success' => true,
                'content' => $result['choices'][0]['message']['content']
            ];
        }
        
        return ['success' => false, 'message' => 'Invalid API response'];
    }
    
    // ==================== RESPONSE PARSERS ====================
    
    private function parseCompetitorList($content) {
        $data = $this->extractJSON($content);
        
        if (isset($data['competitors']) && is_array($data['competitors'])) {
            return $data['competitors'];
        }
        
        return $this->getFallbackCompetitors('example.com');
    }
    
    private function parseKeywordData($content) {
        $data = $this->extractJSON($content);
        
        if (isset($data['keywords']) && is_array($data['keywords'])) {
            return $data['keywords'];
        }
        
        return [];
    }
    
    private function parseKeywordGaps($content) {
        $data = $this->extractJSON($content);
        
        if (isset($data['gaps']) && is_array($data['gaps'])) {
            return $data['gaps'];
        }
        
        return [];
    }
    
    private function parseContentGaps($content) {
        $data = $this->extractJSON($content);
        
        if (isset($data['content_gaps']) && is_array($data['content_gaps'])) {
            return $data['content_gaps'];
        }
        
        return [];
    }
    
    private function parseBacklinkOpportunities($content) {
        $data = $this->extractJSON($content);
        
        if (isset($data['opportunities']) && is_array($data['opportunities'])) {
            return $data['opportunities'];
        }
        
        return [];
    }
    
    private function parseTrafficData($content) {
        $data = $this->extractJSON($content);
        
        if (isset($data['traffic_data']) && is_array($data['traffic_data'])) {
            return [
                'traffic_data' => $data['traffic_data'],
                'trend' => $data['trend'] ?? 'stable',
                'insights' => $data['insights'] ?? 'No insights available'
            ];
        }
        
        return $this->getFallbackTrafficData();
    }
    
    private function parseComprehensiveReport($content) {
        $data = $this->extractJSON($content);
        
        if (!empty($data)) {
            return $data;
        }
        
        return [
            'executive_summary' => 'Analysis generated using AI',
            'key_insights' => ['Comprehensive analysis completed'],
            'priority_actions' => []
        ];
    }
    
    private function extractJSON($content) {
        // Try to extract JSON from response
        $content = trim($content);
        
        // Remove markdown code blocks if present
        $content = preg_replace('/```json\s*|\s*```/', '', $content);
        
        // Try to find JSON
        if (preg_match('/\{.*\}/s', $content, $matches)) {
            $json = json_decode($matches[0], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $json;
            }
        }
        
        // Try direct decode
        $json = json_decode($content, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return $json;
        }
        
        return [];
    }
    
    // ==================== FALLBACK DATA ====================
    
    private function getFallbackCompetitors($domain) {
        return [
            ['domain' => 'competitor1.com', 'similarity_score' => 85, 'common_keywords' => 150],
            ['domain' => 'competitor2.com', 'similarity_score' => 78, 'common_keywords' => 120],
            ['domain' => 'competitor3.com', 'similarity_score' => 72, 'common_keywords' => 95],
            ['domain' => 'competitor4.com', 'similarity_score' => 68, 'common_keywords' => 85],
            ['domain' => 'competitor5.com', 'similarity_score' => 65, 'common_keywords' => 75]
        ];
    }
    
    private function getFallbackKeywords($domain, $limit) {
        $keywords = [];
        $bases = ['seo', 'marketing', 'digital', 'website', 'optimization'];
        
        for ($i = 0; $i < min($limit, 50); $i++) {
            $keywords[] = [
                'keyword' => $bases[array_rand($bases)] . ' tools',
                'search_volume' => rand(1000, 10000),
                'keyword_difficulty' => rand(30, 80),
                'cpc_value' => round(rand(100, 500) / 100, 2),
                'position' => rand(1, 50),
                'traffic_estimate' => rand(50, 500),
                'competition' => ['low', 'medium', 'high'][array_rand(['low', 'medium', 'high'])],
                'trend' => 'stable'
            ];
        }
        
        return $keywords;
    }
    
    private function getFallbackTrafficData() {
        $data = [];
        $baseTraffic = 50000;
        
        for ($i = 5; $i >= 0; $i--) {
            $date = date('Y-m-01', strtotime("-$i months"));
            $traffic = $baseTraffic + ($baseTraffic * rand(-10, 20) / 100);
            
            $data[] = [
                'month_year' => $date,
                'organic_traffic' => round($traffic * 0.6),
                'paid_traffic' => round($traffic * 0.15),
                'direct_traffic' => round($traffic * 0.15),
                'referral_traffic' => round($traffic * 0.07),
                'social_traffic' => round($traffic * 0.03),
                'total_traffic' => round($traffic),
                'bounce_rate' => rand(40, 60),
                'avg_session_duration' => rand(120, 240),
                'pages_per_session' => round(rand(20, 40) / 10, 1)
            ];
        }
        
        return [
            'traffic_data' => $data,
            'trend' => 'growing',
            'insights' => 'Traffic showing positive growth trend'
        ];
    }
}
