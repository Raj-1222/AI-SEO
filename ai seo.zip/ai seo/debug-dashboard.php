<?php
/**
 * Debug Dashboard Issues
 * This file helps diagnose why dashboard modules aren't working
 */

// Start session and check
session_start();

// Enable error display for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Debug</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0B1F4D; color: white; padding: 40px 0; }
        .debug-card { background: white; color: #333; border-radius: 10px; padding: 20px; margin-bottom: 20px; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; max-height: 300px; overflow-y: auto; }
        .success { color: #28A745; font-weight: bold; }
        .error { color: #DC3545; font-weight: bold; }
        .warning { color: #FFC107; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">🔍 Dashboard Debug Tool</h1>
        <p class="text-center text-muted">Comprehensive debugging of dashboard issues</p>
        <hr style="border-color: #FF6B00;">

        <?php
        // Test 1: Session Check
        echo '<div class="debug-card">';
        echo '<h4>1. Session Status</h4>';
        
        if (isset($_SESSION['user_id'])) {
            echo '<p class="success">✅ User is logged in</p>';
            echo '<pre>';
            echo 'User ID: ' . $_SESSION['user_id'] . "\n";
            echo 'Session ID: ' . session_id() . "\n";
            echo 'Session Status: ' . session_status() . "\n";
            echo 'All Session Data: ' . print_r($_SESSION, true);
            echo '</pre>';
        } else {
            echo '<p class="error">❌ User is NOT logged in</p>';
            echo '<div class="alert alert-danger">';
            echo '<strong>Problem:</strong> No session found. You must be logged in to use dashboard features.<br>';
            echo '<a href="views/auth/login.php" class="btn btn-primary mt-2">Go to Login</a>';
            echo '</div>';
        }
        echo '</div>';

        // Test 2: File Paths
        echo '<div class="debug-card">';
        echo '<h4>2. File Path Analysis</h4>';
        
        $files_to_check = [
            'API Endpoints' => [
                'api/keyword-generator.php',
                'api/meta-generator.php',
                'api/blog-generator.php',
                'api/audit.php',
                'api/gemini-ai.php'
            ],
            'JavaScript Files' => [
                'assets/js/keywords.js',
                'assets/js/meta-generator.js',
                'assets/js/blog-generator.js',
                'assets/js/audit.js'
            ],
            'Dashboard Pages' => [
                'views/dashboard/keywords.php',
                'views/dashboard/meta-generator.php',
                'views/dashboard/blog-generator.php',
                'views/dashboard/website-audit.php'
            ]
        ];
        
        foreach ($files_to_check as $category => $files) {
            echo '<h5>' . $category . '</h5>';
            foreach ($files as $file) {
                $fullPath = __DIR__ . '/' . $file;
                if (file_exists($fullPath)) {
                    echo '<p class="success">✅ ' . $file . '</p>';
                } else {
                    echo '<p class="error">❌ ' . $file . ' - NOT FOUND!</p>';
                }
            }
        }
        echo '</div>';

        // Test 3: API Configuration
        echo '<div class="debug-card">';
        echo '<h4>3. API Configuration</h4>';
        
        require_once __DIR__ . '/config/database.php';
        
        $apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';
        $apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : '';
        $model = defined('OPENAI_MODEL') ? OPENAI_MODEL : '';
        
        if (!empty($apiKey) && $apiKey !== 'YOUR_OPENAI_API_KEY_HERE') {
            echo '<p class="success">✅ OpenAI API Key configured</p>';
            echo '<pre>';
            echo 'API Key: ' . substr($apiKey, 0, 20) . '...' . substr($apiKey, -10) . "\n";
            echo 'API URL: ' . $apiUrl . "\n";
            echo 'Model: ' . $model;
            echo '</pre>';
        } else {
            echo '<p class="error">❌ OpenAI API Key NOT configured</p>';
        }
        echo '</div>';

        // Test 4: Actual API Call Test
        echo '<div class="debug-card">';
        echo '<h4>4. Live API Call Test</h4>';
        echo '<button class="btn btn-primary" onclick="testAPICall()">Test Keyword Generator API</button>';
        echo '<div id="api-test-result" class="mt-3"></div>';
        echo '</div>';

        // Test 5: JavaScript Path Test
        echo '<div class="debug-card">';
        echo '<h4>5. JavaScript Path Resolution Test</h4>';
        echo '<p>Current page location: <code>' . $_SERVER['REQUEST_URI'] . '</code></p>';
        echo '<button class="btn btn-primary" onclick="testJSPaths()">Test JavaScript Paths</button>';
        echo '<div id="js-path-result" class="mt-3"></div>';
        echo '</div>';

        // Test 6: Database Connection
        echo '<div class="debug-card">';
        echo '<h4>6. Database Connection</h4>';
        
        try {
            $conn = getDBConnection();
            if ($conn->ping()) {
                echo '<p class="success">✅ Database connected</p>';
                echo '<pre>';
                echo 'Host: ' . DB_HOST . "\n";
                echo 'Database: ' . DB_NAME . "\n";
                echo 'User: ' . DB_USER;
                echo '</pre>';
                
                // Check if user exists
                if (isset($_SESSION['user_id'])) {
                    $userId = $_SESSION['user_id'];
                    $stmt = $conn->prepare("SELECT id, name, email, role, created_at FROM users WHERE id = ?");
                    $stmt->bind_param("i", $userId);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($user = $result->fetch_assoc()) {
                        echo '<p class="success mt-3">✅ User found in database</p>';
                        echo '<pre>' . print_r($user, true) . '</pre>';
                    } else {
                        echo '<p class="error mt-3">❌ User ID ' . $userId . ' not found in database</p>';
                    }
                    $stmt->close();
                }
                
                $conn->close();
            }
        } catch (Exception $e) {
            echo '<p class="error">❌ Database error: ' . $e->getMessage() . '</p>';
        }
        echo '</div>';

        // Test 7: PHP Extensions
        echo '<div class="debug-card">';
        echo '<h4>7. Required PHP Extensions</h4>';
        
        $required_extensions = ['curl', 'mysqli', 'json', 'session', 'mbstring'];
        
        foreach ($required_extensions as $ext) {
            if (extension_loaded($ext)) {
                echo '<p class="success">✅ ' . $ext . '</p>';
            } else {
                echo '<p class="error">❌ ' . $ext . ' - MISSING!</p>';
            }
        }
        echo '</div>';
        ?>

        <!-- JavaScript Testing -->
        <script>
            function testAPICall() {
                const resultDiv = document.getElementById('api-test-result');
                resultDiv.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Testing API call...';
                
                fetch('api/keyword-generator.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: 'generate',
                        website_url: 'https://example.com',
                        industry: 'Technology',
                        location: 'United States'
                    })
                })
                .then(response => {
                    console.log('Response status:', response.status);
                    console.log('Response headers:', [...response.headers.entries()]);
                    return response.text();
                })
                .then(text => {
                    console.log('Raw response:', text);
                    
                    let html = '<div class="alert alert-info">';
                    html += '<strong>Response Status:</strong> ' + (text.startsWith('{') ? 'JSON' : 'HTML/Text') + '<br>';
                    html += '<strong>Response Preview:</strong><br>';
                    html += '<pre>' + text.substring(0, 500).replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</pre>';
                    
                    try {
                        const data = JSON.parse(text);
                        html += '<strong>Parsed JSON:</strong><br>';
                        html += '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
                        
                        if (data.success) {
                            html = '<div class="alert alert-success"><strong>✅ API Call Successful!</strong><br>' + html + '</div>';
                        } else {
                            html = '<div class="alert alert-warning"><strong>⚠️ API Responded with Error:</strong> ' + (data.message || 'Unknown error') + '<br>' + html + '</div>';
                        }
                    } catch (e) {
                        html += '<strong class="text-danger">❌ JSON Parse Error:</strong> ' + e.message;
                        html = '<div class="alert alert-danger">' + html + '</div>';
                    }
                    
                    resultDiv.innerHTML = html;
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    resultDiv.innerHTML = '<div class="alert alert-danger"><strong>❌ Network Error:</strong> ' + error.message + '</div>';
                });
            }

            function testJSPaths() {
                const resultDiv = document.getElementById('js-path-result');
                resultDiv.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Testing paths...';
                
                const currentURL = window.location.href;
                const currentPath = window.location.pathname;
                const baseURL = window.location.origin;
                
                let html = '<div class="alert alert-info">';
                html += '<strong>Current URL:</strong> ' + currentURL + '<br>';
                html += '<strong>Current Path:</strong> ' + currentPath + '<br>';
                html += '<strong>Base URL:</strong> ' + baseURL + '<br><br>';
                html += '<strong>Path Resolution Tests:</strong><br>';
                html += '<ul>';
                html += '<li><code>api/test.php</code> → ' + new URL('api/test.php', currentURL).href + '</li>';
                html += '<li><code>../../api/test.php</code> → ' + new URL('../../api/test.php', currentURL).href + '</li>';
                html += '<li><code>/api/test.php</code> → ' + new URL('/api/test.php', currentURL).href + '</li>';
                html += '</ul>';
                html += '</div>';
                
                resultDiv.innerHTML = html;
            }
        </script>
    </div>
</body>
</html>
