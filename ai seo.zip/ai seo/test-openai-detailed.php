<?php
/**
 * Detailed OpenAI API Test
 * Tests the actual API call with detailed error reporting
 */

// Disable error display
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/database.php';

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OpenAI API Detailed Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0B1F4D; color: white; padding: 40px 0; }
        .test-card { background: white; color: #333; border-radius: 10px; padding: 20px; margin-bottom: 20px; }
        .success { border-left: 5px solid #28A745; }
        .error { border-left: 5px solid #DC3545; }
        .warning { border-left: 5px solid #FFC107; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; max-height: 400px; overflow-y: auto; white-space: pre-wrap; word-wrap: break-word; }
        .status-badge { font-size: 14px; font-weight: bold; padding: 5px 15px; border-radius: 20px; }
        .status-badge.success { background: #28A745; color: white; }
        .status-badge.error { background: #DC3545; color: white; }
        .status-badge.warning { background: #FFC107; color: #333; }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center mb-4">🔍 OpenAI API Detailed Test</h1>
                <p class="text-center text-muted">Comprehensive diagnostic of OpenAI API connection</p>
                <hr style="border-color: #FF6B00;">
            </div>
        </div>

        <?php
        // Test 1: API Key Configuration
        echo '<div class="row mt-4"><div class="col-12">';
        echo '<div class="test-card">';
        echo '<h4>1. API Key Configuration</h4>';
        
        $apiKey = defined('OPENAI_API_KEY') ? OPENAI_API_KEY : '';
        $apiUrl = defined('OPENAI_API_URL') ? OPENAI_API_URL : '';
        $model = defined('OPENAI_MODEL') ? OPENAI_MODEL : '';
        
        if (empty($apiKey) || $apiKey === 'YOUR_OPENAI_API_KEY_HERE') {
            echo '<span class="status-badge error">❌ FAIL</span>';
            echo '<p class="mt-3 text-danger">OpenAI API key is not configured!</p>';
        } else {
            echo '<span class="status-badge success">✅ PASS</span>';
            echo '<p class="mt-3">API Key: ' . substr($apiKey, 0, 20) . '...' . substr($apiKey, -10) . '</p>';
            echo '<p>API URL: ' . htmlspecialchars($apiUrl) . '</p>';
            echo '<p>Model: ' . htmlspecialchars($model) . '</p>';
        }
        
        echo '</div></div></div>';

        // Test 2: cURL Extension
        echo '<div class="row"><div class="col-12">';
        echo '<div class="test-card">';
        echo '<h4>2. cURL Extension</h4>';
        
        if (function_exists('curl_init')) {
            echo '<span class="status-badge success">✅ PASS</span>';
            echo '<p class="mt-3">cURL is available</p>';
            $curlVersion = curl_version();
            echo '<p>cURL Version: ' . $curlVersion['version'] . '</p>';
            echo '<p>SSL Version: ' . $curlVersion['ssl_version'] . '</p>';
        } else {
            echo '<span class="status-badge error">❌ FAIL</span>';
            echo '<p class="mt-3 text-danger">cURL extension is not installed!</p>';
        }
        
        echo '</div></div></div>';

        // Test 3: Simple API Test
        echo '<div class="row"><div class="col-12">';
        echo '<div class="test-card">';
        echo '<h4>3. OpenAI API Connection Test</h4>';
        
        if (!empty($apiKey) && function_exists('curl_init')) {
            echo '<p class="text-muted">Testing actual API call to OpenAI...</p>';
            
            $testPrompt = "Say 'Hello, I am working!' in JSON format like: {\"message\": \"Hello, I am working!\"}";
            
            $data = [
                'model' => $model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'You are a helpful assistant. Respond only in valid JSON format.'
                    ],
                    [
                        'role' => 'user',
                        'content' => $testPrompt
                    ]
                ],
                'temperature' => 0.7,
                'max_tokens' => 100
            ];
            
            $ch = curl_init($apiUrl);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . $apiKey
                ],
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_VERBOSE => true
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            $curlInfo = curl_getinfo($ch);
            curl_close($ch);
            
            echo '<div class="mt-3">';
            echo '<p><strong>HTTP Status Code:</strong> ' . $httpCode . '</p>';
            
            if ($error) {
                echo '<span class="status-badge error">❌ FAIL</span>';
                echo '<p class="text-danger mt-3"><strong>cURL Error:</strong></p>';
                echo '<pre>' . htmlspecialchars($error) . '</pre>';
            } else {
                if ($httpCode === 200) {
                    echo '<span class="status-badge success">✅ PASS</span>';
                    
                    $result = json_decode($response, true);
                    
                    if ($result && isset($result['choices'][0]['message']['content'])) {
                        echo '<p class="text-success mt-3"><strong>API Response:</strong></p>';
                        echo '<pre>' . htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT)) . '</pre>';
                        
                        echo '<p class="text-success"><strong>AI Response Content:</strong></p>';
                        echo '<pre>' . htmlspecialchars($result['choices'][0]['message']['content']) . '</pre>';
                    } else {
                        echo '<span class="status-badge warning">⚠️ WARNING</span>';
                        echo '<p class="text-warning mt-3"><strong>Unexpected Response Format:</strong></p>';
                        echo '<pre>' . htmlspecialchars($response) . '</pre>';
                    }
                } else {
                    echo '<span class="status-badge error">❌ FAIL</span>';
                    echo '<p class="text-danger mt-3"><strong>HTTP Error ' . $httpCode . ':</strong></p>';
                    
                    $errorData = json_decode($response, true);
                    if ($errorData && isset($errorData['error'])) {
                        echo '<p class="text-danger"><strong>Error Type:</strong> ' . htmlspecialchars($errorData['error']['type'] ?? 'Unknown') . '</p>';
                        echo '<p class="text-danger"><strong>Error Message:</strong> ' . htmlspecialchars($errorData['error']['message'] ?? 'No message') . '</p>';
                        
                        // Common error messages and solutions
                        $errorMsg = $errorData['error']['message'] ?? '';
                        
                        if (strpos($errorMsg, 'API key') !== false || strpos($errorMsg, 'authentication') !== false) {
                            echo '<div class="alert alert-danger mt-3">';
                            echo '<strong>🔑 API Key Issue:</strong><br>';
                            echo '- Your API key may be invalid or expired<br>';
                            echo '- Check if the key is correct in config/database.php<br>';
                            echo '- Verify your OpenAI account has billing enabled<br>';
                            echo '- Get a new API key from: <a href="https://platform.openai.com/api-keys" target="_blank">https://platform.openai.com/api-keys</a>';
                            echo '</div>';
                        } elseif (strpos($errorMsg, 'quota') !== false || strpos($errorMsg, 'billing') !== false) {
                            echo '<div class="alert alert-warning mt-3">';
                            echo '<strong>💳 Billing Issue:</strong><br>';
                            echo '- Your OpenAI account may not have billing set up<br>';
                            echo '- You may have exceeded your quota<br>';
                            echo '- Add a payment method at: <a href="https://platform.openai.com/account/billing" target="_blank">https://platform.openai.com/account/billing</a>';
                            echo '</div>';
                        } elseif (strpos($errorMsg, 'model') !== false) {
                            echo '<div class="alert alert-warning mt-3">';
                            echo '<strong>🤖 Model Issue:</strong><br>';
                            echo '- The model "' . htmlspecialchars($model) . '" may not be available<br>';
                            echo '- Try using "gpt-3.5-turbo" or "gpt-4" instead';
                            echo '</div>';
                        }
                    }
                    
                    echo '<p class="mt-3"><strong>Raw Response:</strong></p>';
                    echo '<pre>' . htmlspecialchars($response) . '</pre>';
                }
            }
            
            echo '<p class="mt-3"><strong>Request Details:</strong></p>';
            echo '<pre>' . htmlspecialchars(json_encode([
                'url' => $apiUrl,
                'method' => 'POST',
                'model' => $model,
                'timeout' => '30 seconds',
                'ssl_verify' => 'enabled'
            ], JSON_PRETTY_PRINT)) . '</pre>';
            
            echo '</div>';
        } else {
            echo '<span class="status-badge error">❌ SKIP</span>';
            echo '<p class="mt-3 text-danger">Cannot test: Prerequisites not met</p>';
        }
        
        echo '</div></div></div>';

        // Test 4: Controller Test
        echo '<div class="row"><div class="col-12">';
        echo '<div class="test-card">';
        echo '<h4>4. Keyword Generator Controller Test</h4>';
        
        if (!empty($apiKey) && function_exists('curl_init')) {
            echo '<p class="text-muted">Testing KeywordGeneratorController...</p>';
            
            try {
                require_once __DIR__ . '/controllers/KeywordGeneratorController.php';
                
                $controller = new KeywordGeneratorController();
                $result = $controller->generateKeywords(
                    'https://example.com',
                    'Technology',
                    'United States'
                );
                
                if ($result['success']) {
                    echo '<span class="status-badge success">✅ PASS</span>';
                    echo '<p class="text-success mt-3">Keywords generated successfully!</p>';
                    echo '<pre>' . htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT)) . '</pre>';
                } else {
                    echo '<span class="status-badge error">❌ FAIL</span>';
                    echo '<p class="text-danger mt-3"><strong>Error:</strong> ' . htmlspecialchars($result['message']) . '</p>';
                }
            } catch (Exception $e) {
                echo '<span class="status-badge error">❌ FAIL</span>';
                echo '<p class="text-danger mt-3"><strong>Exception:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
                echo '<pre>' . htmlspecialchars($e->getTraceAsString()) . '</pre>';
            }
        } else {
            echo '<span class="status-badge error">❌ SKIP</span>';
            echo '<p class="mt-3 text-danger">Cannot test: Prerequisites not met</p>';
        }
        
        echo '</div></div></div>';

        // Summary
        echo '<div class="row"><div class="col-12">';
        echo '<div class="test-card success">';
        echo '<h4>📋 Test Summary</h4>';
        echo '<p>If all tests passed, your OpenAI integration is working correctly.</p>';
        echo '<p>If any tests failed, follow the error messages above to fix the issues.</p>';
        echo '<hr>';
        echo '<p><strong>Common Issues:</strong></p>';
        echo '<ul>';
        echo '<li><strong>Invalid API Key:</strong> Get a new key from <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Dashboard</a></li>';
        echo '<li><strong>Billing Not Set Up:</strong> Add payment method at <a href="https://platform.openai.com/account/billing" target="_blank">Billing Settings</a></li>';
        echo '<li><strong>Quota Exceeded:</strong> Check usage at <a href="https://platform.openai.com/usage" target="_blank">Usage Dashboard</a></li>';
        echo '<li><strong>Network Error:</strong> Check firewall/proxy settings</li>';
        echo '</ul>';
        echo '</div></div></div>';
        ?>
    </div>
</body>
</html>
