<?php
/**
 * Get Base Path Helper
 * Returns the correct base path for AJAX calls
 */

// Get the base path from the request
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$scriptName = dirname($_SERVER['SCRIPT_NAME']);

// Remove any trailing slashes
$basePath = rtrim($scriptName, '/');

// Return as JSON
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'base_path' => $basePath,
    'full_url' => $protocol . '://' . $host . $basePath,
    'api_path' => $basePath . '/api',
    'example_fetch' => $basePath . '/api/keyword-generator.php'
]);
