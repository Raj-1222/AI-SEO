<?php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Image Optimizer Status</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container { 
            max-width: 800px; 
            margin: 0 auto; 
            background: white; 
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 { 
            color: #0B1F4D; 
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle { 
            color: #6C757D; 
            margin-bottom: 30px;
            font-size: 16px;
        }
        .status-box { 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 15px; 
            margin: 20px 0;
            border-left: 5px solid #0B1F4D;
        }
        .success { border-left-color: #28a745; background: #d4edda; }
        .error { border-left-color: #dc3545; background: #f8d7da; }
        .warning { border-left-color: #ffc107; background: #fff3cd; }
        .btn { 
            display: inline-block; 
            padding: 12px 30px; 
            background: #FF6B00; 
            color: white; 
            text-decoration: none; 
            border-radius: 10px; 
            margin: 10px 10px 10px 0;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn:hover { 
            background: #E55F00; 
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255,107,0,0.3);
        }
        .btn-secondary { background: #6C757D; }
        .btn-secondary:hover { background: #5A6268; }
        code { 
            background: #2d2d2d; 
            color: #f8f8f2; 
            padding: 2px 8px; 
            border-radius: 5px;
            font-family: 'Courier New', monospace;
        }
        .icon { font-size: 24px; margin-right: 10px; }
        ul { margin: 15px 0; padding-left: 30px; }
        li { margin: 8px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🖼️ Image Optimizer Status</h1>
        <p class="subtitle">Quick diagnostics and access links</p>
        
        <?php
        $allGood = true;
        
        // Check 1: Files exist
        $criticalFiles = [
            'config/image_optimizer_config.php',
            'controllers/ImageProcessorController.php',
            'models/ImageHistory.php',
            'api/image-optimizer.php',
            'views/dashboard/image-optimizer.php'
        ];
        
        $missingFiles = [];
        foreach ($criticalFiles as $file) {
            if (!file_exists(__DIR__ . '/' . $file)) {
                $missingFiles[] = $file;
                $allGood = false;
            }
        }
        
        if (empty($missingFiles)) {
            echo '<div class="status-box success">';
            echo '<strong>✅ All module files are present</strong>';
            echo '</div>';
        } else {
            echo '<div class="status-box error">';
            echo '<strong>❌ Missing files detected:</strong><ul>';
            foreach ($missingFiles as $file) {
                echo "<li>$file</li>";
            }
            echo '</ul></div>';
        }
        
        // Check 2: Directories
        $dirs = [
            'uploads/images/original',
            'uploads/images/optimized',
            'downloads/images'
        ];
        
        $dirIssues = [];
        foreach ($dirs as $dir) {
            $path = __DIR__ . '/' . $dir;
            if (!file_exists($path)) {
                $dirIssues[] = "$dir (doesn't exist)";
                $allGood = false;
            } elseif (!is_writable($path)) {
                $dirIssues[] = "$dir (not writable)";
                $allGood = false;
            }
        }
        
        if (empty($dirIssues)) {
            echo '<div class="status-box success">';
            echo '<strong>✅ All directories are ready and writable</strong>';
            echo '</div>';
        } else {
            echo '<div class="status-box error">';
            echo '<strong>❌ Directory issues:</strong><ul>';
            foreach ($dirIssues as $issue) {
                echo "<li>$issue</li>";
            }
            echo '</ul>';
            echo '<p><strong>Fix:</strong> Run <code>fix-image-optimizer.php</code></p>';
            echo '</div>';
        }
        
        // Check 3: PHP Extensions
        $hasImageLib = extension_loaded('imagick') || extension_loaded('gd');
        
        if ($hasImageLib) {
            $lib = extension_loaded('imagick') ? 'Imagick' : 'GD Library';
            echo '<div class="status-box success">';
            echo "<strong>✅ Image processing available ($lib)</strong>";
            echo '</div>';
        } else {
            echo '<div class="status-box error">';
            echo '<strong>❌ No image processing library found</strong>';
            echo '<p>Install Imagick or enable GD extension</p>';
            echo '</div>';
            $allGood = false;
        }
        
        // Check 4: Database
        try {
            require_once __DIR__ . '/config/init.php';
            $db = getDBConnection();
            
            // Quick table check
            $result = $db->query("SHOW TABLES LIKE 'image_processing_history'");
            $tableExists = ($result->num_rows > 0);
            
            if ($tableExists) {
                echo '<div class="status-box success">';
                echo '<strong>✅ Database connection OK and tables exist</strong>';
                echo '</div>';
            } else {
                echo '<div class="status-box error">';
                echo '<strong>❌ Database tables missing</strong>';
                echo '<p>Import <code>database/image_optimizer_schema.sql</code></p>';
                echo '</div>';
                $allGood = false;
            }
        } catch (Exception $e) {
            echo '<div class="status-box error">';
            echo '<strong>❌ Database connection failed</strong>';
            echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
            echo '</div>';
            $allGood = false;
        }
        
        // Summary
        if ($allGood) {
            echo '<div class="status-box success" style="border-left-width: 10px; background: #d4edda; padding: 30px;">';
            echo '<h2 style="color: #28a745; margin-bottom: 15px;">🎉 All Systems Operational!</h2>';
            echo '<p style="font-size: 18px; margin-bottom: 20px;">Your Image Optimizer is ready to use!</p>';
            echo '<a href="views/dashboard/image-optimizer.php" class="btn">🚀 Open Image Optimizer</a>';
            echo '</div>';
        } else {
            echo '<div class="status-box error" style="border-left-width: 10px;">';
            echo '<h2 style="color: #dc3545; margin-bottom: 15px;">⚠️ Action Required</h2>';
            echo '<p style="margin-bottom: 20px;">Please fix the issues above before using the Image Optimizer.</p>';
            echo '<a href="fix-image-optimizer.php" class="btn">🔧 Run Auto Fix</a>';
            echo '<a href="test-image-optimizer.php" class="btn btn-secondary">📋 Detailed Diagnostics</a>';
            echo '</div>';
        }
        ?>
        
        <div class="status-box" style="background: #e8f4f8; border-left-color: #0dcaf0;">
            <h3 style="color: #0B1F4D; margin-bottom: 15px;">🛠️ Useful Tools</h3>
            <a href="fix-image-optimizer.php" class="btn">Auto Fix Issues</a>
            <a href="test-image-optimizer.php" class="btn btn-secondary">Full Diagnostic</a>
            <a href="install_image_optimizer.php" class="btn btn-secondary">Installation Check</a>
        </div>
        
        <div class="status-box" style="background: #fff3cd; border-left-color: #ffc107;">
            <h3 style="color: #0B1F4D; margin-bottom: 15px;">📚 Quick Help</h3>
            <ul style="margin: 0;">
                <li><strong>Missing tables?</strong> Import <code>database/image_optimizer_schema.sql</code></li>
                <li><strong>Directory errors?</strong> Run <code>chmod -R 755 uploads/ downloads/</code></li>
                <li><strong>No image library?</strong> Install: <code>sudo apt-get install php-imagick</code></li>
                <li><strong>Need help?</strong> Read <code>IMAGE_OPTIMIZER_README.txt</code></li>
            </ul>
        </div>
        
        <p style="text-align: center; color: #6C757D; margin-top: 30px; font-size: 14px;">
            <em>Last checked: <?php echo date('Y-m-d H:i:s'); ?></em>
        </p>
    </div>
</body>
</html>
