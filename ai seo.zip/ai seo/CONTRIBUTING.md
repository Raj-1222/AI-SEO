# Contributing to Aurify AI SEO Automation

Thank you for your interest in contributing! We welcome contributions from the community.

## 🚀 How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported in [Issues](https://github.com/yourusername/ai-seo/issues)
2. If not, create a new issue with:
   - Clear title and description
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots if applicable
   - Environment details (PHP version, OS, browser)

### Suggesting Features

1. Check existing [Feature Requests](https://github.com/yourusername/ai-seo/issues?q=is%3Aissue+is%3Aopen+label%3Aenhancement)
2. Create a new issue with `enhancement` label
3. Describe the feature and use case
4. Explain why it would be valuable

### Pull Requests

1. **Fork the repository**
   ```bash
   git clone https://github.com/yourusername/ai-seo.git
   cd ai-seo
   ```

2. **Create a feature branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```

3. **Make your changes**
   - Follow coding standards (see below)
   - Add comments for complex logic
   - Update documentation if needed

4. **Test your changes**
   - Ensure no existing functionality is broken
   - Test on different browsers if UI changes
   - Check for PHP errors and warnings

5. **Commit your changes**
   ```bash
   git add .
   git commit -m "Add amazing feature"
   ```

6. **Push to your fork**
   ```bash
   git push origin feature/amazing-feature
   ```

7. **Open a Pull Request**
   - Provide clear description of changes
   - Reference related issues
   - Add screenshots for UI changes

## 📋 Coding Standards

### PHP

- Follow [PSR-12](https://www.php-fig.org/psr/psr-12/) coding standard
- Use meaningful variable and function names
- Add PHPDoc comments for functions
- Keep functions small and focused

```php
/**
 * Generate SEO meta tags for a given URL
 * 
 * @param string $url The URL to analyze
 * @param array $options Optional configuration
 * @return array Generated meta tags
 */
function generateMetaTags(string $url, array $options = []): array {
    // Implementation
}
```

### JavaScript

- Use ES6+ features
- Use `const` and `let` instead of `var`
- Use descriptive function names
- Add comments for complex logic

```javascript
/**
 * Fetch SEO audit data from API
 * @param {string} url - Website URL to audit
 * @returns {Promise<Object>} Audit results
 */
async function fetchAuditData(url) {
    // Implementation
}
```

### CSS

- Use BEM naming convention
- Keep selectors specific but not overly complex
- Group related styles together
- Add comments for sections

```css
/* Header Navigation */
.header__nav {
    display: flex;
    align-items: center;
}

.header__nav-item {
    margin: 0 1rem;
}
```

### Database

- Use prepared statements for all queries
- Properly index frequently queried columns
- Use meaningful table and column names
- Add comments for complex queries

```php
// Good
$stmt = $conn->prepare("SELECT * FROM websites WHERE user_id = ? AND status = ?");
$stmt->bind_param("is", $userId, $status);
$stmt->execute();

// Bad - SQL injection risk
$query = "SELECT * FROM websites WHERE user_id = $userId";
```

## 🧪 Testing

- Test all new features thoroughly
- Check for edge cases
- Test on multiple browsers (Chrome, Firefox, Safari, Edge)
- Test on mobile devices
- Verify API responses

## 📝 Documentation

- Update README.md if adding new features
- Add inline comments for complex code
- Update API documentation for new endpoints
- Include examples for new functionality

## 🔒 Security

- Never commit sensitive data (API keys, passwords)
- Sanitize and validate all user input
- Use prepared statements for database queries
- Follow security guidelines in SECURITY.md

## ⚖️ License

By contributing, you agree that your contributions will be licensed under the MIT License.

## 💬 Questions?

Feel free to open an issue for discussion or reach out to the maintainers.

## 🎯 Good First Issues

Look for issues labeled `good first issue` if you're new to the project.

## 🌟 Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Project documentation

---

Thank you for contributing to Aurify AI SEO Automation! 🚀
