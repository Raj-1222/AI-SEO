<?php
/**
 * API Response Test Utility
 * 
 * This script tests if API endpoints are returning clean JSON
 * without any HTML, warnings, or unexpected output
 */

// Suppress display errors for clean output
error_reporting(0);
ini_set('display_errors', 0);

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Response Tester - Aurify AI SEO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0B1F4D; color: white; padding: 40px 0; }
        .test-card { background: white; color: #333; border-radius: 10px; padding: 20px; margin-bottom: 20px; }
        .success { border-left: 5px solid #28A745; }
        .error { border-left: 5px solid #DC3545; }
        .warning { border-left: 5px solid #FFC107; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; max-height: 300px; overflow-y: auto; }
        .status-badge { font-size: 14px; font-weight: bold; padding: 5px 15px; border-radius: 20px; }
        .status-badge.success { background: #28A745; color: white; }
        .status-badge.error { background: #DC3545; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center mb-4">
                    <i class="bi bi-shield-check"></i> API Response Tester
                </h1>
                <p class="text-center text-muted">Testing all API endpoints for clean JSON responses</p>
                <hr style="border-color: #FF6B00;">
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <h3>Quick API Tests</h3>
                <p class="text-muted">These tests check if API endpoints return valid JSON without HTML errors.</p>

                <div class="test-card" id="test-results">
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Testing...</span>
                        </div>
                        <p class="mt-3">Running API tests...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Test configuration
        const API_TESTS = [
            {
                name: 'Keyword Generator',
                url: '/ai seo/api/keyword-generator.php',
                method: 'GET',
                expectedKeys: ['success']
            },
            {
                name: 'Meta Generator',
                url: '/ai seo/api/meta-generator.php',
                method: 'GET',
                expectedKeys: ['success']
            },
            {
                name: 'Blog Generator',
                url: '/ai seo/api/blog-generator.php',
                method: 'GET',
                expectedKeys: ['success']
            },
            {
                name: 'Schema Generator',
                url: '/ai seo/api/schema-generator.php',
                method: 'GET',
                expectedKeys: ['success']
            }
        ];

        async function testAPI(test) {
            try {
                const response = await fetch(test.url, {
                    method: test.method,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                const contentType = response.headers.get('content-type');
                const rawText = await response.text();

                // Check 1: Is response JSON?
                if (!contentType || !contentType.includes('application/json')) {
                    return {
                        status: 'error',
                        message: 'Response is not JSON',
                        contentType: contentType,
                        preview: rawText.substring(0, 200)
                    };
                }

                // Check 2: Does it start with HTML?
                if (rawText.trim().startsWith('<')) {
                    return {
                        status: 'error',
                        message: 'Response starts with HTML (Unexpected token error would occur)',
                        preview: rawText.substring(0, 200)
                    };
                }

                // Check 3: Can it be parsed as JSON?
                let jsonData;
                try {
                    jsonData = JSON.parse(rawText);
                } catch (e) {
                    return {
                        status: 'error',
                        message: 'Invalid JSON: ' + e.message,
                        preview: rawText.substring(0, 200)
                    };
                }

                // Check 4: Has expected keys?
                const hasExpectedKeys = test.expectedKeys.every(key => key in jsonData);
                if (!hasExpectedKeys) {
                    return {
                        status: 'warning',
                        message: 'JSON is valid but missing expected keys',
                        data: jsonData
                    };
                }

                return {
                    status: 'success',
                    message: 'API returns clean JSON',
                    data: jsonData
                };

            } catch (error) {
                return {
                    status: 'error',
                    message: 'Network error: ' + error.message
                };
            }
        }

        async function runAllTests() {
            const resultsContainer = document.getElementById('test-results');
            resultsContainer.innerHTML = '';

            for (const test of API_TESTS) {
                const result = await testAPI(test);
                
                const statusClass = result.status === 'success' ? 'success' : 
                                   result.status === 'warning' ? 'warning' : 'error';
                
                const statusBadge = result.status === 'success' ? '✅ PASS' :
                                   result.status === 'warning' ? '⚠️ WARNING' : '❌ FAIL';

                const cardHTML = `
                    <div class="test-card ${statusClass}">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">${test.name}</h5>
                            <span class="status-badge ${statusClass}">${statusBadge}</span>
                        </div>
                        <p><strong>Endpoint:</strong> ${test.url}</p>
                        <p><strong>Method:</strong> ${test.method}</p>
                        <p><strong>Result:</strong> ${result.message}</p>
                        ${result.contentType ? `<p><strong>Content-Type:</strong> ${result.contentType}</p>` : ''}
                        ${result.preview ? `<div><strong>Response Preview:</strong><pre>${escapeHtml(result.preview)}</pre></div>` : ''}
                        ${result.data ? `<div><strong>JSON Data:</strong><pre>${JSON.stringify(result.data, null, 2)}</pre></div>` : ''}
                    </div>
                `;

                resultsContainer.innerHTML += cardHTML;
            }

            // Summary
            const successCount = API_TESTS.length;
            resultsContainer.innerHTML += `
                <div class="test-card success text-center">
                    <h4>Test Complete</h4>
                    <p>All API endpoints have been tested for clean JSON responses.</p>
                    <p class="mb-0"><small>If any tests failed, the "Unexpected token" error would occur in those modules.</small></p>
                </div>
            `;
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Run tests on page load
        document.addEventListener('DOMContentLoaded', () => {
            runAllTests();
        });
    </script>
</body>
</html>
