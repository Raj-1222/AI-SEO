<?php
/**
 * Direct API Test - Image Optimizer
 * This will help us see what error is happening
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Image Optimizer API Test</h1>";
echo "<style>body{font-family:Arial;max-width:900px;margin:20px auto;} pre{background:#f5f5f5;padding:15px;border-radius:5px;}</style>";

// Test 1: Check if we can include the config
echo "<h2>1. Testing Configuration Load</h2>";
try {
    require_once __DIR__ . '/config/init.php';
    echo "✅ Config loaded<br>";
    echo "Session active: " . (session_status() === PHP_SESSION_ACTIVE ? 'Yes' : 'No') . "<br>";
    echo "User ID: " . ($_SESSION['user_id'] ?? 'Not set') . "<br>";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
    die();
}

// Test 2: Load image optimizer config
echo "<h2>2. Testing Image Optimizer Config</h2>";
try {
    require_once __DIR__ . '/config/image_optimizer_config.php';
    echo "✅ Image optimizer config loaded<br>";
    echo "Using library: " . IMG_LIBRARY . "<br>";
    echo "Upload dir: " . IMG_ORIGINAL_DIR . "<br>";
    echo "Exists: " . (file_exists(IMG_ORIGINAL_DIR) ? 'Yes' : 'No') . "<br>";
    echo "Writable: " . (is_writable(IMG_ORIGINAL_DIR) ? 'Yes' : 'No') . "<br>";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
    die();
}

// Test 3: Check if we can create a test image
echo "<h2>3. Testing Image Creation</h2>";
try {
    if (IMG_HAS_IMAGICK) {
        $img = new Imagick();
        $img->newImage(100, 100, new ImagickPixel('blue'));
        $img->setImageFormat('jpg');
        $testPath = IMG_ORIGINAL_DIR . 'test_' . time() . '.jpg';
        $img->writeImage($testPath);
        echo "✅ Test image created with Imagick<br>";
        echo "Path: $testPath<br>";
        echo "Size: " . filesize($testPath) . " bytes<br>";
        
        // Clean up
        @unlink($testPath);
        $img->clear();
        $img->destroy();
    } elseif (IMG_HAS_GD) {
        $img = imagecreatetruecolor(100, 100);
        $blue = imagecolorallocate($img, 0, 0, 255);
        imagefill($img, 0, 0, $blue);
        $testPath = IMG_ORIGINAL_DIR . 'test_' . time() . '.jpg';
        imagejpeg($img, $testPath, 90);
        echo "✅ Test image created with GD<br>";
        echo "Path: $testPath<br>";
        echo "Size: " . filesize($testPath) . " bytes<br>";
        
        // Clean up
        @unlink($testPath);
        imagedestroy($img);
    }
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
}

// Test 4: Simulate upload
echo "<h2>4. Simulating File Upload</h2>";

// Create a simple test image
$testImageContent = base64_decode('/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABkAGQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlbaWmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD//2Q==');
$testPath = IMG_ORIGINAL_DIR . 'api_test_' . time() . '.jpg';
file_put_contents($testPath, $testImageContent);

echo "Test image created: $testPath<br>";
echo "File size: " . filesize($testPath) . " bytes<br>";

// Test 5: Try to call the API functions directly
echo "<h2>5. Testing API Functions</h2>";

try {
    require_once __DIR__ . '/controllers/ImageProcessorController.php';
    require_once __DIR__ . '/models/ImageHistory.php';
    
    $processor = new ImageProcessorController();
    echo "✅ ImageProcessorController loaded<br>";
    
    $db = getDBConnection();
    $history = new ImageHistory($db);
    echo "✅ ImageHistory model loaded<br>";
    
    // Test compression
    $destPath = IMG_OPTIMIZED_DIR . 'compressed_test_' . time() . '.jpg';
    $result = $processor->compressImage($testPath, $destPath, 85);
    
    if ($result['success']) {
        echo "✅ Image compression test PASSED<br>";
        echo "<pre>";
        print_r($result);
        echo "</pre>";
        
        // Clean up
        @unlink($destPath);
    } else {
        echo "❌ Image compression test FAILED<br>";
        echo "<pre>";
        print_r($result);
        echo "</pre>";
    }
    
    // Clean up test image
    @unlink($testPath);
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
    echo "<pre>";
    echo $e->getTraceAsString();
    echo "</pre>";
}

echo "<hr>";
echo "<h2>Summary</h2>";
echo "<p>If all tests passed, the module should work. If any failed, check the error messages above.</p>";
echo "<p><a href='views/dashboard/image-optimizer.php'>Go to Image Optimizer</a></p>";
?>
