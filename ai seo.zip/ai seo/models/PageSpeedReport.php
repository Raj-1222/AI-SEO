<?php
class PageSpeedReport {
    private $conn;
    private $table = 'pagespeed_reports';
    
    public $id;
    public $website_id;
    public $device_type;
    public $performance_score;
    public $accessibility_score;
    public $best_practices_score;
    public $seo_score;
    public $lcp_value;
    public $lcp_score;
    public $cls_value;
    public $cls_score;
    public $fid_value;
    public $fid_score;
    public $ttfb_value;
    public $ttfb_score;
    public $speed_index_value;
    public $speed_index_score;
    public $fcp_value;
    public $fcp_score;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create PageSpeed report
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (website_id, device_type, performance_score, accessibility_score, 
                   best_practices_score, seo_score, lcp_value, lcp_score, cls_value, 
                   cls_score, fid_value, fid_score, ttfb_value, ttfb_score, 
                   speed_index_value, speed_index_score, fcp_value, fcp_score) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bind_param(
            "isiiiididiididiid",
            $this->website_id,
            $this->device_type,
            $this->performance_score,
            $this->accessibility_score,
            $this->best_practices_score,
            $this->seo_score,
            $this->lcp_value,
            $this->lcp_score,
            $this->cls_value,
            $this->cls_score,
            $this->fid_value,
            $this->fid_score,
            $this->ttfb_value,
            $this->ttfb_score,
            $this->speed_index_value,
            $this->speed_index_score,
            $this->fcp_value,
            $this->fcp_score
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Get reports by website ID
    public function getByWebsite($website_id) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE website_id = ? 
                  ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $website_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get report by device type
    public function getByDeviceType($website_id, $device_type) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE website_id = ? AND device_type = ? 
                  ORDER BY created_at DESC 
                  LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $website_id, $device_type);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Delete reports by website ID
    public function deleteByWebsite($website_id) {
        $query = "DELETE FROM " . $this->table . " WHERE website_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $website_id);
        return $stmt->execute();
    }
}
