<?php
class Schema {
    
    // Generate Organization Schema
    public static function generateOrganization($data) {
        return [
            "@context" => "https://schema.org",
            "@type" => "Organization",
            "name" => $data['name'] ?? '',
            "url" => $data['url'] ?? '',
            "logo" => $data['logo'] ?? '',
            "description" => $data['description'] ?? '',
            "telephone" => $data['telephone'] ?? '',
            "email" => $data['email'] ?? '',
            "address" => $data['address'] ? [
                "@type" => "PostalAddress",
                "streetAddress" => $data['address']['street'] ?? '',
                "addressLocality" => $data['address']['city'] ?? '',
                "addressRegion" => $data['address']['state'] ?? '',
                "postalCode" => $data['address']['zip'] ?? '',
                "addressCountry" => $data['address']['country'] ?? ''
            ] : null,
            "sameAs" => $data['social'] ?? []
        ];
    }
    
    // Generate LocalBusiness Schema
    public static function generateLocalBusiness($data) {
        $schema = [
            "@context" => "https://schema.org",
            "@type" => "LocalBusiness",
            "name" => $data['name'] ?? '',
            "image" => $data['image'] ?? '',
            "url" => $data['url'] ?? '',
            "telephone" => $data['telephone'] ?? '',
            "priceRange" => $data['priceRange'] ?? '',
            "address" => [
                "@type" => "PostalAddress",
                "streetAddress" => $data['address']['street'] ?? '',
                "addressLocality" => $data['address']['city'] ?? '',
                "addressRegion" => $data['address']['state'] ?? '',
                "postalCode" => $data['address']['zip'] ?? '',
                "addressCountry" => $data['address']['country'] ?? ''
            ]
        ];
        
        if (!empty($data['geo'])) {
            $schema['geo'] = [
                "@type" => "GeoCoordinates",
                "latitude" => $data['geo']['latitude'] ?? '',
                "longitude" => $data['geo']['longitude'] ?? ''
            ];
        }
        
        if (!empty($data['openingHours'])) {
            $schema['openingHoursSpecification'] = array_map(function($hours) {
                return [
                    "@type" => "OpeningHoursSpecification",
                    "dayOfWeek" => $hours['day'],
                    "opens" => $hours['opens'],
                    "closes" => $hours['closes']
                ];
            }, $data['openingHours']);
        }
        
        return $schema;
    }
    
    // Generate Product Schema
    public static function generateProduct($data) {
        $schema = [
            "@context" => "https://schema.org",
            "@type" => "Product",
            "name" => $data['name'] ?? '',
            "image" => $data['image'] ?? [],
            "description" => $data['description'] ?? '',
            "brand" => [
                "@type" => "Brand",
                "name" => $data['brand'] ?? ''
            ],
            "sku" => $data['sku'] ?? '',
            "offers" => [
                "@type" => "Offer",
                "url" => $data['url'] ?? '',
                "priceCurrency" => $data['currency'] ?? 'USD',
                "price" => $data['price'] ?? '',
                "availability" => $data['availability'] ?? 'https://schema.org/InStock',
                "priceValidUntil" => $data['priceValidUntil'] ?? ''
            ]
        ];
        
        if (!empty($data['rating'])) {
            $schema['aggregateRating'] = [
                "@type" => "AggregateRating",
                "ratingValue" => $data['rating']['value'] ?? '',
                "reviewCount" => $data['rating']['count'] ?? ''
            ];
        }
        
        return $schema;
    }
    
    // Generate Article Schema
    public static function generateArticle($data) {
        return [
            "@context" => "https://schema.org",
            "@type" => "Article",
            "headline" => $data['headline'] ?? '',
            "image" => $data['image'] ?? '',
            "author" => [
                "@type" => "Person",
                "name" => $data['author'] ?? ''
            ],
            "publisher" => [
                "@type" => "Organization",
                "name" => $data['publisher'] ?? '',
                "logo" => [
                    "@type" => "ImageObject",
                    "url" => $data['publisherLogo'] ?? ''
                ]
            ],
            "datePublished" => $data['datePublished'] ?? '',
            "dateModified" => $data['dateModified'] ?? '',
            "description" => $data['description'] ?? ''
        ];
    }
    
    // Generate FAQ Schema
    public static function generateFAQ($data) {
        $mainEntity = [];
        
        if (!empty($data['questions'])) {
            foreach ($data['questions'] as $qa) {
                $mainEntity[] = [
                    "@type" => "Question",
                    "name" => $qa['question'] ?? '',
                    "acceptedAnswer" => [
                        "@type" => "Answer",
                        "text" => $qa['answer'] ?? ''
                    ]
                ];
            }
        }
        
        return [
            "@context" => "https://schema.org",
            "@type" => "FAQPage",
            "mainEntity" => $mainEntity
        ];
    }
    
    // Generate Breadcrumb Schema
    public static function generateBreadcrumb($data) {
        $itemListElement = [];
        
        if (!empty($data['items'])) {
            foreach ($data['items'] as $index => $item) {
                $itemListElement[] = [
                    "@type" => "ListItem",
                    "position" => $index + 1,
                    "name" => $item['name'] ?? '',
                    "item" => $item['url'] ?? ''
                ];
            }
        }
        
        return [
            "@context" => "https://schema.org",
            "@type" => "BreadcrumbList",
            "itemListElement" => $itemListElement
        ];
    }
    
    // Generate Service Schema
    public static function generateService($data) {
        return [
            "@context" => "https://schema.org",
            "@type" => "Service",
            "name" => $data['name'] ?? '',
            "description" => $data['description'] ?? '',
            "provider" => [
                "@type" => "Organization",
                "name" => $data['provider'] ?? ''
            ],
            "serviceType" => $data['serviceType'] ?? '',
            "areaServed" => $data['areaServed'] ?? '',
            "offers" => [
                "@type" => "Offer",
                "priceCurrency" => $data['currency'] ?? 'USD',
                "price" => $data['price'] ?? ''
            ]
        ];
    }
    
    // Validate JSON Schema
    public static function validate($schema) {
        $json = json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'valid' => false,
                'error' => json_last_error_msg()
            ];
        }
        
        // Check required fields
        if (empty($schema['@context']) || empty($schema['@type'])) {
            return [
                'valid' => false,
                'error' => 'Missing required @context or @type'
            ];
        }
        
        return [
            'valid' => true,
            'json' => $json
        ];
    }
    
    // Format JSON-LD for HTML output
    public static function toHTMLScript($schema) {
        $json = json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return '<script type="application/ld+json">' . "\n" . $json . "\n" . '</script>';
    }
}
