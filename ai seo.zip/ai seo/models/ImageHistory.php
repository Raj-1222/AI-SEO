<?php
/**
 * Image History Model
 * Handles database operations for image processing history
 * Compatible with MySQLi connection
 */

class ImageHistory {
    private $conn;
    private $table = 'image_processing_history';
    
    // Properties
    public $id;
    public $user_id;
    public $original_name;
    public $original_path;
    public $optimized_name;
    public $optimized_path;
    public $original_size;
    public $optimized_size;
    public $compression_ratio;
    public $saved_bytes;
    public $original_format;
    public $optimized_format;
    public $original_width;
    public $original_height;
    public $optimized_width;
    public $optimized_height;
    public $quality_used;
    public $compression_type;
    public $operation_type;
    public $processing_time;
    public $download_count;
    public $status;
    public $metadata;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Create new history record
     */
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  SET user_id = ?,
                      original_name = ?,
                      original_path = ?,
                      optimized_name = ?,
                      optimized_path = ?,
                      original_size = ?,
                      optimized_size = ?,
                      compression_ratio = ?,
                      saved_bytes = ?,
                      original_format = ?,
                      optimized_format = ?,
                      original_width = ?,
                      original_height = ?,
                      optimized_width = ?,
                      optimized_height = ?,
                      quality_used = ?,
                      compression_type = ?,
                      operation_type = ?,
                      processing_time = ?,
                      status = ?,
                      metadata = ?,
                      ip_address = ?,
                      user_agent = ?";
        
        $stmt = $this->conn->prepare($query);
        
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $stmt->bind_param(
            'issssiidsissiiiiissssss',
            $this->user_id,
            $this->original_name,
            $this->original_path,
            $this->optimized_name,
            $this->optimized_path,
            $this->original_size,
            $this->optimized_size,
            $this->compression_ratio,
            $this->saved_bytes,
            $this->original_format,
            $this->optimized_format,
            $this->original_width,
            $this->original_height,
            $this->optimized_width,
            $this->optimized_height,
            $this->quality_used,
            $this->compression_type,
            $this->operation_type,
            $this->processing_time,
            $this->status,
            $this->metadata,
            $ip_address,
            $user_agent
        );
        
        if ($stmt->execute()) {
            $this->id = $this->conn->insert_id;
            $stmt->close();
            return true;
        }
        
        $stmt->close();
        return false;
    }
    
    /**
     * Get history by ID
     */
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        
        $stmt->close();
        return $data;
    }
    
    /**
     * Get all history for user
     */
    public function getByUser($user_id, $limit = 50, $offset = 0) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('iii', $user_id, $limit, $offset);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        
        $stmt->close();
        return $data;
    }
    
    /**
     * Get recent activity
     */
    public function getRecentActivity($user_id, $limit = 10) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $user_id, $limit);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        
        $stmt->close();
        return $data;
    }
    
    /**
     * Increment download count
     */
    public function incrementDownloadCount($id) {
        $query = "UPDATE " . $this->table . " 
                  SET download_count = download_count + 1 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id);
        
        $result = $stmt->execute();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Delete history record
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $id);
        
        $result = $stmt->execute();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Bulk delete
     */
    public function bulkDelete($ids) {
        if (empty($ids)) return false;
        
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $query = "DELETE FROM " . $this->table . " WHERE id IN ($placeholders)";
        
        $stmt = $this->conn->prepare($query);
        
        $types = str_repeat('i', count($ids));
        $stmt->bind_param($types, ...$ids);
        
        $result = $stmt->execute();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Get statistics for user
     */
    public function getStatistics($user_id) {
        $query = "SELECT 
                    COUNT(*) as total_images,
                    COALESCE(SUM(saved_bytes), 0) as total_storage_saved,
                    COALESCE(SUM(download_count), 0) as total_downloads,
                    COALESCE(AVG(compression_ratio), 0) as avg_compression,
                    COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_optimizations
                  FROM " . $this->table . " 
                  WHERE user_id = ? AND status = 'completed'";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        
        $stmt->close();
        return $data;
    }
    
    /**
     * Update statistics table
     */
    public function updateStatistics($user_id) {
        $stats = $this->getStatistics($user_id);
        
        $query = "INSERT INTO image_optimizer_stats 
                  (user_id, date, total_images_processed, total_storage_saved, 
                   total_downloads, avg_compression_ratio)
                  VALUES (?, CURDATE(), ?, ?, ?, ?)
                  ON DUPLICATE KEY UPDATE
                  total_images_processed = VALUES(total_images_processed),
                  total_storage_saved = VALUES(total_storage_saved),
                  total_downloads = VALUES(total_downloads),
                  avg_compression_ratio = VALUES(avg_compression_ratio)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            'iiiid',
            $user_id,
            $stats['total_images'],
            $stats['total_storage_saved'],
            $stats['total_downloads'],
            $stats['avg_compression']
        );
        
        $result = $stmt->execute();
        $stmt->close();
        
        return $result;
    }
    
    /**
     * Search history
     */
    public function search($user_id, $searchTerm, $limit = 50) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  AND (original_name LIKE ? OR optimized_name LIKE ?)
                  ORDER BY created_at DESC 
                  LIMIT ?";
        
        $stmt = $this->conn->prepare($query);
        $searchParam = '%' . $searchTerm . '%';
        $stmt->bind_param('issi', $user_id, $searchParam, $searchParam, $limit);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        
        $stmt->close();
        return $data;
    }
    
    /**
     * Get total storage used
     */
    public function getTotalStorageUsed($user_id) {
        $query = "SELECT COALESCE(SUM(optimized_size), 0) as total_storage 
                  FROM " . $this->table . " 
                  WHERE user_id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        
        $stmt->close();
        return $data['total_storage'] ?? 0;
    }
    
    /**
     * Clear old history (older than X days)
     */
    public function clearOldHistory($user_id, $days = 30) {
        $query = "DELETE FROM " . $this->table . " 
                  WHERE user_id = ? 
                  AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param('ii', $user_id, $days);
        
        $result = $stmt->execute();
        $stmt->close();
        
        return $result;
    }
}
