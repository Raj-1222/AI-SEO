<?php
class SeoIssue {
    private $conn;
    private $table = 'seo_issues';
    
    public $id;
    public $website_id;
    public $category;
    public $issue_type;
    public $status;
    public $severity;
    public $message;
    public $recommendation;
    public $priority;
    public $details;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create SEO issue
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (website_id, category, issue_type, status, severity, message, recommendation, priority, details) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bind_param(
            "issssssss",
            $this->website_id,
            $this->category,
            $this->issue_type,
            $this->status,
            $this->severity,
            $this->message,
            $this->recommendation,
            $this->priority,
            $this->details
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Get issues by website
    public function getByWebsite($website_id, $limit = 100) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE website_id = ? 
                  ORDER BY priority DESC, severity DESC, created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $website_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get issues by category
    public function getByCategory($website_id, $category) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE website_id = ? AND category = ? 
                  ORDER BY priority DESC, severity DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $website_id, $category);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get issues by severity
    public function getBySeverity($website_id, $severity) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE website_id = ? AND severity = ? 
                  ORDER BY priority DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $website_id, $severity);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get summary statistics
    public function getStats($website_id) {
        $query = "SELECT 
                    COUNT(*) as total_issues,
                    SUM(CASE WHEN status = 'pass' THEN 1 ELSE 0 END) as passed,
                    SUM(CASE WHEN status = 'warning' THEN 1 ELSE 0 END) as warnings,
                    SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors,
                    SUM(CASE WHEN severity = 'critical' THEN 1 ELSE 0 END) as critical,
                    SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high,
                    SUM(CASE WHEN severity = 'medium' THEN 1 ELSE 0 END) as medium,
                    SUM(CASE WHEN severity = 'low' THEN 1 ELSE 0 END) as low
                  FROM " . $this->table . " 
                  WHERE website_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $website_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Delete issues by website
    public function deleteByWebsite($website_id) {
        $query = "DELETE FROM " . $this->table . " WHERE website_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $website_id);
        return $stmt->execute();
    }
    
    // Batch create issues
    public function batchCreate($issues) {
        $success_count = 0;
        foreach ($issues as $issue) {
            $this->website_id = $issue['website_id'];
            $this->category = $issue['category'];
            $this->issue_type = $issue['issue_type'];
            $this->status = $issue['status'];
            $this->severity = $issue['severity'];
            $this->message = $issue['message'];
            $this->recommendation = $issue['recommendation'];
            $this->priority = $issue['priority'];
            $this->details = isset($issue['details']) ? $issue['details'] : null;
            
            if ($this->create()) {
                $success_count++;
            }
        }
        return $success_count;
    }
}
