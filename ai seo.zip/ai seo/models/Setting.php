<?php
class Setting {
    private $conn;
    private $table = 'settings';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Get setting by key
    public function get($key) {
        $query = "SELECT setting_value, setting_type FROM " . $this->table . " WHERE setting_key = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $this->castValue($row['setting_value'], $row['setting_type']);
        }
        return null;
    }
    
    // Set setting value
    public function set($key, $value, $type = 'text') {
        $query = "INSERT INTO " . $this->table . " (setting_key, setting_value, setting_type) 
                  VALUES (?, ?, ?) 
                  ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = CURRENT_TIMESTAMP";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssss", $key, $value, $type, $value);
        return $stmt->execute();
    }
    
    // Get all settings
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY setting_key";
        $result = $this->conn->query($query);
        $settings = [];
        
        while ($row = $result->fetch_assoc()) {
            $settings[$row['setting_key']] = [
                'value' => $this->castValue($row['setting_value'], $row['setting_type']),
                'type' => $row['setting_type'],
                'description' => $row['description']
            ];
        }
        
        return $settings;
    }
    
    // Get settings by prefix
    public function getByPrefix($prefix) {
        $query = "SELECT * FROM " . $this->table . " WHERE setting_key LIKE ? ORDER BY setting_key";
        $pattern = $prefix . '%';
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $pattern);
        $stmt->execute();
        $result = $stmt->get_result();
        $settings = [];
        
        while ($row = $result->fetch_assoc()) {
            $settings[$row['setting_key']] = $this->castValue($row['setting_value'], $row['setting_type']);
        }
        
        return $settings;
    }
    
    // Cast value based on type
    private function castValue($value, $type) {
        switch ($type) {
            case 'boolean':
                return (bool)$value;
            case 'number':
                return is_numeric($value) ? (int)$value : 0;
            case 'json':
                return json_decode($value, true);
            default:
                return $value;
        }
    }
    
    // Batch update settings
    public function batchUpdate($settings) {
        $success = 0;
        foreach ($settings as $key => $value) {
            if ($this->set($key, $value)) {
                $success++;
            }
        }
        return $success;
    }
}
