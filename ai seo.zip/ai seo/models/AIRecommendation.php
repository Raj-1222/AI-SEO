<?php
class AIRecommendation {
    private $conn;
    private $table = 'ai_recommendations';
    
    public $id;
    public $website_id;
    public $summary;
    public $top_problems;
    public $business_impact;
    public $priority_actions;
    public $solutions;
    public $estimated_improvements;
    public $raw_response;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create recommendation
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (website_id, summary, top_problems, business_impact, priority_actions, solutions, estimated_improvements, raw_response) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bind_param(
            "isssssss",
            $this->website_id,
            $this->summary,
            $this->top_problems,
            $this->business_impact,
            $this->priority_actions,
            $this->solutions,
            $this->estimated_improvements,
            $this->raw_response
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Get recommendation by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Get recommendations by website
    public function getByWebsite($website_id, $limit = 10) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE website_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $website_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get all recommendations
    public function getAll($limit = 50) {
        $query = "SELECT ar.*, w.url, w.title 
                  FROM " . $this->table . " ar
                  LEFT JOIN websites w ON ar.website_id = w.id
                  ORDER BY ar.created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Delete old recommendations
    public function deleteOld($days = 30) {
        $query = "DELETE FROM " . $this->table . " 
                  WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $days);
        return $stmt->execute();
    }
    
    // Get statistics
    public function getStats() {
        $query = "SELECT 
                    COUNT(*) as total_recommendations,
                    COUNT(DISTINCT website_id) as unique_websites,
                    DATE(created_at) as date,
                    COUNT(*) as daily_count
                  FROM " . $this->table . "
                  GROUP BY DATE(created_at)
                  ORDER BY date DESC
                  LIMIT 7";
        $result = $this->conn->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
