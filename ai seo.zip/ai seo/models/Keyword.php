<?php
class Keyword {
    private $conn;
    private $table = 'keywords';
    
    public $id;
    public $user_id;
    public $website_url;
    public $industry;
    public $location;
    public $primary_keywords;
    public $secondary_keywords;
    public $long_tail_keywords;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create keyword entry
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (user_id, website_url, industry, location, primary_keywords, secondary_keywords, long_tail_keywords) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            "issssss",
            $this->user_id,
            $this->website_url,
            $this->industry,
            $this->location,
            $this->primary_keywords,
            $this->secondary_keywords,
            $this->long_tail_keywords
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Get by user
    public function getByUser($user_id, $limit = 20) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $user_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Delete
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
