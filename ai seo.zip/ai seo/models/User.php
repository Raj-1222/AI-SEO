<?php
class User {
    private $conn;
    private $table = 'users';
    
    public $id;
    public $name;
    public $email;
    public $password;
    public $role;
    public $created_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Register new user
    public function register() {
        $query = "INSERT INTO " . $this->table . " (name, email, password, role) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        
        // Hash password
        $hashed_password = password_hash($this->password, PASSWORD_DEFAULT);
        
        $stmt->bind_param("ssss", $this->name, $this->email, $hashed_password, $this->role);
        
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
    
    // Login user
    public function login($email, $password, $remember = false) {
        $query = "SELECT id, name, email, password, role FROM " . $this->table . " WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            if (password_verify($password, $row['password'])) {
                // Set session
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $row['name'];
                $_SESSION['user_email'] = $row['email'];
                $_SESSION['user_role'] = $row['role'];
                $_SESSION['last_activity'] = time();
                
                // Handle remember me
                if ($remember) {
                    $token = bin2hex(random_bytes(32));
                    $this->setRememberToken($row['id'], $token);
                    setcookie('remember_token', $token, time() + (86400 * 30), "/"); // 30 days
                    setcookie('user_id', $row['id'], time() + (86400 * 30), "/");
                }
                
                return true;
            }
        }
        return false;
    }
    
    // Set remember token
    private function setRememberToken($user_id, $token) {
        $hashed_token = hash('sha256', $token);
        $query = "UPDATE " . $this->table . " SET remember_token = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("si", $hashed_token, $user_id);
        return $stmt->execute();
    }
    
    // Check remember token
    public function checkRememberToken($user_id, $token) {
        $hashed_token = hash('sha256', $token);
        $query = "SELECT id, name, email, role FROM " . $this->table . " WHERE id = ? AND remember_token = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $user_id, $hashed_token);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['user_role'] = $row['role'];
            $_SESSION['last_activity'] = time();
            return true;
        }
        return false;
    }
    
    // Check if email exists
    public function emailExists($email) {
        $query = "SELECT id FROM " . $this->table . " WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    // Get user by ID
    public function getUserById($id) {
        $query = "SELECT id, name, email, role, created_at FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Update user profile
    public function updateProfile($id, $name, $email) {
        $query = "UPDATE " . $this->table . " SET name = ?, email = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssi", $name, $email, $id);
        return $stmt->execute();
    }
    
    // Update password
    public function updatePassword($id, $new_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $query = "UPDATE " . $this->table . " SET password = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("si", $hashed_password, $id);
        return $stmt->execute();
    }
    
    // Create password reset token
    public function createPasswordResetToken($email) {
        $token = bin2hex(random_bytes(32));
        $query = "INSERT INTO password_resets (email, token) VALUES (?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $email, $token);
        
        if ($stmt->execute()) {
            return $token;
        }
        return false;
    }
    
    // Verify password reset token
    public function verifyResetToken($email, $token) {
        $query = "SELECT * FROM password_resets WHERE email = ? AND token = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    // Reset password
    public function resetPassword($email, $token, $new_password) {
        if ($this->verifyResetToken($email, $token)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $query = "UPDATE " . $this->table . " SET password = ? WHERE email = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("ss", $hashed_password, $email);
            
            if ($stmt->execute()) {
                // Delete used token
                $delete_query = "DELETE FROM password_resets WHERE email = ? AND token = ?";
                $delete_stmt = $this->conn->prepare($delete_query);
                $delete_stmt->bind_param("ss", $email, $token);
                $delete_stmt->execute();
                return true;
            }
        }
        return false;
    }
    
    // Logout
    public function logout() {
        // Clear remember me cookies
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, "/");
            setcookie('user_id', '', time() - 3600, "/");
        }
        
        // Clear remember token from database
        if (isset($_SESSION['user_id'])) {
            $query = "UPDATE " . $this->table . " SET remember_token = NULL WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
        }
        
        // Destroy session
        session_unset();
        session_destroy();
    }
}
