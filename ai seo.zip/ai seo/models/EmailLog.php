<?php
class EmailLog {
    private $conn;
    private $table = 'email_logs';
    
    public $id;
    public $user_id;
    public $recipient_email;
    public $report_id;
    public $status;
    public $error_message;
    public $sent_at;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create email log
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (user_id, recipient_email, report_id, status, error_message) 
                  VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            "isiss",
            $this->user_id,
            $this->recipient_email,
            $this->report_id,
            $this->status,
            $this->error_message
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Update status
    public function updateStatus($id, $status, $errorMessage = null) {
        $query = "UPDATE " . $this->table . " 
                  SET status = ?, error_message = ?, sent_at = NOW() 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssi", $status, $errorMessage, $id);
        return $stmt->execute();
    }
    
    // Get by user
    public function getByUser($userId, $limit = 50) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get statistics
    public function getStatistics($userId) {
        $query = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
                  FROM " . $this->table . " 
                  WHERE user_id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}
