<?php
class MetaTag {
    private $conn;
    private $table = 'meta_tags';
    
    public $id;
    public $user_id;
    public $focus_keyword;
    public $seo_title;
    public $meta_description;
    public $og_title;
    public $og_description;
    public $og_image;
    public $twitter_title;
    public $twitter_description;
    public $twitter_image;
    public $seo_score;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (user_id, focus_keyword, seo_title, meta_description, og_title, og_description, og_image, twitter_title, twitter_description, twitter_image, seo_score) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            "isssssssssi",
            $this->user_id,
            $this->focus_keyword,
            $this->seo_title,
            $this->meta_description,
            $this->og_title,
            $this->og_description,
            $this->og_image,
            $this->twitter_title,
            $this->twitter_description,
            $this->twitter_image,
            $this->seo_score
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Get by user
    public function getByUser($user_id, $limit = 20) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $user_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Delete
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
