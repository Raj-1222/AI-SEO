<?php
class N8nWebhookLog {
    private $conn;
    private $table = 'n8n_webhook_logs';
    
    public $id;
    public $website_id;
    public $webhook_url;
    public $request_data;
    public $response_data;
    public $status;
    public $status_code;
    public $error_message;
    public $retry_count;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create log entry
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (website_id, webhook_url, request_data, response_data, status, status_code, error_message, retry_count) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bind_param(
            "issssssi",
            $this->website_id,
            $this->webhook_url,
            $this->request_data,
            $this->response_data,
            $this->status,
            $this->status_code,
            $this->error_message,
            $this->retry_count
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Update log entry
    public function update() {
        $query = "UPDATE " . $this->table . " 
                  SET response_data = ?, status = ?, status_code = ?, error_message = ?, retry_count = ?
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("sssii", $this->response_data, $this->status, $this->status_code, $this->error_message, $this->retry_count, $this->id);
        
        return $stmt->execute();
    }
    
    // Get log by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Get logs by website
    public function getByWebsite($website_id, $limit = 10) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE website_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $website_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get failed logs for retry
    public function getFailedForRetry($maxRetries = 3) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE status = 'failed' AND retry_count < ? 
                  ORDER BY created_at ASC 
                  LIMIT 10";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $maxRetries);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get statistics
    public function getStats() {
        $query = "SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                    AVG(retry_count) as avg_retries
                  FROM " . $this->table;
        $result = $this->conn->query($query);
        return $result->fetch_assoc();
    }
}
