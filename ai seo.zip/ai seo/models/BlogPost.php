<?php
class BlogPost {
    private $conn;
    private $table = 'blog_posts';
    
    public $id;
    public $user_id;
    public $keyword;
    public $word_count;
    public $language;
    public $tone;
    public $title;
    public $outline;
    public $introduction;
    public $content;
    public $faq;
    public $call_to_action;
    public $seo_score;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (user_id, keyword, word_count, language, tone, title, outline, introduction, content, faq, call_to_action, seo_score) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            "isisssssssi",
            $this->user_id,
            $this->keyword,
            $this->word_count,
            $this->language,
            $this->tone,
            $this->title,
            $this->outline,
            $this->introduction,
            $this->content,
            $this->faq,
            $this->call_to_action,
            $this->seo_score
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Get by user
    public function getByUser($user_id, $limit = 20) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $user_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Delete
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
    
    // Update
    public function update() {
        $query = "UPDATE " . $this->table . " 
                  SET title = ?, content = ?, seo_score = ? 
                  WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssii", $this->title, $this->content, $this->seo_score, $this->id);
        return $stmt->execute();
    }
}
