<?php
class Website {
    private $conn;
    private $table = 'websites';
    
    public $id;
    public $user_id;
    public $url;
    public $title;
    public $description;
    public $meta_keywords;
    public $language;
    public $ssl_enabled;
    public $cms_detected;
    public $server_info;
    public $country;
    public $ip_address;
    public $response_time;
    public $seo_score;
    public $status;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create website audit entry
    public function create() {
        $query = "INSERT INTO " . $this->table . " 
                  (user_id, url, title, description, meta_keywords, language, ssl_enabled, 
                   cms_detected, server_info, country, ip_address, response_time, seo_score, status) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bind_param(
            "isssssississis",
            $this->user_id,
            $this->url,
            $this->title,
            $this->description,
            $this->meta_keywords,
            $this->language,
            $this->ssl_enabled,
            $this->cms_detected,
            $this->server_info,
            $this->country,
            $this->ip_address,
            $this->response_time,
            $this->seo_score,
            $this->status
        );
        
        if ($stmt->execute()) {
            $this->id = $stmt->insert_id;
            return true;
        }
        return false;
    }
    
    // Get website by ID
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    // Get all websites by user
    public function getByUser($user_id, $limit = 10, $offset = 0) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ? OFFSET ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $user_id, $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Update website details
    public function update() {
        $query = "UPDATE " . $this->table . " 
                  SET title = ?, description = ?, meta_keywords = ?, language = ?, 
                      ssl_enabled = ?, cms_detected = ?, server_info = ?, country = ?, 
                      ip_address = ?, response_time = ?, seo_score = ?, status = ? 
                  WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bind_param(
            "ssssisssiissi",
            $this->title,
            $this->description,
            $this->meta_keywords,
            $this->language,
            $this->ssl_enabled,
            $this->cms_detected,
            $this->server_info,
            $this->country,
            $this->ip_address,
            $this->response_time,
            $this->seo_score,
            $this->status,
            $this->id
        );
        
        return $stmt->execute();
    }
    
    // Delete website
    public function delete($id) {
        $query = "DELETE FROM " . $this->table . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
    
    // Check if URL already audited by user
    public function urlExists($user_id, $url) {
        $query = "SELECT id FROM " . $this->table . " WHERE user_id = ? AND url = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $user_id, $url);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }
    
    // Get existing audit ID for URL
    public function getAuditIdByUrl($user_id, $url) {
        $query = "SELECT id FROM " . $this->table . " WHERE user_id = ? AND url = ? LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $user_id, $url);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row ? $row['id'] : null;
    }
    
    // Get recent audits
    public function getRecent($user_id, $limit = 5) {
        $query = "SELECT * FROM " . $this->table . " 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $user_id, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Get statistics
    public function getStats($user_id) {
        $query = "SELECT 
                    COUNT(*) as total_audits,
                    AVG(seo_score) as avg_score,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN ssl_enabled = 1 THEN 1 ELSE 0 END) as ssl_sites
                  FROM " . $this->table . " 
                  WHERE user_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}
