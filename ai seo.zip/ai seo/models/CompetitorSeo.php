<?php
class CompetitorSeo {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // ==================== COMPETITOR MANAGEMENT ====================
    
    /**
     * Get or create competitor record
     */
    public function getOrCreateCompetitor($userId, $competitorDomain, $primaryDomain = null) {
        // Check if competitor exists
        $query = "SELECT id FROM competitors 
                  WHERE user_id = ? AND competitor_domain = ? 
                  LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $userId, $competitorDomain);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return $row['id'];
        }
        
        // Create new competitor record
        $query = "INSERT INTO competitors (user_id, primary_domain, competitor_domain, status) 
                  VALUES (?, ?, ?, 'active')";
        $stmt = $this->conn->prepare($query);
        $primaryDomain = $primaryDomain ?? $competitorDomain;
        $stmt->bind_param("iss", $userId, $primaryDomain, $competitorDomain);
        $stmt->execute();
        
        return $stmt->insert_id;
    }
    
    /**
     * Get all competitors for user
     */
    public function getCompetitorsByUser($userId, $limit = 50) {
        $query = "SELECT * FROM competitors 
                  WHERE user_id = ? AND status = 'active' 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Update competitor info
     */
    public function updateCompetitor($competitorId, $data) {
        $query = "UPDATE competitors 
                  SET competitor_name = ?, industry = ?, discovery_method = ?, updated_at = NOW() 
                  WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("sssi", 
            $data['competitor_name'], 
            $data['industry'], 
            $data['discovery_method'], 
            $competitorId
        );
        return $stmt->execute();
    }
    
    // ==================== KEYWORD ANALYSIS ====================
    
    /**
     * Save competitor keyword
     */
    public function saveCompetitorKeyword($competitorId, $keywordData) {
        $query = "INSERT INTO competitor_keywords 
                  (competitor_id, keyword, search_volume, keyword_difficulty, cpc_value, 
                   position, url, traffic_estimate, competition, trend) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                  ON DUPLICATE KEY UPDATE 
                  search_volume = VALUES(search_volume),
                  position = VALUES(position),
                  traffic_estimate = VALUES(traffic_estimate),
                  updated_at = NOW()";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isiidisiss",
            $competitorId,
            $keywordData['keyword'],
            $keywordData['search_volume'],
            $keywordData['keyword_difficulty'],
            $keywordData['cpc_value'],
            $keywordData['position'],
            $keywordData['url'] ?? null,
            $keywordData['traffic_estimate'],
            $keywordData['competition'],
            $keywordData['trend']
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get competitor keywords
     */
    public function getCompetitorKeywords($competitorId, $limit = 100) {
        $query = "SELECT * FROM competitor_keywords 
                  WHERE competitor_id = ? 
                  ORDER BY search_volume DESC, position ASC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $competitorId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== KEYWORD GAP ANALYSIS ====================
    
    /**
     * Save keyword gap
     */
    public function saveKeywordGap($userId, $primaryDomain, $gapData) {
        $query = "INSERT INTO keyword_gap_analysis 
                  (user_id, primary_domain, competitor_domain, keyword, gap_type, 
                   search_volume, competitor_position, our_position, keyword_difficulty, 
                   opportunity_score, priority) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                  ON DUPLICATE KEY UPDATE 
                  search_volume = VALUES(search_volume),
                  competitor_position = VALUES(competitor_position),
                  our_position = VALUES(our_position),
                  opportunity_score = VALUES(opportunity_score)";
        
        $stmt = $this->conn->prepare($query);
        
        $priority = $this->determinePriority($gapData['opportunity_score']);
        
        $stmt->bind_param("issssiiiis",
            $userId,
            $primaryDomain,
            $gapData['competitor_domain'],
            $gapData['keyword'],
            $gapData['gap_type'],
            $gapData['search_volume'],
            $gapData['competitor_position'],
            $gapData['our_position'],
            $gapData['keyword_difficulty'] ?? 0,
            $gapData['opportunity_score'],
            $priority
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get keyword gaps
     */
    public function getKeywordGaps($userId, $primaryDomain, $limit = 100) {
        $query = "SELECT * FROM keyword_gap_analysis 
                  WHERE user_id = ? AND primary_domain = ? 
                  ORDER BY opportunity_score DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isi", $userId, $primaryDomain, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== CONTENT GAP ANALYSIS ====================
    
    /**
     * Save content gap
     */
    public function saveContentGap($userId, $primaryDomain, $gapData) {
        $query = "INSERT INTO content_gap_analysis 
                  (user_id, primary_domain, competitor_domain, topic, keyword_cluster, 
                   competitor_urls, our_coverage, content_quality_gap, opportunity_score, 
                   recommended_action, priority) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        $keywordCluster = is_array($gapData['keyword_cluster']) ? json_encode($gapData['keyword_cluster']) : $gapData['keyword_cluster'];
        $competitorUrls = is_array($gapData['competitor_urls']) ? json_encode($gapData['competitor_urls']) : $gapData['competitor_urls'];
        $priority = $gapData['priority'] ?? 'medium';
        
        $stmt->bind_param("issssssssss",
            $userId,
            $primaryDomain,
            $gapData['competitor_domain'],
            $gapData['topic'],
            $keywordCluster,
            $competitorUrls,
            'none',
            0,
            $gapData['estimated_traffic'],
            '',
            $priority
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get content gaps
     */
    public function getContentGaps($userId, $primaryDomain, $limit = 50) {
        $query = "SELECT * FROM content_gap_analysis 
                  WHERE user_id = ? AND primary_domain = ? 
                  ORDER BY opportunity_score DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isi", $userId, $primaryDomain, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== BACKLINKS ANALYSIS ====================
    
    /**
     * Save competitor backlink
     */
    public function saveCompetitorBacklink($competitorId, $backlinkData) {
        $query = "INSERT INTO competitor_backlinks 
                  (competitor_id, source_url, target_url, anchor_text, domain_authority, 
                   page_authority, link_type, first_seen, last_checked, status, spam_score) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?)
                  ON DUPLICATE KEY UPDATE 
                  last_checked = CURDATE(),
                  status = VALUES(status),
                  domain_authority = VALUES(domain_authority),
                  page_authority = VALUES(page_authority)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isssiisssi",
            $competitorId,
            $backlinkData['source_url'],
            $backlinkData['target_url'],
            $backlinkData['anchor_text'],
            $backlinkData['domain_authority'],
            $backlinkData['page_authority'],
            $backlinkData['link_type'],
            $backlinkData['first_seen'],
            $backlinkData['status'],
            $backlinkData['spam_score']
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get competitor backlinks
     */
    public function getCompetitorBacklinks($competitorId, $limit = 100) {
        $query = "SELECT * FROM competitor_backlinks 
                  WHERE competitor_id = ? AND status = 'active' 
                  ORDER BY domain_authority DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $competitorId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== TOP PAGES ====================
    
    /**
     * Save competitor top page
     */
    public function saveCompetitorTopPage($competitorId, $pageData) {
        $query = "INSERT INTO competitor_top_pages 
                  (competitor_id, url, title, estimated_traffic, ranking_keywords, 
                   backlinks_count, social_shares, page_authority, content_type, last_updated) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE())
                  ON DUPLICATE KEY UPDATE 
                  estimated_traffic = VALUES(estimated_traffic),
                  ranking_keywords = VALUES(ranking_keywords),
                  backlinks_count = VALUES(backlinks_count),
                  social_shares = VALUES(social_shares),
                  last_updated = CURDATE()";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("issiiiiis",
            $competitorId,
            $pageData['url'],
            $pageData['title'],
            $pageData['estimated_traffic'],
            $pageData['ranking_keywords'],
            $pageData['backlinks_count'],
            $pageData['social_shares'],
            $pageData['page_authority'],
            $pageData['content_type']
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get competitor top pages
     */
    public function getCompetitorTopPages($competitorId, $limit = 20) {
        $query = "SELECT * FROM competitor_top_pages 
                  WHERE competitor_id = ? 
                  ORDER BY estimated_traffic DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $competitorId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== TRAFFIC ESTIMATES ====================
    
    /**
     * Save traffic estimate
     */
    public function saveTrafficEstimate($competitorId, $trafficData) {
        $query = "INSERT INTO competitor_traffic 
                  (competitor_id, month_year, organic_traffic, paid_traffic, direct_traffic, 
                   referral_traffic, social_traffic, total_traffic, bounce_rate, 
                   avg_session_duration, pages_per_session) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                  ON DUPLICATE KEY UPDATE 
                  organic_traffic = VALUES(organic_traffic),
                  paid_traffic = VALUES(paid_traffic),
                  total_traffic = VALUES(total_traffic),
                  bounce_rate = VALUES(bounce_rate)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isiiiiiidid",
            $competitorId,
            $trafficData['month_year'],
            $trafficData['organic_traffic'],
            $trafficData['paid_traffic'],
            $trafficData['direct_traffic'],
            $trafficData['referral_traffic'],
            $trafficData['social_traffic'],
            $trafficData['total_traffic'],
            $trafficData['bounce_rate'],
            $trafficData['avg_session_duration'],
            $trafficData['pages_per_session']
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get traffic estimates
     */
    public function getTrafficEstimates($competitorId, $months = 6) {
        $query = "SELECT * FROM competitor_traffic 
                  WHERE competitor_id = ? 
                  ORDER BY month_year DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $competitorId, $months);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== SERP COMPARISON ====================
    
    /**
     * Save SERP comparison
     */
    public function saveSERPComparison($userId, $keyword, $primaryDomain, $serpData) {
        foreach ($serpData['positions'] as $domain => $positionData) {
            if ($domain === $primaryDomain) {
                $primaryPosition = $positionData['position'];
                $primaryUrl = $positionData['url'];
            } else {
                $query = "INSERT INTO serp_comparison 
                          (user_id, keyword, location, primary_domain, primary_position, primary_url, 
                           competitor_domain, competitor_position, competitor_url, search_volume) 
                          VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?)";
                
                $stmt = $this->conn->prepare($query);
                $stmt->bind_param("issisisi",
                    $userId,
                    $keyword,
                    $primaryDomain,
                    $primaryPosition ?? 0,
                    $primaryUrl ?? '',
                    $domain,
                    $positionData['position'],
                    $positionData['url'],
                    $serpData['search_volume']
                );
                $stmt->execute();
            }
        }
        
        return true;
    }
    
    /**
     * Get SERP comparisons
     */
    public function getSERPComparisons($userId, $keyword = null, $limit = 50) {
        if ($keyword) {
            $query = "SELECT * FROM serp_comparison 
                      WHERE user_id = ? AND keyword = ? 
                      ORDER BY created_at DESC 
                      LIMIT ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("isi", $userId, $keyword, $limit);
        } else {
            $query = "SELECT * FROM serp_comparison 
                      WHERE user_id = ? 
                      ORDER BY created_at DESC 
                      LIMIT ?";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("ii", $userId, $limit);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== META ANALYSIS ====================
    
    /**
     * Save competitor meta analysis
     */
    public function saveCompetitorMeta($competitorId, $metaData) {
        $query = "INSERT INTO competitor_meta_analysis 
                  (competitor_id, url, title, title_length, meta_description, description_length, 
                   h1_tag, canonical_url, robots_meta, og_tags, twitter_tags, schema_markup, 
                   has_favicon, meta_quality_score) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("issississsssii",
            $competitorId,
            $metaData['url'],
            $metaData['title'],
            $metaData['title_length'],
            $metaData['meta_description'],
            $metaData['description_length'],
            $metaData['h1_tag'],
            $metaData['canonical_url'],
            $metaData['robots_meta'],
            $metaData['og_tags'],
            $metaData['twitter_tags'],
            $metaData['schema_markup'],
            $metaData['has_favicon'],
            $metaData['meta_quality_score']
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get competitor meta analysis
     */
    public function getCompetitorMeta($competitorId, $limit = 20) {
        $query = "SELECT * FROM competitor_meta_analysis 
                  WHERE competitor_id = ? 
                  ORDER BY meta_quality_score DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $competitorId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== CONTENT ANALYSIS ====================
    
    /**
     * Save competitor content
     */
    public function saveCompetitorContent($competitorId, $contentData) {
        $query = "INSERT INTO competitor_content 
                  (competitor_id, url, title, word_count, content_type, publish_date, 
                   keywords_targeted, headings_count, images_count, internal_links, 
                   external_links, readability_score, seo_score, social_shares, estimated_traffic) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isssissiiiiiiii",
            $competitorId,
            $contentData['url'],
            $contentData['title'],
            $contentData['word_count'],
            $contentData['content_type'],
            $contentData['publish_date'],
            $contentData['keywords_targeted'],
            $contentData['headings_count'],
            $contentData['images_count'],
            $contentData['internal_links'],
            $contentData['external_links'],
            $contentData['readability_score'],
            $contentData['seo_score'],
            $contentData['social_shares'],
            $contentData['estimated_traffic']
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get competitor content
     */
    public function getCompetitorContent($competitorId, $limit = 20) {
        $query = "SELECT * FROM competitor_content 
                  WHERE competitor_id = ? 
                  ORDER BY estimated_traffic DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $competitorId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== CHANGE MONITORING ====================
    
    /**
     * Save competitor change
     */
    public function saveCompetitorChange($competitorId, $changeData) {
        $query = "INSERT INTO competitor_change_monitoring 
                  (competitor_id, change_type, change_description, old_value, new_value, 
                   impact_level, url) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("issssss",
            $competitorId,
            $changeData['change_type'],
            $changeData['change_description'],
            $changeData['old_value'] ?? null,
            $changeData['new_value'] ?? null,
            $changeData['impact_level'],
            $changeData['url'] ?? null
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get competitor changes
     */
    public function getCompetitorChanges($competitorId, $days = 30, $limit = 50) {
        $query = "SELECT * FROM competitor_change_monitoring 
                  WHERE competitor_id = ? AND detected_at >= DATE_SUB(NOW(), INTERVAL ? DAY) 
                  ORDER BY detected_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iii", $competitorId, $days, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== REPORTS ====================
    
    /**
     * Save competitor analysis report
     */
    public function saveCompetitorReport($userId, $primaryDomain, $reportData) {
        $query = "INSERT INTO competitor_analysis_reports 
                  (user_id, primary_domain, competitors_analyzed, report_type, summary, 
                   key_findings, opportunities, threats, recommendations, report_data) 
                  VALUES (?, ?, ?, 'comprehensive', ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        
        $competitorsAnalyzed = json_encode(array_keys($reportData['competitors']));
        $reportJson = json_encode($reportData);
        
        $stmt->bind_param("issssssss",
            $userId,
            $primaryDomain,
            $competitorsAnalyzed,
            'Comprehensive competitor analysis completed',
            '',
            '',
            '',
            '',
            $reportJson
        );
        
        return $stmt->execute();
    }
    
    /**
     * Get competitor reports
     */
    public function getCompetitorReports($userId, $limit = 10) {
        $query = "SELECT * FROM competitor_analysis_reports 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // ==================== HELPER METHODS ====================
    
    /**
     * Determine priority based on opportunity score
     */
    private function determinePriority($score) {
        if ($score >= 10000) return 'critical';
        if ($score >= 5000) return 'high';
        if ($score >= 1000) return 'medium';
        return 'low';
    }
    
    /**
     * Get competitor statistics
     */
    public function getCompetitorStats($competitorId) {
        $stats = [];
        
        // Keyword count
        $query = "SELECT COUNT(*) as count FROM competitor_keywords WHERE competitor_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $competitorId);
        $stmt->execute();
        $result = $stmt->get_result();
        $stats['keyword_count'] = $result->fetch_assoc()['count'];
        
        // Backlink count
        $query = "SELECT COUNT(*) as count FROM competitor_backlinks WHERE competitor_id = ? AND status = 'active'";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $competitorId);
        $stmt->execute();
        $result = $stmt->get_result();
        $stats['backlink_count'] = $result->fetch_assoc()['count'];
        
        // Latest traffic
        $query = "SELECT total_traffic FROM competitor_traffic WHERE competitor_id = ? ORDER BY month_year DESC LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $competitorId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stats['latest_traffic'] = $row ? $row['total_traffic'] : 0;
        
        return $stats;
    }
}
