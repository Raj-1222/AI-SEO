<?php
/**
 * Error Log Viewer
 * Shows recent errors from error.log
 */
session_start();

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error Log Viewer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0B1F4D; color: white; padding: 40px 0; }
        .log-card { background: white; color: #333; border-radius: 10px; padding: 20px; margin-bottom: 20px; }
        .log-entry { padding: 10px; margin: 5px 0; border-left: 3px solid #FF6B00; background: #f8f9fa; }
        .log-entry.error { border-left-color: #DC3545; }
        .log-entry.success { border-left-color: #28A745; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; max-height: 400px; overflow-y: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">📋 Error Log Viewer</h1>
        <p class="text-center text-muted">Last 100 lines from error.log</p>
        <hr style="border-color: #FF6B00;">

        <div class="log-card">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>Recent Errors</h4>
                <button class="btn btn-primary" onclick="location.reload()">Refresh</button>
            </div>

            <?php
            $errorLogPath = __DIR__ . '/error.log';
            
            if (file_exists($errorLogPath)) {
                $lines = file($errorLogPath);
                $recentLines = array_slice($lines, -100); // Last 100 lines
                $recentLines = array_reverse($recentLines); // Show newest first
                
                echo '<p class="text-muted">Showing last ' . count($recentLines) . ' lines (newest first)</p>';
                echo '<div style="max-height: 600px; overflow-y: auto;">';
                
                foreach ($recentLines as $line) {
                    $line = trim($line);
                    if (empty($line)) continue;
                    
                    $class = 'log-entry';
                    if (stripos($line, 'error') !== false || stripos($line, 'fail') !== false) {
                        $class .= ' error';
                    } elseif (stripos($line, 'success') !== false || stripos($line, 'Result success=true') !== false) {
                        $class .= ' success';
                    }
                    
                    // Highlight important lines
                    $line = htmlspecialchars($line);
                    $line = str_replace('KEYWORD API:', '<strong style="color: #FF6B00;">KEYWORD API:</strong>', $line);
                    $line = str_replace('OpenAI', '<strong style="color: #0B1F4D;">OpenAI</strong>', $line);
                    
                    echo '<div class="' . $class . '">' . $line . '</div>';
                }
                
                echo '</div>';
            } else {
                echo '<div class="alert alert-warning">';
                echo '<strong>No error log file found!</strong><br>';
                echo 'Log file should be at: ' . $errorLogPath . '<br>';
                echo 'Try making an API call first to generate logs.';
                echo '</div>';
            }
            ?>
        </div>

        <div class="log-card">
            <h4>Test API Call</h4>
            <p>Click button to test API and generate new log entries:</p>
            <button class="btn btn-success" onclick="testAPI()">Test Keyword Generator API</button>
            <div id="test-result" class="mt-3"></div>
        </div>

        <div class="log-card">
            <h4>Session Info</h4>
            <pre><?php print_r($_SESSION); ?></pre>
        </div>
    </div>

    <script>
        function testAPI() {
            const resultDiv = document.getElementById('test-result');
            resultDiv.innerHTML = '<div class="spinner-border"></div> Testing API...';
            
            fetch('../../api/keyword-generator.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    action: 'generate',
                    website_url: 'https://example.com',
                    industry: 'Technology',
                    location: 'USA'
                })
            })
            .then(r => r.text())
            .then(text => {
                console.log('Response:', text);
                resultDiv.innerHTML = '<pre>' + text + '</pre>';
                resultDiv.innerHTML += '<p class="mt-2 text-success">✅ Check error log above for details! <button class="btn btn-sm btn-primary" onclick="location.reload()">Refresh Log</button></p>';
            })
            .catch(e => {
                resultDiv.innerHTML = '<div class="alert alert-danger">Error: ' + e.message + '</div>';
            });
        }
    </script>
</body>
</html>
