# Security Policy

## 🔒 Reporting Security Vulnerabilities

If you discover a security vulnerability within this project, please send an email to security@aurify.com. All security vulnerabilities will be promptly addressed.

**Please do not create public GitHub issues for security vulnerabilities.**

## 🛡️ Security Best Practices

### Before Deployment

1. **Never commit sensitive data:**
   - Database credentials
   - API keys
   - Passwords
   - Secret tokens
   - Email credentials

2. **Always use environment-specific configuration:**
   - Copy `.env.example` to `.env` and fill in your actual credentials
   - Keep `.env` in `.gitignore`
   - Use `config/database.example.php` as template, never commit `config/database.php`

3. **Change default credentials:**
   ```
   Default Admin: admin@aurify.com / admin123
   ⚠️ CHANGE IMMEDIATELY AFTER INSTALLATION!
   ```

### Production Deployment Checklist

- [ ] Change default admin password
- [ ] Update all API keys with production keys
- [ ] Set `DEBUG_MODE` to `false` in config
- [ ] Disable `display_errors` in PHP
- [ ] Enable HTTPS (force SSL)
- [ ] Set proper file permissions (755 for directories, 644 for files)
- [ ] Secure `uploads/` directory (prevent PHP execution)
- [ ] Enable rate limiting on API endpoints
- [ ] Configure proper CORS headers
- [ ] Set up regular database backups
- [ ] Configure security headers (CSP, X-Frame-Options, etc.)
- [ ] Review and restrict database user privileges
- [ ] Enable PHP opcache for performance
- [ ] Configure fail2ban or similar for brute-force protection

### File Permissions (Linux/Unix)

```bash
# Set proper ownership
chown -R www-data:www-data /path/to/project

# Directories
find /path/to/project -type d -exec chmod 755 {} \;

# Files
find /path/to/project -type f -exec chmod 644 {} \;

# Writable directories
chmod 777 /path/to/project/uploads
chmod 777 /path/to/project/logs
chmod 777 /path/to/project/cache

# Sensitive files
chmod 600 /path/to/project/config/database.php
chmod 600 /path/to/project/.env
```

### Apache Configuration

Add to `.htaccess` in `uploads/` directory:

```apache
# Prevent PHP execution in uploads
<FilesMatch "\.(php|php3|php4|php5|phtml)$">
    Order Allow,Deny
    Deny from all
</FilesMatch>
```

### Nginx Configuration

```nginx
# Prevent access to sensitive files
location ~ /\. {
    deny all;
}

location ~ /(config|database|vendor)/ {
    deny all;
}

# Prevent PHP execution in uploads
location ~* ^/uploads/.*\.php$ {
    deny all;
}
```

## 🔐 Environment Variables

Instead of storing sensitive data in PHP files, use environment variables:

```php
// Example: Using environment variables
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('OPENAI_API_KEY', getenv('OPENAI_API_KEY') ?: '');
```

## 🚨 Known Security Considerations

### SQL Injection Prevention
- All database queries use prepared statements with parameter binding
- User input is sanitized before database operations

### XSS Protection
- Output is escaped using `htmlspecialchars()` where appropriate
- Content Security Policy headers recommended

### CSRF Protection
- Session-based CSRF tokens implemented
- All forms validate CSRF tokens

### Password Security
- Passwords hashed using `password_hash()` with bcrypt
- Minimum password length: 6 characters (configurable)
- Password reset tokens expire after 1 hour

### File Upload Security
- File type validation (whitelist approach)
- File size limits enforced
- Uploaded files stored outside web root recommended
- Random filename generation for uploads

### Session Security
- Session fixation protection (session regeneration)
- Session timeout after 1 hour of inactivity
- HTTP-only session cookies
- Secure flag on cookies (HTTPS required)

### API Security
- Rate limiting recommended
- API authentication required
- Input validation on all endpoints
- JSON response validation

## 📊 Security Headers

Add these headers to your web server configuration:

```
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
Content-Security-Policy: default-src 'self'
Referrer-Policy: strict-origin-when-cross-origin
```

## 🔄 Regular Maintenance

1. **Update dependencies regularly:**
   ```bash
   composer update
   npm update
   ```

2. **Monitor logs for suspicious activity:**
   - Check `logs/error.log`
   - Review database audit logs
   - Monitor failed login attempts

3. **Backup strategy:**
   - Daily automated database backups
   - Weekly full system backups
   - Store backups offsite
   - Test restore procedures regularly

4. **Security audits:**
   - Run security scanners periodically
   - Review user permissions
   - Check for outdated dependencies
   - Monitor CVE databases

## 📝 Compliance

This application processes user data. Ensure compliance with:
- GDPR (if serving EU users)
- CCPA (if serving California users)
- Other relevant data protection regulations

Implement:
- Privacy policy
- Terms of service
- Cookie consent
- Data retention policies
- Right to deletion procedures

## 🔗 Resources

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [PHP Security Guide](https://www.php.net/manual/en/security.php)
- [MySQL Security](https://dev.mysql.com/doc/refman/8.0/en/security.html)
- [Let's Encrypt (Free SSL)](https://letsencrypt.org/)

## 📞 Contact

For security concerns, contact: security@aurify.com

---

**Last Updated:** November 2026
