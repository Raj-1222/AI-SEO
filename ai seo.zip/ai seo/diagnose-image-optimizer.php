<?php
/**
 * Complete Diagnostic Script for Image Optimizer
 * This script checks EVERYTHING and provides detailed error information
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html><head>";
echo "<title>Image Optimizer Diagnostics</title>";
echo "<style>
body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
.section { background: white; padding: 20px; margin: 10px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
.success { color: #28a745; }
.error { color: #dc3545; }
.warning { color: #ffc107; }
h2 { border-bottom: 2px solid #007bff; padding-bottom: 10px; }
table { width: 100%; border-collapse: collapse; margin: 10px 0; }
th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
th { background: #007bff; color: white; }
.status { font-weight: bold; padding: 4px 8px; border-radius: 4px; }
.status.ok { background: #d4edda; color: #155724; }
.status.fail { background: #f8d7da; color: #721c24; }
.status.warn { background: #fff3cd; color: #856404; }
pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; }
</style>";
echo "</head><body>";

echo "<h1>🔍 Image Optimizer Complete Diagnostics</h1>";

// ============================================
// 1. CHECK PHP EXTENSIONS
// ============================================
echo "<div class='section'>";
echo "<h2>1. PHP Extensions & Configuration</h2>";
echo "<table>";
echo "<tr><th>Check</th><th>Status</th><th>Details</th></tr>";

$phpVersion = phpversion();
$status = version_compare($phpVersion, '7.4.0', '>=') ? 'ok' : 'fail';
echo "<tr><td>PHP Version</td><td><span class='status $status'>$phpVersion</span></td><td>Minimum required: 7.4.0</td></tr>";

$hasGD = extension_loaded('gd');
$gdStatus = $hasGD ? 'ok' : 'fail';
echo "<tr><td>GD Library</td><td><span class='status $gdStatus'>" . ($hasGD ? 'INSTALLED' : 'NOT INSTALLED') . "</span></td><td>" . ($hasGD ? 'Available for image processing' : 'Required for image processing') . "</td></tr>";

$hasImagick = extension_loaded('imagick');
$imagickStatus = $hasImagick ? 'ok' : 'warn';
echo "<tr><td>Imagick</td><td><span class='status $imagickStatus'>" . ($hasImagick ? 'INSTALLED' : 'NOT INSTALLED') . "</span></td><td>" . ($hasImagick ? 'Available for advanced processing' : 'Optional, GD will be used') . "</td></tr>";

$hasMySQLi = extension_loaded('mysqli');
$mysqliStatus = $hasMySQLi ? 'ok' : 'fail';
echo "<tr><td>MySQLi</td><td><span class='status $mysqliStatus'>" . ($hasMySQLi ? 'INSTALLED' : 'NOT INSTALLED') . "</span></td><td>Required for database operations</td></tr>";

$hasFileInfo = extension_loaded('fileinfo');
$fileinfoStatus = $hasFileInfo ? 'ok' : 'fail';
echo "<tr><td>FileInfo</td><td><span class='status $fileinfoStatus'>" . ($hasFileInfo ? 'INSTALLED' : 'NOT INSTALLED') . "</span></td><td>Required for MIME type detection</td></tr>";

$memoryLimit = ini_get('memory_limit');
echo "<tr><td>Memory Limit</td><td><span class='status ok'>$memoryLimit</span></td><td>Recommended: 256M or higher</td></tr>";

$maxExecution = ini_get('max_execution_time');
echo "<tr><td>Max Execution Time</td><td><span class='status ok'>{$maxExecution}s</span></td><td>Recommended: 300s or higher</td></tr>";

$uploadMaxSize = ini_get('upload_max_filesize');
echo "<tr><td>Upload Max Filesize</td><td><span class='status ok'>$uploadMaxSize</span></td><td>PHP upload limit</td></tr>";

$postMaxSize = ini_get('post_max_size');
echo "<tr><td>Post Max Size</td><td><span class='status ok'>$postMaxSize</span></td><td>PHP post limit</td></tr>";

echo "</table>";
echo "</div>";

// ============================================
// 2. CHECK DATABASE CONNECTION & TABLES
// ============================================
echo "<div class='section'>";
echo "<h2>2. Database Connection & Tables</h2>";

require_once __DIR__ . '/config/database.php';

try {
    $conn = getDBConnection();
    echo "<p class='success'>✓ Database connection successful</p>";
    
    // Check required tables
    $requiredTables = [
        'users',
        'image_processing_history',
        'image_optimizer_stats',
        'image_optimizer_settings',
        'image_batch_queue',
        'watermark_templates',
        'image_resize_presets',
        'image_download_log',
        'image_seo_scores'
    ];
    
    echo "<table>";
    echo "<tr><th>Table Name</th><th>Status</th><th>Row Count</th></tr>";
    
    foreach ($requiredTables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result && $result->num_rows > 0) {
            $countResult = $conn->query("SELECT COUNT(*) as cnt FROM `$table`");
            $count = $countResult ? $countResult->fetch_assoc()['cnt'] : 'N/A';
            echo "<tr><td>$table</td><td><span class='status ok'>EXISTS</span></td><td>$count rows</td></tr>";
        } else {
            echo "<tr><td>$table</td><td><span class='status fail'>MISSING</span></td><td>-</td></tr>";
        }
    }
    
    echo "</table>";
    
    $conn->close();
    
} catch (Exception $e) {
    echo "<p class='error'>✗ Database connection failed: " . $e->getMessage() . "</p>";
    echo "<p><strong>Connection Details:</strong></p>";
    echo "<pre>Host: " . DB_HOST . "\n";
    echo "User: " . DB_USER . "\n";
    echo "Database: " . DB_NAME . "</pre>";
}

echo "</div>";

// ============================================
// 3. CHECK DIRECTORIES & PERMISSIONS
// ============================================
echo "<div class='section'>";
echo "<h2>3. Directory Structure & Permissions</h2>";

require_once __DIR__ . '/config/image_optimizer_config.php';

$directories = [
    'Base Directory' => IMG_BASE_DIR,
    'Upload Directory' => IMG_UPLOAD_DIR,
    'Original Images' => IMG_ORIGINAL_DIR,
    'Optimized Images' => IMG_OPTIMIZED_DIR,
    'Watermarks' => IMG_WATERMARK_DIR,
    'Temp Directory' => IMG_TEMP_DIR,
    'Download Directory' => IMG_DOWNLOAD_DIR
];

echo "<table>";
echo "<tr><th>Directory</th><th>Exists</th><th>Writable</th><th>Path</th></tr>";

foreach ($directories as $name => $path) {
    $exists = file_exists($path);
    $writable = $exists && is_writable($path);
    
    $existsStatus = $exists ? 'ok' : 'fail';
    $writableStatus = $writable ? 'ok' : 'fail';
    
    echo "<tr>";
    echo "<td>$name</td>";
    echo "<td><span class='status $existsStatus'>" . ($exists ? 'YES' : 'NO') . "</span></td>";
    echo "<td><span class='status $writableStatus'>" . ($writable ? 'YES' : 'NO') . "</span></td>";
    echo "<td><small>$path</small></td>";
    echo "</tr>";
}

echo "</table>";
echo "</div>";

// ============================================
// 4. CHECK REQUIRED FILES
// ============================================
echo "<div class='section'>";
echo "<h2>4. Required Files</h2>";

$requiredFiles = [
    'Database Config' => __DIR__ . '/config/database.php',
    'Image Config' => __DIR__ . '/config/image_optimizer_config.php',
    'Init Script' => __DIR__ . '/config/init.php',
    'API Endpoint' => __DIR__ . '/api/image-optimizer.php',
    'Image Controller' => __DIR__ . '/controllers/ImageProcessorController.php',
    'Image Model' => __DIR__ . '/models/ImageHistory.php',
    'View File' => __DIR__ . '/views/dashboard/image-optimizer.php',
    'JavaScript' => __DIR__ . '/assets/js/image-optimizer.js',
    'CSS' => __DIR__ . '/assets/css/image-optimizer.css'
];

echo "<table>";
echo "<tr><th>File</th><th>Status</th><th>Path</th></tr>";

foreach ($requiredFiles as $name => $path) {
    $exists = file_exists($path);
    $status = $exists ? 'ok' : 'fail';
    
    echo "<tr>";
    echo "<td>$name</td>";
    echo "<td><span class='status $status'>" . ($exists ? 'EXISTS' : 'MISSING') . "</span></td>";
    echo "<td><small>$path</small></td>";
    echo "</tr>";
}

echo "</table>";
echo "</div>";

// ============================================
// 5. CHECK SESSION & USER
// ============================================
echo "<div class='section'>";
echo "<h2>5. Session & Authentication</h2>";

session_start();

if (isset($_SESSION['user_id'])) {
    echo "<p class='success'>✓ User is logged in</p>";
    echo "<table>";
    echo "<tr><th>Session Key</th><th>Value</th></tr>";
    echo "<tr><td>User ID</td><td>" . $_SESSION['user_id'] . "</td></tr>";
    echo "<tr><td>Username</td><td>" . ($_SESSION['username'] ?? 'N/A') . "</td></tr>";
    echo "<tr><td>Email</td><td>" . ($_SESSION['email'] ?? 'N/A') . "</td></tr>";
    echo "</table>";
} else {
    echo "<p class='warning'>⚠ No user logged in (session not set)</p>";
}

echo "</div>";

// ============================================
// 6. TEST IMAGE PROCESSING
// ============================================
echo "<div class='section'>";
echo "<h2>6. Image Processing Test</h2>";

if ($hasGD || $hasImagick) {
    echo "<p>Creating test image and processing it...</p>";
    
    try {
        // Create a test image
        $testImage = imagecreatetruecolor(100, 100);
        $bgColor = imagecolorallocate($testImage, 0, 100, 200);
        imagefill($testImage, 0, 0, $bgColor);
        
        $testPath = IMG_TEMP_DIR . 'test_' . time() . '.jpg';
        
        if (imagejpeg($testImage, $testPath, 85)) {
            echo "<p class='success'>✓ Test image created successfully</p>";
            echo "<p>Path: $testPath</p>";
            echo "<p>Size: " . filesize($testPath) . " bytes</p>";
            
            // Try to process it
            require_once __DIR__ . '/controllers/ImageProcessorController.php';
            $processor = new ImageProcessorController();
            
            $metadata = $processor->getImageMetadata($testPath);
            echo "<p class='success'>✓ Image metadata extracted</p>";
            echo "<pre>" . print_r($metadata, true) . "</pre>";
            
            // Clean up
            @unlink($testPath);
            echo "<p class='success'>✓ Test image cleaned up</p>";
        } else {
            echo "<p class='error'>✗ Failed to create test image</p>";
        }
        
        imagedestroy($testImage);
        
    } catch (Exception $e) {
        echo "<p class='error'>✗ Image processing test failed: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p class='error'>✗ Cannot test - no image library available</p>";
}

echo "</div>";

// ============================================
// 7. TEST API ENDPOINT
// ============================================
echo "<div class='section'>";
echo "<h2>7. API Endpoint Test</h2>";

if (isset($_SESSION['user_id'])) {
    echo "<p>Testing API stats endpoint...</p>";
    
    // Simulate API call
    $_GET['action'] = 'stats';
    
    ob_start();
    include __DIR__ . '/api/image-optimizer.php';
    $apiResponse = ob_get_clean();
    
    echo "<p><strong>API Response:</strong></p>";
    echo "<pre>" . htmlspecialchars($apiResponse) . "</pre>";
    
    $decoded = json_decode($apiResponse, true);
    if ($decoded && isset($decoded['success'])) {
        if ($decoded['success']) {
            echo "<p class='success'>✓ API is working correctly</p>";
        } else {
            echo "<p class='error'>✗ API returned error: " . ($decoded['message'] ?? 'Unknown error') . "</p>";
        }
    } else {
        echo "<p class='error'>✗ API response is not valid JSON</p>";
    }
} else {
    echo "<p class='warning'>⚠ Cannot test API - no user logged in</p>";
}

echo "</div>";

// ============================================
// 8. RECOMMENDATIONS
// ============================================
echo "<div class='section'>";
echo "<h2>8. Recommendations & Next Steps</h2>";

$issues = [];

if (!$hasGD && !$hasImagick) {
    $issues[] = "Install GD Library or Imagick extension for image processing";
}

if (!$hasMySQLi) {
    $issues[] = "Install MySQLi extension for database operations";
}

// Check if tables are missing
try {
    $conn = getDBConnection();
    $result = $conn->query("SHOW TABLES LIKE 'image_processing_history'");
    if (!$result || $result->num_rows == 0) {
        $issues[] = "Import database schema: database/image_optimizer_schema.sql";
    }
    $conn->close();
} catch (Exception $e) {
    $issues[] = "Fix database connection issues";
}

// Check directories
foreach ($directories as $name => $path) {
    if (!file_exists($path)) {
        $issues[] = "Create missing directory: $path";
    } elseif (!is_writable($path)) {
        $issues[] = "Make directory writable: $path (chmod 755 or 777)";
    }
}

if (empty($issues)) {
    echo "<p class='success'>✓ <strong>All checks passed! Your Image Optimizer should be working.</strong></p>";
    echo "<p>If you're still having issues:</p>";
    echo "<ol>";
    echo "<li>Open browser console (F12) and check for JavaScript errors</li>";
    echo "<li>Check the Network tab in browser DevTools to see actual API responses</li>";
    echo "<li>Look for errors in: " . __DIR__ . "/error.log</li>";
    echo "</ol>";
} else {
    echo "<p class='error'><strong>Issues Found:</strong></p>";
    echo "<ol>";
    foreach ($issues as $issue) {
        echo "<li class='error'>$issue</li>";
    }
    echo "</ol>";
}

echo "</div>";

// ============================================
// 9. QUICK FIXES
// ============================================
echo "<div class='section'>";
echo "<h2>9. Quick Fix Scripts</h2>";

echo "<p>Run these scripts to fix common issues:</p>";
echo "<ul>";
echo "<li><a href='fix-image-optimizer.php' target='_blank'>fix-image-optimizer.php</a> - Create directories and fix permissions</li>";
echo "<li><a href='install_image_optimizer.php' target='_blank'>install_image_optimizer.php</a> - Install database tables</li>";
echo "<li><a href='status-image-optimizer.php' target='_blank'>status-image-optimizer.php</a> - Check current status</li>";
echo "</ul>";

echo "</div>";

echo "</body></html>";
