-- Competitor SEO Analysis Module Schema

USE u124793735_ai;

-- Competitor Profiles Table
CREATE TABLE IF NOT EXISTS competitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    primary_domain VARCHAR(500) NOT NULL,
    competitor_domain VARCHAR(500) NOT NULL,
    competitor_name VARCHAR(255) NULL,
    industry VARCHAR(200) NULL,
    discovery_method VARCHAR(100) NULL,
    status ENUM('active', 'archived') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_primary_domain (primary_domain(255)),
    INDEX idx_competitor_domain (competitor_domain(255)),
    INDEX idx_status (status),
    UNIQUE KEY unique_competitor (user_id, primary_domain(255), competitor_domain(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Keywords Table
CREATE TABLE IF NOT EXISTS competitor_keywords (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    keyword VARCHAR(500) NOT NULL,
    search_volume INT DEFAULT 0,
    keyword_difficulty INT DEFAULT 0,
    cpc_value DECIMAL(10,2) DEFAULT 0.00,
    position INT DEFAULT 0,
    url TEXT NULL,
    traffic_estimate INT DEFAULT 0,
    competition ENUM('low', 'medium', 'high') DEFAULT 'medium',
    trend VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (competitor_id) REFERENCES competitors(id) ON DELETE CASCADE,
    INDEX idx_competitor_id (competitor_id),
    INDEX idx_keyword (keyword(255)),
    INDEX idx_search_volume (search_volume),
    INDEX idx_position (position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Keyword Gap Analysis Table
CREATE TABLE IF NOT EXISTS keyword_gap_analysis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    primary_domain VARCHAR(500) NOT NULL,
    competitor_domain VARCHAR(500) NOT NULL,
    keyword VARCHAR(500) NOT NULL,
    gap_type ENUM('competitor_only', 'lower_ranking', 'missing_opportunity') NOT NULL,
    search_volume INT DEFAULT 0,
    competitor_position INT DEFAULT 0,
    our_position INT DEFAULT 0,
    keyword_difficulty INT DEFAULT 0,
    opportunity_score INT DEFAULT 0,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_gap_type (gap_type),
    INDEX idx_priority (priority),
    INDEX idx_opportunity_score (opportunity_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Content Analysis Table
CREATE TABLE IF NOT EXISTS competitor_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    url TEXT NOT NULL,
    title VARCHAR(500) NULL,
    word_count INT DEFAULT 0,
    content_type VARCHAR(100) NULL,
    publish_date DATE NULL,
    keywords_targeted TEXT NULL,
    headings_count INT DEFAULT 0,
    images_count INT DEFAULT 0,
    internal_links INT DEFAULT 0,
    external_links INT DEFAULT 0,
    readability_score INT DEFAULT 0,
    seo_score INT DEFAULT 0,
    social_shares INT DEFAULT 0,
    estimated_traffic INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (competitor_id) REFERENCES competitors(id) ON DELETE CASCADE,
    INDEX idx_competitor_id (competitor_id),
    INDEX idx_content_type (content_type),
    INDEX idx_word_count (word_count),
    INDEX idx_estimated_traffic (estimated_traffic)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Content Gap Analysis Table
CREATE TABLE IF NOT EXISTS content_gap_analysis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    primary_domain VARCHAR(500) NOT NULL,
    competitor_domain VARCHAR(500) NOT NULL,
    topic VARCHAR(500) NOT NULL,
    keyword_cluster TEXT NULL,
    competitor_urls TEXT NULL,
    our_coverage ENUM('none', 'partial', 'full') DEFAULT 'none',
    content_quality_gap INT DEFAULT 0,
    opportunity_score INT DEFAULT 0,
    recommended_action TEXT NULL,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_priority (priority),
    INDEX idx_opportunity_score (opportunity_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Backlinks Table
CREATE TABLE IF NOT EXISTS competitor_backlinks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    source_url TEXT NOT NULL,
    target_url TEXT NOT NULL,
    anchor_text VARCHAR(500) NULL,
    domain_authority INT DEFAULT 0,
    page_authority INT DEFAULT 0,
    link_type ENUM('dofollow', 'nofollow', 'ugc', 'sponsored') DEFAULT 'dofollow',
    first_seen DATE NULL,
    last_checked DATE NULL,
    status ENUM('active', 'lost', 'broken') DEFAULT 'active',
    spam_score INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (competitor_id) REFERENCES competitors(id) ON DELETE CASCADE,
    INDEX idx_competitor_id (competitor_id),
    INDEX idx_link_type (link_type),
    INDEX idx_status (status),
    INDEX idx_domain_authority (domain_authority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Top Pages Table
CREATE TABLE IF NOT EXISTS competitor_top_pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    url TEXT NOT NULL,
    title VARCHAR(500) NULL,
    estimated_traffic INT DEFAULT 0,
    ranking_keywords INT DEFAULT 0,
    backlinks_count INT DEFAULT 0,
    social_shares INT DEFAULT 0,
    page_authority INT DEFAULT 0,
    content_type VARCHAR(100) NULL,
    last_updated DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (competitor_id) REFERENCES competitors(id) ON DELETE CASCADE,
    INDEX idx_competitor_id (competitor_id),
    INDEX idx_estimated_traffic (estimated_traffic),
    INDEX idx_ranking_keywords (ranking_keywords)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Traffic Estimates Table
CREATE TABLE IF NOT EXISTS competitor_traffic (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    month_year DATE NOT NULL,
    organic_traffic INT DEFAULT 0,
    paid_traffic INT DEFAULT 0,
    direct_traffic INT DEFAULT 0,
    referral_traffic INT DEFAULT 0,
    social_traffic INT DEFAULT 0,
    total_traffic INT DEFAULT 0,
    bounce_rate DECIMAL(5,2) DEFAULT 0.00,
    avg_session_duration INT DEFAULT 0,
    pages_per_session DECIMAL(5,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (competitor_id) REFERENCES competitors(id) ON DELETE CASCADE,
    INDEX idx_competitor_id (competitor_id),
    INDEX idx_month_year (month_year),
    INDEX idx_total_traffic (total_traffic),
    UNIQUE KEY unique_traffic (competitor_id, month_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SERP Comparison Table
CREATE TABLE IF NOT EXISTS serp_comparison (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    keyword VARCHAR(500) NOT NULL,
    location VARCHAR(200) NULL,
    primary_domain VARCHAR(500) NOT NULL,
    primary_position INT DEFAULT 0,
    primary_url TEXT NULL,
    competitor_domain VARCHAR(500) NOT NULL,
    competitor_position INT DEFAULT 0,
    competitor_url TEXT NULL,
    search_volume INT DEFAULT 0,
    serp_features TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_keyword (keyword(255)),
    INDEX idx_primary_position (primary_position),
    INDEX idx_competitor_position (competitor_position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Meta Analysis Table
CREATE TABLE IF NOT EXISTS competitor_meta_analysis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    url TEXT NOT NULL,
    title VARCHAR(500) NULL,
    title_length INT DEFAULT 0,
    meta_description TEXT NULL,
    description_length INT DEFAULT 0,
    h1_tag VARCHAR(500) NULL,
    canonical_url TEXT NULL,
    robots_meta VARCHAR(200) NULL,
    og_tags TEXT NULL,
    twitter_tags TEXT NULL,
    schema_markup TEXT NULL,
    has_favicon TINYINT(1) DEFAULT 0,
    meta_quality_score INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (competitor_id) REFERENCES competitors(id) ON DELETE CASCADE,
    INDEX idx_competitor_id (competitor_id),
    INDEX idx_meta_quality_score (meta_quality_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Change Monitoring Table
CREATE TABLE IF NOT EXISTS competitor_change_monitoring (
    id INT AUTO_INCREMENT PRIMARY KEY,
    competitor_id INT NOT NULL,
    change_type ENUM('content', 'ranking', 'backlink', 'traffic', 'technical', 'meta') NOT NULL,
    change_description TEXT NOT NULL,
    old_value TEXT NULL,
    new_value TEXT NULL,
    impact_level ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    url TEXT NULL,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (competitor_id) REFERENCES competitors(id) ON DELETE CASCADE,
    INDEX idx_competitor_id (competitor_id),
    INDEX idx_change_type (change_type),
    INDEX idx_impact_level (impact_level),
    INDEX idx_detected_at (detected_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Competitor Analysis Reports Table
CREATE TABLE IF NOT EXISTS competitor_analysis_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    primary_domain VARCHAR(500) NOT NULL,
    competitors_analyzed TEXT NOT NULL,
    report_type VARCHAR(100) NOT NULL,
    summary TEXT NULL,
    key_findings TEXT NULL,
    opportunities TEXT NULL,
    threats TEXT NULL,
    recommendations TEXT NULL,
    report_data LONGTEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_report_type (report_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
