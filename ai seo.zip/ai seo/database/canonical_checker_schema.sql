-- Canonical URL Checker Database Schema
-- Add these tables to your database

-- Table for storing canonical check history
CREATE TABLE IF NOT EXISTS `canonical_checks` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `urls_checked` TEXT NOT NULL,
    `total_checked` INT NOT NULL DEFAULT 0,
    `missing_canonical` INT NOT NULL DEFAULT 0,
    `incorrect_canonical` INT NOT NULL DEFAULT 0,
    `has_canonical` INT NOT NULL DEFAULT 0,
    `results_json` LONGTEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_date` (`user_id`, `created_at`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for storing canonical issues and fixes
CREATE TABLE IF NOT EXISTS `canonical_issues` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `check_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `url` VARCHAR(500) NOT NULL,
    `current_canonical` VARCHAR(500) DEFAULT NULL,
    `recommended_canonical` VARCHAR(500) DEFAULT NULL,
    `status` ENUM('missing', 'incorrect', 'correct', 'self') NOT NULL,
    `ai_recommendation` TEXT,
    `seo_impact` TEXT,
    `fix_code` TEXT,
    `is_fixed` TINYINT(1) DEFAULT 0,
    `fixed_at` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`check_id`) REFERENCES `canonical_checks`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_check` (`check_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_url` (`url`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table for storing canonical checker statistics
CREATE TABLE IF NOT EXISTS `canonical_stats` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `date` DATE NOT NULL,
    `total_checks` INT DEFAULT 0,
    `total_urls_checked` INT DEFAULT 0,
    `total_missing` INT DEFAULT 0,
    `total_incorrect` INT DEFAULT 0,
    `total_correct` INT DEFAULT 0,
    `total_fixed` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_user_date` (`user_id`, `date`),
    INDEX `idx_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data (optional - for testing)
-- INSERT INTO canonical_checks (user_id, urls_checked, total_checked, missing_canonical, incorrect_canonical, has_canonical, results_json)
-- VALUES (1, '["https://example.com", "https://example.com/about"]', 2, 1, 0, 1, '[]');
