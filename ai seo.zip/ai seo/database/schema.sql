-- Create Database (Database already created in Hostinger: u124793735_ai)
-- CREATE DATABASE IF NOT EXISTS u124793735_ai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE u124793735_ai;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    remember_token VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_remember_token (remember_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user (password: admin123)
INSERT INTO users (name, email, password, role) VALUES 
('Admin User', 'admin@aurify.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Session Table (optional, for database-based sessions)
CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id INT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    payload TEXT NOT NULL,
    last_activity INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_last_activity (last_activity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Password Reset Tokens Table
CREATE TABLE IF NOT EXISTS password_resets (
    email VARCHAR(100) NOT NULL,
    token VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Websites Table for Audit Module
CREATE TABLE IF NOT EXISTS websites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    url VARCHAR(500) NOT NULL,
    title VARCHAR(255) NULL,
    description TEXT NULL,
    meta_keywords TEXT NULL,
    language VARCHAR(50) NULL,
    ssl_enabled TINYINT(1) DEFAULT 0,
    cms_detected VARCHAR(100) NULL,
    server_info VARCHAR(255) NULL,
    country VARCHAR(100) NULL,
    ip_address VARCHAR(50) NULL,
    response_time INT NULL,
    seo_score INT DEFAULT 0,
    status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_url (url(255)),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Audit Details Table
CREATE TABLE IF NOT EXISTS audit_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    website_id INT NOT NULL,
    heading_h1 INT DEFAULT 0,
    heading_h2 INT DEFAULT 0,
    heading_h3 INT DEFAULT 0,
    images_count INT DEFAULT 0,
    images_with_alt INT DEFAULT 0,
    links_internal INT DEFAULT 0,
    links_external INT DEFAULT 0,
    page_size INT NULL,
    load_time DECIMAL(10,2) NULL,
    mobile_friendly TINYINT(1) DEFAULT 0,
    has_robots_txt TINYINT(1) DEFAULT 0,
    has_sitemap TINYINT(1) DEFAULT 0,
    has_analytics TINYINT(1) DEFAULT 0,
    social_media_tags TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE,
    INDEX idx_website_id (website_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PageSpeed Reports Table
CREATE TABLE IF NOT EXISTS pagespeed_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    website_id INT NOT NULL,
    device_type ENUM('desktop', 'mobile') NOT NULL,
    performance_score INT DEFAULT 0,
    accessibility_score INT DEFAULT 0,
    best_practices_score INT DEFAULT 0,
    seo_score INT DEFAULT 0,
    lcp_value DECIMAL(10,2) NULL,
    lcp_score INT DEFAULT 0,
    cls_value DECIMAL(10,4) NULL,
    cls_score INT DEFAULT 0,
    fid_value DECIMAL(10,2) NULL,
    fid_score INT DEFAULT 0,
    ttfb_value DECIMAL(10,2) NULL,
    ttfb_score INT DEFAULT 0,
    speed_index_value DECIMAL(10,2) NULL,
    speed_index_score INT DEFAULT 0,
    fcp_value DECIMAL(10,2) NULL,
    fcp_score INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE,
    INDEX idx_website_id (website_id),
    INDEX idx_device_type (device_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Technical SEO Issues Table
CREATE TABLE IF NOT EXISTS seo_issues (
    id INT AUTO_INCREMENT PRIMARY KEY,
    website_id INT NOT NULL,
    category VARCHAR(100) NOT NULL,
    issue_type VARCHAR(100) NOT NULL,
    status ENUM('pass', 'warning', 'error') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    message TEXT NOT NULL,
    recommendation TEXT NOT NULL,
    priority INT DEFAULT 0,
    details TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE,
    INDEX idx_website_id (website_id),
    INDEX idx_status (status),
    INDEX idx_severity (severity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings Table
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NULL,
    setting_type ENUM('text', 'number', 'boolean', 'json') DEFAULT 'text',
    description TEXT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_setting_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- n8n Webhook Logs Table
CREATE TABLE IF NOT EXISTS n8n_webhook_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    website_id INT NULL,
    webhook_url VARCHAR(500) NOT NULL,
    request_data TEXT NULL,
    response_data TEXT NULL,
    status ENUM('pending', 'success', 'failed', 'retry') NOT NULL,
    status_code INT NULL,
    error_message TEXT NULL,
    retry_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE SET NULL,
    INDEX idx_website_id (website_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT INTO settings (setting_key, setting_value, setting_type, description) VALUES
('n8n_webhook_enabled', '1', 'boolean', 'Enable/Disable n8n webhook integration'),
('n8n_webhook_url', '', 'text', 'n8n webhook URL for sending audit data'),
('n8n_retry_enabled', '1', 'boolean', 'Enable automatic retry on failure'),
('n8n_max_retries', '3', 'number', 'Maximum number of retry attempts'),
('n8n_timeout', '30', 'number', 'Webhook request timeout in seconds')
ON DUPLICATE KEY UPDATE setting_value=setting_value;

-- AI Recommendations Table
CREATE TABLE IF NOT EXISTS ai_recommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    website_id INT NOT NULL,
    summary TEXT NOT NULL,
    top_problems TEXT NULL,
    business_impact TEXT NULL,
    priority_actions TEXT NULL,
    solutions TEXT NULL,
    estimated_improvements TEXT NULL,
    raw_response LONGTEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE,
    INDEX idx_website_id (website_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Keywords Table (Phase 8)
CREATE TABLE IF NOT EXISTS keywords (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    website_url VARCHAR(500) NOT NULL,
    industry VARCHAR(200) NOT NULL,
    location VARCHAR(200) NULL,
    primary_keywords TEXT NULL,
    secondary_keywords TEXT NULL,
    long_tail_keywords TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Meta Tags Table (Phase 9)
CREATE TABLE IF NOT EXISTS meta_tags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    focus_keyword VARCHAR(200) NOT NULL,
    seo_title VARCHAR(255) NOT NULL,
    meta_description TEXT NOT NULL,
    og_title VARCHAR(255) NULL,
    og_description TEXT NULL,
    og_image VARCHAR(500) NULL,
    twitter_title VARCHAR(255) NULL,
    twitter_description TEXT NULL,
    twitter_image VARCHAR(500) NULL,
    seo_score INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Blog Posts Table (Phase 10)
CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    keyword VARCHAR(200) NOT NULL,
    word_count INT DEFAULT 1500,
    language VARCHAR(50) DEFAULT 'English',
    tone VARCHAR(50) DEFAULT 'professional',
    title VARCHAR(255) NOT NULL,
    outline TEXT NULL,
    introduction TEXT NULL,
    content LONGTEXT NULL,
    faq TEXT NULL,
    call_to_action TEXT NULL,
    seo_score INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at),
    INDEX idx_keyword (keyword)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PDF Reports Table (Phase 14)
CREATE TABLE IF NOT EXISTS pdf_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    website_id INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (website_id) REFERENCES websites(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_website_id (website_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Email Logs Table (Phase 15)
CREATE TABLE IF NOT EXISTS email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    recipient_email VARCHAR(255) NOT NULL,
    report_id INT NULL,
    status ENUM('sent', 'failed', 'pending') DEFAULT 'pending',
    error_message TEXT NULL,
    sent_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

