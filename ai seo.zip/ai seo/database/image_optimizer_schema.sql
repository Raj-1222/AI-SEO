-- Image Optimization Suite Database Schema
-- Run this SQL file to create all necessary tables

-- Image Optimizer Settings Table
CREATE TABLE IF NOT EXISTS `image_optimizer_settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `default_quality` INT DEFAULT 85,
    `default_format` VARCHAR(10) DEFAULT 'webp',
    `auto_backup` TINYINT(1) DEFAULT 1,
    `watermark_enabled` TINYINT(1) DEFAULT 0,
    `watermark_text` VARCHAR(255) DEFAULT NULL,
    `watermark_position` VARCHAR(20) DEFAULT 'bottom-right',
    `watermark_opacity` INT DEFAULT 50,
    `max_upload_size` INT DEFAULT 10485760, -- 10MB in bytes
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Image Processing History Table
CREATE TABLE IF NOT EXISTS `image_processing_history` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `original_name` VARCHAR(255) NOT NULL,
    `original_path` VARCHAR(500) NOT NULL,
    `optimized_name` VARCHAR(255) NOT NULL,
    `optimized_path` VARCHAR(500) NOT NULL,
    `original_size` BIGINT NOT NULL, -- in bytes
    `optimized_size` BIGINT NOT NULL, -- in bytes
    `compression_ratio` DECIMAL(5,2) NOT NULL, -- percentage
    `saved_bytes` BIGINT NOT NULL,
    `original_format` VARCHAR(10) NOT NULL,
    `optimized_format` VARCHAR(10) NOT NULL,
    `original_width` INT NOT NULL,
    `original_height` INT NOT NULL,
    `optimized_width` INT NOT NULL,
    `optimized_height` INT NOT NULL,
    `quality_used` INT DEFAULT 85,
    `compression_type` VARCHAR(20) DEFAULT 'medium', -- lossless, low, medium, high, maximum
    `operation_type` VARCHAR(50) DEFAULT 'compression', -- compression, resize, convert, watermark, crop, rotate
    `processing_time` DECIMAL(6,3) DEFAULT NULL, -- seconds
    `download_count` INT DEFAULT 0,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(500) DEFAULT NULL,
    `status` VARCHAR(20) DEFAULT 'completed', -- pending, processing, completed, failed
    `error_message` TEXT DEFAULT NULL,
    `metadata` TEXT DEFAULT NULL, -- JSON format for additional data
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_created` (`user_id`, `created_at`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Image Optimizer Statistics Table
CREATE TABLE IF NOT EXISTS `image_optimizer_stats` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `date` DATE NOT NULL,
    `total_images_processed` INT DEFAULT 0,
    `total_storage_saved` BIGINT DEFAULT 0, -- in bytes
    `total_downloads` INT DEFAULT 0,
    `total_compressions` INT DEFAULT 0,
    `total_resizes` INT DEFAULT 0,
    `total_conversions` INT DEFAULT 0,
    `total_watermarks` INT DEFAULT 0,
    `total_crops` INT DEFAULT 0,
    `total_rotations` INT DEFAULT 0,
    `avg_compression_ratio` DECIMAL(5,2) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    UNIQUE KEY `unique_user_date` (`user_id`, `date`),
    INDEX `idx_user_date` (`user_id`, `date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Batch Processing Queue Table
CREATE TABLE IF NOT EXISTS `image_batch_queue` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `batch_id` VARCHAR(50) NOT NULL,
    `total_images` INT NOT NULL,
    `processed_images` INT DEFAULT 0,
    `failed_images` INT DEFAULT 0,
    `status` VARCHAR(20) DEFAULT 'pending', -- pending, processing, completed, failed
    `operation_type` VARCHAR(50) NOT NULL,
    `settings` TEXT NOT NULL, -- JSON format
    `zip_path` VARCHAR(500) DEFAULT NULL,
    `zip_size` BIGINT DEFAULT NULL,
    `started_at` TIMESTAMP NULL DEFAULT NULL,
    `completed_at` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_batch_id` (`batch_id`),
    INDEX `idx_user_status` (`user_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Watermark Templates Table
CREATE TABLE IF NOT EXISTS `watermark_templates` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `template_name` VARCHAR(100) NOT NULL,
    `watermark_type` VARCHAR(20) NOT NULL, -- text, image
    `watermark_text` VARCHAR(255) DEFAULT NULL,
    `watermark_image_path` VARCHAR(500) DEFAULT NULL,
    `position` VARCHAR(20) DEFAULT 'bottom-right',
    `opacity` INT DEFAULT 50,
    `font_size` INT DEFAULT 24,
    `font_color` VARCHAR(20) DEFAULT '#FFFFFF',
    `is_default` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_user_default` (`user_id`, `is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Image Presets Table (for resize presets)
CREATE TABLE IF NOT EXISTS `image_resize_presets` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT DEFAULT NULL, -- NULL for system presets
    `preset_name` VARCHAR(100) NOT NULL,
    `width` INT NOT NULL,
    `height` INT NOT NULL,
    `maintain_aspect_ratio` TINYINT(1) DEFAULT 1,
    `is_system_preset` TINYINT(1) DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `sort_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_system_active` (`is_system_preset`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert System Presets
INSERT INTO `image_resize_presets` (`preset_name`, `width`, `height`, `is_system_preset`, `sort_order`) VALUES
('Instagram Post', 1080, 1080, 1, 1),
('Instagram Story', 1080, 1920, 1, 2),
('Facebook Post', 1200, 630, 1, 3),
('LinkedIn Post', 1200, 627, 1, 4),
('Twitter Post', 1600, 900, 1, 5),
('YouTube Thumbnail', 1280, 720, 1, 6),
('Website Banner', 1920, 600, 1, 7),
('Hero Section', 1920, 1080, 1, 8),
('Product Image', 800, 800, 1, 9),
('Blog Featured', 1200, 630, 1, 10),
('Logo', 512, 512, 1, 11),
('Favicon', 32, 32, 1, 12);

-- Image Downloads Log Table
CREATE TABLE IF NOT EXISTS `image_download_log` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `history_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `download_type` VARCHAR(20) NOT NULL, -- original, optimized, zip
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(500) DEFAULT NULL,
    `downloaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`history_id`) REFERENCES `image_processing_history`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    INDEX `idx_history` (`history_id`),
    INDEX `idx_user_date` (`user_id`, `downloaded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Image SEO Scores Table
CREATE TABLE IF NOT EXISTS `image_seo_scores` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `history_id` INT NOT NULL,
    `filename_score` INT DEFAULT 0, -- 0-100
    `format_score` INT DEFAULT 0, -- 0-100
    `size_score` INT DEFAULT 0, -- 0-100
    `dimension_score` INT DEFAULT 0, -- 0-100
    `metadata_score` INT DEFAULT 0, -- 0-100
    `overall_score` INT DEFAULT 0, -- 0-100
    `recommendations` TEXT DEFAULT NULL, -- JSON format
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`history_id`) REFERENCES `image_processing_history`(`id`) ON DELETE CASCADE,
    INDEX `idx_history` (`history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create indexes for better performance
ALTER TABLE `image_processing_history` ADD INDEX `idx_user_operation` (`user_id`, `operation_type`);
ALTER TABLE `image_processing_history` ADD INDEX `idx_compression_type` (`compression_type`);
ALTER TABLE `image_optimizer_stats` ADD INDEX `idx_date` (`date`);
