<?php
/**
 * Quick Audit Test - Minimal test to see raw API responses
 * This bypasses all the dashboard code and directly calls the APIs
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html><head><title>Quick Audit Test</title>";
echo "<style>body{font-family:monospace;padding:20px;background:#f5f5f5}";
echo ".box{background:white;padding:20px;margin:20px 0;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}";
echo ".success{color:#28a745}.error{color:#dc3545}.warning{color:#ffc107}";
echo "pre{background:#f8f9fa;padding:15px;border-radius:4px;overflow-x:auto}</style></head><body>";

echo "<h1>🔍 Quick Audit API Test</h1>";
echo "<p>Testing all three audit APIs with minimal setup</p>";

// Start session for authentication
session_start();

// Check/create test session
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 2; // Your user ID from error logs
    echo "<div class='box warning'><b>⚠️ Created test session with user_id = 2</b></div>";
}

$testUrl = 'https://example.com';
echo "<div class='box'><b>Test URL:</b> $testUrl</div>";

// Function to test API
function testAPI($apiName, $apiPath, $postData) {
    echo "<div class='box'>";
    echo "<h2>Testing: $apiName</h2>";
    
    $url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/" . $apiPath;
    echo "<p><b>API URL:</b> $url</p>";
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($postData),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Cookie: ' . session_name() . '=' . session_id()
        ],
        CURLOPT_TIMEOUT => 30
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    echo "<p><b>HTTP Code:</b> <span class='" . ($httpCode == 200 ? 'success' : 'error') . "'>$httpCode</span></p>";
    
    if ($curlError) {
        echo "<p class='error'><b>CURL Error:</b> $curlError</p>";
        echo "</div>";
        return null;
    }
    
    // Show first 500 characters of response
    echo "<p><b>Response Preview (first 500 chars):</b></p>";
    echo "<pre>" . htmlspecialchars(substr($response, 0, 500)) . "...</pre>";
    
    // Check if it's valid JSON
    $data = json_decode($response, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        echo "<p class='success'><b>✅ VALID JSON</b></p>";
        echo "<p><b>Success:</b> " . ($data['success'] ? '<span class="success">true</span>' : '<span class="error">false</span>') . "</p>";
        echo "<p><b>Message:</b> " . htmlspecialchars($data['message'] ?? 'N/A') . "</p>";
        
        if (isset($data['website_id'])) {
            echo "<p><b>Website ID:</b> {$data['website_id']}</p>";
        }
        
        echo "<details><summary><b>Full Response Data</b></summary>";
        echo "<pre>" . htmlspecialchars(json_encode($data, JSON_PRETTY_PRINT)) . "</pre>";
        echo "</details>";
        
        echo "</div>";
        return $data;
    } else {
        echo "<p class='error'><b>❌ INVALID JSON</b></p>";
        echo "<p><b>JSON Error:</b> " . json_last_error_msg() . "</p>";
        echo "<p><b>Response starts with:</b> <code>" . htmlspecialchars(substr($response, 0, 100)) . "</code></p>";
        
        // Check if it's HTML
        if (stripos($response, '<!DOCTYPE') !== false || stripos($response, '<html') !== false) {
            echo "<p class='error'><b>⚠️ API returned HTML instead of JSON!</b></p>";
            echo "<p>This means there's a PHP error or warning being output before the JSON.</p>";
            echo "<details><summary><b>Full HTML Response</b></summary>";
            echo "<pre>" . htmlspecialchars($response) . "</pre>";
            echo "</details>";
        }
        
        echo "</div>";
        return null;
    }
}

// Test 1: Basic Audit
$audit1 = testAPI('Basic Website Audit', 'api/audit.php', [
    'url' => $testUrl
]);

$websiteId = 1;
if ($audit1 && isset($audit1['website_id'])) {
    $websiteId = $audit1['website_id'];
}

// Test 2: PageSpeed
$audit2 = testAPI('PageSpeed Insights', 'api/pagespeed.php', [
    'url' => $testUrl,
    'website_id' => $websiteId
]);

// Test 3: Technical SEO
$audit3 = testAPI('Technical SEO Scan', 'api/technical-seo.php', [
    'url' => $testUrl,
    'website_id' => $websiteId
]);

// Summary
echo "<div class='box' style='background:#e8f5e9'>";
echo "<h2>📊 Test Summary</h2>";
echo "<p><b>audit.php:</b> " . ($audit1 ? '<span class="success">✅ PASS</span>' : '<span class="error">❌ FAIL</span>') . "</p>";
echo "<p><b>pagespeed.php:</b> " . ($audit2 ? '<span class="success">✅ PASS</span>' : '<span class="error">❌ FAIL</span>') . "</p>";
echo "<p><b>technical-seo.php:</b> " . ($audit3 ? '<span class="success">✅ PASS</span>' : '<span class="error">❌ FAIL</span>') . "</p>";

if ($audit1 && $audit2 && $audit3) {
    echo "<hr><h3 class='success'>🎉 ALL TESTS PASSED!</h3>";
    echo "<p>All APIs are returning valid JSON. The Website Audit module should now work correctly.</p>";
    echo "<p><b>Next Steps:</b></p>";
    echo "<ol>";
    echo "<li>Clear your browser cache (Ctrl+Shift+Delete)</li>";
    echo "<li>Go to Dashboard → Website Audit</li>";
    echo "<li>Open Browser Console (F12)</li>";
    echo "<li>Try auditing a website and watch the console logs</li>";
    echo "</ol>";
} else {
    echo "<hr><h3 class='error'>⚠️ SOME TESTS FAILED</h3>";
    echo "<p>One or more APIs are not returning valid JSON. This is why the Website Audit module is failing.</p>";
    echo "<p><b>Troubleshooting Steps:</b></p>";
    echo "<ol>";
    echo "<li>Look at the HTML response above to see the actual error</li>";
    echo "<li>Check <a href='view-errors.php'>view-errors.php</a> for PHP errors</li>";
    echo "<li>Verify database connection in config/database.php</li>";
    echo "<li>Ensure all required database tables exist</li>";
    echo "</ol>";
}
echo "</div>";

echo "<div class='box'>";
echo "<h3>💡 Additional Info</h3>";
echo "<p><b>Session ID:</b> " . session_id() . "</p>";
echo "<p><b>User ID:</b> " . ($_SESSION['user_id'] ?? 'Not set') . "</p>";
echo "<p><b>Server Time:</b> " . date('Y-m-d H:i:s') . "</p>";
echo "<p><b>PageSpeed API Key:</b> " . (defined('PAGESPEED_API_KEY') ? (strlen(PAGESPEED_API_KEY) > 10 ? 'Configured ✅' : 'Not configured ❌') : 'Not loaded ❌') . "</p>";
echo "</div>";

echo "</body></html>";
