# ⚡ Quick Start Guide

## 🎯 For New Users Installing This Project

### 1️⃣ Clone Repository
```bash
git clone https://github.com/yourusername/ai-seo.git
cd ai-seo
```

### 2️⃣ Setup Database
```bash
# Create database
mysql -u root -p -e "CREATE DATABASE aurify_seo"

# Import schema
mysql -u root -p aurify_seo < database/schema.sql
```

### 3️⃣ Configure
```bash
# Copy example config
cp config/database.example.php config/database.php

# Edit with your credentials
notepad config/database.php
```

### 4️⃣ Access
- **URL:** http://localhost/ai-seo
- **Login:** admin@aurify.com / admin123
- **⚠️ Change password immediately!**

📖 **Full setup:** See [SETUP.md](SETUP.md)

---

## 🚀 For Project Owner Pushing to GitHub

### Before First Push

1. **Verify sensitive data is removed:**
```bash
# Check config file
notepad "config/database.php"
# Should show "your_database_password" NOT real password
```

2. **Save your real credentials somewhere safe!**
   - See `SECURITY_CLEANUP_SUMMARY.md` for your credentials
   - Save to password manager or secure notes
   - **DO NOT commit them!**

3. **Push to GitHub:**
```bash
git init
git add .
git commit -m "Initial commit: AI SEO Platform"
git remote add origin https://github.com/yourusername/ai-seo.git
git push -u origin main
```

4. **After pushing - Restore local config:**
```bash
# Edit config/database.php with your REAL credentials
notepad "config/database.php"
# Git will ignore it (it's in .gitignore)
```

📋 **Full checklist:** See [GITHUB_PUSH_CHECKLIST.md](GITHUB_PUSH_CHECKLIST.md)

---

## 📚 Documentation Index

| Document | Purpose |
|----------|---------|
| **README.md** | Main project documentation |
| **SETUP.md** | Detailed installation guide |
| **SECURITY.md** | Security best practices |
| **GITHUB_PUSH_CHECKLIST.md** | Pre-push verification |
| **SECURITY_CLEANUP_SUMMARY.md** | What was secured & removed |
| **CONTRIBUTING.md** | How to contribute |
| **QUICK_START.md** | This file |

---

## 🔑 Important Files

### 🔒 Protected (Never Commit)
- `config/database.php` - Your real credentials
- `.env` - Environment variables
- `logs/*.log` - Application logs
- `uploads/*` - User uploads

### 📝 Templates (Safe to Commit)
- `config/database.example.php` - Config template
- `.env.example` - Environment template

### ⚙️ Must Configure
1. `config/database.php` - Database & API keys
2. `.htaccess` - Apache configuration (if needed)
3. File permissions - uploads, logs folders

---

## 🎯 Common Tasks

### Run Website Audit
```
Dashboard → Website Audit → Enter URL → Generate Report
```

### Generate AI Content
```
Dashboard → Blog Generator → Enter Topic → Generate
```

### Analyze Competitor
```
Dashboard → Competitor SEO → Enter URLs → Analyze
```

### Optimize Images
```
Dashboard → Image Optimizer → Upload → Optimize
```

### Generate Keywords
```
Dashboard → Keywords → Enter Seed Keyword → Generate
```

---

## 🆘 Quick Troubleshooting

### "Database connection failed"
```bash
# Check credentials in config/database.php
# Verify MySQL is running
sudo systemctl status mysql
```

### "Permission denied"
```bash
# Fix permissions
chmod 777 uploads logs cache
```

### "API key invalid"
```bash
# Add API keys in config/database.php
define('OPENAI_API_KEY', 'sk-proj-xxxxx');
define('PAGESPEED_API_KEY', 'AIzaSyxxxxx');
```

### "White page / Error 500"
```bash
# Check error logs
tail -f logs/error.log
```

---

## 📞 Get Help

- 📖 **Full Docs:** See README.md
- 🔒 **Security:** See SECURITY.md  
- 🛠️ **Setup:** See SETUP.md
- 🐛 **Issues:** [GitHub Issues](https://github.com/yourusername/ai-seo/issues)

---

**Ready to optimize? Let's go! 🚀**
